import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class UserApiUsageHistory {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	userId: number;

	@ApiProperty()
	@Column()
	route: string;

	@ApiProperty()
	@Column({ nullable: true })
	body: string;

	@ApiProperty()
	@Column({ nullable: true })
	query: string;

	@ApiProperty()
	@Column({ nullable: true })
	params: string;

	@ApiProperty()
	@Column({ nullable: true })
	State: string;

	@ApiProperty()
	@Column({ nullable: true })
	City: string;

	@ApiProperty()
	@Column({ nullable: true })
	Pincode: string;

	@ApiProperty()
	@Column({ nullable: true })
	Taluka: string;

	@ApiProperty()
	@Column({ nullable: true })
	District: string;

	@ApiProperty()
	@Column({ default: "india" })
	Country: string;

	@ApiProperty()
	@Column({ nullable: true })
	layer: string;

	@ApiProperty()
	@Column({
		nullable: true,
		type: "varchar",
		array: true,
	})
	layerType: string[];

	@ApiProperty()
	@Column({
		nullable: true,
	})
	ipAddress: string;

	@CreateDateColumn()
	createdAt: Date;

	@ApiProperty()
	@Column({ default: 0 })
	creditsUsed: number;
}

export class CreditsSpentQuery {
	startTime: Date;
	endTime: Date;
	userIds: number[];
	teamIds: number[];
	groupBy: "user" | "location" | "layerType" | "time";
}
