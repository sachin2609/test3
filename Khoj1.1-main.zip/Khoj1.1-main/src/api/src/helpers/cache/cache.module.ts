import { Module } from "@nestjs/common";
import { CacheModule } from "@nestjs/cache-manager";
import { HttpModule } from "@nestjs/axios";
import { CacheController } from "./cache.controller";
import { CacheService } from "./cache.service";
import * as redisStore from "cache-manager-redis-store";

@Module({
	imports: [
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
		HttpModule.register({
			timeout: 1000000000,
			maxRedirects: 100,
		}),
	],
	providers: [CacheService],
	controllers: [CacheController],
})
export class Cache_Module {}
