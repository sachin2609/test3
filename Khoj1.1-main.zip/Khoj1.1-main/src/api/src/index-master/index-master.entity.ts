import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, Index } from "typeorm";
import { Grid } from "../grid/grids.entity";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class Indexmaster {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Index()
	@Column()
	indexName: string;

	@ApiProperty()
	@Index()
	@Column({ default: "number" })
	indexType: string;

	@ApiProperty()
	@Index()
	@Column("decimal", { default: 0 })
	indexValue: number;

	@ApiProperty()
	@Column("decimal", { default: 0 })
	percentile: number;

	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	categoricalValue: string;

	@ApiProperty()
	@Index()
	@ManyToOne(() => Grid, (grid) => grid.indexmaster)
	grid: Grid;

	@Column({ nullable: true })
	metrics: string;

	@Column({ nullable: true })
	description: string;
}
