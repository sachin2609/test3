import { Body, Controller, Headers, Post, HttpException, HttpStatus, Get } from "@nestjs/common";
import { ApiHeader, ApiResponse } from "@nestjs/swagger";
import { PoiPaginationDto } from "src/interfaces/poi";
import { Poi } from "src/poi/poi.entity";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { MerchantService } from "./merchant.service";
import { RolesGuardService } from "../helpers/roles-guard/roles-guard.service";
import { Header } from "../interfaces/header";
import { RealIP } from "nestjs-real-ip";
import { JwtService } from "@nestjs/jwt";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { User } from "src/users/users.entity";
import { FetchMerchantsBodyDto } from "src/interfaces/merchant";

@Controller("merchant")
export class MerchantController {
	constructor(
		private _merchantService: MerchantService,
		private _rolesGuardService: RolesGuardService,
		private _jwtService: JwtService,
	) {}

	@Roles("merchant_acquisition")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/acquisition")
	async acquisition(
		@Body() body,
		@Headers() header: Header,
		@RealIP() ip: string,
	): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			const resp = await this._merchantService.acquisition(body);
			await this._rolesGuardService.updateCreds(
				header.token,
				resp["count"] - 1,
				"/merchant/acquisition",
				ip,
				JSON.stringify(body),
			);
			return resp;
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("merchant_scorecard")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/acquisition-new")
	async acquisitionNew(
		@Body() body,
		@Headers() header: Header,
		@RealIP() ip: string,
	): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			const resp = await this._merchantService.acquisitionNew(body);
			console.log("deducting ", resp["count"]);
			const credsResp = await this._rolesGuardService.updateCreds(
				header.token,
				resp["count"] - 1,
				"/merchant/acquisition-new",
				ip,
				JSON.stringify(body),
			);
			console.log("response from creds deduction", credsResp);
			if (credsResp) {
				return resp;
			} else {
				throw new HttpException(
					{
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left",
					},
					HttpStatus.FORBIDDEN,
				);
			}
		} catch (error) {
			if (error.status == "403") {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/scorecard")
	async scorecard(
		@Body() body,
		@Headers() header: Header,
		@RealIP() ip: string,
	): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			const resp = await this._merchantService.scorecard(body);
			await this._rolesGuardService.updateCreds(
				header.token,
				resp["count"] - 1,
				"/merchant/scorecard",
				ip,
				JSON.stringify(body),
			);
			return resp;
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/scorecard-new")
	async scorecardNew(@Body() body): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			return await this._merchantService.scorecardNew(body);
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/scorecard-new-new")
	async scorecardNewNew(@Body() body): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			return await this._merchantService.scorecardNewNew(body);
		} catch (error) {
			if (error.status == 400) {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/personal-scorecard")
	async personalScorecard(@Body() body, @Headers() header): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			return await this._merchantService.personalScorecard(body, header["token"]);
		} catch (error) {
			if (error.status == 400) {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("save-against-user")
	async saveMerchantsAgainstUser(@Body() body, @Headers() headers) {
		const user = await this._jwtService.decode(
			headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"],
		);
		return await this._merchantService.saveMerchantsAgainstUser(user["id"] as number, body, user["type"]);
	}

	@Roles("merchant_acquisition")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("get-merchants")
	async getMerchantsAgainstIds(@Body() body, @Headers() header, @RealIP() ip: string) {
		const resp = await this._merchantService.getMerchantsAgainstIds(body);
		console.log("deducting ", resp["count"]);
		let credsResp;
		if (header.token) {
			credsResp = await this._rolesGuardService.updateCreds(
				header.token,
				resp["count"],
				"/merchant/get-merchants",
				ip,
				JSON.stringify(body),
			);
		} else {
			credsResp = await this._rolesGuardService.apiKeyUpdateCreds(
				header["apikey"],
				resp["count"],
				"/merchants/get-merchants",
				ip,
				JSON.stringify(body),
			);
		}
		console.log("response from creds deduction", credsResp);
		if (credsResp) {
			return resp;
		} else {
			throw new HttpException(
				{
					status: HttpStatus.FORBIDDEN,
					error: "Insufficient Credits Left",
				},
				HttpStatus.FORBIDDEN,
			);
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Get("get-merchantIds")
	async getMerchantIdsAgainstUser(@Headers() headers) {
		const user = this._jwtService.decode(
			headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"],
		);
		return await this._merchantService.getMerchantIdsAgainstUser(user["id"] as number, user["type"]);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("delete-against-user")
	async deleteMerchantsAgainstUser(@Body() body, @Headers() headers) {
		const user = await this._jwtService.decode(
			headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"],
		);
		return await this._merchantService.deleteMerchantsAgainstUser(user["id"] as number, body, user["type"]);
	}

	@Roles(Role.BASIC)
	@Post("fetch/count")
	async fetchCounts(@Headers() headers) {
		const user: Partial<User | ApiKeyUser> = this._jwtService.decode(
			headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"],
		) as Partial<User | ApiKeyUser>;
		return await this._merchantService.fetchCounts(user);
	}

	@Roles(Role.BASIC)
	@Post("fetch")
	async fetchMerchants(@Headers() headers, @Body() body: FetchMerchantsBodyDto) {
		try {
			const user: Partial<User | ApiKeyUser> = this._jwtService.decode(
				headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"],
			) as Partial<User | ApiKeyUser>;
			return await this._merchantService.fetch_merchants(body, user);
		} catch (error) {
			console.error(error);
			return { count: 0, data: [] };
		}
	}
}
