import { SetMetadata } from '@nestjs/common';

export const CacheKey = (cacheKeyValue) => SetMetadata('cache-key', cacheKeyValue);
export const CacheTime = (cacheTimeValue) => SetMetadata('cache-time', cacheTimeValue);