import { Controller } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
@ApiTags("poi-grid")
@Controller("poi-grid")
export class PoiGridController {}
