import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

export enum PropertyReviewStatus {
	notReviewed = "notReviewed",
	reviewed = "reviewed"
}

@Entity()
export class Property {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	name: string;

	@ApiProperty()
	@Column()
	building: string;

	@ApiProperty()
	@Column()
	street: string;

	@ApiProperty()
	@Column({ nullable: true })
	town: string;

	@ApiProperty()
	@Column()
	city: string;

	@ApiProperty()
	@Column({ nullable: true })
	landmark: string;

	@ApiProperty()
	@Column()
	pinCode: number;

	@ApiProperty()
	@Column({ default: "analyzer" })
	status: string;

	@ApiProperty()
	@Column("decimal", { nullable: true })
	latitude: number;

	@ApiProperty()
	@Column("decimal", { nullable: true })
	longitude: number;

	@ApiProperty()
	@CreateDateColumn()
	createdAt: Date;

	@ApiProperty()
	@Column({ default: PropertyReviewStatus.notReviewed })
	reviewStatus: PropertyReviewStatus;
}
