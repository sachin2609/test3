import { Test, TestingModule } from "@nestjs/testing";
import { InsghtGridController } from "./insght-grid.controller";

describe("InsghtGridController", () => {
	let controller: InsghtGridController;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			controllers: [InsghtGridController]
		}).compile();

		controller = module.get<InsghtGridController>(InsghtGridController);
	});

	it("should be defined", () => {
		expect(controller).toBeDefined();
	});
});
