import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { PropertyDetail } from "./property-detail.entity";
import { PropertyDetailController } from "./property-detail.controller";
import { PropertyDetailService } from "./property-detail.service";

@Module({
	imports: [TypeOrmModule.forFeature([PropertyDetail])],
	controllers: [PropertyDetailController],
	providers: [PropertyDetailService]
})
export class PropertyDetailModule {}
