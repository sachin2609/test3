import { Entity, PrimaryColumn, Column } from "typeorm";

@Entity()
export class LayerDetail {
	@PrimaryColumn()
	layerId: number;

	@PrimaryColumn()
	key: string;

	@Column()
	value: string;

	@Column({ default:"string" })
	dataType: string;

	@Column('decimal',{ nullable:true })
	unit: number;
}

