import { Process, Processor } from "@nestjs/bull";
import { Job } from "bull";
import { PropertyService } from "./property.service";
@Processor("uploadproperty")
export class PropertyProcessor {
	constructor(private _propertyService: PropertyService) {}
	@Process("processCsv")
	handleCsvParse(job: Job): void {
		console.log(job.data);
		setTimeout(() => {
			this._propertyService.parseCsv(job.data.filenames, job.data.userId);
		}, 200);
	}
}
