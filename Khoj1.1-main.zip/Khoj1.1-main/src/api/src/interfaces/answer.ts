import { ApiProperty } from "@nestjs/swagger";

export class AnswerSearch {
	@ApiProperty({ type: Array, description: "questionIds" })
	questionIds: [];

	@ApiProperty({ type: Number, description: "userId" })
	faId?: number;

	@ApiProperty({ type: Number, description: "userId" })
	userId?: number | string;

	@ApiProperty({ type: Array, description: "propertyId" })
	uniqueId?: [];

	@ApiProperty()
	userDetails?: boolean;

	@ApiProperty()
	answers?: string[];

	@ApiProperty()
	status?: string[];
}

export class AnswerBody {
	@ApiProperty({ type: Number, description: "questionId" })
	questionId: number;

	@ApiProperty({ type: Number, description: "userId" })
	userId: number;

	@ApiProperty({ type: Number, description: "propertyId" })
	propertyId: number;

	@ApiProperty()
	workItemId: number;

	@ApiProperty()
	answer: string[];

	@ApiProperty()
	remarks: string;
}
