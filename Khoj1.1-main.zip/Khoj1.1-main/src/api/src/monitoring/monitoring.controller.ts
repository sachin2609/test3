import { Body, Controller, Get, Headers, Header, Post, UseInterceptors, Req, HttpStatus } from "@nestjs/common";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { MonitoringService } from "./monitoring.service";
import { TeamService } from "src/team/team.service";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { LeadConversionQuery, LostOpportunityQuery, MonitoringQuery } from "src/interfaces/monitoring";
import { CacheTime } from "src/helpers/cache/cache-key.decorator";
import { CacheInterceptorInterceptor } from "src/helpers/cache/cache-interceptor.interceptor";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";
import { Request } from "express";
import { RealIP } from "nestjs-real-ip";

@Controller("monitor")
export class MonitoringController {
	constructor(
		private monitoringService: MonitoringService,
		private teamService: TeamService,
		private _syslogService: SyslogService,
	) {}

	@Roles(Role.BASIC)
	@Get()
	async getStats(@Headers() headers, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.getStats(user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Header("enable-compression", "true")
	@Roles(Role.BASIC, Role.ADMIN, Role.MAPS_USER)
	@Post("leads-category-count")
	@CacheTime(process.env.CACHE_TIME_IN_SEC)
	@UseInterceptors(CacheInterceptorInterceptor)
	async getTopCategories(@Headers() headers, @Body() body: MonitoringQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.getTopCategories(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Header("enable-compression", "true")
	@Roles(Role.BASIC, Role.ADMIN, Role.MAPS_USER)
	@Post("leads-category-gst-count")
	@CacheTime(process.env.CACHE_TIME_IN_SEC)
	@UseInterceptors(CacheInterceptorInterceptor)
	async getTopCategoriesGST(@Headers() headers, @Body() body: MonitoringQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.getTopCategoriesGST(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Header("enable-compression", "true")
	@Roles(Role.BASIC, Role.ADMIN, Role.MAPS_USER)
	@Post("top-reasons")
	@CacheTime(process.env.CACHE_TIME_IN_SEC)
	@UseInterceptors(CacheInterceptorInterceptor)
	async getTopReasons(@Headers() headers, @Body() body: MonitoringQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.getTopReasons(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Header("enable-compression", "true")
	@Roles(Role.BASIC, Role.ADMIN, Role.MAPS_USER)
	@CacheTime(process.env.CACHE_TIME_IN_SEC)
	@UseInterceptors(CacheInterceptorInterceptor)
	@Post("lead-conversion-timeline")
	async dayWiseLeadConversion(
		@Headers() headers,
		@Body() body: LeadConversionQuery,
		@Req() req: Request,
		@RealIP() ip,
	) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.getStatusConversionDistribution(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Header("enable-compression", "true")
	@Roles(Role.BASIC, Role.ADMIN, Role.MAPS_USER)
	@Post("user-activity")
	@CacheTime(process.env.CACHE_TIME_IN_SEC)
	@UseInterceptors(CacheInterceptorInterceptor)
	async userActivity(@Headers() headers, @Body() body: MonitoringQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.getUserActivity(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC, Role.ADMIN, Role.MAPS_USER)
	@Post("team-activity")
	async teamActivity(@Headers() headers, @Body() body: MonitoringQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.getTeamsStatsDistribution(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Header("enable-compression", "true")
	@Roles(Role.BASIC)
	@Post("in-progress-ageing")
	@CacheTime(process.env.CACHE_TIME_IN_SEC)
	@UseInterceptors(CacheInterceptorInterceptor)
	async inProgressAgeing(@Headers() headers, @Body() body: LeadConversionQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.getCurrentInProgressLeadsAgeing(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Header("enable-compression", "true")
	@Roles(Role.BASIC)
	@Post("lead-report")
	@CacheTime(process.env.CACHE_TIME_IN_SEC)
	@UseInterceptors(CacheInterceptorInterceptor)
	async report(@Headers() headers, @Body() body: MonitoringQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.merchantWiseReportHistory(body, user, false);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("lead-report-paginated")
	@CacheTime(process.env.CACHE_TIME_IN_SEC)
	@UseInterceptors(CacheInterceptorInterceptor)
	async leadReportPaginated(@Headers() headers, @Body() body: MonitoringQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.merchantWiseReportHistory(body, user, false, true);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("lead-report-historical")
	async reportHistorical(@Headers() headers, @Body() body: MonitoringQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.merchantWiseReportHistory(body, user, true);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Header("enable-compression", "true")
	@Roles(Role.BASIC)
	@Post("upcoming-reminder")
	@CacheTime(process.env.CACHE_TIME_IN_SEC)
	@UseInterceptors(CacheInterceptorInterceptor)
	async upcomingReminders(@Headers() headers, @Body() body: MonitoringQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				headers["token"] || headers["apikey"],
			);
			const res = await this.monitoringService.getUpcomingReminders(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("lost-opportunities")
	async lostOpportunities(@Headers() header, @Body() body: LostOpportunityQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user: Partial<User | ApiKeyUser> = await this.teamService.decodeUserJWT(
				header["token"] || header["apikey"],
			);
			const res = await this.monitoringService.fetchLostOpportunities(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}
}
