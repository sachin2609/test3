import { Role } from "src/relations/user-grid/user-grid.entity";
import { ApiProperty } from "@nestjs/swagger";

export class UserGridRequest {
	@ApiProperty()
	userId: number;

	@ApiProperty()
	zone: string;

	@ApiProperty()
	role: Role;
}
export class ZoneUser {
	@ApiProperty()
	zone: string;

	@ApiProperty()
	analyzer: number;

	@ApiProperty()
	verifier: number;

	@ApiProperty()
	approver: number;
}
