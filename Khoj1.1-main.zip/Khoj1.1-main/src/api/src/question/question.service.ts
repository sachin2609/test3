import { Injectable } from "@nestjs/common";
import { Repository, In } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { Question } from "./question.entity";
import * as fs from "fs";
@Injectable()
export class QuestionService {
	constructor(@InjectRepository(Question) private questionsRespository: Repository<Question>) {}

	async list(): Promise<Question[]> {
		return await this.questionsRespository.find();
	}

	async create(questions: Question[]): Promise<Question[]> {
		//return await this.questionsRespository.save(questions);
		console.log(questions);
		//const data = JSON.parse(fs.readFileSync("./src/files/questions.json", "utf-8"));
		return await this.questionsRespository.save(questions);
	}

	async findByIds(ids: number[]): Promise<Question[]> {
		return await this.questionsRespository.find({ 
			where: { id: In(ids) }
		});
	}
}
