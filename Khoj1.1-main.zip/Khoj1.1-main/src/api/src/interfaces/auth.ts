// interface to be used by auth module

import { ApiProperty } from "@nestjs/swagger";

export class AuthRequest {
	@ApiProperty({ type: Number, description: "id" })
	id: number;

	@ApiProperty({ type: String, description: "email" })
	email: string;

	@ApiProperty({ type: String, description: "firstName" })
	firstName: string;

	@ApiProperty({ type: String, description: "lastName" })
	lastName: string;

	@ApiProperty({ type: String, description: "picture" })
	picture: string;

	@ApiProperty({ type: String, description: "team" })
	team: string;

	@ApiProperty({ type: Array, description: "roles" })
	roles: string[];

	@ApiProperty({ type: String, description: "googleAccessToken" })
	googleAccessToken: string;
}
