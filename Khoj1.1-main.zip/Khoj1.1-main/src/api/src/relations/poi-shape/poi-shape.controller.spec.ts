import { Test, TestingModule } from '@nestjs/testing';
import { PoiShapeController } from './poi-shape.controller';

describe('PoiShapeController', () => {
  let controller: PoiShapeController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PoiShapeController],
    }).compile();

    controller = module.get<PoiShapeController>(PoiShapeController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
