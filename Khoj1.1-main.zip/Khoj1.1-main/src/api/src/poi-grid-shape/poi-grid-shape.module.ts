import { Module } from '@nestjs/common';
import { HttpModule } from "@nestjs/axios";
import { JwtModule } from '@nestjs/jwt';
import { MongooseModule } from '@nestjs/mongoose';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CsvModule } from 'nest-csv-parser';
import { Answer } from 'src/answer/answer.entity';
import { CsvUploadedFiles } from 'src/csv-processor/csv-upload.entity';
import { GlobalServiceService } from 'src/helpers/global-service/global-service.service';
import { GridService } from 'src/grid/grid.service';
import { Grid } from 'src/grid/grids.entity';
import { Indexmaster } from 'src/index-master/index-master.entity';
import { MongoDatabaseModule } from 'src/helpers/mongo-database/mongo-database.module';
import { PoiDetail } from 'src/poi-details/poi-details.entity';
import { Poi } from 'src/poi/poi.entity';
import { PoiService } from 'src/poi/poi.service';
import { Poiexported } from 'src/poi/poisExported.entity';
import { PropertyDetail } from 'src/property-detail/property-detail.entity';
import { PropertyDetailService } from 'src/property-detail/property-detail.service';
import { Property } from 'src/property/property.entity';
import { PropertyService } from 'src/property/property.service';
import { Question } from 'src/question/question.entity';
import { PoiGrid } from 'src/relations/poi-grid/poi-grid.entity';
import { PoiGridService } from 'src/relations/poi-grid/poi-grid.service';
import { PoiShape } from 'src/relations/poi-shape/poi-shape.entity';
import { PoiShapeService } from 'src/relations/poi-shape/poi-shape.service';
import { PropertyGrid } from 'src/relations/property-grid/property-grid.entity';
import { PropertyGridService } from 'src/relations/property-grid/property-grid.service';
import { UserGrid } from 'src/relations/user-grid/user-grid.entity';
import { ShapeDetail } from 'src/shape-details/shape-details.entity';
import { Shape } from 'src/shape/shape.entity';
import { DemoShapesDBSchema } from 'src/shape/shape.schema';
import { ShapeService } from 'src/shape/shape.service';
import { Shapeindex } from 'src/shape/shapeIndex.entity';
import { TargetDetail } from 'src/target-details/target-details.entity';
import { User } from 'src/users/users.entity';
import { WorkItem } from 'src/work-item/work-item.entity';
import { WorkItemService } from 'src/work-item/work-item.service';
import { PoiGridShapeController } from './poi-grid-shape.controller';
import { UserMerchant } from 'src/merchant/user-merchant.entity';
import { ApiKeyUserMerchant } from 'src/merchant/api-key-user-merchant.entity';
import { POIFilter, POIFilterUserTeam } from 'src/poi-filter/poi-filter.entity';

@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		}),
		HttpModule,
		TypeOrmModule.forFeature([
			WorkItem,
			Poi,
			Grid,
			PoiGrid,
			Property,
			User,
			PropertyGrid,
			UserGrid,
			PropertyDetail,
			Indexmaster,
			Answer,
			Question,
			PoiDetail,
			Poiexported,
			TargetDetail,
			CsvUploadedFiles,
			Shape,
			UserMerchant,
			ApiKeyUserMerchant,
      PoiShape,
      Shapeindex,
      ShapeDetail,
	  POIFilter,
			POIFilterUserTeam,
		]),
		CsvModule,
		MongooseModule.forFeature([{ name: 'DemoShapesDB', schema: DemoShapesDBSchema }]),
    MongoDatabaseModule
	],
	controllers: [PoiGridShapeController],
	providers: [
		PoiService,
		GridService,
		PoiGridService,
		PropertyService,
		PropertyGridService,
		WorkItemService,
		PropertyDetailService,
		GlobalServiceService,
    PoiShapeService,
    ShapeService
	]
})
export class PoiGridShapeModule {}
