import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import * as passport from "passport";
import * as express from "express";
import { join } from "path";
import * as cors from "cors";

// import { SwaggerModule, DocumentBuilder } from "@nestjs/swagger";
// import { CsvProcessorModule } from "./csv-processor/csv-processor.module";
// import { PoiRoutesModule } from "./routing/poi-routes/poi-routes.module";

async function bootstrap() {
	const app = await NestFactory.create(AppModule);
	const enableRestrictedCORS = process.env.RESTRICT_CORS === "true";
	app.use(
		"/public",
		express.static(join(__dirname, "..", "public"), {
			setHeaders: function setHeaders(res, path, stat) {
				res.header("Access-Control-Allow-Origin", "*");
				res.header("Access-Control-Allow-Methods", "GET");
				res.header("Access-Control-Allow-Headers", "Content-Type");
			},
		}),
	);
	app.use("/static", express.static(String(process.env.PATH_TO_SAVE_FILES)));
	app.use(passport.initialize());
	if (enableRestrictedCORS) {
		const allowedOrigins = [String(process.env.FRONTEND_LOGIN_URL), ...process.env.ALLOWED_CORS_ORIGINS.split(",")];
		app.enableCors({
			origin: allowedOrigins,
		});
	} else app.use(cors());
	app.use(function (req, res, next) {
		res.removeHeader("X-Powered-By");
		next();
	});
	const port = process.env.API_PORT ?? 3000;
	await app.listen(port);

	// Swagger Setup
	// const options = new DocumentBuilder()
	// 	.setTitle("DS API")
	// 	.setDescription("All EndPoints available")
	// 	.setVersion("1.0")
	// 	.build();
	// const options2 = new DocumentBuilder()
	// 	.setTitle("DS API")
	// 	.setDescription("The Customised Api description")
	// 	.setVersion("1.1")
	// 	.build();
	//const document = SwaggerModule.createDocument(app, options);
	//const document2 = SwaggerModule.createDocument(app, options2, {
	//	include: [CsvProcessorModule, PoiRoutesModule],
	//});
	//SwaggerModule.setup("swagger", app, document);
	//SwaggerModule.setup("swagger2", app, document2);
}
bootstrap();
