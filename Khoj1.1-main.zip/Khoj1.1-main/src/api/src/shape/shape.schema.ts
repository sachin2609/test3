import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import * as mongoose from 'mongoose';
import { Shapeindex } from './shapeIndex.entity';
export interface Geometry {
	type: String;
	coordinates: [[Number]];
}

export const DemoShapesDBSchema = new mongoose.Schema({
	name: { type: String, required: true },
	objectId: String,
}, { collection: "ShapesDB" })

export interface DemoShapesDB extends mongoose.Document {
	id: string;
	name: string;
	state: string;
	city: string;
	pincode: string;
	district: string;
	level: string;
	geometry: string;
	objectId: string;
	index: [Shapeindex];
}
