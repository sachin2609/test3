import { Test, TestingModule } from '@nestjs/testing';
import { PoiGridShapeController } from './poi-grid-shape.controller';

describe('PoiGridShapeController', () => {
  let controller: PoiGridShapeController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PoiGridShapeController],
    }).compile();

    controller = module.get<PoiGridShapeController>(PoiGridShapeController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
