import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { In, IsNull, Not, Repository } from "typeorm";
import { AppConfigs } from "./app-configs.entity";
import { isBoolean } from "lodash";
import { intersection, uniq } from "lodash";
import { User } from "src/users/users.entity";
import { PromptChain, UpdatePromptChainBody } from "src/interfaces/prompt-log";

@Injectable()
export class AppConfigsService {
	constructor(
		@InjectRepository(AppConfigs) private appConfigsRepository: Repository<AppConfigs>,
		@InjectRepository(User) private userRepository: Repository<User>,
	) {}

	async addAppConfigs(query: Partial<AppConfigs>) {
		const { name, config } = query;
		let { isActive, teamIds } = query;
		if (!name || !config) throw new HttpException(`'name' and 'config' are required!`, HttpStatus.BAD_REQUEST);
		isActive = isActive ?? false;
		teamIds = teamIds ?? [];
		const existingAppConfig = await (async () => {
			try {
				return await this.appConfigsRepository.findOne({ where: { name } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (existingAppConfig) {
			throw new HttpException(`App Config with name '${name}' already exists!`, HttpStatus.BAD_REQUEST);
		}
		const existingActiveAppConfigs = await (async () => {
			try {
				if (isActive) {
					const qb = this.appConfigsRepository
						.createQueryBuilder(`app_configs`)
						.where(`"isActive" = :active`, { active: true });
					if (teamIds?.length) {
						qb.andWhere(`"teamIds" && :teamIds`, { teamIds });
					}
					return await qb.getMany();
				}
			} catch (error) {
				console.error(error);
			}
		})();
		if (existingActiveAppConfigs?.length) {
			const configsForTeam = (() => {
				const teamIDs = intersection(teamIds, uniq(existingActiveAppConfigs.map((c) => c.teamIds).flat()));
				return teamIDs.map((t) => {
					return {
						teamID: t,
						configID: existingActiveAppConfigs.find((e) => e.teamIds.some((id) => id === t)).id,
					};
				});
			})();
			const errMessage = !teamIds?.length
				? "An Active Default Config is already present!"
				: `Active App configs already exists for following team(s) - ${JSON.stringify(configsForTeam).replace(
						/\"/g,
						"",
				  )}!`;
			throw new HttpException(errMessage, HttpStatus.BAD_REQUEST);
		}
		try {
			await this.appConfigsRepository.save({
				name,
				config: JSON.stringify(config),
				isActive,
				teamIds: teamIds?.length ? teamIds : null,
			});
		} catch (error) {
			console.error(error);
			throw new HttpException(`Failed to add app config!`, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async getAppConfigs(tokenUserId: number): Promise<AppConfigs> {
		const teamId = await (async () => {
			try {
				const user = await this.userRepository.findOne({ where: { id: Number(tokenUserId) } });
				return user?.teamId;
			} catch (error) {
				console.error("Cannot fetch Team!", error);
				return undefined;
			}
		})();
		if (!teamId) throw new HttpException("User not related to a Team!", HttpStatus.BAD_REQUEST);
		const config = await (async () => {
			try {
				let config = await this.appConfigsRepository
					.createQueryBuilder(`app_configs`)
					.where(`"isActive" = true`)
					.andWhere(`:teamId = ANY("teamIds")`, { teamId })
					.getOne();
				if (!config) {
					config = await this.appConfigsRepository.findOne({ where: { isActive: true, teamIds: IsNull() } });
				}
				config.config = JSON.parse(config.config);
				return config;
			} catch (err) {
				console.error(err);
				throw new HttpException(`Failed to get app config!`, HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		if (!config) {
			throw new HttpException(`No active app config found!`, HttpStatus.NOT_FOUND);
		}
		return config;
	}

	async updateAppConfig(query: AppConfigs) {
		const { id, name, config, isActive, teamIds } = query;
		if (!id) throw new HttpException(`'id' missing!`, HttpStatus.BAD_REQUEST);
		const appConfig = await (async () => {
			try {
				return await this.appConfigsRepository.findOne({ where: { id } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (!appConfig) throw new HttpException(`App Config with id : ${id} doesnt exist!`, HttpStatus.BAD_REQUEST);

		// Check if new name is already taken for another config
		if (name && name !== appConfig.name) {
			const existingSameNameAppConf = await (async () => {
				try {
					return await this.appConfigsRepository.findOne({ where: { name } });
				} catch (error) {
					console.error(error);
				}
			})();
			if (existingSameNameAppConf)
				throw new HttpException(`Another App Config with name: ${name} already exist!`, HttpStatus.BAD_REQUEST);
		}

		if (isBoolean(isActive) && Boolean(isActive) === true) {
			// Check if Team IDs is being changed, check if new Team IDs dont already have a config assigned to them
			// Or if an inactive config is being changed to Active, the same check should happen
			if (
				(teamIds?.length && uniq(teamIds.sort()) !== uniq(appConfig.teamIds.sort())) ||
				appConfig.isActive === false
			) {
				const otherAssignedAppConfig = await (async () => {
					try {
						const qb = this.appConfigsRepository
							.createQueryBuilder(`app_configs`)
							.where(`"isActive" = :active`, { active: true })
							.andWhere(`"id" != :id`, { id })
							.andWhere(`"teamIds" && :teamIds`, { teamIds });
						return await qb.getMany();
					} catch (err) {
						console.error("Cannot fetch App Configs!", err);
					}
				})();
				if (otherAssignedAppConfig?.length) {
					const configsForTeam = (() => {
						const teamIDs = intersection(
							teamIds,
							uniq(otherAssignedAppConfig.map((c) => c.teamIds).flat()),
						);
						return teamIDs.map((t) => {
							return {
								teamID: t,
								configID: otherAssignedAppConfig.find((e) => e.teamIds.some((id) => id === t)).id,
							};
						});
					})();
					throw new HttpException(
						`Active App configs already exists for following team(s) - ${JSON.stringify(
							configsForTeam,
						).replace(/\"/g, "")}`,
						HttpStatus.BAD_REQUEST,
					);
				}
			}

			// Check if this config is being set as default and no default config already exists
			if (!teamIds?.length) {
				const otherAppConfigWithNoTeamIDs = await (async () => {
					try {
						return await this.appConfigsRepository.findOne({
							where: { isActive: true, id: Not(In([id])), teamIds: IsNull() },
						});
					} catch (err) {
						console.error("Cannot fetch App Configs!", err);
					}
				})();
				if (otherAppConfigWithNoTeamIDs) {
					throw new HttpException(
						`Default Config Already exists with ID - ${otherAppConfigWithNoTeamIDs.id}`,
						HttpStatus.BAD_REQUEST,
					);
				}
			}
		}

		// Update App Config if no Exception
		try {
			await this.appConfigsRepository.update(
				{ id: id },
				{
					name: name ?? undefined,
					isActive: isBoolean(isActive) ? Boolean(isActive) : undefined,
					config: JSON.stringify(config) ?? undefined,
					teamIds: teamIds ? (teamIds.length ? teamIds : null) : undefined,
				},
			);
		} catch (error) {
			console.error(error);
			throw new HttpException(`Failed to update app config!`, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async deleteAppConfig(id: number) {
		if (!id) throw new HttpException(`'id' missing!`, HttpStatus.BAD_REQUEST);
		const existingAppConf = await (async () => {
			try {
				return await this.appConfigsRepository.findOne({ where: { id } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (!existingAppConf) {
			throw new HttpException(`App Config with id : ${id} doesnt exist!`, HttpStatus.BAD_REQUEST);
		}

		// Ensure an Active Config doesn't get deleted
		if (existingAppConf.isActive) {
			throw new HttpException(`Cannot delete an Active App Config!`, HttpStatus.BAD_REQUEST);
		}

		// Ensure there is a default Active Config Available to fall back to
		const defaultConfig = await (async () => {
			try {
				return await this.appConfigsRepository.find({
					where: {
						teamIds: IsNull(),
						isActive: true,
					},
				});
			} catch (err) {
				console.error("Cannot fetch App Configs!", err);
			}
		})();
		if (!defaultConfig)
			throw new HttpException(
				"Please create a default App Config to fall back to first!",
				HttpStatus.BAD_REQUEST,
			);

		try {
			await this.appConfigsRepository.delete({ id });
		} catch (error) {
			console.error(error);
			throw new HttpException(`Failed to delete app config!`, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async updatePromptChain(query: UpdatePromptChainBody) {
		if (!query?.id) throw new HttpException(`"id" missing!`, HttpStatus.BAD_REQUEST);
		if (!query?.promptsChain?.id) throw new HttpException(`Prompt chain "id" missing!`, HttpStatus.BAD_REQUEST);
		const existingAppConfig = await (async () => {
			try {
				const appConfig = await this.appConfigsRepository.findOne({ where: { id: query.id } });
				appConfig.config = JSON.parse(appConfig.config);
				return appConfig;
			} catch (error) {
				console.error("Cannot fetch App Config!", error);
			}
		})();
		if (!existingAppConfig)
			throw new HttpException(`No app config with id : ${query.id} exists!`, HttpStatus.BAD_REQUEST);
		const promptsChain = existingAppConfig?.config?.["promptsChain"] as PromptChain[];
		if (!promptsChain.length)
			throw new HttpException(`App config with id : ${query.id} has no 'promptsChain'`, HttpStatus.BAD_REQUEST);
		const prompt = promptsChain.find((p) => p.id === query.promptsChain.id);
		if (!prompt)
			throw new HttpException(`prompt with id : ${query.promptsChain.id} not found!`, HttpStatus.BAD_REQUEST);
		try {
			promptsChain.forEach((p) => {
				if (p.id === query.promptsChain.id) p = { ...p, ...query.promptsChain };
			});
			existingAppConfig.config["promptsChain"] = promptsChain;
			await this.appConfigsRepository.save(existingAppConfig);
		} catch (error) {
			console.error("Cannot Update Prompt Chain for App Config!", error);
			return { response: "Error : " + String(error) };
		} finally {
			return { response: "Success!" };
		}
	}
}
