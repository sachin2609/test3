import { Test, TestingModule } from '@nestjs/testing';
import { TargetShapeController } from './target-shape.controller';

describe('TargetShapeController', () => {
  let controller: TargetShapeController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TargetShapeController],
    }).compile();

    controller = module.get<TargetShapeController>(TargetShapeController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
