import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Note } from "./notes.entity";
import { NotesQuery } from "src/interfaces/notes";
import { DataSource, Repository } from "typeorm";
import { Poi } from "src/poi/poi.entity";
import { User } from "src/users/users.entity";

@Injectable()
export class NoteService {
	constructor(
		@InjectRepository(Note) private noteRepository: Repository<Note>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(User) private userRepository: Repository<User>,
		private connection: DataSource,
	) {}

	async fetchNote(query: NotesQuery) {
		let notes: Note[] = [];
		const { startDate, endDate, poiId } = query;
		try {
			// Format startDate and endDate for PostgreSQL
			const formattedStartDate = startDate ? new Date(startDate).toISOString().split("T")[0] : null;
			const formattedEndDate = endDate ? new Date(endDate).toISOString().split("T")[0] : null;

			// Create a dynamic query using the NoteRepository
			// Instantiate your NoteRepository class

			const notesQuery = this.noteRepository.createQueryBuilder("note").where("note.isDeleted = false");

			if (formattedStartDate) {
				notesQuery.andWhere("note.createdAt >= TO_TIMESTAMP(:startDate, 'YYYY-MM-DD')", {
					startDate: formattedStartDate,
				});
			}

			if (formattedEndDate) {
				notesQuery.andWhere("note.updatedAt <= TO_TIMESTAMP(:endDate, 'YYYY-MM-DD')", {
					endDate: formattedEndDate,
				});
			}

			if (poiId) {
				notesQuery.andWhere("note.poiId IN (:...poiId)", { poiId });
			}

			notesQuery.andWhere("note.tokenUserId IN (:...userId) OR note.apiKeyUserId IN (:...userId)", {
				userId: query.userId,
			});

			notes = await notesQuery.getMany();
		} catch (err) {
			console.log(err);
			throw new HttpException(`Could not fetch notes`, HttpStatus.SERVICE_UNAVAILABLE);
		} finally {
			return notes;
		}
	}
	async createNote(query: Partial<Note>) {
		if (!query.tokenUserId && !query.apiKeyUserId)
			throw new HttpException(`'tokenUserId' or 'apiKeyUserId' is needed!`, HttpStatus.BAD_REQUEST);
		if (!query.note) throw new HttpException(`'message' missing!`, HttpStatus.BAD_REQUEST);
		if (!query.poiId) throw new HttpException(`'poiId' missing!`, HttpStatus.BAD_REQUEST);
		const existingPoi = await (async () => {
			try {
				return await this.poiRepository.findOne({ where: { id: Number(query.poiId) } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (!existingPoi) throw new HttpException(`Invalid 'poiId'!`, HttpStatus.BAD_REQUEST);

		const existingUser = await (async () => {
			try {
				return await this.userRepository.findOne({
					where: {
						id: Number(query.tokenUserId ? query.tokenUserId : query.apiKeyUserId),
						isAuthorized: true,
					},
				});
			} catch (error) {
				console.error(error);
			}
		})();
		if (!existingUser) throw new HttpException(`Invalid 'userId'!`, HttpStatus.BAD_REQUEST);

		const existingValidNote = await (async () => {
			try {
				return await this.noteRepository.findOne({
					where: { poiId: query.poiId },
				});
			} catch (error) {
				console.error(error);
			}
		})();

		if (existingValidNote) {
			if (
				(query.tokenUserId && Number(query.tokenUserId) !== Number(existingValidNote.tokenUserId)) ||
				(query.apiKeyUserId && Number(query.apiKeyUserId) !== Number(existingValidNote.apiKeyUserId))
			) {
				console.log(existingValidNote.tokenUserId, query.tokenUserId);
				throw new HttpException(
					`Poi with ID ${query.poiId} is already acted upon by someone for making notes!`,
					HttpStatus.FORBIDDEN,
				);
			}
		}
		try {
			await this.noteRepository.save({ ...query, isDeleted: false });
		} catch (error) {
			console.error(error);
			return { response: `Failed !` };
		} finally {
			return { response: `Note Created Successfully!` };
		}
	}
	async deleteNote(query: Partial<Note>) {
		if (!query.id) throw new HttpException(`'id' missing!`, HttpStatus.BAD_REQUEST);
		const existingNote = await (async () => {
			try {
				return await this.noteRepository.findOne({ where: { id: Number(query.id) } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (!existingNote) throw new HttpException(`Invalid id!`, HttpStatus.BAD_REQUEST);
		try {
			existingNote.isDeleted = true;
			await this.noteRepository.save(existingNote);
		} catch (error) {
			console.error(error);
			return { response: `Failed!` };
		} finally {
			return { response: `Note Deleted Successfully!` };
		}
	}
}
