import { Lead } from "src/leads/leads.entity";

class BasicQuery {
	startTime?: Date;
	endTime?: Date;
	userIds: number[];
}

export class MonitoringQuery extends BasicQuery {
	cascade: boolean;
	limit?: number;
	userId?: number;
	teamId?: number;
	page?: number;
	sortBy?: "id" | "name" | "type" | "address";
	sortType?: "asc" | "desc";
	allFosData?: boolean;
}

export class LeadConversionQuery extends BasicQuery {
	cascade: boolean;
	brackets: number;
}

export class UpcomingRemindersQuery extends BasicQuery {
	cascade: boolean;
	brackets?: number;
}

export class LeadQueryRes extends Lead {
	p_type: string;
}

export class KpiQuery extends BasicQuery {
	actions: string[];
}

export class LostOpportunityQuery extends BasicQuery {
	cascade: boolean;
}

export class ReportRes {
	id: number; // POI ID from poi
	name: string; // POI name from poi
	address: string; // POI address from poi
	type: string; // type from poi
	geometry: {
		type: "Point" | "Polygon";
		coordinates: number[];
	};
	poi_details: {
		// key-value for each record in poi_details
		[key: string]: any;
	};
	lead_details: {
		// status from leads
		total_calls: number; // no of "call" action from kpi
		total_navigations: number; // no of "Navigate" action from kpi
		successful_calls_made: number; // no of successful calls from prompt_logs
		lead_status: {
			visited: boolean;
			status: string;
			comment: string;
			timestamp: Date;
			remarks: string;
		};
		latest_activity: {
			poiId: number;
			activity: object;
			timestamp: Date;
			activity_type: string;
		};
	};
	user: {
		id: number;
		firstName: string;
		lastName: string;
		teamId: number;
		teamName: string;
	};
}

export class ReportHistoryRes {
	id: number; // POI ID from poi
	name: string; // POI name from poi
	address: string; // POI address from poi
	type: string; // type from poi
	geometry: {
		type: "Point" | "Polygon";
		coordinates: number[];
	};
	poi_details: {
		// key-value for each record in poi_details
		[key: string]: any;
	};
	lead_details: {
		// status from leads
		total_calls: number; // no of "call" action from kpi
		total_navigations: number; // no of "Navigate" action from kpi
		successful_calls_made: number; // no of successful calls from prompt_logs
		lead_status: {
			visited: boolean;
			status: string;
			comment: string;
			timestamp: Date;
			remarks: string;
		};
		activities: {
			poiId: number;
			activity: object;
			timestamp: Date;
			activity_type: string;
			activity_number: number;
		}[];
	};
	user: {
		id: number;
		firstName: string;
		lastName: string;
		teamId: number;
		teamName: string;
	};
}
