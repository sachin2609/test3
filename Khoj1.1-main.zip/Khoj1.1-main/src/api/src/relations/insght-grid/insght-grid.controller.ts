import { Controller, Post, Body } from "@nestjs/common";
import { InsghtGridService } from "./insght-grid.service";
import { Property } from "../../property/property.entity";
import { Insight } from "../../insight/insight.entity";
import { AggregateQuery } from "../../interfaces/insightGrid";
import { Repository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { Grid } from "../../grid/grids.entity";
import { ApiTags, ApiBody, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { LatLng } from "src/interfaces/poi";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
/*
interface LatLng {
	latitude: number;
	longitude: number;
}*/
@ApiTags("insght-grid")
@Controller("insght-grid")
export class InsghtGridController {
	constructor(
		private _insghtGridService: InsghtGridService,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		@InjectRepository(Property) private propertyRepository: Repository<Property>
	) {}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Populate Insight-grid" })
	async populate(): Promise<void> {
		await this._insghtGridService.populate();
	}

	@Roles("basic")
	@Post("search")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Search" })
	@ApiBody({ type: Object })
	async search(@Body() query: JSON): Promise<Insight[]> {
		if (query["propertyId"]) {
			const property = await this.propertyRepository.findOne({ where: { id: query["propertyId"] }});
			console.log("property", property);
			return await this._insghtGridService.search(property.latitude, property.longitude);
		} else if (query["gridId"]) {
			const grid = await this.gridRepository.findOne({ where: { id: query["gridId"] }});
			console.log("grid", grid);
			return await this._insghtGridService.search(grid.latitude, grid.longitude);
		}
	}

	@Roles("basic")
	@Post("aggregate")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Aggregate" })
	@ApiBody({ type: AggregateQuery })
	async aggregate(@Body() query: AggregateQuery): Promise<unknown> {
		return await this._insghtGridService.aggregate(query);
	}

	@Roles("basic")
	@Post("affluencecategory")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "getSocietiesAgainstAffluenceCategories" })
	@ApiBody({ type: AggregateQuery })
	async getSocietiesAgainstAffluenceCategory(@Body() query: AggregateQuery): Promise<unknown> {
		return await this._insghtGridService.getSocietyCountAgainstAffluenceClass(query);
	}

	@Roles("basic")
	@Post("affluencecategorylatlng")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "getSocietiesAgainstAffluenceCategoryLatLong" })
	@ApiBody({ type: LatLng })
	async getSocietiesAgainstAffluenceCategoryLatLng(@Body() query: LatLng): Promise<unknown> {
		return await this._insghtGridService.getSocietyCountAgainstAffluenceClassLatLng(
			query.latitude,
			query.longitude
		);
	}

	@Roles("basic")
	@Post("aggregatelatlng")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "AggregateLatLong" })
	@ApiBody({ type: AggregateQuery })
	async aggregateLatLon(@Body() query: AggregateQuery): Promise<unknown> {
		return await this._insghtGridService.aggregateLatLon(query);
	}
}
