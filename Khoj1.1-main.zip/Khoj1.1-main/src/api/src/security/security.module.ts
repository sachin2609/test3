import { Module } from "@nestjs/common";
import { HttpModule } from "@nestjs/axios";
import { JwtModule } from "@nestjs/jwt";
import { CsvModule } from "nest-csv-parser";
import { SecurityController } from "./security.controller";
import { SecurityService } from "./security.service";
import { RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Team } from "src/team/team.entity";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { Shape } from "src/shape/shape.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";

@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		HttpModule.register({
			timeout: 100000,
			maxRedirects: 100,
		}),
		TypeOrmModule.forFeature([
			User,
			Team,
			ApiKeyUser,
			ApiKeyOrganisation,
			UserApiUsageHistory,
			UserCredits,
			ApiKeyUserApiUsageHistory,
			ApiKeyUserCredits,
			ApiKeyIp,
			Shape,
			UserIdIp,
		]),
		CsvModule,
	],
	controllers: [SecurityController],
	providers: [SecurityService, RolesGuardService],
})
export class SecurityModule {}
