import { Module } from "@nestjs/common";
import { CacheModule } from "@nestjs/cache-manager";
import { LayersController } from "./layers.controller";
import { LayersService } from "./layers.service";
import { Layer } from "./layers.entity";
import { LayerDetail } from "../layer-details/layer-details.entity";
import { JwtModule } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Grid } from "../grid/grids.entity";
import { Indexmaster } from "../index-master/index-master.entity";
import * as redisStore from "cache-manager-redis-store";
import { RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { Organisation } from "src/organisations/organisations.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { User } from "src/users/users.entity";
import { Shape } from "src/shape/shape.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { Team } from "src/team/team.entity";

@Module({
	imports: [
		TypeOrmModule.forFeature([
			Layer,
			LayerDetail,
			Grid,
			Indexmaster,
			User,
			Team,
			Organisation,
			ApiKeyOrganisation,
			ApiKeyUser,
			UserCredits,
			UserApiUsageHistory,
			ApiKeyUserApiUsageHistory,
			ApiKeyUserCredits,
			Shape,
			ApiKeyIp,
			UserIdIp,
		]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
	],
	controllers: [LayersController],
	providers: [LayersService, RolesGuardService],
})
export class LayersModule {}
