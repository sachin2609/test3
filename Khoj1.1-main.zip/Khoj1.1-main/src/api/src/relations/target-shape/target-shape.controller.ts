import { Body, Controller, Post, Headers } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { GlobalServiceService } from 'src/helpers/global-service/global-service.service';
import { MultilevelShapesQuery } from 'src/interfaces/shapes';
import { ShapeService } from 'src/shape/shape.service';
import { PoiShapeService } from '../poi-shape/poi-shape.service';
import { TargetShapeService } from './target-shape.service';

@Controller('target-shape')
export class TargetShapeController {
    constructor(
		private _shapeService: ShapeService,
        private _targetShapeService: TargetShapeService,
        private _jwtService: JwtService,
		private _globalService: GlobalServiceService
	) {}

	@Post('filter')
	async multilevelSearch(@Headers() header,@Body() body: MultilevelShapesQuery): Promise<unknown> {
        const user = await this._globalService.decode(header["token"]);
		console.log(user);
		console.log(body);
		try {
			return await this._targetShapeService.filter(user['id'],body);
		} catch(error) {
			console.log(error);
			return {
				count: 0,
				data: []
			};
		}
	}

}
