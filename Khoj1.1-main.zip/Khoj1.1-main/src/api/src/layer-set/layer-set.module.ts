import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LayerSetController } from './layer-set.controller';
import { LayerSet } from './layer-set.entity';
import { LayerSetService } from './layer-set.service';

@Module({
  imports: [
	  TypeOrmModule.forFeature([LayerSet]),
	  JwtModule.register({
		secret: process.env.JWT_SECURITY_KEY,
		signOptions: { expiresIn: process.env.JWT_EXPIRY }
	})
	],
  controllers: [LayerSetController],
  providers: [LayerSetService]
})
export class LayerSetModule {}
