export class ReminderQuery {
	startDate?: Date;
	endDate?: Date;
	userId?: number[];
	poiId?: number[];
}
