import { Test, TestingModule } from '@nestjs/testing';
import { ApiKeyUsersService } from './api-key-users.service';

describe('ApiKeyUsersService', () => {
  let service: ApiKeyUsersService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ApiKeyUsersService],
    }).compile();

    service = module.get<ApiKeyUsersService>(ApiKeyUsersService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
