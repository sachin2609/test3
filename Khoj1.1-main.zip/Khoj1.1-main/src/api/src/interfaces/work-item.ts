import { WorkItemStage, WorkItemStatus, WorkItem } from "src/work-item/work-item.entity";
import { ApiProperty } from "@nestjs/swagger";

export class WorkItemRequest {
	@ApiProperty()
	propertyId: number;

	@ApiProperty()
	userId: number;

	@ApiProperty()
	stage: WorkItemStage;

	@ApiProperty()
	assignedBy: number;
}

export class WorkItemResponse {
	@ApiProperty()
	id: number;

	@ApiProperty()
	propertyId: number;

	@ApiProperty()
	propertyName: string;

	@ApiProperty()
	stage: WorkItemStage;

	@ApiProperty()
	status: WorkItemStatus;
}

export class WorkItemQuery {
	@ApiProperty()
	limit: number;

	@ApiProperty()
	page: number;

	@ApiProperty()
	status: WorkItemStatus;
}

export class WorkItemPaginationDto {
	@ApiProperty()
	page: number;

	@ApiProperty()
	limit: number;

	@ApiProperty()
	totalPages: number;

	@ApiProperty()
	data: WorkItemResponse[];
}

export class WorkItemUsers {
	@ApiProperty()
	propertyId: number;

	@ApiProperty()
	analyzer: string;

	@ApiProperty()
	verifier: string;

	@ApiProperty()
	approver: string;
}
export class WorkItemPaginationDtoNew {
	@ApiProperty()
	page: number;

	@ApiProperty()
	limit: number;

	@ApiProperty()
	totalPages: number;

	@ApiProperty()
	data: WorkItem[];
}
