import { Body, Controller, Get, Headers, HttpStatus, Post, Req, UsePipes, ValidationPipe } from "@nestjs/common";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { Kpi } from "./kpi.entity";
import { KpiService } from "./kpi.service";
import { JwtService } from "@nestjs/jwt";
import { KpiQuery } from "src/interfaces/monitoring";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";
import { Request } from "express";
import { RealIP } from "nestjs-real-ip";
import { KpiDTO } from "src/interfaces/kpi-dto";

@Controller("kpi")
export class KpiController {
	constructor(
		private kpiService: KpiService,
		private jwtService: JwtService,
		private _syslogService: SyslogService,
	) {}

	@Roles("basic")
	@Post()
	@UsePipes(new ValidationPipe())
	async addKpi(@Headers() header, @Body() body: KpiDTO, @Req() req: Request, @RealIP() ip): Promise<Kpi> {
		try {
			const res = await this.kpiService.addKpi(header, body as Kpi);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles("basic")
	@Get("day-wise-summary")
	async getDayWaySummary(@Headers() header, @Req() req: Request, @RealIP() ip) {
		try {
			const res = await this.kpiService.getDayWiseSummary(header);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles("basic")
	@Get("is-in-progress-and-launched")
	async isInProgressAndLaunched(@Headers() header, @Req() req: Request, @RealIP() ip) {
		try {
			const res = await this.kpiService.isInProgressAndLaunched(header);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("user-actions")
	async getUserActions(@Headers() header, @Body() body: KpiQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const user = this.jwtService.decode(header["token"] || header["apikey"] || header["apiKey"]) as Partial<
				User | ApiKeyUser
			>;
			const res = await this.kpiService.fetchActions(body, user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}
}
