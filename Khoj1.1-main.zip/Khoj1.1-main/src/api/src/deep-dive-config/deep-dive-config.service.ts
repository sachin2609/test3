import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { uniqBy } from 'lodash';
import { Repository } from 'typeorm';
import { DeepDiveConfig } from './deep-dive-config.entity';

@Injectable()
export class DeepDiveConfigService {
	constructor(
		@InjectRepository(DeepDiveConfig) private deepDiveConfigRepository: Repository<DeepDiveConfig>
	) {}

	async addDeepDiveConfig(body: DeepDiveConfig, userId: number): Promise<DeepDiveConfig> {
		body["userId"] = userId;
		return await this.deepDiveConfigRepository.save(body);
	}

	async getDeepDiveConfig(userId: number): Promise<DeepDiveConfig[]> {
		console.log("UserId Found :",userId);
		const deepDiveConfigs = await this.deepDiveConfigRepository.find({ where: {userId: userId }});
		const defaultDeepDiveConfigs = await this.deepDiveConfigRepository.find({ where: {default: true }});
		let response = deepDiveConfigs.concat(defaultDeepDiveConfigs);
		response = uniqBy([...deepDiveConfigs, ...defaultDeepDiveConfigs], "id");
		return response;
	}

	async delete(body,userId) {
		const deepDive = await this.deepDiveConfigRepository.findOne({ where: {id: body["id"] }});
		if(deepDive.userId != userId) {
			throw new HttpException("You are not owner of this DeepDive",HttpStatus.FORBIDDEN);
		}
		return await this.deepDiveConfigRepository.delete({id: body["id"],userId: userId});
	}

	async updateDeepDiveConfig(body: DeepDiveConfig, userId: number): Promise<DeepDiveConfig> {
		const deepDive = await this.deepDiveConfigRepository.findOne({ where: {id: body.id, userId: userId }});
		await Promise.all(Object.keys(body).map(eachKey => {
			deepDive[eachKey] = body[eachKey];
		}));
		return await this.deepDiveConfigRepository.save(deepDive);
	}
}
