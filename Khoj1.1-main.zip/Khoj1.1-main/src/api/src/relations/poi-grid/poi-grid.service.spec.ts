import { Test, TestingModule } from "@nestjs/testing";
import { PoiGridService } from "./poi-grid.service";

describe("PoiGridService", () => {
	let service: PoiGridService;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			providers: [PoiGridService]
		}).compile();

		service = module.get<PoiGridService>(PoiGridService);
	});

	it("should be defined", () => {
		expect(service).toBeDefined();
	});
});
