import { Controller, Post, Body, Headers, HttpException, HttpStatus, UseInterceptors } from "@nestjs/common";
import { PoiShapeService } from "./poi-shape.service";
import { MultilevelShapesQuery } from "../../interfaces/shapes";
import { ShapeService } from "../../shape/shape.service";
import { Roles, RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { RealIP } from "nestjs-real-ip";
import { CacheInterceptorInterceptor } from "src/helpers/cache/cache-interceptor.interceptor";

@Controller("poi-shape")
export class PoiShapeController {
	constructor(
		private _shapeService: ShapeService,
		private _poiShapeService: PoiShapeService,
		private _rolesGuardService: RolesGuardService,
	) {}

	@Roles("basic")
	@Post("filter")
	@UseInterceptors(CacheInterceptorInterceptor)
	async multilevelSearch(
		@Body() body: MultilevelShapesQuery,
		@Headers() header,
		@RealIP() ip: string,
	): Promise<unknown> {
		try {
			const resp = await this._poiShapeService.filter(body);
			console.log("deducting ", resp["count"]);
			let credsResp;
			if (header.token) {
				credsResp = await this._rolesGuardService.updateCreds(
					header.token,
					resp["count"],
					"/poi-shape/filter",
					ip,
					JSON.stringify(body),
				);
			} else {
				credsResp = await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp["count"],
					"/poi-shape/filter",
					ip,
					JSON.stringify(body),
				);
			}
			console.log("response from creds deduction", credsResp);
			if (credsResp) {
				return resp;
			} else {
				throw new HttpException(
					{
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left",
					},
					HttpStatus.FORBIDDEN,
				);
			}
		} catch (error) {
			console.log(error);
			return {
				count: 0,
				data: [],
			};
		}
	}
}
