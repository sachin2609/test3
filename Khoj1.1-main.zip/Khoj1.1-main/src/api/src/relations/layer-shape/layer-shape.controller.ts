import { Controller, Post, Body } from '@nestjs/common';
import { MultilevelShapesQuery } from '../../interfaces/shapes';
import { LayerShapeService } from './layer-shape.service';
@Controller('layer-shape')
export class LayerShapeController {
	constructor(private _layerShapeService: LayerShapeService) {}
	
	@Post('filter')
	async multilevelSearch(@Body() body: MultilevelShapesQuery): Promise<unknown> {
		try {
			return await this._layerShapeService.filter(body);
		} catch(error) {
			console.log(error);
			return {
				count: 0,
				data: []
			};
		}
	}

}
