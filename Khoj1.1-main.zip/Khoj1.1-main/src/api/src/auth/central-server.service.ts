import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import axios from "axios";
import { CentralServerAppUserDto } from "src/interfaces/cental-server";
import { User } from "src/users/users.entity";

@Injectable()
export class CentralServerService {
	async axiosReq(
		url: string,
		method: "get" | "post" | "put" | "delete",
		bearerToken?: string,
		data?: string,
		contentType?: "json" | "urlencoded",
	): Promise<any> {
		const config = {
			method,
			maxBodyLength: Infinity,
			url,
			headers: {
				"Content-Type": contentType
					? contentType === "json" ?? "application/x-www-form-urlencoded"
					: "application/json",
				Authorization: bearerToken ? `Bearer ${bearerToken}` : undefined,
				Accept: "*/*",
			},
			data: data,
		};
		return axios(config);
	}

	async addUserToCentralServer(user: Partial<User>) {
		const data = {
			secret: String(process.env.CENTRAL_SERVER_CLIENT_SECRET),
			phoneNumber: user.phoneNumber,
		};
		try {
			return await this.axiosReq(
				String(process.env.CENTRAL_SERVER_URL) + `/app-user`,
				"post",
				null,
				JSON.stringify(data),
			);
		} catch (err) {
			console.error(err);
			throw new HttpException(
				"Cannot Add User to Central Server - " + err.response.data.message,
				HttpStatus.BAD_REQUEST,
			);
		}
	}

	async getUserFromCentralServer(phoneNumbers: string[]): Promise<CentralServerAppUserDto[]> {
		if (!phoneNumbers?.length) throw new HttpException("Phone Number is required!", HttpStatus.BAD_REQUEST);
		const data = {
			secret: String(process.env.CENTRAL_SERVER_CLIENT_SECRET),
			phoneNumbers: phoneNumbers,
		};
		const csUsers = await (async () => {
			try {
				return await this.axiosReq(
					`${String(process.env.CENTRAL_SERVER_URL)}/app-user/fetch`,
					"post",
					null,
					JSON.stringify(data),
				);
			} catch (err) {
				console.error(err);
				throw new HttpException(
					"Cannot Get User from Central Server - " + err.data.message,
					HttpStatus.SERVICE_UNAVAILABLE,
				);
			}
		})();
		return csUsers?.data?.data;
	}

	async deleteUserFromCentralServer(user: User) {
		if (!user) throw new HttpException("User is required!", HttpStatus.BAD_REQUEST);
		const data = {
			secret: String(process.env.CENTRAL_SERVER_CLIENT_SECRET),
			phoneNumbers: [user.phoneNumber],
		};
		const existingCSUser = (await this.getUserFromCentralServer([user.phoneNumber]))?.[0];
		if (!existingCSUser?.phoneNumber) {
			throw new HttpException("User does not exist in Central Server!", HttpStatus.BAD_REQUEST);
		}
		try {
			return await this.axiosReq(
				String(process.env.CENTRAL_SERVER_URL) + `/app-user/${existingCSUser?.id}`,
				"delete",
				null,
				JSON.stringify({ secret: data.secret }),
			);
		} catch (err) {
			console.error(err);
			throw new HttpException("Cannot Delete User from Central Server - " + err, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async sendSMSInvite(users: Array<User>) {
		if (!users?.length) throw new HttpException("Users are required!", HttpStatus.BAD_REQUEST);
		const phNumNameDict = {};
		const phoneNumbers = users.map((u) => {
			phNumNameDict[u.phoneNumber] = String(u.firstName) + " " + String(u.lastName);
			return u.phoneNumber;
		});
		const centralServerUsers = await this.getUserFromCentralServer(phoneNumbers);
		if (!centralServerUsers?.length) {
			throw new HttpException("Users does not exist in Central Server!", HttpStatus.BAD_REQUEST);
		}
		for (const user of centralServerUsers) {
			try {
				await this.axiosReq(
					String(process.env.TWO_FA_URL) + `&apikey=${String(process.env.TWO_FA_API_KEY)}`,
					"post",
					null,
					`to=${user.phoneNumber}&from=${String(process.env.TWO_FA_SENDER_ID)}&var1=${String(
						phNumNameDict[user.phoneNumber],
					)}&var2=${String(user.code)}&templatename=${String(process.env.TWO_FA_SMS_TEMPLATE)}`,
					"urlencoded",
				);
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot Send SMS Invite!", HttpStatus.SERVICE_UNAVAILABLE);
			}
		}
	}
}
