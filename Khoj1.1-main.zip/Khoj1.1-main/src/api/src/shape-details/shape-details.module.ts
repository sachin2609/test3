import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ShapeDetailsController } from './shape-details.controller';
import { ShapeDetail } from './shape-details.entity';
import { ShapeDetailsService } from './shape-details.service';

@Module({
  imports:[TypeOrmModule.forFeature([ShapeDetail])],
  controllers: [ShapeDetailsController],
  providers: [ShapeDetailsService]
})
export class ShapeDetailsModule {}
