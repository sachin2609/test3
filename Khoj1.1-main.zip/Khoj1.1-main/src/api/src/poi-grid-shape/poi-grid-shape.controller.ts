import { Body, Controller, Post } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { GlobalServiceService } from 'src/helpers/global-service/global-service.service';
import { GridService } from 'src/grid/grid.service';
import { Grid } from 'src/grid/grids.entity';
import { Roles } from 'src/helpers/roles-guard/roles-guard.service';
import { MultilevelShapesQuery } from 'src/interfaces/shapes';
import { Poi } from 'src/poi/poi.entity';
import { PoiService } from 'src/poi/poi.service';
import { Property } from 'src/property/property.entity';
import { PoiShapeService } from 'src/relations/poi-shape/poi-shape.service';
import { Repository } from 'typeorm';

@Controller('poi-grid-shape')
export class PoiGridShapeController {
    constructor(
		private _poiService: PoiService,
		private _gridService: GridService,
		@InjectRepository(Property) private propertyRepository: Repository<Property>,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		private _jwtService: JwtService,
		private _globalService : GlobalServiceService,
        private _poiShapeService: PoiShapeService
	) {}
	
	@Roles("basic")
    @Post('filter')
	async filter(@Body() body): Promise<unknown> {
		try {
			const poiShapeRes = await this._poiShapeService.filter(body);
            const poiShapeResData = poiShapeRes["data"] as Poi[];
            const poiGridRes = await this._poiService.filter(body);
            const poiGridResData = poiGridRes["data"] as Poi[];
			let shapeIndex = {};
			let shapeDetails = {};
            await Promise.all(poiShapeResData.map(eachPoi => {
				shapeIndex[eachPoi.id] = eachPoi["index"];
				shapeDetails[eachPoi.id] = eachPoi["internalDetails"];
			}));
			const data = poiGridResData.filter(ar => poiShapeResData.find(rm => (rm.id === ar.id) ));
			const typeCountsDict = {};
			await Promise.all(data.map(eachPoi => {
				eachPoi["shapeIndex"] = shapeIndex[eachPoi.id];
				eachPoi["shapeDetails"] = shapeDetails[eachPoi.id];
				if (typeCountsDict[eachPoi.type]) {
					typeCountsDict[eachPoi.type] += 1;
				} else {
					typeCountsDict[eachPoi.type] = 1;
				}
			}));
			const responseDict = {};
			responseDict["count"] = data.length;
			responseDict["typeCount"] = typeCountsDict;
			responseDict['data'] = data;
			return responseDict;
		} catch(error) {
			console.log(error);
			return {
				count: 0,
				data: []
			};
		}
	}
}
