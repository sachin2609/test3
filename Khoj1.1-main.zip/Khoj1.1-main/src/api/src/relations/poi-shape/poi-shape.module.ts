import { Module } from "@nestjs/common";
import { CacheModule } from "@nestjs/cache-manager";
import { PoiShapeController } from "./poi-shape.controller";
import { PoiShapeService } from "./poi-shape.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { PoiShape } from "./poi-shape.entity";
import { Poi } from "../../poi/poi.entity";
import { ShapeService } from "../../shape/shape.service";
import { DemoShapesDBSchema } from "../../shape/shape.schema";
import { Shape } from "../../shape/shape.entity";
import { MongooseModule } from "@nestjs/mongoose";
import { Grid } from "../../grid/grids.entity";
import { Shapeindex } from "../../shape/shapeIndex.entity";
import { ShapeDetail } from "../../shape-details/shape-details.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
import { PoiDetail } from "src/poi-details/poi-details.entity";
import { RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { UserCredits } from "src/user-history/user-credits.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { User } from "src/users/users.entity";
import { Organisation } from "src/organisations/organisations.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { JwtModule } from "@nestjs/jwt";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import * as redisStore from "cache-manager-redis-store";
import { Team } from "src/team/team.entity";

@Module({
	imports: [
		MongooseModule.forFeature([{ name: "DemoShapesDB", schema: DemoShapesDBSchema }]),
		TypeOrmModule.forFeature([
			Poi,
			PoiShape,
			Shape,
			Grid,
			Shapeindex,
			ShapeDetail,
			PoiDetail,
			UserCredits,
			UserApiUsageHistory,
			User,
			Team,
			Organisation,
			ApiKeyUserCredits,
			ApiKeyUserApiUsageHistory,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyIp,
			UserIdIp,
		]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		MongoDatabaseModule,
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
	],
	controllers: [PoiShapeController],
	providers: [PoiShapeService, ShapeService, RolesGuardService],
})
export class PoiShapeModule {}
