import { ApiProperty } from "@nestjs/swagger";
import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class Note {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id?: number;

	@ApiProperty()
	@Column({ type: "integer" })
	poiId: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	tokenUserId?: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	apiKeyUserId?: number;

	@ApiProperty()
	@Column()
	note: string;

	@ApiProperty()
	@Column()
	isDeleted: boolean;

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt: Date;

	@ApiProperty()
	@UpdateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)", onUpdate: "CURRENT_TIMESTAMP(6)" })
	updatedAt: Date;
}


