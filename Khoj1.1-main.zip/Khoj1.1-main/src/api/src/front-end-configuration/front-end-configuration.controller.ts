import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';
import { Roles } from 'src/helpers/roles-guard/roles-guard.service';
import { FrontEndConfigurationId, PostFrontEndConfigurationBody, UpdateFrontEndConfigurationBody } from 'src/interfaces/front-end-configuration';
import { FrontEndConfigurationService } from './front-end-configuration.service';

@Controller('front-end-configuration')
export class FrontEndConfigurationController {
    constructor(
        private frontEndConfigService: FrontEndConfigurationService
    ) {}

    @Roles("admin")
    @Get()
    async getAll() {
        try {
            return await this.frontEndConfigService.findAll();
        } catch(err) {
            console.log(err);
            return { response: "Failure!" };
        }
    }

    @Roles("admin")
    @Get(":id")
    async getById(@Param() param: FrontEndConfigurationId) {
        try {
            return await this.frontEndConfigService.findById(param);
        } catch(err) {
            console.error(err);
            return { response: "Failure!" };
        }
    }

    @Roles("admin")
    @Post()
    async post(@Body() body: PostFrontEndConfigurationBody) {
        try {
            return await this.frontEndConfigService.post(body);
        } catch (error) {
            console.error(error);
            return { response: "Failure!" };
        }
    }

    @Roles("admin")
    @Put()
    async update(@Body() body: UpdateFrontEndConfigurationBody) {
        try {
            return await this.frontEndConfigService.update(body);    
        } catch (error) {
            console.error(error);
            return { response: "Failure!" }
        }
    }

    @Roles("admin")
    @Delete(":id")
    async delete(@Param() param: FrontEndConfigurationId) {
        try {
            return await this.frontEndConfigService.delete(param);   
        } catch (error) {
            console.error(error);
            return { response: "Failure!" }
        }
    }
}
