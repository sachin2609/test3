import { Injectable } from "@nestjs/common";
import { Repository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { Answer } from "../answer/answer.entity";
@Injectable()
export class UploadService {
	constructor(@InjectRepository(Answer) private answerRepository: Repository<Answer>) {}

	async createAnswer(answer: Answer): Promise<Answer> {
		return await this.answerRepository.save(answer);
	}
}
