import { IsArray, IsBoolean, IsOptional, IsString, Validate } from "class-validator";
import { IsNumberOrString } from "src/helpers/validations/IsNumberOrString";

export class AddLeadDto {
	@Validate(IsNumberOrString)
	poiId: number;

	@IsOptional()
	@IsString()
	status: string;

	@IsOptional()
	@IsBoolean()
	visited?: boolean;

	@IsOptional()
	@IsString()
	comment?: string;

	@IsOptional()
	@IsString()
	remarks?: string;

	@IsOptional()
	@IsArray()
	@IsString({ each: true })
	tags?: string[];
}
