import { ApiProperty } from "@nestjs/swagger";
import { PoiStatus } from "src/poi/poi.entity";

export class POI {
	@ApiProperty({ type: String, description: "name" })
	name: string;

	@ApiProperty({ type: String, description: "address" })
	address: string;

	@ApiProperty({ type: String, description: "category" })
	category: string;

	@ApiProperty({ type: String, description: "type" })
	type: string;

	@ApiProperty({ type: String, description: "subType" })
	subType: string;

	@ApiProperty({ type: Number, description: "votes" })
	votes: number;

	@ApiProperty({ type: Number, description: "rating" })
	rating: number;

	@ApiProperty({ type: Number, description: "latitude" })
	latitude: number;

	@ApiProperty({ type: Number, description: "longitude" })
	longitude: number;

	@ApiProperty({ type: Number, description: "createdBy" })
	createdBy: number;

	@ApiProperty({ type: String, description: "dataType" })
	dataType: string;

	@ApiProperty()
	status: PoiStatus;
}
