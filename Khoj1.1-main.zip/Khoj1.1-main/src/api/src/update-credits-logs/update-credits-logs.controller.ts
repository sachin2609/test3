import { Controller } from '@nestjs/common';

@Controller('update-credits-logs')
export class UpdateCreditsLogsController {}
