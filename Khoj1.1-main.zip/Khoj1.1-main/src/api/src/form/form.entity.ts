import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

enum userType {
	analyzer = "analyzer",
	verifier = "verifier",
	approver = "approver"
}

@Entity()
export class Form {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column("simple-array")
	questionIds: number[];

	@ApiProperty()
	@Column()
	section: number;
}
