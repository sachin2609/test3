import { Controller, Post, Get, UseInterceptors } from "@nestjs/common";
import { InsightService } from "./insight.service";
import { ApiTags, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { CacheInterceptorInterceptor } from "src/helpers/cache/cache-interceptor.interceptor";
import { CacheKey } from "src/helpers/cache/cache-key.decorator";
import { CachePopulateInterceptor } from "src/helpers/cache/cache-populate.interceptor";
@ApiTags("insight")
@Controller("insight")
export class InsightController {
	constructor(private _insightService: InsightService) {}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "create Insight" })
	async create(): Promise<void> {
		await this._insightService.create();
	}
	
	@Roles("basic")
	@Get()
	@CacheKey("get-insights")
	@UseInterceptors(CacheInterceptorInterceptor)
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "create Insight" })
	async listInsights(): Promise<unknown> {
		return await this._insightService.listInsights();
	}

	@Roles("admin")
	@Get("populate-get")
	@CacheKey("get-insights")
	@UseInterceptors(CachePopulateInterceptor)
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "create Insight" })
	async populatelistInsights(): Promise<unknown> {
		return await this._insightService.listInsights();
	}
}
