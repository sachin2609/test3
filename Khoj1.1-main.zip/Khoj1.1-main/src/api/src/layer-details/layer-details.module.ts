import { Module } from '@nestjs/common';
import { LayerDetailsController } from './layer-details.controller';
import { LayerDetailsService } from './layer-details.service';
import { LayerDetail } from './layer-details.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
@Module({
	imports: [
		TypeOrmModule.forFeature([LayerDetail])
	],
	controllers: [LayerDetailsController],
	providers: [LayerDetailsService]
})
export class LayerDetailsModule {}
