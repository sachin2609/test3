import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { User } from "src/users/users.entity";
import { TeamController } from "./team.controller";
import { Team } from "./team.entity";
import { TeamService } from "./team.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { MailerModule } from "@nestjs-modules/mailer";
import { HandlebarsAdapter } from "@nestjs-modules/mailer/dist/adapters/handlebars.adapter";
import path = require("path");
import { CentralServerService } from "src/auth/central-server.service";
import { UserCredits } from "src/user-history/user-credits.entity";
import { CacheModule } from "@nestjs/cache-manager";
import * as redisStore from "cache-manager-redis-store";

@Module({
	imports: [
		TypeOrmModule.forFeature([Team, User, UserCredits]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
		MailerModule.forRoot({
			transport: {
				host: "smtp.gmail.com",
				port: 587,
				ignoreTLS: true,
				secure: false,
				service: "gmail",
				auth: {
					user: process.env.MAILDEV_INCOMING_USER,
					pass: process.env.MAILDEV_INCOMING_PASS,
				},
				tls: { rejectUnauthorized: false },
			},
			defaults: {
				from: "datasutram01@wellnessforever.in",
			},
			template: {
				dir: path.join(process.env.PWD, "templates/pages"),
				adapter: new HandlebarsAdapter(),
				options: {
					strict: false,
				},
			},
			options: {
				partials: {
					dir: path.join(process.env.PWD, "templates/partials"),
					options: {
						strict: true,
					},
				},
			},
		}),
	],
	controllers: [TeamController],
	providers: [TeamService, KeyCloakService, CentralServerService],
})
export class TeamModule {}
