import { Entity, PrimaryColumn, Column, Index } from "typeorm";

@Entity()
export class ShapeDetail {
	@PrimaryColumn()
	@Index()
	shapeId: number;

	@PrimaryColumn()
	key: string;

	@Column()
	value: string;

	@Column({ default:"string" })
	dataType: string;

	@Column({nullable: true})
	metrics: string;
	
	@Column('decimal', {nullable:true})
	unit: number;
}
