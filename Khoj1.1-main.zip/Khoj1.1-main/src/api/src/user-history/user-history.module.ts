import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { UserHistory } from "./user-history.entity";
import { UserHistoryService } from "./user-history.service";
import { UserHistoryController } from "./user-history.controller";
import { User } from "src/users/users.entity";
import { MailerModule } from "@nestjs-modules/mailer";
import * as path from "path";
import { HandlebarsAdapter } from "@nestjs-modules/mailer/dist/adapters/handlebars.adapter";
import { JwtModule } from "@nestjs/jwt";
import { Organisation } from "src/organisations/organisations.entity";
import { Kpi } from "src/kpi/kpi.entity";
import { TeamService } from "src/team/team.service";
import { Team } from "src/team/team.entity";
import { UserCredits } from "./user-credits.entity";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";

@Module({
	imports: [
		TypeOrmModule.forFeature([UserHistory, User, Organisation, Kpi, Team, UserCredits]),
		MailerModule.forRoot({
			transport: {
				host: "smtp.gmail.com",
				port: 587,
				ignoreTLS: true,
				secure: false,
				service: "gmail",
				auth: {
					user: process.env.MAILDEV_INCOMING_USER,
					pass: process.env.MAILDEV_INCOMING_PASS,
				},
				tls: { rejectUnauthorized: false },
			},
			defaults: {
				from: "datasutram01@wellnessforever.in",
			},
			template: {
				dir: path.join(process.env.PWD, "templates/pages"),
				adapter: new HandlebarsAdapter(),
				options: {
					strict: false,
				},
			},
			options: {
				partials: {
					dir: path.join(process.env.PWD, "templates/partials"),
					options: {
						strict: true,
					},
				},
			},
		}),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
	],
	providers: [UserHistoryService, TeamService, KeyCloakService, CentralServerService],
	controllers: [UserHistoryController],
})
export class UserHistoryModule {}
