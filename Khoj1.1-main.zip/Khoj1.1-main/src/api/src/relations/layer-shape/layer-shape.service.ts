import { Injectable } from '@nestjs/common';
import { Repository, In } from 'typeorm';
import { TypeOrmModule, InjectRepository } from '@nestjs/typeorm';
import { LayerShape } from './layer-shape.entity';
import { MultilevelShapesQuery } from '../../interfaces/shapes';
import { ShapeService } from '../../shape/shape.service';
import { Shapeindex } from '../../shape/shapeIndex.entity';
import { LayerDetail } from '../../layer-details/layer-details.entity';
import { Layer } from '../../layers/layers.entity';
import * as _ from 'lodash';
@Injectable()
export class LayerShapeService {
	constructor(
		private _shapeService: ShapeService,
		@InjectRepository(LayerShape) private layerShapeRepository: Repository<LayerShape>,
		@InjectRepository(Shapeindex) private shapeIndexRepository: Repository<Shapeindex>,
		@InjectRepository(Layer) private layerRepository: Repository<Layer>,
		@InjectRepository(LayerDetail) private layerDetailRepository: Repository<LayerDetail>
	) {}
	async filter(query: MultilevelShapesQuery): Promise<unknown> {
		const shapeIds = await this._shapeService.returnShapeIdsmultilevelShapes(query);
		const layerShapeIndexDict = {};
		const shapeIndexDict = {};
		console.log("shape ids inside poi filter", shapeIds);
		const shapeIndexes = await this.shapeIndexRepository.createQueryBuilder('shapeindex')
			.where('shapeindex."shapeId" IN (:...shapeIds)', { shapeIds: shapeIds })
			.select('"shapeId"')
			.addSelect('"indexName"')
			.addSelect('"indexValue"')
			.addSelect('"indexType"')
			.addSelect('"categoricalValue"')
			.getRawMany();
		shapeIndexes.forEach(eachIndex => {
			if (!shapeIndexDict[eachIndex['shapeId']]) {
				shapeIndexDict[eachIndex['shapeId']] = {};
				if (eachIndex.indexType === 'string') {
					shapeIndexDict[eachIndex['shapeId']][eachIndex.indexName] = eachIndex.indexValue;
				} else {
					shapeIndexDict[eachIndex['shapeId']][eachIndex.indexName] = eachIndex.categoricalValue;
				}
			} else {
				if (eachIndex.indexType === 'number') {
					shapeIndexDict[eachIndex['shapeId']][eachIndex.indexName] = eachIndex.indexValue;
				} else {
					shapeIndexDict[eachIndex['shapeId']][eachIndex.indexName] = eachIndex.categoricalValue;
				}
			}
		});
		const layerShapeRelations = await this.layerShapeRepository.find({ where: {
			shapeId: In(_.flattenDeep(shapeIds)) 
	}});
		let layerIds = layerShapeRelations.map(eachRelation => {
			layerShapeIndexDict[eachRelation.layerId] = shapeIndexDict[eachRelation.shapeId];
			return eachRelation.layerId;
		});
		console.log("Lenth of PoiIds found :",layerIds.length);
		let layerIdsFromLayerDetails = [];
		if(query["layerDetails"]) {
			let intersectionStatus = 0;
			const poiDetails :any[] = query["layerDetails"];
			if(poiDetails.length==0) {
				layerIdsFromLayerDetails = [];
			} else {
				await Promise.all(poiDetails.map(async (eachPoiDetail, index) => {
					if(eachPoiDetail.dataType == "string") {
						const tempPoiIdsFromString = [];
						const tempPoiIds = await this.layerDetailRepository
							.createQueryBuilder("layer_detail")
							.where('key = :key AND value IN(:...values)',{key: eachPoiDetail.key, values: eachPoiDetail.values})
							.select('"layerId"')
							.distinct(true)
							.getRawMany()
						await Promise.all(tempPoiIds.map(eachPoiId => {
							tempPoiIdsFromString.push(eachPoiId.layerId);
						}));
						layerIdsFromLayerDetails.push(tempPoiIdsFromString);
					}
					if(eachPoiDetail.dataType == "number") {
						const tempPoiIdsArray = [];
						const tempPoiDetails = await this.layerDetailRepository
							.createQueryBuilder("layer_detail")
							.where('key = :key',{key: eachPoiDetail.key})
							.andWhere('unit BETWEEN :min and :max', {min: eachPoiDetail["values"]["min"], max: eachPoiDetail["values"]["max"]})
							.select('"layerId"')
							.distinct(true)
							.getRawMany()

						await Promise.all(tempPoiDetails.map(eachPoiDetailHere => {
								tempPoiIdsArray.push(eachPoiDetailHere.layerId);
						}));
						layerIdsFromLayerDetails.push(tempPoiIdsArray);
					}
				}));
			}
		}
		layerIds = _.intersection(layerIds, layerIdsFromLayerDetails);
		let layers;
		if(layerIds.length > 40000) {
			const layerIdsArr = _.chunk(layerIds,40000);
			layers = await Promise.all(layerIdsArr.map(async eachLayerId => {
				if (query.types) {
					return await this.layerRepository.find({ where: {
						id: In(eachLayerId),
						type: In(query.types)
				}});
				} else {
					return await this.layerRepository.find({ where: {
						id: In(eachLayerId),
				}});
				}
			}));
			layers = _.flattenDeep(layers);
		} else {
			if (query.types) {
				layers = await this.layerRepository.find({ where: {
					id: In(layerIds),
					type: In(query.types)
			}});
			} else {
				layers = await this.layerRepository.find({ where: {
					id: In(layerIds),
			}});
			}
		}
		//Internal Details...
		let layerDetailDict = {};
		let layerDetails = [];
		if(layerIds.length > 40000) {
			const layerIdsArr = _.chunk(layerIds,40000);
			layerDetails = await Promise.all(layerIdsArr.map(async eachLayerId => {
				return await this.layerDetailRepository.find({ where: {layerId: In(eachLayerId)}});
			}));
			layerDetails = _.flattenDeep(layerDetails);
		} else {
			layerDetails = await this.layerDetailRepository.find({ where: {layerId: In(layerIds)}});
		}
		console.log("layerDetails length :",layerDetails.length);
		await Promise.all(layerDetails.map(eachObj => {
			if(layerDetailDict[eachObj.layerId] != undefined) {
				layerDetailDict[eachObj.layerId][eachObj.key] = eachObj.value 
			} else {
				let tempObj = {};
				tempObj[eachObj.key] = eachObj.value;
				layerDetailDict[eachObj.poiId] = tempObj;
			}
		}));
		//InternalDetails Done...
		const response = await this.prepareResponse(layers, layerShapeIndexDict, layerDetailDict);
		return response;
	}

	async prepareResponse(layers: Layer[], layerShapeIndexDict: any , layerDetailDict: any) {
		console.log(layerDetailDict);
		const subCountsDict = {};
		await Promise.all(layers.map(async eachLayer => {
			eachLayer["internalDetails"] = layerDetailDict[eachLayer.id];
			eachLayer['geometry'] = {};
			eachLayer['geometry']['type'] = 'point';
			const coordinates: number[] = [];
			coordinates.push(Number(eachLayer.longitude));
			coordinates.push(Number(eachLayer.latitude));
			eachLayer['geometry']['coordinates'] = coordinates;
			delete eachLayer.latitude;
			delete eachLayer.longitude;
			eachLayer['index'] = layerShapeIndexDict[eachLayer.id];
			if (subCountsDict[eachLayer.type]) {
				subCountsDict[eachLayer.type] += 1;
			} else {
				subCountsDict[eachLayer.type] = 1;
			}
		}));/*
		pois.forEach(async eachPoi => {
			
		});*/
		const responseDict = {};
		responseDict["count"] = layers.length;
		responseDict["subTypeCount"] = subCountsDict;
		responseDict['data'] = layers;
		return responseDict;
	}
}
