import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { HttpService } from "@nestjs/axios";
import { Repository, In, DataSource } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { Poi, PoiStatus } from "../poi/poi.entity";
import { GridService } from "../grid/grid.service";
import { PoiGrid } from "../relations/poi-grid/poi-grid.entity";
import * as tf from "@turf/turf";
import * as geohash from "ngeohash";
import { Grid } from "../grid/grids.entity";
import { LatLong, PoiPaginationDto } from "../interfaces/poi";
import * as _ from "lodash";
import { PoiDetail } from "../poi-details/poi-details.entity";
import { Indexmaster } from "src/index-master/index-master.entity";
import * as stats from "stats-lite";
import { FilterQuery } from "../interfaces/requests";
import * as dotenv from "dotenv";
dotenv.config();
import { PoiService } from "src/poi/poi.service";
import { Shape } from "src/shape/shape.entity";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { UserMerchant } from "./user-merchant.entity";
import { PlacesQuery } from "src/interfaces/places";
import { firstValueFrom } from "rxjs";
import { ShapeService } from "src/shape/shape.service";
import { MultilevelShapesQuery } from "src/interfaces/shapes";
import { ApiKeyUserMerchant } from "./api-key-user-merchant.entity";
import { Lead } from "src/leads/leads.entity";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { FetchMerchantsBodyDto } from "../interfaces/merchant";
import { POIFilter, POIFilterUserTeam } from "src/poi-filter/poi-filter.entity";
import { InjectModel } from "@nestjs/mongoose";
import { DemoShapesDB } from "src/shape/shape.schema";
import { Model } from "mongoose";

@Injectable()
export class MerchantService {
	scorecardRadius: number;
	disableReverseGeocode: boolean;
	bulkScorecardLimit: number;
	constructor(
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(PoiGrid) private poiGridRepository: Repository<PoiGrid>,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		@InjectRepository(PoiDetail) private poiDetailRepository: Repository<PoiDetail>,
		@InjectRepository(Indexmaster) private indexMasterRepository: Repository<Indexmaster>,
		@InjectRepository(Shape) private shapeRepository: Repository<Shape>,
		@InjectRepository(ShapeDetail) private shapeDetailRepository: Repository<ShapeDetail>,
		@InjectRepository(UserMerchant) private userMerchantRepository: Repository<UserMerchant>,
		@InjectRepository(ApiKeyUserMerchant) private apiKeyUserMerchantRepository: Repository<ApiKeyUserMerchant>,
		@InjectRepository(Lead) private leadsRepository: Repository<Lead>,
		@InjectModel("DemoShapesDB") private demoShapesDBModel: Model<DemoShapesDB>,
		private _gridService: GridService,
		private _poiService: PoiService,
		private _shapeService: ShapeService,
		private httpService: HttpService,
		private connection: DataSource,
	) {
		this.scorecardRadius = isNaN(Number(process?.env?.SCORECARD_API_RADIUS))
			? 0.5
			: Number(process.env.SCORECARD_API_RADIUS);
		this.disableReverseGeocode = process?.env?.DISABLE_REVERSE_GEOCODING == "true" ? true : false;
		this.bulkScorecardLimit = isNaN(Number(process?.env?.BULK_SCORECARD_LIMIT))
			? 1000
			: Number(process.env.BULK_SCORECARD_LIMIT);
	}

	async acquisition(query: FilterQuery): Promise<Poi[] | any> {
		let gridIds;
		const gridsSearchedArr = [];
		let poiIdsFromPoiDetails = [];
		let poiGridIds;
		let poiIds;
		if (query["within"]) {
			if (query["within"]["points"].length == 0) {
				delete query["within"];
			}
		}
		const poiStatus = PoiStatus.approved;

		if (query["grids"] || query["location"] || query["within"] || query["poiDetails"]) {
			if (query["poiDetails"]) {
				const poiDetails: any[] = query["poiDetails"];
				if (poiDetails.length == 0) {
					delete query["poiDetails"];
				}
			}
			if (query["grids"]) {
				if (query["grids"]["range"]) {
					if (Object.keys(query["grids"]["range"]).length) {
					}
				}
				if (query["grids"]["select"]) {
					if (Object.keys(query["grids"]["select"]).length) {
						console.log("gridsSelectResponse", gridsSearchedArr);
					}
				}
			}
			if (query["location"]) {
				const locationQueryObject = {};
				let locationQueryString = "";
				Object.keys(query["location"]).forEach((location, index) => {
					if (index === 0) {
						locationQueryObject[location] = query["location"][location];
						locationQueryString += "grid." + location + " = :" + location;
					} else {
						locationQueryObject[location] = query["location"][location];
						locationQueryString += " AND grid." + location + " = :" + location;
					}
				});
				if (Object.keys(locationQueryObject).length) {
					try {
						const locationGrids = await this.gridRepository
							.createQueryBuilder("grid")
							.select("grid.id")
							.where(locationQueryString, locationQueryObject)
							.getMany();
						const locationGridIds = await locationGrids.map((eachGrid) => {
							return eachGrid.id;
						});
						console.log("Length of gridIds in Location Search :", locationGridIds.length);
						gridsSearchedArr.push(locationGridIds);
					} catch (error) {
						console.log(error);
					}
				}
			}
			if (query["within"]) {
				let distance = 0.3;
				if (query["within"]["radius"]) {
					distance = query["within"]["radius"];
				}
				const withinGridsArr: number[][] = await Promise.all(
					query["within"]["points"].map(async (eachLatLong) => {
						//const eachTarget = await this.propertyRepository.findOne({ id: eachId });
						//const point = tf.point([eachTarget.latitude, eachTarget.longitude]);
						/*
						const point = tf.point([eachLatLong.lat, eachLatLong.lng]);
						const topLeft = tf.destination(point, distance, angleA);
						const bottomRight = tf.destination(point, distance, angleB);
						const withinGrids = geohash.bboxes(
						  topLeft["geometry"]["coordinates"][0],
						  topLeft["geometry"]["coordinates"][1],
						  bottomRight["geometry"]["coordinates"][0],
						  bottomRight["geometry"]["coordinates"][1],
						  7
						);
									*/
						const pi = Math.PI;
						const lat_increment = 1 / 110.574;
						const lng_increment = 1 / 111.32;
						const lat_max = Number(eachLatLong.lat) + distance * lat_increment;
						const lat_min = Number(eachLatLong.lat) - distance * lat_increment;
						const lng_max =
							Number(eachLatLong.lng) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
						const lng_min =
							Number(eachLatLong.lng) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
						const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
						try {
							const tempGrid = await this.gridRepository
								.createQueryBuilder("grid")
								.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
								.select("grid.id")
								.getMany();

							const tempGridIds = tempGrid.map((eachGrid) => {
								return eachGrid.id;
							});
							return tempGridIds;
						} catch (error) {
							return null;
						}
					}),
				);
				const tempGrids = _.flattenDeep(withinGridsArr);
				console.log("Length of GridIds from Within search :", tempGrids.length);
				gridsSearchedArr.push(tempGrids);
			}
			if (query["poiDetails"]) {
				const poiDetails: any[] = query["poiDetails"];
				if (poiDetails.length == 0) {
					poiIdsFromPoiDetails = [];
				} else {
					await Promise.all(
						poiDetails.map(async (eachPoiDetail) => {
							if (eachPoiDetail.dataType == "string") {
								const tempPoiIdsFromString = [];
								const tempPoiIds = await this.poiDetailRepository
									.createQueryBuilder("poi_detail")
									.where("key = :key AND value IN(:...values)", {
										key: eachPoiDetail.key,
										values: eachPoiDetail.values,
									})
									.select('"poiId"')
									.distinct(true)
									.getRawMany();
								await Promise.all(
									tempPoiIds.map((eachPoiId) => {
										tempPoiIdsFromString.push(eachPoiId.poiId);
									}),
								);
								poiIdsFromPoiDetails.push(tempPoiIdsFromString);
							}
							if (eachPoiDetail.dataType == "number") {
								console.log("inside numbers query");
								const tempPoiIdsArray = [];
								console.log(eachPoiDetail);
								const tempPoiDetails = await this.poiDetailRepository
									.createQueryBuilder("poi_detail")
									.where("key = :key", { key: eachPoiDetail.key })
									.andWhere("unit BETWEEN :min and :max", {
										min: eachPoiDetail["values"]["min"],
										max: eachPoiDetail["values"]["max"],
									})
									.select('"poiId"')
									.distinct(true)
									.getRawMany();

								console.log("temp poi details", tempPoiDetails);
								await Promise.all(
									tempPoiDetails.map((eachPoiDetailHere) => {
										tempPoiIdsArray.push(eachPoiDetailHere.poiId);
									}),
								);
								poiIdsFromPoiDetails.push(tempPoiIdsArray);
							}
						}),
					);
				}
			}
			let responseIds = [];
			gridsSearchedArr.forEach((eachArr, index) => {
				if (index === 0) {
					responseIds = eachArr;
				} else {
					responseIds = _.intersection(responseIds, eachArr);
				}
			});
			console.log("Length of gridIds :", responseIds.length);
			if (!responseIds) {
				responseIds = [];
			}
			if (responseIds.length > 0) {
				gridIds = responseIds;
				try {
					let poiGrids;
					if (responseIds.length > 50000) {
						const responseIdsArr = _.chunk(responseIds, 50000);
						poiGrids = await Promise.all(
							responseIdsArr.map(async (eachResponseIdsArr) => {
								return await this.poiGridRepository
									.createQueryBuilder("poi_grid")
									.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachResponseIdsArr })
									.getMany();
							}),
						);
					} else {
						poiGrids = await this.poiGridRepository
							.createQueryBuilder("poi_grid")
							.where("poi_grid.gridId IN (:...gridIds)", { gridIds: responseIds })
							.getMany();
					}
					poiGrids = _.flattenDeep(poiGrids);
					poiGridIds = poiGrids.map((eachGrid) => {
						return eachGrid.poiId;
					});
					poiIds = poiGridIds;
				} catch (error) {
					console.log(error);
				}
			} else {
				return [];
			}
		}
		if (!poiIds) {
			poiIds = [];
		}
		if (poiIds.length == 0) {
			poiIds = [0];
		}
		if (query["poiDetails"]) {
			console.log("poi ids array", poiIdsFromPoiDetails);
			let poiIdsFromPoiDetailsIntersected = [];
			const poiDetails: unknown[] = query["poiDetails"];
			poiIdsFromPoiDetails.forEach((eachArr, index) => {
				if (index === 0) {
					poiIdsFromPoiDetailsIntersected = eachArr;
				} else {
					poiIdsFromPoiDetailsIntersected = _.intersection(poiIdsFromPoiDetailsIntersected, eachArr);
				}
			});
			if (poiDetails.length > 0) {
				poiIds = _.intersection(poiIds, poiIdsFromPoiDetailsIntersected);
			}
		}
		const indexMasterGrids = await this.gridRepository
			.createQueryBuilder("grid")
			.leftJoinAndSelect("grid.indexmaster", "indexmaster")
			.where("grid.id In (:...gridIds)", { gridIds: gridIds })
			.getMany();
		const indexMasterGridsDict = {};
		indexMasterGrids.forEach((eachGrid) => {
			const tempDict = {};
			eachGrid.indexmaster.forEach((eachIndexMaster) => {
				if (eachIndexMaster.indexType === "string") {
					tempDict[eachIndexMaster.indexName] = eachIndexMaster.categoricalValue;
				} else {
					tempDict[eachIndexMaster.indexName] = eachIndexMaster.indexValue;
				}
			});
			indexMasterGridsDict[eachGrid.id] = tempDict;
		});
		if (poiIds.length > 60000) {
			const poiIdsArr = _.chunk(poiIds, 60000);
			const pois = await Promise.all(
				poiIdsArr.map(async (eachPoiIdsArr) => {
					const poiGridRelationships = await this.poiGridRepository.find({
						where: {
							poiId: In(eachPoiIdsArr as number[]),
						},
					});
					const poiGridsRelationDict = {};
					try {
						poiGridRelationships.forEach((eachRelation) => {
							poiGridsRelationDict[eachRelation.poiId] = eachRelation.gridId;
						});
						let poiObjects = [];
						if (query["subTypes"] && query["types"]) {
							poiObjects = await this.poiRepository.find({
								where: {
									id: In(eachPoiIdsArr),
									status: poiStatus,
									type: In(query.types),
									subType: In(query["subTypes"]),
									category: "merchant",
								},
							});
						} else if (query["types"]) {
							poiObjects = await this.poiRepository.find({
								where: {
									id: In(eachPoiIdsArr),
									status: poiStatus,
									type: In(query.types),
									category: "merchant",
								},
							});
						} else if (query["subTypes"]) {
							poiObjects = await this.poiRepository.find({
								where: {
									id: In(eachPoiIdsArr),
									status: poiStatus,
									subType: In(query["subTypes"]),
									category: "merchant",
								},
							});
						} else {
							poiObjects = await this.poiRepository.find({
								where: { id: In(eachPoiIdsArr), status: poiStatus, category: "merchant" },
							});
						}
						poiObjects.forEach((eachPoiObject) => {
							const eachGridRelation = poiGridsRelationDict[eachPoiObject.id];
							eachPoiObject["index"] = indexMasterGridsDict[eachGridRelation];
						});
						return poiObjects;
					} catch (error) {
						console.log("error is", error);
					}
				}),
			);
			const POIs = _.flattenDeep(pois) as Poi[];
			const merchants = [];
			await Promise.all(
				POIs.map(async (eachPoi) => {
					const merchant = {};
					const poiGrid = await this.poiGridRepository.findOne({
						where: {
							poiId: eachPoi.id,
						},
					});
					const grid = await this.gridRepository.findOne({
						where: {
							id: poiGrid.gridId,
						},
					});
					merchant["id"] = eachPoi.id;
					merchant["name"] = eachPoi.name;
					merchant["address"] = eachPoi.address;
					merchant["category"] = eachPoi.category;
					merchant["merchantType"] = eachPoi.type;
					merchant["index"] = { footfall: eachPoi["index"]["footfall"] };
					const coordinates: number[] = [];
					coordinates.push(Number(eachPoi["longitude"]));
					coordinates.push(Number(eachPoi["latitude"]));
					merchant["geometry"] = { type: "Point", coordinates: coordinates };
					merchant["locationHierarchy"] = {
						Pincode: grid.Pincode,
						Taluka: grid.Taluka,
						District: grid.District,
						State: grid.State,
					};
					merchants.push(merchant);
				}),
			);
			const response = {};
			response["count"] = merchants.length;
			response["data"] = merchants;
			return response;
		} else {
			try {
				console.log("PoiIds", poiIds);
				if (poiIds.length == 0) {
					poiIds = [0];
				}
				const poiGridRelationships = await this.poiGridRepository.find({
					where: {
						poiId: In(poiIds as number[]),
					},
				});
				let poiObjects = [];
				if (query["subTypes"] && query["types"]) {
					poiObjects = await this.poiRepository.find({
						where: {
							id: In(poiIds),
							status: poiStatus,
							type: In(query.types),
							subType: In(query["subTypes"]),
							category: "merchant",
						},
					});
				} else if (query["types"]) {
					poiObjects = await this.poiRepository.find({
						where: {
							id: In(poiIds),
							status: poiStatus,
							type: In(query.types),
							category: "merchant",
						},
					});
				} else if (query["subTypes"]) {
					poiObjects = await this.poiRepository.find({
						where: {
							id: In(poiIds),
							status: poiStatus,
							subType: In(query["subTypes"]),
							category: "merchant",
						},
					});
				} else {
					poiObjects = await this.poiRepository.find({
						where: { id: In(poiIds), status: poiStatus, category: "merchant" },
					});
				}
				console.log("poiObjects length : ", poiObjects.length);
				const poiGridsRelationDict = {};
				poiGridRelationships.forEach((eachRelation) => {
					poiGridsRelationDict[eachRelation.poiId] = eachRelation.gridId;
				});
				poiObjects.forEach((eachPoiObject) => {
					const eachGridRelation = poiGridsRelationDict[eachPoiObject.id];
					eachPoiObject["index"] = indexMasterGridsDict[eachGridRelation];
				});
				const merchants = [];
				await Promise.all(
					poiObjects.map(async (eachPoi) => {
						const merchant = {};
						const poiGrid = await this.poiGridRepository.findOne({
							where: {
								poiId: eachPoi.id,
							},
						});
						const grid = await this.gridRepository.findOne({
							where: {
								id: poiGrid.gridId,
							},
						});
						merchant["id"] = eachPoi.id;
						merchant["name"] = eachPoi.name;
						merchant["address"] = eachPoi.address;
						merchant["category"] = eachPoi.category;
						merchant["merchantType"] = eachPoi.type;
						merchant["index"] = { footfall: eachPoi["index"]["footfall"] };
						const coordinates: number[] = [];
						coordinates.push(Number(eachPoi["longitude"]));
						coordinates.push(Number(eachPoi["latitude"]));
						merchant["geometry"] = { type: "Point", coordinates: coordinates };
						merchant["locationHierarchy"] = {
							Pincode: grid.Pincode,
							Taluka: grid.Taluka,
							District: grid.District,
							State: grid.State,
						};
						merchants.push(merchant);
					}),
				);
				const response = {};
				response["count"] = merchants.length;
				response["data"] = merchants;
				return response;
			} catch (error) {
				return [];
				console.log(error);
			}
		}
	}

	async scorecard(query) {
		const url = "http://" + process.env.GEOCODING_API_HOST + ":" + process.env.GEOCODING_API_PORT + "/geocode";
		console.log("URL: ", url);
		const address = { address: query["address"], shapedict: false };
		const res = await this.httpService.post(url, address).toPromise();
		console.log("Res :", res.data);
		let latLongs: LatLong[] = [];
		latLongs = res["data"][0]["geometry"]["coordinates"];
		console.log("Lat-Longs :", latLongs);
		let distance = 0.3;
		if (query["radius"]) {
			distance = query["radius"];
			console.log("Radius Found: ", distance);
		}
		//Within Search Begins...
		/*
		const point = tf.point([latLongs[0], latLongs[1]]);
		const topLeft = tf.destination(point, distance, angleA);
		const bottomRight = tf.destination(point, distance, angleB);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		*/
		const pi = Math.PI;
		const lat_increment = 1 / 110.574;
		const lng_increment = 1 / 111.32;
		const lat_max = Number(latLongs[0]) + distance * lat_increment;
		const lat_min = Number(latLongs[0]) - distance * lat_increment;
		const lng_max = Number(latLongs[1]) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
		const lng_min = Number(latLongs[1]) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
		const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
		let gridIdsFromWithin;
		try {
			const tempGrid = await this.gridRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.select("grid.id")
				.getMany();

			gridIdsFromWithin = tempGrid.map((eachGrid) => {
				return eachGrid.id;
			});
		} catch (error) {
			console.log("Error:", error);
		}
		//Within Search Ends...
		//Location Search Begins...
		let gridIdsFromLocation;
		if (query["location"]) {
			const locationQueryObject = {};
			let locationQueryString = "";
			Object.keys(query["location"]).forEach((location, index) => {
				if (index === 0) {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += "grid." + location + " = :" + location;
				} else {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += " AND grid." + location + " = :" + location;
				}
			});
			if (Object.keys(locationQueryObject).length) {
				try {
					const locationGrids = await this.gridRepository
						.createQueryBuilder("grid")
						.select("grid.id")
						.where(locationQueryString, locationQueryObject)
						.getMany();
					const locationGridIds = await locationGrids.map((eachGrid) => {
						return eachGrid.id;
					});
					console.log("Length of gridIds in Location Search :", locationGridIds.length);
					gridIdsFromLocation = locationGridIds;
				} catch (error) {
					console.log(error);
				}
			}
		}
		let gridIds: number[];
		if (query["location"]) {
			gridIds = _.intersection(gridIdsFromLocation, gridIdsFromWithin);
		} else {
			gridIds = gridIdsFromWithin;
		}
		//Grid Search Complete...
		//Searching PoiIds...
		let poiIds: number[];
		try {
			if (gridIds.length > 0) {
				let poiGrids;
				if (gridIds.length > 50000) {
					const gridIdsArr = _.chunk(gridIds, 50000);
					poiGrids = await Promise.all(
						gridIdsArr.map(async (eachGridIds) => {
							return await this.poiGridRepository
								.createQueryBuilder("poi_grid")
								.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachGridIds })
								.getMany();
						}),
					);
				} else {
					poiGrids = await this.poiGridRepository
						.createQueryBuilder("poi_grid")
						.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
						.getMany();
				}
				poiGrids = _.flattenDeep(poiGrids);
				poiIds = poiGrids.map((eachGrid) => {
					return eachGrid.poiId;
				});
				console.log("Length of PoiIds:", poiIds);
			} else {
				poiIds = [0];
			}
		} catch (err) {
			console.log(err);
		}
		//PoiIds Found...
		//Searching for Pois and PoiNames...
		let pois: Poi[];
		const poiNames: any[] = [];
		try {
			if (poiIds.length > 0) {
				if (poiIds.length > 50000) {
					const poiIdsArr = _.chunk(poiIds, 50000);
					const temppois = await Promise.all(
						poiIdsArr.map(async (eachPoiIds) => {
							if (query["merchantType"]) {
								return await this.poiRepository
									.createQueryBuilder("poi")
									.where("poi.id IN (:...poiIds) AND poi.category = 'merchant'", {
										poiIds: eachPoiIds,
									})
									.andWhere("poi.type IN (:...types)", { types: query["merchantType"] })
									.getMany();
							} else {
								return await this.poiRepository
									.createQueryBuilder("poi")
									.where("poi.id IN (:...poiIds) AND poi.category = 'merchant'", {
										poiIds: eachPoiIds,
									})
									.getMany();
							}
						}),
					);
					pois = _.flattenDeep(temppois) as Poi[];
				} else {
					if (query["merchantType"]) {
						/*pois = await this.poiRepository.find({ 
			where:{id: In(poiIds), category:"financial", type: In(query["merchantType"])}});
									console.log("Pois: ",pois);*/

						pois = await this.poiRepository
							.createQueryBuilder("poi")
							.where("id IN (:...poiIds) AND category = 'merchant'", { poiIds: poiIds })
							.andWhere("type IN (:...types)", { types: query["merchantType"] })
							.getMany();
					} else {
						pois = await this.poiRepository
							.createQueryBuilder("poi")
							.where("poi.id IN (:...poiIds) AND poi.category = 'merchant'", { poiIds: poiIds })
							.getMany();
					}
				}
			} else {
				return [];
			}
			await Promise.all(
				pois.map((eachPoi) => {
					const tempObj = {};
					tempObj["name"] = eachPoi.name;
					tempObj["poiId"] = eachPoi.id;
					poiNames.push(tempObj);
				}),
			);
			//console.log("PoiNames :",poiNames);
		} catch (err) {
			console.log(err);
			return [];
		}
		//Pois and PoiNames found...
		const merchants = [];
		//Matching Starts Here...
		if (query["name"]) {
			let similarityIndexes = [];
			await Promise.all(
				poiNames.map(async (eachObj) => {
					const similarity = (await this._gridService.similarity(query["name"], eachObj["name"], true)) * 100;
					if (similarity >= Number(process.env.LOWEST_MATCH_PERCENT)) {
						const tempObj = { poiId: eachObj["poiId"], similarity: similarity };
						similarityIndexes.push(tempObj);
					}
				}),
			);
			similarityIndexes = _.orderBy(similarityIndexes, ["similarity"], ["desc"]);
			//console.log("Similarity Index :",similarityIndexes);
			await Promise.all(
				similarityIndexes.map(async (eachSimilarityObj) => {
					const merchant = {};
					const poi = await this.poiRepository.findOne({ where: { id: eachSimilarityObj["poiId"] } });
					const poiGrid = await this.poiGridRepository.findOne({
						where: { poiId: eachSimilarityObj["poiId"] },
					});
					const grid = await this.gridRepository.findOne({ where: { id: poiGrid.gridId } });
					merchant["matchPercentage"] = eachSimilarityObj["similarity"];
					merchant["id"] = poi.id;
					merchant["name"] = poi.name;
					merchant["address"] = poi.address;
					merchant["category"] = poi.category;
					merchant["merchantType"] = poi.type;
					merchant["merchantSubType"] = poi.subType;
					merchant["dataSource"] = poi.dataType;
					const locationHierarchy = {};
					locationHierarchy["Pincode"] = grid.Pincode;
					locationHierarchy["Taluka"] = grid.Taluka;
					locationHierarchy["District"] = grid.District;
					locationHierarchy["State"] = grid.State;
					merchant["locationHierarchy"] = locationHierarchy;
					const coordinates: number[] = [];
					coordinates.push(Number(poi["longitude"]));
					coordinates.push(Number(poi["latitude"]));
					const geometry = { type: "Point", coordinates: coordinates };
					merchant["geometry"] = geometry;
					//Within Search Begins...
					/*
				const point = tf.point([latLngs[0], latLngs[1]]);
				const topLeft = tf.destination(point, distance, angleA);
				const bottomRight = tf.destination(point, distance, angleB);
				const withinGrids = geohash.bboxes(
					topLeft["geometry"]["coordinates"][0],
					topLeft["geometry"]["coordinates"][1],
					bottomRight["geometry"]["coordinates"][0],
					bottomRight["geometry"]["coordinates"][1],
					7
				);
				*/
					const pi = Math.PI;
					const lat_increment = 1 / 110.574;
					const lng_increment = 1 / 111.32;
					const lat_max = Number(latLongs[0]) + distance * lat_increment;
					const lat_min = Number(latLongs[0]) - distance * lat_increment;
					const lng_max = Number(latLongs[1]) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
					const lng_min = Number(latLongs[1]) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
					const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
					let gridIds: number[] = [];
					try {
						const tempGrid = await this.gridRepository
							.createQueryBuilder("grid")
							.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
							.select("grid.id")
							.getMany();

						gridIds = tempGrid.map((eachGrid) => {
							return eachGrid.id;
						});
					} catch (error) {
						console.log("Error:", error);
					}
					//Within Search Ends...
					//Scorecard calculation begins...
					const indexAggrigationDict = {
						affluence: "median",
						footfall: "median",
						population: "sum",
						entertainment: "sum",
						economic_activity: "categorical-median",
						loan_opportunity: "categorical-median",
						loan_risk: "median",
						high_street: "median",
						income: "median",
						income_group: "categorical",
						commercial_activity: "categorical-median",
						digitization_index: "categorical-median",
						commercial: "sum",
						financial_institute: "sum",
						retail: "sum",
					};
					const scorecard = {};
					const poiDensity = {};
					await Promise.all(
						Object.keys(indexAggrigationDict).map(async (eachKey) => {
							if (gridIds.length > 0) {
								try {
									let indexValues = [];
									if (gridIds.length > 50000) {
										const gridIdsArr = _.chunk(gridIds, 50000);
										await Promise.all(
											gridIdsArr.map(async (eachGridIds) => {
												const indexMaster = await this.indexMasterRepository
													.createQueryBuilder("indexmaster")
													.select('"indexValue"')
													.where('"indexName" = :indexName AND "gridId" IN(:...gridIds)', {
														indexName: eachKey,
														gridIds: eachGridIds,
													})
													.getRawMany();
												if (indexAggrigationDict[eachKey] == "categorical") {
													indexValues = await Promise.all(
														indexMaster.map((eachIndexMaster) => {
															return Number(eachIndexMaster["indexValue"]);
														}),
													);
												} else {
													indexValues = await Promise.all(
														indexMaster.map((eachIndexMaster) => {
															return Number(eachIndexMaster["indexValue"]);
														}),
													);
												}
											}),
										);
									} else {
										const indexMaster = await this.indexMasterRepository
											.createQueryBuilder("indexmaster")
											.select('"indexValue"')
											.where('"indexName" = :indexName AND "gridId" IN(:...gridIds)', {
												indexName: eachKey,
												gridIds: gridIds,
											})
											.getRawMany();
										if (indexAggrigationDict[eachKey] == "categorical") {
											indexValues = await Promise.all(
												indexMaster.map((eachIndexMaster) => {
													return String(eachIndexMaster["indexValue"]);
												}),
											);
										} else {
											indexValues = await Promise.all(
												indexMaster.map((eachIndexMaster) => {
													return Number(eachIndexMaster["indexValue"]);
												}),
											);
										}
									}
									if (indexAggrigationDict[eachKey] == "mean") {
										const mean = stats.mean(indexValues);
										scorecard[eachKey] = mean;
									}
									if (indexAggrigationDict[eachKey] == "median") {
										const median = stats.median(indexValues);
										scorecard[eachKey] = median;
									}
									if (indexAggrigationDict[eachKey] == "sum") {
										const sum = stats.sum(indexValues);
										scorecard[eachKey] = sum;
									}
									if (indexAggrigationDict[eachKey] == "mode") {
										let mode;
										mode = stats.mode(indexValues);
										if (typeof mode != "number") {
											mode = Array.from(mode);
										}
										scorecard[eachKey] = mode;
									}
									if (indexAggrigationDict[eachKey] == "percentage") {
										let ligCount = 0;
										let migCount = 0;
										let higCount = 0;
										await Promise.all(
											indexValues.map((eachVal) => {
												if (eachVal == 0) {
													ligCount = ligCount + 1;
												}
												if (eachVal == 1) {
													migCount = migCount + 1;
												}
												if (eachVal == 2) {
													higCount = higCount + 1;
												}
											}),
										);
										scorecard["LIG%"] = (ligCount / indexValues.length) * 100;
										scorecard["MIG%"] = (migCount / indexValues.length) * 100;
										scorecard["HIG%"] = (higCount / indexValues.length) * 100;
									}
									if (indexAggrigationDict[eachKey] == "categorical") {
										scorecard[eachKey] = {};
										console.log("Aggrigation Type : Categorial");
										const valuePairs = await this.indexMasterRepository
											.createQueryBuilder("indexmaster")
											.select(['"indexValue"', '"categoricalValue"'])
											.where('"indexName" = :indexName', { indexName: eachKey })
											.distinct(true)
											.getRawMany();
										const values = valuePairs.map((eachObj) => {
											return eachObj["indexValue"];
										});
										await Promise.all(
											values.map(async (eachVal) => {
												let count = 0;
												await Promise.all(
													indexValues.map((val) => {
														if (Number(val) == Number(eachVal)) {
															count = count + 1;
														}
													}),
												);
												const percent = (count / indexValues.length) * 100;
												let categorialValue;
												await Promise.all(
													valuePairs.map((eachObj) => {
														if (eachObj["indexValue"] == eachVal) {
															categorialValue = eachObj["categoricalValue"];
														}
													}),
												);
												scorecard[eachKey][categorialValue] = percent;
											}),
										);
									}
									if (indexAggrigationDict[eachKey] == "categorical-median") {
										const median = stats.median(indexValues);
										console.log("Aggrigation Type : Categorial-Median");
										const valuePairs = await this.indexMasterRepository
											.createQueryBuilder("indexmaster")
											.select('"categoricalValue"')
											.where('"indexName" = :indexName AND "indexValue" = :indexValue', {
												indexName: eachKey,
												indexValue: median,
											})
											.distinct(true)
											.getRawMany();
										scorecard[eachKey] = valuePairs[0]["categoricalValue"];
									}
								} catch (err) {
									console.log(err);
								}
							}
						}),
					);
					//Calculation of Society count and poi count begins...
					if (gridIds.length > 0) {
						try {
							let poiIds: number[] = [];
							if (gridIds.length > 50000) {
								const gridIdsArr = _.chunk(gridIds, 50000);
								await Promise.all(
									gridIdsArr.map(async (eachArr) => {
										const poiGrids = await this.poiGridRepository
											.createQueryBuilder("poi_grid")
											.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
											.distinct(true)
											.getMany();
										poiIds = await Promise.all(
											poiGrids.map((eachObj) => {
												return eachObj.poiId;
											}),
										);
									}),
								);
							} else {
								const poiGrids = await this.poiGridRepository
									.createQueryBuilder("poi_grid")
									.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
									.distinct(true)
									.getMany();
								poiIds = await Promise.all(
									poiGrids.map((eachObj) => {
										return eachObj.poiId;
									}),
								);
							}
							poiIds = _.flattenDeep(poiIds);
							scorecard["POI density"] = poiIds.length;
							//Poi density done...
							let societyCount = 0;
							if (poiIds.length > 20000) {
								const poiIdsArr = _.chunk(poiIds, 20000);
								await Promise.all(
									poiIdsArr.map(async (eachArr) => {
										const count = await this.poiRepository.count({
											where: {
												id: In(eachArr),
												type: "society",
											},
										});
										societyCount = societyCount + count;
									}),
								);
							} else {
								societyCount = await this.poiRepository.count({
									where: { id: In(poiIds), type: "society" },
								});
							}
							scorecard["Society Density"] = societyCount;
							//Individual Type count begins...
							const reqPois: string[] = query["poiTypes"];
							await Promise.all(
								reqPois.map(async (eachPoi) => {
									let individualTypeCount = 0;
									if (poiIds.length > 20000) {
										const poiIdsArr = _.chunk(poiIds, 20000);
										await Promise.all(
											poiIdsArr.map(async (eachArr) => {
												const count = await this.poiRepository.count({
													where: {
														id: In(eachArr),
														type: eachPoi,
													},
												});
												individualTypeCount = societyCount + count;
											}),
										);
									} else {
										individualTypeCount = await this.poiRepository.count({
											where: {
												id: In(poiIds),
												type: eachPoi,
											},
										});
									}
									poiDensity[eachPoi] = individualTypeCount;
								}),
							);
						} catch (err) {
							console.log(err);
						}
					}
					//Scorecard calculation ends...
					merchant["scorecard"] = scorecard;
					merchant["poiTypeCount"] = poiDensity;
					merchants.push(merchant);
				}),
			);
		} //Matching Ends Here...
		else {
			await Promise.all(
				pois.map(async (poi) => {
					const merchant = {};
					const poiGrid = await this.poiGridRepository.findOne({
						where: {
							poiId: poi.id,
						},
					});
					const grid = await this.gridRepository.findOne({
						where: {
							id: poiGrid.gridId,
						},
					});
					merchant["id"] = poi.id;
					merchant["name"] = poi.name;
					merchant["address"] = poi.address;
					merchant["category"] = poi.category;
					merchant["merchantType"] = poi.type;
					merchant["merchantSubType"] = poi.subType;
					merchant["dataSource"] = poi.dataType;
					const locationHierarchy = {};
					locationHierarchy["Pincode"] = grid.Pincode;
					locationHierarchy["Taluka"] = grid.Taluka;
					locationHierarchy["District"] = grid.District;
					locationHierarchy["State"] = grid.State;
					merchant["locationHierarchy"] = locationHierarchy;
					const coordinates: number[] = [];
					coordinates.push(Number(poi["longitude"]));
					coordinates.push(Number(poi["latitude"]));
					const geometry = { type: "Point", coordinates: coordinates };
					merchant["geometry"] = geometry;
					const latLngs = [poi.latitude, poi.longitude];
					//Within Search Begins...
					/*
						  const point = tf.point([latLngs[0], latLngs[1]]);
						  const topLeft = tf.destination(point, distance, angleA);
						  const bottomRight = tf.destination(point, distance, angleB);
						  const withinGrids = geohash.bboxes(
							  topLeft["geometry"]["coordinates"][0],
							  topLeft["geometry"]["coordinates"][1],
							  bottomRight["geometry"]["coordinates"][0],
							  bottomRight["geometry"]["coordinates"][1],
							  7
						  );
						  */
					const pi = Math.PI;
					const lat_increment = 1 / 110.574;
					const lng_increment = 1 / 111.32;
					const lat_max = Number(latLngs[0]) + distance * lat_increment;
					const lat_min = Number(latLngs[0]) - distance * lat_increment;
					const lng_max = Number(latLngs[1]) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
					const lng_min = Number(latLngs[1]) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
					const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
					let gridIds: number[] = [];
					try {
						const tempGrid = await this.gridRepository
							.createQueryBuilder("grid")
							.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
							.select("grid.id")
							.getMany();

						gridIds = tempGrid.map((eachGrid) => {
							return eachGrid.id;
						});
					} catch (error) {
						console.log("Error:", error);
					}
					//Within Search Ends...
					const indexAggrigationDict = {
						affluence: "median",
						footfall: "median",
						population: "sum",
						entertainment: "sum",
						economic_activity: "categorical-median",
						loan_opportunity: "categorical-median",
						loan_risk: "median",
						high_street: "median",
						income: "median",
						income_group: "categorical",
						commercial_activity: "categorical-median",
						digitization_index: "categorical-median",
						commercial: "sum",
						financial_institute: "sum",
						retail: "sum",
					};
					const scorecard = {};
					const poiDensity = {};
					await Promise.all(
						Object.keys(indexAggrigationDict).map(async (eachKey) => {
							if (gridIds.length > 0) {
								try {
									let indexValues = [];
									if (gridIds.length > 50000) {
										const gridIdsArr = _.chunk(gridIds, 50000);
										await Promise.all(
											gridIdsArr.map(async (eachGridIds) => {
												const indexMaster = await this.indexMasterRepository
													.createQueryBuilder("indexmaster")
													.select('"indexValue"')
													.where('"indexName" = :indexName AND "gridId" IN(:...gridIds)', {
														indexName: eachKey,
														gridIds: eachGridIds,
													})
													.getRawMany();
												if (indexAggrigationDict[eachKey] == "categorical") {
													indexValues = await Promise.all(
														indexMaster.map((eachIndexMaster) => {
															return Number(eachIndexMaster["indexValue"]);
														}),
													);
												} else {
													indexValues = await Promise.all(
														indexMaster.map((eachIndexMaster) => {
															return Number(eachIndexMaster["indexValue"]);
														}),
													);
												}
											}),
										);
									} else {
										const indexMaster = await this.indexMasterRepository
											.createQueryBuilder("indexmaster")
											.select('"indexValue"')
											.where('"indexName" = :indexName AND "gridId" IN(:...gridIds)', {
												indexName: eachKey,
												gridIds: gridIds,
											})
											.getRawMany();
										if (indexAggrigationDict[eachKey] == "categorical") {
											indexValues = await Promise.all(
												indexMaster.map((eachIndexMaster) => {
													return String(eachIndexMaster["indexValue"]);
												}),
											);
										} else {
											indexValues = await Promise.all(
												indexMaster.map((eachIndexMaster) => {
													return Number(eachIndexMaster["indexValue"]);
												}),
											);
										}
									}
									if (indexAggrigationDict[eachKey] == "mean") {
										const mean = stats.mean(indexValues);
										scorecard[eachKey] = mean;
									}
									if (indexAggrigationDict[eachKey] == "median") {
										const median = stats.median(indexValues);
										scorecard[eachKey] = median;
									}
									if (indexAggrigationDict[eachKey] == "sum") {
										const sum = stats.sum(indexValues);
										scorecard[eachKey] = sum;
									}
									if (indexAggrigationDict[eachKey] == "mode") {
										let mode;
										mode = stats.mode(indexValues);
										if (typeof mode != "number") {
											mode = Array.from(mode);
										}
										scorecard[eachKey] = mode;
									}
									if (indexAggrigationDict[eachKey] == "percentage") {
										let ligCount = 0;
										let migCount = 0;
										let higCount = 0;
										await Promise.all(
											indexValues.map((eachVal) => {
												if (eachVal == 0) {
													ligCount = ligCount + 1;
												}
												if (eachVal == 1) {
													migCount = migCount + 1;
												}
												if (eachVal == 2) {
													higCount = higCount + 1;
												}
											}),
										);
										scorecard["LIG%"] = (ligCount / indexValues.length) * 100;
										scorecard["MIG%"] = (migCount / indexValues.length) * 100;
										scorecard["HIG%"] = (higCount / indexValues.length) * 100;
									}
									if (indexAggrigationDict[eachKey] == "categorical") {
										scorecard[eachKey] = {};
										console.log("Aggrigation Type : Categorial");
										const valuePairs = await this.indexMasterRepository
											.createQueryBuilder("indexmaster")
											.select(['"indexValue"', '"categoricalValue"'])
											.where('"indexName" = :indexName', { indexName: eachKey })
											.distinct(true)
											.getRawMany();
										const values = valuePairs.map((eachObj) => {
											return eachObj["indexValue"];
										});
										await Promise.all(
											values.map(async (eachVal) => {
												let count = 0;
												await Promise.all(
													indexValues.map((val) => {
														if (Number(val) == Number(eachVal)) {
															count = count + 1;
														}
													}),
												);
												const percent = (count / indexValues.length) * 100;
												let categorialValue;
												await Promise.all(
													valuePairs.map((eachObj) => {
														if (eachObj["indexValue"] == eachVal) {
															categorialValue = eachObj["categoricalValue"];
														}
													}),
												);
												scorecard[eachKey][categorialValue] = percent;
											}),
										);
									}
									if (indexAggrigationDict[eachKey] == "categorical-median") {
										const median = stats.median(indexValues);
										console.log("Aggrigation Type : Categorial-Median");
										const valuePairs = await this.indexMasterRepository
											.createQueryBuilder("indexmaster")
											.select('"categoricalValue"')
											.where('"indexName" = :indexName AND "indexValue" = :indexValue', {
												indexName: eachKey,
												indexValue: median,
											})
											.distinct(true)
											.getRawMany();
										//console.log("Vlaue Pair:",valuePairs);
										scorecard[eachKey] = valuePairs[0]["categoricalValue"];
									}
								} catch (err) {
									console.log(err);
								}
							}
						}),
					);
					if (gridIds.length > 0) {
						try {
							let poiIds: number[] = [];
							if (gridIds.length > 50000) {
								const gridIdsArr = _.chunk(gridIds, 50000);
								await Promise.all(
									gridIdsArr.map(async (eachArr) => {
										const poiGrids = await this.poiGridRepository
											.createQueryBuilder("poi_grid")
											.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
											.distinct(true)
											.getMany();
										poiIds = await Promise.all(
											poiGrids.map((eachObj) => {
												return eachObj.poiId;
											}),
										);
									}),
								);
							} else {
								const poiGrids = await this.poiGridRepository
									.createQueryBuilder("poi_grid")
									.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
									.distinct(true)
									.getMany();
								poiIds = await Promise.all(
									poiGrids.map((eachObj) => {
										return eachObj.poiId;
									}),
								);
							}
							poiIds = _.flattenDeep(poiIds);
							scorecard["POI density"] = poiIds.length;
							//Poi density done...
							let societyCount = 0;
							if (poiIds.length > 20000) {
								const poiIdsArr = _.chunk(poiIds, 20000);
								await Promise.all(
									poiIdsArr.map(async (eachArr) => {
										const count = await this.poiRepository.count({
											where: {
												id: In(eachArr),
												type: "society",
											},
										});
										societyCount = societyCount + count;
									}),
								);
							} else {
								societyCount = await this.poiRepository.count({
									where: { id: In(poiIds), type: "society" },
								});
							}
							scorecard["Society Density"] = societyCount;
							//Individual Type count begins...
							const reqPois: string[] = query["poiTypes"];
							await Promise.all(
								reqPois.map(async (eachPoi) => {
									let individualTypeCount = 0;
									if (poiIds.length > 20000) {
										const poiIdsArr = _.chunk(poiIds, 20000);
										await Promise.all(
											poiIdsArr.map(async (eachArr) => {
												const count = await this.poiRepository.count({
													where: {
														id: In(eachArr),
														type: eachPoi,
													},
												});
												individualTypeCount = societyCount + count;
											}),
										);
									} else {
										individualTypeCount = await this.poiRepository.count({
											where: {
												id: In(poiIds),
												type: eachPoi,
											},
										});
									}
									poiDensity[eachPoi] = individualTypeCount;
								}),
							);
						} catch (err) {
							console.log(err);
						}
					}
					merchant["scorecard"] = scorecard;
					merchant["poiTypeCount"] = poiDensity;
					merchants.push(merchant);
				}),
			);
		}
		const response = { count: merchants.length, merchants: merchants };
		response["typeCount"] = {};
		await Promise.all(
			merchants.map((merchant) => {
				const subTypes = Object.keys(response["typeCount"]);
				if (subTypes.includes(merchant.merchantType)) {
					//console.log("Type encounterd :",poi.type);
					response["typeCount"][merchant.merchantType] = response["typeCount"][merchant.merchantType] + 1;
				} else {
					response["typeCount"][merchant.merchantType] = 1;
				}
			}),
		);
		console.log("TypeCount :", response["typeCount"]);
		return response;
	}

	async acquisitionNew(query) {
		if (query["types"] == undefined) {
			const typesArr = await this.poiRepository
				.createQueryBuilder("poi")
				.select("type")
				.distinct(true)
				.where(`category = 'merchant'`)
				.getRawMany();
			//console.log("Merchant Types :",typesArr);
			query["types"] = typesArr.map((eachObj) => {
				return eachObj["type"];
			});
		}
		if (query["merchantIds"]) {
			query["ids"] = query["merchantIds"];
		}
		const res = await this._poiService.filter(query);
		const data = res["data"] as Poi[];
		if (data == undefined) {
			return { count: 0, data: [] };
		}
		let merchants = [];
		if (query["subTypes"]) {
			merchants = await this.filterMerchantsFromPois(data, query["subTypes"]);
		} else {
			merchants = await this.filterMerchantsFromPois(data);
		}
		const response = {};
		response["count"] = merchants.length;
		response["data"] = merchants;
		if (query["location"]) {
			const shape = await this.shapeRepository.findOne({
				where: {
					level: Object.keys(query["location"])[0],
					name: query["location"][Object.keys(query["location"])[0]],
				},
			});
			const shapeDetails = await this.shapeDetailRepository.find({ where: { shapeId: shape.id } });
			const reqKeys = ["pincode_category", "population", "area"];
			const pincodeDetails = {};
			await Promise.all(
				reqKeys.map(async (eachKey) => {
					await Promise.all(
						shapeDetails.map((eachShapeDetail) => {
							if (eachShapeDetail.key == eachKey) {
								pincodeDetails[eachKey] = {
									unit: eachShapeDetail.metrics,
									value: eachShapeDetail.value,
								};
							}
						}),
					);
				}),
			);
			const orderedPincodeDetails = {};
			_(pincodeDetails)
				.keys()
				.sort()
				.each(function (key) {
					orderedPincodeDetails[key] = pincodeDetails[key];
				});
			response["location"] = { pincode: shape.name, properties: orderedPincodeDetails };
			//response["pincodeDetails"] = orderedPincodeDetails;
			//response[""]
		}
		return response;
	}

	async acquisitionV3(query) {
		if (query["types"] == undefined) {
			const typesArr = await this.poiRepository
				.createQueryBuilder("poi")
				.select("type")
				.distinct(true)
				.where(`category = 'merchant'`)
				.getRawMany();
			//console.log("Merchant Types :",typesArr);
			query["types"] = typesArr.map((eachObj) => {
				return eachObj["type"];
			});
		}
		const res = await this._poiService.filter(query);
		const data = res["data"] as Poi[];
		if (data == undefined) {
			return { count: 0, data: [] };
		}
		let merchants = [];
		if (query["subTypes"]) {
			merchants = await this.filterMerchantsFromPois(data, query["subTypes"]);
		} else {
			merchants = await this.filterMerchantsFromPois(data);
		}
		const response = {};
		if (query["page"]) {
			const page = Number(query["page"]);
			const merchantsArr = _.chunk(merchants, 10);
			const totalPages = merchantsArr.length;
			if (page > totalPages) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "Page number requested is greater than total number of pages",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			if (page < 1 || !Number.isInteger(page)) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "Invalid Page Number",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			response["count"] = merchantsArr[page - 1].length;
			response["data"] = merchantsArr[page - 1];
			response["page"] = page;
			response["totalCount"] = merchants.length;
			return response;
		} else {
			response["count"] = merchants.length;
			response["data"] = merchants;
			return response;
		}
	}

	async scorecardNew(query) {
		const url = "http://" + process.env.GEOCODING_API_HOST + ":" + process.env.GEOCODING_API_PORT + "/geocode";
		console.log("URL: ", url);
		const address = { address: query["address"], shapedict: false };
		const res = await this.httpService.post(url, address).toPromise();
		console.log("Res :", res.data);
		let latLongs: LatLong[] = [];
		latLongs = res["data"][0]["geometry"]["coordinates"];
		//putting radius in query...
		if (query["radius"] == undefined) {
			query["radius"] = 0.3;
		}
		const distance = query["radius"];
		//putting types in query...
		if (query["merchantType"]) {
			query["types"] = query["merchantType"];
		} else {
			const typesArr = await this.poiRepository
				.createQueryBuilder("poi")
				.select("type")
				.distinct(true)
				.where(`category = 'merchant'`)
				.getRawMany();
			//console.log("Merchant Types :",typesArr);
			query["types"] = typesArr.map((eachObj) => {
				return eachObj["type"];
			});
		}
		//Putting within in query...
		query["within"] = { radius: query["radius"], points: [{ lat: latLongs[0], lng: latLongs[1] }] };
		const queryRes = await this._poiService.filter(query);
		const data = queryRes["data"] as Poi[];
		const pois = await this.filterMerchantsFromPois(data);
		const poiNames = [];
		await Promise.all(
			pois.map((eachPoi) => {
				const tempObj = {};
				tempObj["name"] = eachPoi.name;
				tempObj["poiId"] = eachPoi.id;
				poiNames.push(tempObj);
			}),
		);
		const merchants = [];
		if (query["name"]) {
			let similarityIndexes = [];
			await Promise.all(
				poiNames.map(async (eachObj) => {
					const similarity = (await this._gridService.similarity(query["name"], eachObj["name"], true)) * 100;
					if (similarity >= Number(process.env.LOWEST_MATCH_PERCENT)) {
						const tempObj = { poiId: eachObj["poiId"], similarity: similarity };
						similarityIndexes.push(tempObj);
					}
				}),
			);
			similarityIndexes = _.orderBy(similarityIndexes, ["similarity"], ["desc"]);
			await Promise.all(
				similarityIndexes.map(async (eachSimilarityObj) => {
					const merchant = {};
					const poi = await this.poiRepository.findOne({ where: { id: eachSimilarityObj["poiId"] } });
					const poiGrid = await this.poiGridRepository.findOne({
						where: { poiId: eachSimilarityObj["poiId"] },
					});
					const grid = await this.gridRepository.findOne({ where: { id: poiGrid.gridId } });
					merchant["matchPercentage"] = eachSimilarityObj["similarity"];
					merchant["id"] = poi.id;
					merchant["name"] = poi.name;
					merchant["address"] = poi.address;
					merchant["category"] = poi.category;
					merchant["merchantType"] = poi.type;
					merchant["merchantSubType"] = poi.subType;
					merchant["dataSource"] = poi.dataType;
					const locationHierarchy = {};
					locationHierarchy["Pincode"] = grid.Pincode;
					locationHierarchy["Taluka"] = grid.Taluka;
					locationHierarchy["District"] = grid.District;
					locationHierarchy["State"] = grid.State;
					merchant["locationHierarchy"] = locationHierarchy;
					const coordinates: number[] = [];
					coordinates.push(Number(poi.longitude));
					coordinates.push(Number(poi.latitude));
					const geometry = { type: "Point", coordinates: coordinates };
					merchant["geometry"] = geometry;
					const latLngs = [poi.latitude, poi.longitude];
					//Within Search Begins...
					/*
				const point = tf.point([latLngs[0], latLngs[1]]);
				const topLeft = tf.destination(point, distance, angleA);
				const bottomRight = tf.destination(point, distance, angleB);
				const withinGrids = geohash.bboxes(
					topLeft["geometry"]["coordinates"][0],
					topLeft["geometry"]["coordinates"][1],
					bottomRight["geometry"]["coordinates"][0],
					bottomRight["geometry"]["coordinates"][1],
					7
				);
				*/
					const pi = Math.PI;
					const lat_increment = 1 / 110.574;
					const lng_increment = 1 / 111.32;
					const lat_max = Number(latLngs[0]) + distance * lat_increment;
					const lat_min = Number(latLngs[0]) - distance * lat_increment;
					const lng_max = Number(latLngs[1]) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
					const lng_min = Number(latLngs[1]) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
					const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
					let gridIds: number[] = [];
					try {
						const tempGrid = await this.gridRepository
							.createQueryBuilder("grid")
							.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
							.select("grid.id")
							.getMany();

						gridIds = tempGrid.map((eachGrid) => {
							return eachGrid.id;
						});
					} catch (error) {
						console.log("Error:", error);
					}
					//Within Search Ends...
					const indexAggrigationDict = {
						affluence: "median",
						footfall: "median",
						population: "sum",
						entertainment: "sum",
						economic_activity: "categorical-median",
						loan_opportunity: "categorical-median",
						loan_risk: "median",
						high_street: "median",
						income: "median",
						income_group: "categorical",
						commercial_activity: "categorical-median",
						digitization_index: "categorical-median",
						commercial: "sum",
						financial_institute: "sum",
						retail: "sum",
					};
					const scorecard = {};
					const poiDensity = {};
					//scorecard = await this.getScorecard(indexAggrigationDict, gridIds);
					//new try...
					const indexAggQuery = {};
					indexAggQuery["responseType"] = "aggregation";
					indexAggQuery["requiredShapes"] = false;
					indexAggQuery["locationIndex"] = indexAggrigationDict;
					const indexAggRes = await this._gridService.getAggrigation(gridIds, indexAggQuery, true);
					const indexAggData = indexAggRes["data"] as any[];
					await Promise.all(
						indexAggData.map(async (eachObj) => {
							if (eachObj["aggregationType"] == "categorial") {
								scorecard[eachObj["key"]] = {};
								await Promise.all(
									Object.keys(eachObj["value"]).map((eachKey) => {
										scorecard[eachObj["key"]][eachKey] = eachObj["value"][eachKey];
									}),
								);
							} else {
								scorecard[eachObj["key"]] = eachObj["value"];
							}
						}),
					);
					//try ends...
					//Calculation of Society count and poi count begins...
					if (gridIds.length > 0) {
						try {
							let poiIds: number[] = [];
							if (gridIds.length > 50000) {
								const gridIdsArr = _.chunk(gridIds, 50000);
								await Promise.all(
									gridIdsArr.map(async (eachArr) => {
										const poiGrids = await this.poiGridRepository
											.createQueryBuilder("poi_grid")
											.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
											.distinct(true)
											.getMany();
										poiIds = await Promise.all(
											poiGrids.map((eachObj) => {
												return eachObj.poiId;
											}),
										);
									}),
								);
							} else {
								const poiGrids = await this.poiGridRepository
									.createQueryBuilder("poi_grid")
									.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
									.distinct(true)
									.getMany();
								poiIds = await Promise.all(
									poiGrids.map((eachObj) => {
										return eachObj.poiId;
									}),
								);
							}
							poiIds = _.flattenDeep(poiIds);
							scorecard["POI density"] = poiIds.length;
							//Poi density done...
							let societyCount = 0;
							if (poiIds.length > 20000) {
								const poiIdsArr = _.chunk(poiIds, 20000);
								await Promise.all(
									poiIdsArr.map(async (eachArr) => {
										const count = await this.poiRepository.count({
											where: {
												id: In(eachArr),
												type: "society",
											},
										});
										societyCount = societyCount + count;
									}),
								);
							} else {
								societyCount = await this.poiRepository.count({
									where: { id: In(poiIds), type: "society" },
								});
							}
							scorecard["Society Density"] = societyCount;
							//Individual Type count begins...
							const reqPois: string[] = query["poiTypes"];
							await Promise.all(
								reqPois.map(async (eachPoi) => {
									let individualTypeCount = 0;
									if (poiIds.length > 20000) {
										const poiIdsArr = _.chunk(poiIds, 20000);
										await Promise.all(
											poiIdsArr.map(async (eachArr) => {
												const count = await this.poiRepository.count({
													where: {
														id: In(eachArr),
														type: eachPoi,
													},
												});
												individualTypeCount = societyCount + count;
											}),
										);
									} else {
										individualTypeCount = await this.poiRepository.count({
											where: {
												id: In(poiIds),
												type: eachPoi,
											},
										});
									}
									poiDensity[eachPoi] = individualTypeCount;
								}),
							);
						} catch (err) {
							console.log(err);
						}
					}
					//Scorecard calculation ends...
					merchant["scorecard"] = scorecard;
					merchant["poiTypeCount"] = poiDensity;
					merchants.push(merchant);
				}),
			);
		} else {
			await Promise.all(
				pois.map(async (poi) => {
					const merchant = {};
					const poiGrid = await this.poiGridRepository.findOne({
						where: {
							poiId: poi.id,
						},
					});
					const grid = await this.gridRepository.findOne({
						where: {
							id: poiGrid.gridId,
						},
					});
					merchant["id"] = poi.id;
					merchant["name"] = poi.name;
					merchant["address"] = poi.address;
					merchant["category"] = poi.category;
					merchant["merchantType"] = poi.merchantType;
					merchant["merchantSubType"] = poi.subType;
					merchant["dataSource"] = poi.dataType;
					const locationHierarchy = {};
					locationHierarchy["Pincode"] = grid.Pincode;
					locationHierarchy["Taluka"] = grid.Taluka;
					locationHierarchy["District"] = grid.District;
					locationHierarchy["State"] = grid.State;
					merchant["locationHierarchy"] = locationHierarchy;
					//let geometry = {"type":"Point","coordinates":[poi.latitude,poi.longitude]};
					merchant["geometry"] = poi["geometry"];
					const latLngs = [poi["geometry"]["coordinates"][0], poi["geometry"]["coordinates"][1]];
					//Within Search Begins...
					/*
						  const point = tf.point([latLngs[0], latLngs[1]]);
						  const topLeft = tf.destination(point, distance, angleA);
						  const bottomRight = tf.destination(point, distance, angleB);
						  const withinGrids = geohash.bboxes(
							  topLeft["geometry"]["coordinates"][0],
							  topLeft["geometry"]["coordinates"][1],
							  bottomRight["geometry"]["coordinates"][0],
							  bottomRight["geometry"]["coordinates"][1],
							  7
						  );
						  */
					const pi = Math.PI;
					const lat_increment = 1 / 110.574;
					const lng_increment = 1 / 111.32;
					const lat_max = Number(latLngs[0]) + distance * lat_increment;
					const lat_min = Number(latLngs[0]) - distance * lat_increment;
					const lng_max = Number(latLngs[1]) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
					const lng_min = Number(latLngs[1]) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
					const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
					//console.log("WithinGrids :",withinGrids);
					let gridIds: number[] = [];
					try {
						const tempGrid = await this.gridRepository
							.createQueryBuilder("grid")
							.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
							.select("grid.id")
							.getMany();
						//console.log("TempGrids:",tempGrid);
						gridIds = await Promise.all(
							tempGrid.map((eachGrid) => {
								return eachGrid.id;
							}),
						);
						//console.log("GRIDISD: ",gridIds);
					} catch (error) {
						console.log("Error:", error);
					}
					//Within Search Ends...
					const indexAggrigationDict = {
						affluence: "median",
						footfall: "median",
						population: "sum",
						entertainment: "sum",
						economic_activity: "categorical-median",
						loan_opportunity: "categorical-median",
						loan_risk: "median",
						high_street: "median",
						income: "median",
						income_group: "categorical",
						commercial_activity: "categorical-median",
						digitization_index: "categorical-median",
						commercial: "sum",
						financial_institute: "sum",
						retail: "sum",
					};
					const scorecard = {};
					const poiDensity = {};
					//new try...
					if (gridIds.length > 0) {
						const indexAggQuery = {};
						indexAggQuery["responseType"] = "aggregation";
						indexAggQuery["requiredShapes"] = false;
						indexAggQuery["locationIndex"] = indexAggrigationDict;
						const indexAggRes = await this._gridService.getAggrigation(gridIds, indexAggQuery, true);
						const indexAggData = indexAggRes["data"] as any[];
						await Promise.all(
							indexAggData.map(async (eachObj) => {
								if (eachObj["aggregationType"] == "categorial") {
									scorecard[eachObj["key"]] = {};
									await Promise.all(
										Object.keys(eachObj["value"]).map((eachKey) => {
											scorecard[eachObj["key"]][eachKey] = eachObj["value"][eachKey];
										}),
									);
								} else {
									scorecard[eachObj["key"]] = eachObj["value"];
								}
							}),
						);
					}
					//try ends...
					if (gridIds.length > 0) {
						try {
							let poiIds: number[] = [];
							if (gridIds.length > 50000) {
								const gridIdsArr = _.chunk(gridIds, 50000);
								await Promise.all(
									gridIdsArr.map(async (eachArr) => {
										const poiGrids = await this.poiGridRepository
											.createQueryBuilder("poi_grid")
											.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
											.distinct(true)
											.getMany();
										poiIds = await Promise.all(
											poiGrids.map((eachObj) => {
												return eachObj.poiId;
											}),
										);
									}),
								);
							} else {
								const poiGrids = await this.poiGridRepository
									.createQueryBuilder("poi_grid")
									.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
									.distinct(true)
									.getMany();
								poiIds = await Promise.all(
									poiGrids.map((eachObj) => {
										return eachObj.poiId;
									}),
								);
							}
							poiIds = _.flattenDeep(poiIds);
							scorecard["POI density"] = poiIds.length;
							//Poi density done...
							let societyCount = 0;
							if (poiIds.length > 20000) {
								const poiIdsArr = _.chunk(poiIds, 20000);
								await Promise.all(
									poiIdsArr.map(async (eachArr) => {
										const count = await this.poiRepository.count({
											where: {
												id: In(eachArr),
												type: "society",
											},
										});
										societyCount = societyCount + count;
									}),
								);
							} else {
								societyCount = await this.poiRepository.count({
									where: { id: In(poiIds), type: "society" },
								});
							}
							scorecard["Society Density"] = societyCount;
							//Individual Type count begins...
							const reqPois: string[] = query["poiTypes"];
							await Promise.all(
								reqPois.map(async (eachPoi) => {
									let individualTypeCount = 0;
									if (poiIds.length > 20000) {
										const poiIdsArr = _.chunk(poiIds, 20000);
										await Promise.all(
											poiIdsArr.map(async (eachArr) => {
												const count = await this.poiRepository.count({
													where: {
														id: In(eachArr),
														type: eachPoi,
													},
												});
												individualTypeCount = societyCount + count;
											}),
										);
									} else {
										individualTypeCount = await this.poiRepository.count({
											where: {
												id: In(poiIds),
												type: eachPoi,
											},
										});
									}
									poiDensity[eachPoi] = individualTypeCount;
								}),
							);
						} catch (err) {
							console.log(err);
						}
					}
					merchant["scorecard"] = scorecard;
					merchant["poiTypeCount"] = poiDensity;
					merchants.push(merchant);
				}),
			);
		}
		const response = { count: merchants.length, merchants: merchants };
		response["typeCount"] = {};
		await Promise.all(
			merchants.map((merchant) => {
				const subTypes = Object.keys(response["typeCount"]);
				if (subTypes.includes(merchant.merchantType)) {
					//console.log("Type encounterd :",poi.type);
					response["typeCount"][merchant.merchantType] = response["typeCount"][merchant.merchantType] + 1;
				} else {
					response["typeCount"][merchant.merchantType] = 1;
				}
			}),
		);
		console.log("TypeCount :", response["typeCount"]);
		return response;
	}

	async filterMerchantsFromPois(data: Poi[], subTypes?: string[]) {
		const merchants = [];
		const poiIds = await Promise.all(
			data.map((eachPoi) => {
				if (eachPoi.category == "merchant") {
					return eachPoi.id;
				}
			}),
		);
		let poiGrids = [];
		if (poiIds.length > 40000) {
			const poiIdsArr = _.chunk(poiIds, 40000);
			await Promise.all(
				poiIdsArr.map(async (eachArr) => {
					const tempPoiGrids = await this.poiGridRepository.find({ where: { poiId: In(eachArr) } });
					poiGrids.push(tempPoiGrids);
				}),
			);
			poiGrids = _.flattenDeep(poiGrids);
		} else {
			poiGrids = await this.poiGridRepository.find({ where: { poiId: In(poiIds) } });
		}
		let gridIds = await Promise.all(
			poiGrids.map((eachPoiGrid) => {
				return eachPoiGrid["gridId"];
			}),
		);
		gridIds = _.uniq(gridIds);
		let grids = [];
		if (gridIds.length > 40000) {
			const gridIdsArr = _.chunk(gridIds, 40000);
			await Promise.all(
				gridIdsArr.map(async (eachGridIds) => {
					const tempGrids = await this.gridRepository.find({ where: { id: In(eachGridIds) } });
					grids.push(tempGrids);
				}),
			);
			grids = _.flattenDeep(grids);
		} else {
			grids = await this.gridRepository.find({ where: { id: In(gridIds) } });
		}
		const poiGridDict = {};
		await Promise.all(
			poiGrids.map((eachPoiGrid) => {
				const grid = _.find(grids, function (o) {
					return (o.id = eachPoiGrid.gridId);
				});
				poiGridDict[eachPoiGrid["poiId"]] = grid;
			}),
		);
		//console.log(poiGridDict);
		await Promise.all(
			data.map(async (eachPoi) => {
				if (eachPoi.category == "merchant") {
					if (subTypes) {
						if (subTypes.includes(eachPoi.subType)) {
							const merchant = {};
							const grid = poiGridDict[eachPoi.id];
							merchant["id"] = eachPoi.id;
							if (eachPoi["internalDetails"]["merchant_ID"]) {
								merchant["merchantId"] = eachPoi["internalDetails"]["merchant_ID"]["value"];
							}
							if (eachPoi["internalDetails"]["contact"]) {
								merchant["contact"] = eachPoi["internalDetails"]["contact"];
							}
							merchant["name"] = eachPoi.name;
							merchant["address"] = eachPoi.address;
							merchant["category"] = eachPoi.category;
							merchant["merchantType"] = eachPoi.type;
							merchant["index"] = {};
							if (eachPoi["internalDetails"]["footfall"]) {
								merchant["index"]["footfall"] = eachPoi["internalDetails"]["footfall"];
							} else {
								merchant["index"]["footfall"] = eachPoi["index"]["footfall"];
							}
							if (eachPoi["internalDetails"]["market_area"]) {
								merchant["index"]["market_area"] = eachPoi["internalDetails"]["market_area"];
							} else {
								merchant["index"]["market_area"] = eachPoi["index"]["market_area"];
							}
							merchant["geometry"] = eachPoi["geometry"];
							merchant["locationDetails"] = {
								Pincode: grid.Pincode,
								Taluka: grid.Taluka,
								District: grid.District,
								State: grid.State,
							};
							//Ordering....
							const orderedMerchant = {};
							_(merchant)
								.keys()
								.sort()
								.each(function (key) {
									orderedMerchant[key] = merchant[key];
								});
							merchants.push(orderedMerchant);
						}
					} else {
						const merchant = {};
						const grid = poiGridDict[eachPoi.id];
						merchant["id"] = eachPoi.id;
						if (eachPoi["internalDetails"]["merchant_ID"]) {
							merchant["merchantId"] = eachPoi["internalDetails"]["merchant_ID"]["value"];
						}
						if (eachPoi["internalDetails"]["contact"]) {
							merchant["contact"] = eachPoi["internalDetails"]["contact"];
						}
						merchant["name"] = eachPoi.name;
						merchant["address"] = eachPoi.address;
						merchant["category"] = eachPoi.category;
						merchant["merchantType"] = eachPoi.type;
						merchant["index"] = {};
						if (eachPoi["internalDetails"]["footfall"]) {
							merchant["index"]["footfall"] = eachPoi["internalDetails"]["footfall"];
						} else {
							merchant["index"]["footfall"] = eachPoi["index"]["footfall"];
						}
						if (eachPoi["internalDetails"]["market_area"]) {
							merchant["index"]["market_area"] = eachPoi["internalDetails"]["market_area"];
						} else {
							merchant["index"]["market_area"] = eachPoi["index"]["market_area"];
						}
						merchant["geometry"] = eachPoi["geometry"];
						merchant["locationDetails"] = {
							Pincode: grid.Pincode,
							Taluka: grid.Taluka,
							District: grid.District,
							State: grid.State,
						};
						//Ordering....
						const orderedMerchant = {};
						_(merchant)
							.keys()
							.sort()
							.each(function (key) {
								orderedMerchant[key] = merchant[key];
							});
						merchants.push(orderedMerchant);
					}
				}
			}),
		);
		return merchants;
	}

	async scorecardNewNew(query) {
		let distance = 0.3;
		if (query["radius"]) {
			distance = query["radius"];
		}
		const merchants = [];
		if (query["address"]) {
			const url = "http://" + process.env.GEOCODING_API_HOST + ":" + process.env.GEOCODING_API_PORT + "/geocode";
			console.log("URL: ", url);
			const address = { address: query["address"], shapedict: false };
			const headersRequest = {
				"Content-Type": "application/json",
				token: process.env.GEOCODEAPI_TOKEN,
			};
			const res = await this.httpService.post(url, address, { headers: headersRequest }).toPromise();
			console.log("Res :", res.data);
			let latLongs = [];
			latLongs = res["data"][0]["geometry"]["coordinates"];
			console.log("LatLongs :", latLongs);
			const hash = geohash.encode(latLongs[1], latLongs[0], 7);
			console.log("Hash :", hash);
			const grid = await this.gridRepository.findOne({
				where: {
					hash: hash,
				},
			});
			if (grid == undefined) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "Bad Address",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			console.log("Grid :", grid);
			const poiGrids = await this.poiGridRepository.find({
				where: {
					gridId: grid.id,
				},
			});
			console.log("Length of PoiGrids:", poiGrids);
			const poiIds = await Promise.all(
				poiGrids.map((eachPoiGrid) => {
					return eachPoiGrid.poiId;
				}),
			);
			let pois = [];
			if (query["merchantType"]) {
				pois = await this.poiRepository.find({
					where: {
						id: In(poiIds),
						category: "merchant",
						type: In(query["merchantType"]),
					},
				});
			} else {
				pois = await this.poiRepository.find({
					where: {
						id: In(poiIds),
						category: "merchant",
					},
				});
			}
			console.log("Pois :", pois);
			if (pois.length == 0) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "No merchants Found",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			let distanceObjs = [];
			await Promise.all(
				pois.map((eachPoi) => {
					const from = tf.point([eachPoi.latitude, eachPoi.longitude]);
					const to = tf.point([latLongs[0], latLongs[1]]);
					const distance = tf.distance(from, to);
					console.log("Distance:", distance);
					const tempObj = { distance: distance, poiId: eachPoi.id };
					distanceObjs.push(tempObj);
				}),
			);
			distanceObjs = _.orderBy(distanceObjs, ["distance"], ["asc"]);
			const poi = await this.poiRepository.findOne({
				where: {
					id: distanceObjs[0]["poiId"],
				},
			});
			console.log("POI :", poi);
			if (poi != undefined) {
				const merchant = {};
				const poiGrid = await this.poiGridRepository.findOne({
					where: {
						poiId: poi.id,
					},
				});
				const grid = await this.gridRepository.findOne({
					where: {
						id: poiGrid.gridId,
					},
				});
				merchant["address"] = poi.address;
				merchant["dataSource"] = poi.dataType;
				const locationHierarchy = {};
				locationHierarchy["Pincode"] = grid.Pincode;
				locationHierarchy["Taluka"] = grid.Taluka;
				locationHierarchy["District"] = grid.District;
				locationHierarchy["State"] = grid.State;
				merchant["locationHierarchy"] = locationHierarchy;
				const coordinates: number[] = [];
				coordinates.push(Number(poi.longitude));
				coordinates.push(Number(poi.latitude));
				merchant["geometry"] = { type: "Point", coordinates: coordinates };
				const pi = Math.PI;
				const lat_increment = 1 / 110.574;
				const lng_increment = 1 / 111.32;
				const lat_max = Number(poi.latitude) + distance * lat_increment;
				const lat_min = Number(poi.latitude) - distance * lat_increment;
				const lng_max = Number(poi.longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
				const lng_min = Number(poi.longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
				const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
				let gridIds: number[] = [];
				try {
					const tempGrid = await this.gridRepository
						.createQueryBuilder("grid")
						.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
						.select("grid.id")
						.getMany();
					//console.log("TempGrids:",tempGrid);
					gridIds = await Promise.all(
						tempGrid.map((eachGrid) => {
							return eachGrid.id;
						}),
					);
					//console.log("GRIDISD: ",gridIds);
				} catch (error) {
					console.log("Error:", error);
				}
				//Within Search Ends...
				const indexAggrigationDict = {
					affluence: "median",
					footfall: "median",
					population: "sum",
					entertainment: "sum",
					economic_activity: "categorical-median",
					loan_opportunity: "categorical-median",
					loan_risk: "median",
					high_street: "median",
					income: "median",
					income_group: "categorical",
					commercial_activity: "categorical-median",
					digitization_index: "categorical-median",
					commercial: "sum",
					financial_institute: "sum",
					retail: "sum",
				};
				const scorecard = {};
				const poiDensity = {};
				const indexAggQuery = {};
				indexAggQuery["responseType"] = "aggregation";
				indexAggQuery["requiredShapes"] = false;
				indexAggQuery["locationIndex"] = indexAggrigationDict;
				const indexAggRes = await this._gridService.getAggrigation(gridIds, indexAggQuery, true);
				const indexAggData = indexAggRes["data"] as unknown[];
				await Promise.all(
					indexAggData.map(async (eachObj) => {
						if (eachObj["aggregationType"] == "categorial") {
							scorecard[eachObj["key"]] = {};
							await Promise.all(
								Object.keys(eachObj["value"]).map((eachKey) => {
									scorecard[eachObj["key"]][eachKey] = eachObj["value"][eachKey];
								}),
							);
						} else {
							scorecard[eachObj["key"]] = eachObj["value"];
						}
					}),
				);
				//try ends...
				//Calculation of Society count and poi count begins...
				if (gridIds.length > 0) {
					try {
						let poiIds: number[] = [];
						if (gridIds.length > 50000) {
							const gridIdsArr = _.chunk(gridIds, 50000);
							await Promise.all(
								gridIdsArr.map(async (eachArr) => {
									const poiGrids = await this.poiGridRepository
										.createQueryBuilder("poi_grid")
										.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
										.distinct(true)
										.getMany();
									poiIds = await Promise.all(
										poiGrids.map((eachObj) => {
											return eachObj.poiId;
										}),
									);
								}),
							);
						} else {
							const poiGrids = await this.poiGridRepository
								.createQueryBuilder("poi_grid")
								.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
								.distinct(true)
								.getMany();
							poiIds = await Promise.all(
								poiGrids.map((eachObj) => {
									return eachObj.poiId;
								}),
							);
						}
						poiIds = _.flattenDeep(poiIds);
						scorecard["POI_density"] = poiIds.length;
						//Poi density done...
						let societyCount = 0;
						if (poiIds.length > 20000) {
							const poiIdsArr = _.chunk(poiIds, 20000);
							await Promise.all(
								poiIdsArr.map(async (eachArr) => {
									const count = await this.poiRepository.count({
										where: {
											id: In(eachArr),
											type: "society",
										},
									});
									societyCount = societyCount + count;
								}),
							);
						} else {
							societyCount = await this.poiRepository.count({
								where: { id: In(poiIds), type: "society" },
							});
						}
						scorecard["society_density"] = societyCount;
						//Individual Type count begins...
						const reqPois: string[] = query["poiTypes"];
						await Promise.all(
							reqPois.map(async (eachPoi) => {
								let individualTypeCount = 0;
								if (poiIds.length > 20000) {
									const poiIdsArr = _.chunk(poiIds, 20000);
									await Promise.all(
										poiIdsArr.map(async (eachArr) => {
											const count = await this.poiRepository.count({
												where: {
													id: In(eachArr),
													type: eachPoi,
												},
											});
											individualTypeCount = societyCount + count;
										}),
									);
								} else {
									individualTypeCount = await this.poiRepository.count({
										where: {
											id: In(poiIds),
											type: eachPoi,
										},
									});
								}
								poiDensity[eachPoi] = individualTypeCount;
							}),
						);
					} catch (err) {
						console.log(err);
					}
				}
				//Scorecard calculation ends...
				merchant["scorecard"] = scorecard;
				merchant["poiTypeCount"] = poiDensity;
				return merchant;
				merchants.push(merchant);
			} else {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "No Match Found",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
		}
		if (query["name"] && query["location"]) {
			if (query["merchantType"]) {
				query["types"] = query["merchantType"];
			} else {
				const typesArr = await this.poiRepository
					.createQueryBuilder("poi")
					.select("type")
					.distinct(true)
					.where(`category = 'merchant'`)
					.getRawMany();
				//console.log("Merchant Types :",typesArr);
				query["types"] = typesArr.map((eachObj) => {
					return eachObj["type"];
				});
			}
			const queryRes = await this._poiService.filter(query);
			const data = queryRes["data"] as Poi[];
			console.log("Length of data from poi/filter :", data.length);
			const pois = await this.filterMerchantsFromPois(data);
			const poiNames = [];
			await Promise.all(
				pois.map((eachPoi) => {
					const tempObj = {};
					tempObj["name"] = eachPoi.name;
					tempObj["poiId"] = eachPoi.id;
					poiNames.push(tempObj);
				}),
			);
			if (query["name"]) {
				let similarityIndexes = [];
				await Promise.all(
					poiNames.map(async (eachObj) => {
						const similarity =
							(await this._gridService.similarity(query["name"], eachObj["name"], true)) * 100;
						if (similarity >= Number(process.env.LOWEST_MATCH_PERCENT)) {
							const tempObj = { poiId: eachObj["poiId"], similarity: similarity };
							similarityIndexes.push(tempObj);
						}
					}),
				);
				similarityIndexes = _.orderBy(similarityIndexes, ["similarity"], ["desc"]);
				const topSimilarityObj = similarityIndexes[0];
				const merchant = {};
				const poi = await this.poiRepository.findOne({
					where: {
						id: topSimilarityObj["poiId"],
					},
				});
				const poiGrid = await this.poiGridRepository.findOne({
					where: {
						poiId: topSimilarityObj["poiId"],
					},
				});
				const grid = await this.gridRepository.findOne({
					where: {
						id: poiGrid.gridId,
					},
				});
				merchant["matchPercentage"] = topSimilarityObj["similarity"];
				//merchant["id"] = poi.id;
				//merchant["name"] = poi.name;
				merchant["address"] = poi.address;
				//merchant["category"] = poi.category;
				//merchant["merchantType"] = poi.type;
				//merchant["merchantSubType"] = poi.subType;
				merchant["dataSource"] = poi.dataType;
				const locationHierarchy = {};
				locationHierarchy["Pincode"] = grid.Pincode;
				locationHierarchy["Taluka"] = grid.Taluka;
				locationHierarchy["District"] = grid.District;
				locationHierarchy["State"] = grid.State;
				merchant["locationHierarchy"] = locationHierarchy;
				const coordinates: number[] = [];
				coordinates.push(Number(poi.longitude));
				coordinates.push(Number(poi.latitude));
				const geometry = { type: "Point", coordinates: coordinates };
				merchant["geometry"] = geometry;
				const latLngs = [poi.latitude, poi.longitude];
				//Within Search Begins...
				/*
						const point = tf.point([latLngs[0], latLngs[1]]);
						const topLeft = tf.destination(point, distance, angleA);
						const bottomRight = tf.destination(point, distance, angleB);
						const withinGrids = geohash.bboxes(
							topLeft["geometry"]["coordinates"][0],
							topLeft["geometry"]["coordinates"][1],
							bottomRight["geometry"]["coordinates"][0],
							bottomRight["geometry"]["coordinates"][1],
							7
						);
						*/
				const pi = Math.PI;
				const lat_increment = 1 / 110.574;
				const lng_increment = 1 / 111.32;
				const lat_max = Number(latLngs[0]) + distance * lat_increment;
				const lat_min = Number(latLngs[0]) - distance * lat_increment;
				const lng_max = Number(latLngs[1]) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
				const lng_min = Number(latLngs[1]) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
				const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
				let gridIds: number[] = [];
				try {
					const tempGrid = await this.gridRepository
						.createQueryBuilder("grid")
						.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
						.select("grid.id")
						.getMany();

					gridIds = tempGrid.map((eachGrid) => {
						return eachGrid.id;
					});
				} catch (error) {
					console.log("Error:", error);
				}
				//Within Search Ends...
				const indexAggrigationDict = {
					affluence: "median",
					footfall: "median",
					population: "sum",
					entertainment: "sum",
					economic_activity: "categorical-median",
					loan_opportunity: "categorical-median",
					loan_risk: "median",
					high_street: "median",
					income: "median",
					income_group: "categorical",
					commercial_activity: "categorical-median",
					digitization_index: "categorical-median",
					commercial: "sum",
					financial_institute: "sum",
					retail: "sum",
				};
				const scorecard = {};
				const poiDensity = {};
				//scorecard = await this.getScorecard(indexAggrigationDict, gridIds);
				//new try...
				const indexAggQuery = {};
				indexAggQuery["responseType"] = "aggregation";
				indexAggQuery["requiredShapes"] = false;
				indexAggQuery["locationIndex"] = indexAggrigationDict;
				const indexAggRes = await this._gridService.getAggrigation(gridIds, indexAggQuery, true);
				const indexAggData = indexAggRes["data"] as any[];
				await Promise.all(
					indexAggData.map(async (eachObj) => {
						if (eachObj["aggregationType"] == "categorial") {
							scorecard[eachObj["key"]] = {};
							await Promise.all(
								Object.keys(eachObj["value"]).map((eachKey) => {
									scorecard[eachObj["key"]][eachKey] = eachObj["value"][eachKey];
								}),
							);
						} else {
							scorecard[eachObj["key"]] = eachObj["value"];
						}
					}),
				);
				//try ends...
				//Calculation of Society count and poi count begins...
				if (gridIds.length > 0) {
					try {
						let poiIds: number[] = [];
						if (gridIds.length > 50000) {
							const gridIdsArr = _.chunk(gridIds, 50000);
							await Promise.all(
								gridIdsArr.map(async (eachArr) => {
									const poiGrids = await this.poiGridRepository
										.createQueryBuilder("poi_grid")
										.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
										.distinct(true)
										.getMany();
									poiIds = await Promise.all(
										poiGrids.map((eachObj) => {
											return eachObj.poiId;
										}),
									);
								}),
							);
						} else {
							const poiGrids = await this.poiGridRepository
								.createQueryBuilder("poi_grid")
								.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
								.distinct(true)
								.getMany();
							poiIds = await Promise.all(
								poiGrids.map((eachObj) => {
									return eachObj.poiId;
								}),
							);
						}
						poiIds = _.flattenDeep(poiIds);
						scorecard["POI_density"] = poiIds.length;
						//Poi density done...
						let societyCount = 0;
						if (poiIds.length > 20000) {
							const poiIdsArr = _.chunk(poiIds, 20000);
							await Promise.all(
								poiIdsArr.map(async (eachArr) => {
									const count = await this.poiRepository.count({
										where: {
											id: In(eachArr),
											type: "society",
										},
									});
									societyCount = societyCount + count;
								}),
							);
						} else {
							societyCount = await this.poiRepository.count({
								where: { id: In(poiIds), type: "society" },
							});
						}
						scorecard["society_density"] = societyCount;
						//Individual Type count begins...
						const reqPois: string[] = query["poiTypes"];
						await Promise.all(
							reqPois.map(async (eachPoi) => {
								let individualTypeCount = 0;
								if (poiIds.length > 20000) {
									const poiIdsArr = _.chunk(poiIds, 20000);
									await Promise.all(
										poiIdsArr.map(async (eachArr) => {
											const count = await this.poiRepository.count({
												where: {
													id: In(eachArr),
													type: eachPoi,
												},
											});
											individualTypeCount = societyCount + count;
										}),
									);
								} else {
									individualTypeCount = await this.poiRepository.count({
										where: {
											id: In(poiIds),
											type: eachPoi,
										},
									});
								}
								poiDensity[eachPoi] = individualTypeCount;
							}),
						);
					} catch (err) {
						console.log(err);
					}
				}
				//Scorecard calculation ends...
				merchant["scorecard"] = scorecard;
				merchant["poiTypeCount"] = poiDensity;
				return merchant;
				merchants.push(merchant);
			}
		}
		const response = { count: merchants.length, merchants: merchants };
		response["typeCount"] = {};
		await Promise.all(
			merchants.map((merchant) => {
				const subTypes = Object.keys(response["typeCount"]);
				if (subTypes.includes(merchant.merchantType)) {
					//console.log("Type encounterd :",poi.type);
					response["typeCount"][merchant.merchantType] = response["typeCount"][merchant.merchantType] + 1;
				} else {
					response["typeCount"][merchant.merchantType] = 1;
				}
			}),
		);
		console.log("TypeCount :", response["typeCount"]);
		return response;
	}

	async personalScorecard(query, token) {
		const finalResponse = {};
		finalResponse["locations"] = [];
		let distance = 0.5;
		if (query["radius"]) {
			distance = query["radius"];
		}
		if (query["address"]) {
			const url = "http://" + process.env.GEOCODING_API_HOST + ":" + process.env.GEOCODING_API_PORT + "/geocode";
			console.log("URL: ", url);
			const address = { address: query["address"], shapedict: false };
			const headersRequest = {
				"Content-Type": "application/json",
				token: token,
			};
			let res;
			try {
				res = await firstValueFrom(this.httpService.post(url, address, { headers: headersRequest }));
			} catch (err) {
				console.log(err);
				throw new HttpException(
					{
						status: HttpStatus.FAILED_DEPENDENCY,
						error: "GeoCode Error",
					},
					HttpStatus.FAILED_DEPENDENCY,
				);
			}
			console.log("Res :", res.data);
			let latLongs = [];
			latLongs = res["data"][0]["geometry"]["coordinates"];
			console.log("LatLongs :", latLongs);
			const hash = geohash.encode(latLongs[1], latLongs[0], 7);
			console.log("Hash :", hash);
			const grid = await this.gridRepository.findOne({ where: { hash: hash } });
			if (grid == undefined) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "Bad Address",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			console.log("Grid :", grid);
			//const latLngs = [grid.latitude, grid.longitude];
			/*
			const point = tf.point([latLngs[0], latLngs[1]]);
			const topLeft = tf.destination(point, distance, angleA);
			const bottomRight = tf.destination(point, distance, angleB);
			const withinGrids = geohash.bboxes(
				topLeft["geometry"]["coordinates"][0],
				topLeft["geometry"]["coordinates"][1],
				bottomRight["geometry"]["coordinates"][0],
				bottomRight["geometry"]["coordinates"][1],
				7
			);
			*/
			const pi = Math.PI;
			const lat_increment = 1 / 110.574;
			const lng_increment = 1 / 111.32;
			const lat_max = Number(grid.latitude) + distance * lat_increment;
			const lat_min = Number(grid.latitude) - distance * lat_increment;
			const lng_max = Number(grid.longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
			const lng_min = Number(grid.longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
			const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
			let gridIds: number[] = [];
			try {
				const tempGrid = await this.gridRepository
					.createQueryBuilder("grid")
					.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
					.select("grid.id")
					.getMany();

				gridIds = tempGrid.map((eachGrid) => {
					return eachGrid.id;
				});
			} catch (error) {
				console.log("Error:", error);
			}
			console.log("Number of Grids :", gridIds.length);
			const indexAggrigationDict = {
				affluence: "median",
				footfall: "median",
				population: "sum",
				entertainment: "sum",
				economic_activity: "categorical-median",
				loan_opportunity: "categorical-median",
				loan_risk: "categorical-median",
				high_street: "median",
				income: "median",
				income_group: "categorical",
				commercial_activity: "categorical-median",
				digitization_index: "categorical-median",
				commercial: "sum",
				financial_institute: "sum",
				retail: "sum",
				society_density: "sum",
				POI_density: "sum",
				market_area: "categorical-median",
				office_area: "categorical-median",
				residential_area: "categorical-median",
			};
			const response = {};
			const scorecard = {};
			const locationHierarchy = {};
			locationHierarchy["Pincode"] = grid.Pincode;
			locationHierarchy["Taluka"] = grid.Taluka;
			locationHierarchy["District"] = grid.District;
			locationHierarchy["State"] = grid.State;
			response["locationHierarchy"] = locationHierarchy;
			response["address"] = query["address"];
			const coordinates: number[] = [];
			coordinates.push(Number(grid.longitude));
			coordinates.push(Number(grid.latitude));
			const geometry = { type: "Point", coordinates: coordinates };
			response["geometry"] = geometry;
			//new try...
			const indexAggQuery = {};
			indexAggQuery["responseType"] = "aggregation";
			indexAggQuery["requiredShapes"] = false;
			indexAggQuery["locationIndex"] = indexAggrigationDict;
			const indexAggRes = await this._gridService.getAggrigation(gridIds, indexAggQuery, true);
			const indexAggData = indexAggRes["data"] as unknown[];
			await Promise.all(
				indexAggData.map(async (eachObj) => {
					if (eachObj["aggregationType"] == "categorial") {
						scorecard[eachObj["key"]] = {};
						await Promise.all(
							Object.keys(eachObj["value"]).map((eachKey) => {
								scorecard[eachObj["key"]][eachKey] = eachObj["value"][eachKey];
							}),
						);
					} else {
						scorecard[eachObj["key"]] = eachObj["value"];
					}
				}),
			);
			//try ends...
			const poiDensity = {};
			if (gridIds.length > 0) {
				try {
					let poiIds: number[] = [];
					if (gridIds.length > 50000) {
						const gridIdsArr = _.chunk(gridIds, 50000);
						await Promise.all(
							gridIdsArr.map(async (eachArr) => {
								const poiGrids = await this.poiGridRepository
									.createQueryBuilder("poi_grid")
									.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
									.distinct(true)
									.getMany();
								poiIds = await Promise.all(
									poiGrids.map((eachObj) => {
										return eachObj.poiId;
									}),
								);
							}),
						);
					} else {
						const poiGrids = await this.poiGridRepository
							.createQueryBuilder("poi_grid")
							.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
							.distinct(true)
							.getMany();
						poiIds = await Promise.all(
							poiGrids.map((eachObj) => {
								return eachObj.poiId;
							}),
						);
					}
					poiIds = _.flattenDeep(poiIds);
					/*
							  scorecard["POI_density"] = {"value":poiIds.length,"unit":"number"};
							  //Poi density done...
							  let societyCount = 0;
							  if(poiIds.length > 20000) {
								  const poiIdsArr = _.chunk(poiIds,20000);
								  await Promise.all(poiIdsArr.map(async eachArr => {
									  const count = await this.poiRepository.count({ where: {id: In(eachArr) , type:"society"}});
									  societyCount = societyCount + count;
								  }));
							  } else {
								  societyCount = await this.poiRepository.count({ where: {id: In(poiIds), type:"society"}});
							  }
							  scorecard["society_density"] = {"value":societyCount,"unit":"number"};
							  */
					//Individual Type count begins...
					const reqPois: string[] = query["poiTypes"];
					await Promise.all(
						reqPois.map(async (eachPoi) => {
							let individualTypeCount = 0;
							if (poiIds.length > 20000) {
								const poiIdsArr = _.chunk(poiIds, 20000);
								await Promise.all(
									poiIdsArr.map(async (eachArr) => {
										const count = await this.poiRepository.count({
											where: {
												id: In(eachArr),
												type: eachPoi,
											},
										});
										individualTypeCount = individualTypeCount + count;
									}),
								);
							} else {
								individualTypeCount = await this.poiRepository.count({
									where: {
										id: In(poiIds),
										type: eachPoi,
									},
								});
							}
							poiDensity[eachPoi] = individualTypeCount;
						}),
					);
				} catch (err) {
					console.log(err);
				}
			}
			const orderedScorecard = {};
			_(scorecard)
				.keys()
				.sort()
				.each(function (key) {
					orderedScorecard[key] = scorecard[key];
				});
			const orderedPoiDensity = {};
			_(poiDensity)
				.keys()
				.sort()
				.each(function (key) {
					orderedPoiDensity[key] = orderedPoiDensity[key];
				});
			response["scorecard"] = orderedScorecard;
			return response;
			finalResponse["locations"].push(response);
		}
		if (query["lat"] && query["lng"]) {
			const latLongs = [query["lat"], query["lng"]];
			console.log("LatLongs :", latLongs);
			const hash = geohash.encode(latLongs[1], latLongs[0], 7);
			console.log("Hash :", hash);
			const grid = await this.gridRepository.findOne({
				where: {
					hash: hash,
				},
			});
			if (grid == undefined) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "Bad Address",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			console.log("Grid :", grid);
			//const latLngs = [grid.latitude, grid.longitude];
			/*
				  const point = tf.point([latLngs[0], latLngs[1]]);
				  const topLeft = tf.destination(point, distance, angleA);
				  const bottomRight = tf.destination(point, distance, angleB);
				  const withinGrids = geohash.bboxes(
					  topLeft["geometry"]["coordinates"][0],
					  topLeft["geometry"]["coordinates"][1],
					  bottomRight["geometry"]["coordinates"][0],
					  bottomRight["geometry"]["coordinates"][1],
					  7
				  );
				  */
			const pi = Math.PI;
			const lat_increment = 1 / 110.574;
			const lng_increment = 1 / 111.32;
			const lat_max = Number(grid.latitude) + distance * lat_increment;
			const lat_min = Number(grid.latitude) - distance * lat_increment;
			const lng_max = Number(grid.longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
			const lng_min = Number(grid.longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
			const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
			let gridIds: number[] = [];
			try {
				const tempGrid = await this.gridRepository
					.createQueryBuilder("grid")
					.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
					.select("grid.id")
					.getMany();

				gridIds = tempGrid.map((eachGrid) => {
					return eachGrid.id;
				});
			} catch (error) {
				console.log("Error:", error);
			}
			console.log("Number of Grids :", gridIds.length);
			const indexAggrigationDict = {
				affluence: "median",
				footfall: "median",
				population: "sum",
				entertainment: "sum",
				economic_activity: "categorical-median",
				loan_opportunity: "categorical-median",
				loan_risk: "categorical-median",
				high_street: "median",
				income: "median",
				income_group: "categorical",
				commercial_activity: "categorical-median",
				digitization_index: "categorical-median",
				commercial: "sum",
				financial_institute: "sum",
				retail: "sum",
				society_density: "sum",
				POI_density: "sum",
				market_area: "categorical-median",
				office_area: "categorical-median",
				residential_area: "categorical-median",
			};
			const response = {};
			const scorecard = {};
			const locationHierarchy = {};
			locationHierarchy["Pincode"] = grid.Pincode;
			locationHierarchy["Taluka"] = grid.Taluka;
			locationHierarchy["District"] = grid.District;
			locationHierarchy["State"] = grid.State;
			response["locationHierarchy"] = locationHierarchy;
			//new try...
			const indexAggQuery = {};
			indexAggQuery["responseType"] = "aggregation";
			indexAggQuery["requiredShapes"] = false;
			indexAggQuery["locationIndex"] = indexAggrigationDict;
			const coordinates: number[] = [];
			coordinates.push(Number(grid.longitude));
			coordinates.push(Number(grid.latitude));
			const geometry = { type: "Point", coordinates: coordinates };
			response["geometry"] = geometry;
			const indexAggRes = await this._gridService.getAggrigation(gridIds, indexAggQuery, true);
			const indexAggData = indexAggRes["data"] as any[];
			await Promise.all(
				indexAggData.map(async (eachObj) => {
					if (eachObj["aggregationType"] == "categorial") {
						scorecard[eachObj["key"]] = {};
						await Promise.all(
							Object.keys(eachObj["value"]).map((eachKey) => {
								scorecard[eachObj["key"]][eachKey] = eachObj["value"][eachKey];
							}),
						);
					} else {
						scorecard[eachObj["key"]] = eachObj["value"];
					}
				}),
			);
			//try ends...
			const poiDensity = {};
			if (gridIds.length > 0) {
				try {
					let poiIds: number[] = [];
					if (gridIds.length > 50000) {
						const gridIdsArr = _.chunk(gridIds, 50000);
						await Promise.all(
							gridIdsArr.map(async (eachArr) => {
								const poiGrids = await this.poiGridRepository
									.createQueryBuilder("poi_grid")
									.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
									.distinct(true)
									.getMany();
								poiIds = await Promise.all(
									poiGrids.map((eachObj) => {
										return eachObj.poiId;
									}),
								);
							}),
						);
					} else {
						const poiGrids = await this.poiGridRepository
							.createQueryBuilder("poi_grid")
							.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
							.distinct(true)
							.getMany();
						poiIds = await Promise.all(
							poiGrids.map((eachObj) => {
								return eachObj.poiId;
							}),
						);
					}
					poiIds = _.flattenDeep(poiIds);
					/*
							  scorecard["POI_density"] = {"value":poiIds.length,"unit":"number"};
							  //Poi density done...
							  let societyCount = 0;
							  if(poiIds.length > 20000) {
								  const poiIdsArr = _.chunk(poiIds,20000);
								  await Promise.all(poiIdsArr.map(async eachArr => {
									  const count = await this.poiRepository.count({ where: {id: In(eachArr) , type:"society"}});
									  societyCount = societyCount + count;
								  }));
							  } else {
								  societyCount = await this.poiRepository.count({ where: {id: In(poiIds), type:"society"}});
							  }
							  scorecard["society_density"] = {"value":societyCount,"unit":"number"};
							  */
					//Individual Type count begins...
					const reqPois: string[] = query["poiTypes"];
					await Promise.all(
						reqPois.map(async (eachPoi) => {
							let individualTypeCount = 0;
							if (poiIds.length > 20000) {
								const poiIdsArr = _.chunk(poiIds, 20000);
								await Promise.all(
									poiIdsArr.map(async (eachArr) => {
										const count = await this.poiRepository.count({
											where: { id: In(eachArr), type: eachPoi },
										});
										individualTypeCount = individualTypeCount + count;
									}),
								);
							} else {
								individualTypeCount = await this.poiRepository.count({
									where: { id: In(poiIds), type: eachPoi },
								});
							}
							poiDensity[eachPoi] = individualTypeCount;
						}),
					);
				} catch (err) {
					console.log(err);
				}
			}
			const orderedScorecard = {};
			_(scorecard)
				.keys()
				.sort()
				.each(function (key) {
					orderedScorecard[key] = scorecard[key];
				});
			const orderedPoiDensity = {};
			_(poiDensity)
				.keys()
				.sort()
				.each(function (key) {
					orderedPoiDensity[key] = orderedPoiDensity[key];
				});
			//response["poiTypeCount"] = orderedPoiDensity;
			response["scorecard"] = orderedScorecard;
			return response;
			finalResponse["locations"].push(response);
		}
		return finalResponse;
	}

	async merchantScorecard(query, token) {
		let distance = 0.3;
		if (query["radius"]) {
			distance = query["radius"];
		}
		const merchants = [];
		if (query["address"]) {
			const url = "http://" + process.env.GEOCODING_API_HOST + ":" + process.env.GEOCODING_API_PORT + "/geocode";
			console.log("URL: ", url);
			const address = { address: query["address"], shapedict: false };
			const headersRequest = {
				"Content-Type": "application/json",
				token: token,
			};
			let res;
			try {
				res = await this.httpService.post(url, address, { headers: headersRequest }).toPromise();
			} catch (err) {
				console.log(err);
				throw new HttpException(
					{
						status: HttpStatus.FAILED_DEPENDENCY,
						error: "GeoCode Error",
					},
					HttpStatus.FAILED_DEPENDENCY,
				);
			}
			console.log("Res :", res.data);
			let latLongs = [];
			latLongs = res["data"][0]["geometry"]["coordinates"];
			console.log("LatLongs :", latLongs);
			const hash = geohash.encode(latLongs[1], latLongs[0], 7);
			console.log("Hash :", hash);
			const grid = await this.gridRepository.findOne({
				where: {
					hash: hash,
				},
			});
			if (grid == undefined) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "Bad Address",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			console.log("Grid :", grid);
			const merchant = {};
			merchant["address"] = query["address"];
			merchant["dataSource"] = "datasutram";
			const locationHierarchy = {};
			locationHierarchy["Pincode"] = grid.Pincode;
			locationHierarchy["Taluka"] = grid.Taluka;
			locationHierarchy["District"] = grid.District;
			locationHierarchy["State"] = grid.State;
			merchant["locationHierarchy"] = locationHierarchy;
			const coordinates: number[] = [];
			coordinates.push(Number(grid.longitude));
			coordinates.push(Number(grid.latitude));
			merchant["geometry"] = { type: "Point", coordinates: coordinates };
			const pi = Math.PI;
			const lat_increment = 1 / 110.574;
			const lng_increment = 1 / 111.32;
			const lat_max = Number(grid.latitude) + distance * lat_increment;
			const lat_min = Number(grid.latitude) - distance * lat_increment;
			const lng_max = Number(grid.longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
			const lng_min = Number(grid.longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
			const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
			let gridIds: number[] = [];
			try {
				const tempGrid = await this.gridRepository
					.createQueryBuilder("grid")
					.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
					.select("grid.id")
					.getMany();
				//console.log("TempGrids:",tempGrid);
				gridIds = await Promise.all(
					tempGrid.map((eachGrid) => {
						return eachGrid.id;
					}),
				);
				//console.log("GRIDISD: ",gridIds);
			} catch (error) {
				console.log("Error:", error);
			}
			//Within Search Ends...
			const indexAggrigationDict = {
				affluence: "median",
				footfall: "median",
				population: "sum",
				entertainment: "sum",
				economic_activity: "categorical-median",
				loan_opportunity: "categorical-median",
				loan_risk: "categorical-median",
				high_street: "median",
				income: "median",
				income_group: "categorical",
				commercial_activity: "categorical-median",
				digitization_index: "categorical-median",
				commercial: "sum",
				financial_institute: "sum",
				retail: "sum",
				society_density: "sum",
				POI_density: "sum",
				market_area: "categorical-median",
				office_area: "categorical-median",
				residential_area: "categorical-median",
			};
			const scorecard = {};
			const poiDensity = {};
			//scorecard = await this.getScorecard(indexAggrigationDict, gridIds);
			//new try...
			const indexAggQuery = {};
			indexAggQuery["responseType"] = "aggregation";
			indexAggQuery["requiredShapes"] = false;
			indexAggQuery["locationIndex"] = indexAggrigationDict;
			const indexAggRes = await this._gridService.getAggrigation(gridIds, indexAggQuery, true);
			const indexAggData = indexAggRes["data"] as unknown[];
			await Promise.all(
				indexAggData.map(async (eachObj) => {
					if (eachObj["aggregationType"] == "categorial") {
						scorecard[eachObj["key"]] = {};
						await Promise.all(
							Object.keys(eachObj["value"]).map((eachKey) => {
								scorecard[eachObj["key"]][eachKey] = eachObj["value"][eachKey];
							}),
						);
					} else {
						scorecard[eachObj["key"]] = eachObj["value"];
					}
				}),
			);
			//try ends...
			//Calculation of Society count and poi count begins...
			if (gridIds.length > 0) {
				try {
					let poiIds: number[] = [];
					if (gridIds.length > 50000) {
						const gridIdsArr = _.chunk(gridIds, 50000);
						await Promise.all(
							gridIdsArr.map(async (eachArr) => {
								const poiGrids = await this.poiGridRepository
									.createQueryBuilder("poi_grid")
									.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
									.distinct(true)
									.getMany();
								poiIds = await Promise.all(
									poiGrids.map((eachObj) => {
										return eachObj.poiId;
									}),
								);
							}),
						);
					} else {
						const poiGrids = await this.poiGridRepository
							.createQueryBuilder("poi_grid")
							.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
							.distinct(true)
							.getMany();
						poiIds = await Promise.all(
							poiGrids.map((eachObj) => {
								return eachObj.poiId;
							}),
						);
					}
					poiIds = _.flattenDeep(poiIds);
					const reqPois: string[] = query["poiTypes"];
					await Promise.all(
						reqPois.map(async (eachPoi) => {
							let individualTypeCount = 0;
							if (poiIds.length > 20000) {
								const poiIdsArr = _.chunk(poiIds, 20000);
								await Promise.all(
									poiIdsArr.map(async (eachArr) => {
										const count = await this.poiRepository.count({
											where: { id: In(eachArr), type: eachPoi },
										});
										individualTypeCount = individualTypeCount + count;
									}),
								);
							} else {
								individualTypeCount = await this.poiRepository.count({
									where: {
										id: In(poiIds),
										type: eachPoi,
									},
								});
							}
							poiDensity[eachPoi] = individualTypeCount;
						}),
					);
				} catch (err) {
					console.log(err);
				}
			}
			//Scorecard calculation ends...
			const orderedScorecard = {};
			_(scorecard)
				.keys()
				.sort()
				.each(function (key) {
					orderedScorecard[key] = scorecard[key];
				});
			const orderedPoiDensity = {};
			_(poiDensity)
				.keys()
				.sort()
				.each(function (key) {
					orderedPoiDensity[key] = poiDensity[key];
				});
			merchant["poiTypeCount"] = orderedPoiDensity;
			merchant["scorecard"] = orderedScorecard;
			return merchant;
		}
		if (query["name"] && query["location"]) {
			if (query["merchantType"]) {
				query["types"] = query["merchantType"];
			} else {
				const typesArr = await this.poiRepository
					.createQueryBuilder("poi")
					.select("type")
					.distinct(true)
					.where(`category = 'merchant'`)
					.getRawMany();
				query["types"] = typesArr.map((eachObj) => {
					return eachObj["type"];
				});
			}
			const queryRes = await this._poiService.filter(query);
			const data = queryRes["data"] as Poi[];
			console.log("Length of data from poi/filter :", data.length);
			const pois = await this.filterMerchantsFromPois(data);
			const poiNames = [];
			await Promise.all(
				pois.map((eachPoi) => {
					const tempObj = {};
					tempObj["name"] = eachPoi.name;
					tempObj["poiId"] = eachPoi.id;
					poiNames.push(tempObj);
				}),
			);
			if (query["name"]) {
				let similarityIndexes = [];
				await Promise.all(
					poiNames.map(async (eachObj) => {
						const similarity =
							(await this._gridService.similarity(query["name"], eachObj["name"], true)) * 100;
						if (similarity >= Number(process.env.LOWEST_MATCH_PERCENT)) {
							const tempObj = { poiId: eachObj["poiId"], similarity: similarity };
							similarityIndexes.push(tempObj);
						}
					}),
				);
				similarityIndexes = _.orderBy(similarityIndexes, ["similarity"], ["desc"]);
				if (similarityIndexes.length == 0) {
					throw new HttpException(
						{
							status: HttpStatus.NO_CONTENT,
							error: "No relevent merchants found",
						},
						HttpStatus.BAD_REQUEST,
					);
				}
				const topSimilarityObj = similarityIndexes[0];
				const merchant = {};
				const poi = await this.poiRepository.findOne({
					where: {
						id: topSimilarityObj["poiId"],
					},
				});
				const poiGrid = await this.poiGridRepository.findOne({
					where: {
						poiId: topSimilarityObj["poiId"],
					},
				});
				const grid = await this.gridRepository.findOne({
					where: {
						id: poiGrid.gridId,
					},
				});
				merchant["matchPercentage"] = topSimilarityObj["similarity"];
				//merchant["id"] = poi.id;
				merchant["name"] = poi.name;
				merchant["address"] = poi.address;
				//merchant["category"] = poi.category;
				//merchant["merchantType"] = poi.type;
				//merchant["merchantSubType"] = poi.subType;
				merchant["dataSource"] = poi.dataType;
				const locationHierarchy = {};
				locationHierarchy["Pincode"] = grid.Pincode;
				locationHierarchy["Taluka"] = grid.Taluka;
				locationHierarchy["District"] = grid.District;
				locationHierarchy["State"] = grid.State;
				merchant["locationHierarchy"] = locationHierarchy;
				const coordinates: number[] = [];
				coordinates.push(Number(poi.longitude));
				coordinates.push(Number(poi.latitude));
				const geometry = { type: "Point", coordinates: coordinates };
				merchant["geometry"] = geometry;
				const pi = Math.PI;
				const lat_increment = 1 / 110.574;
				const lng_increment = 1 / 111.32;
				const lat_max = Number(poi.latitude) + distance * lat_increment;
				const lat_min = Number(poi.latitude) - distance * lat_increment;
				const lng_max = Number(poi.longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
				const lng_min = Number(poi.longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
				const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
				let gridIds: number[] = [];
				try {
					const tempGrid = await this.gridRepository
						.createQueryBuilder("grid")
						.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
						.select("grid.id")
						.getMany();

					gridIds = tempGrid.map((eachGrid) => {
						return eachGrid.id;
					});
				} catch (error) {
					console.log("Error:", error);
				}
				//Within Search Ends...
				const indexAggrigationDict = {
					affluence: "median",
					footfall: "median",
					population: "sum",
					entertainment: "sum",
					economic_activity: "categorical-median",
					loan_opportunity: "categorical-median",
					loan_risk: "categorical-median",
					high_street: "median",
					income: "median",
					income_group: "categorical",
					commercial_activity: "categorical-median",
					digitization_index: "categorical-median",
					commercial: "sum",
					financial_institute: "sum",
					retail: "sum",
					society_density: "sum",
					POI_density: "sum",
					market_area: "categorical-median",
					office_area: "categorical-median",
					residential_area: "categorical-median",
				};
				const scorecard = {};
				const poiDensity = {};
				//scorecard = await this.getScorecard(indexAggrigationDict, gridIds);
				//new try...
				const indexAggQuery = {};
				indexAggQuery["responseType"] = "aggregation";
				indexAggQuery["requiredShapes"] = false;
				indexAggQuery["locationIndex"] = indexAggrigationDict;
				const indexAggRes = await this._gridService.getAggrigation(gridIds, indexAggQuery, true);
				const indexAggData = indexAggRes["data"] as any[];
				await Promise.all(
					indexAggData.map(async (eachObj) => {
						if (eachObj["aggregationType"] == "categorial") {
							scorecard[eachObj["key"]] = {};
							await Promise.all(
								Object.keys(eachObj["value"]).map((eachKey) => {
									scorecard[eachObj["key"]][eachKey] = eachObj["value"][eachKey];
								}),
							);
						} else {
							scorecard[eachObj["key"]] = eachObj["value"];
						}
					}),
				);
				//try ends...
				//Calculation of Society count and poi count begins...
				if (gridIds.length > 0) {
					try {
						let poiIds: number[] = [];
						if (gridIds.length > 50000) {
							const gridIdsArr = _.chunk(gridIds, 50000);
							await Promise.all(
								gridIdsArr.map(async (eachArr) => {
									const poiGrids = await this.poiGridRepository
										.createQueryBuilder("poi_grid")
										.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachArr })
										.distinct(true)
										.getMany();
									poiIds = await Promise.all(
										poiGrids.map((eachObj) => {
											return eachObj.poiId;
										}),
									);
								}),
							);
						} else {
							const poiGrids = await this.poiGridRepository
								.createQueryBuilder("poi_grid")
								.where("poi_grid.gridId IN (:...gridIds)", { gridIds: gridIds })
								.distinct(true)
								.getMany();
							poiIds = await Promise.all(
								poiGrids.map((eachObj) => {
									return eachObj.poiId;
								}),
							);
						}
						poiIds = _.flattenDeep(poiIds);
						//Individual Type count begins...
						const reqPois: string[] = query["poiTypes"];
						await Promise.all(
							reqPois.map(async (eachPoi) => {
								let individualTypeCount = 0;
								if (poiIds.length > 20000) {
									const poiIdsArr = _.chunk(poiIds, 20000);
									await Promise.all(
										poiIdsArr.map(async (eachArr) => {
											const count = await this.poiRepository.count({
												where: {
													id: In(eachArr),
													type: eachPoi,
												},
											});
											individualTypeCount = individualTypeCount + count;
										}),
									);
								} else {
									individualTypeCount = await this.poiRepository.count({
										where: {
											id: In(poiIds),
											type: eachPoi,
										},
									});
								}
								poiDensity[eachPoi] = individualTypeCount;
							}),
						);
					} catch (err) {
						console.log(err);
					}
				}
				//Scorecard calculation ends...
				const orderedScorecard = {};
				_(scorecard)
					.keys()
					.sort()
					.each(function (key) {
						orderedScorecard[key] = scorecard[key];
					});
				const orderedPoiDensity = {};
				_(poiDensity)
					.keys()
					.sort()
					.each(function (key) {
						orderedPoiDensity[key] = poiDensity[key];
					});
				merchant["poiTypeCount"] = orderedPoiDensity;
				merchant["scorecard"] = orderedScorecard;
				return merchant;
				merchants.push(merchant);
			}
		}
		const response = { count: merchants.length, merchants: merchants };
		const responseTypeCount = {};
		await Promise.all(
			merchants.map((merchant) => {
				const subTypes = Object.keys(responseTypeCount);
				if (subTypes.includes(merchant.merchantType)) {
					//console.log("Type encounterd :",poi.type);
					responseTypeCount[merchant.merchantType] = responseTypeCount[merchant.merchantType] + 1;
				} else {
					responseTypeCount[merchant.merchantType] = 1;
				}
			}),
		);
		console.log("TypeCount :", responseTypeCount);
		const orderedTypeCount = {};
		_(responseTypeCount)
			.keys()
			.sort()
			.each(function (key) {
				orderedTypeCount[key] = responseTypeCount[key];
			});
		response["poiTypeCount"] = orderedTypeCount;
		return response;
	}

	async update(query) {
		if (query["merchant_id"]) {
			const poiDetail = await this.poiDetailRepository.findOne({
				where: {
					key: "merchant_ID",
					value: query["merchant_id"],
				},
			});
			if (poiDetail == undefined) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "Invalid merchant_id",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			const values: PoiDetail[] = query["values"];
			await Promise.all(
				values.map((eachPoiDetail) => {
					eachPoiDetail.poiId = poiDetail.poiId;
				}),
			);
			await this.poiDetailRepository.save(values);
		} else {
			const poi = await this.poiRepository.findOne({
				where: {
					id: query["poiId"],
				},
			});
			if (poi == undefined) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "Invalid PoiId",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			const values: PoiDetail[] = query["values"];
			await Promise.all(
				values.map((eachPoiDetail) => {
					eachPoiDetail.poiId = poi.id;
				}),
			);
			await this.poiDetailRepository.save(values);
		}
	}

	async saveMerchantsAgainstUser(userId: number, query, type: string) {
		const merchantIds: number[] = query["merchantIds"] as number[];
		if (merchantIds.length == 0) {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: "Empty Array of merchantIds",
				},
				HttpStatus.BAD_REQUEST,
			);
		}
		const existingUserMerchants: UserMerchant[] = await this.userMerchantRepository.find({
			where: { merchantId: In(merchantIds) },
		});
		const existingApiKeyUserMerchants: ApiKeyUserMerchant[] = await this.apiKeyUserMerchantRepository.find({
			where: { merchantId: In(merchantIds) },
		});
		if (existingUserMerchants.length > 0 || existingApiKeyUserMerchants.length > 0) {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: `This merchant is already liked by another user`,
				},
				HttpStatus.BAD_REQUEST,
			);
		}
		const userMerchants: UserMerchant[] | ApiKeyUserMerchant[] = [];
		merchantIds.forEach((eachMerchantId) => {
			const tempObj: UserMerchant | ApiKeyUserMerchant = { userId: userId, merchantId: eachMerchantId };
			userMerchants.push(tempObj);
		});
		if (type == "token") {
			return await this.userMerchantRepository.save(userMerchants);
		} else {
			return await this.apiKeyUserMerchantRepository.save(userMerchants);
		}
	}

	async getMerchantsAgainstIds(query) {
		try {
			const merchantIds = query["merchantIds"] as number[];
			if (merchantIds.length == 0) {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "Empty Array of merchantIds",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
			const poiGrids = await this.poiGridRepository.find({ where: { poiId: In(merchantIds) } });
			const poiGridDict = {};
			const gridIds = await Promise.all(
				poiGrids.map((eachPoiGrid) => {
					poiGridDict[eachPoiGrid.poiId] = eachPoiGrid.gridId;
					return eachPoiGrid.gridId;
				}),
			);
			let indexMasterGrids = [];
			if (gridIds.length > 50000) {
				console.log("Chunking...");
				const gridIdsArr = _.chunk(gridIds, 50000);
				await Promise.all(
					gridIdsArr.map(async (eachGridIds) => {
						const tempIndexMasterGrids = await this.gridRepository
							.createQueryBuilder("grid")
							.leftJoinAndSelect("grid.indexmaster", "indexmaster")
							.where("grid.id In (:...gridIds)", { gridIds: eachGridIds })
							.getMany();
						indexMasterGrids.push(tempIndexMasterGrids);
					}),
				);
				indexMasterGrids = _.flattenDeep(indexMasterGrids);
			} else {
				indexMasterGrids = await this.gridRepository
					.createQueryBuilder("grid")
					.leftJoinAndSelect("grid.indexmaster", "indexmaster")
					.where("grid.id In (:...gridIds)", { gridIds: gridIds })
					.getMany();
			}
			const indexMasterGridsDict = {};
			indexMasterGrids.forEach((eachGrid) => {
				const tempDict = {};
				eachGrid.indexmaster.forEach((eachIndexMaster) => {
					if (eachIndexMaster.indexType === "string") {
						tempDict[eachIndexMaster.indexName] = eachIndexMaster.categoricalValue;
					} else {
						tempDict[eachIndexMaster.indexName] = eachIndexMaster.indexValue;
					}
				});
				indexMasterGridsDict[eachGrid.id] = tempDict;
			});
			const poiDetailsDict = {};
			const poiDetails = await this.poiDetailRepository.find({ where: { poiId: In(merchantIds) } });
			poiDetails.forEach((poiDetail) => {
				if (poiDetailsDict[poiDetail.poiId] == undefined) {
					const tempDict = {};
					tempDict[poiDetail.key] = poiDetail.value;
					poiDetailsDict[poiDetail.poiId] = tempDict;
				} else {
					poiDetailsDict[poiDetail.poiId][poiDetail.key] = poiDetail.value;
				}
			});
			const pois = await this.poiRepository.find({ where: { id: In(merchantIds) } });
			const response = { count: pois.length, data: [] };
			await Promise.all(
				pois.map((poi) => {
					const tempObj = {
						id: poi.id,
						name: poi.name,
						address: poi.address,
						category: poi.category,
						type: poi.type,
						subType: poi.subType,
						votes: poi.votes,
						rating: poi.rating,
						latitude: undefined,
						longitude: undefined,
						createdBy: poi.createdBy,
						dataType: poi.dataType,
						status: poi.status,
						targetDetail: undefined,
						indexStatus: poi.indexStatus,
						geometry: { type: "Point", coordinates: [Number(poi.longitude), Number(poi.latitude)] },
						index:
							indexMasterGridsDict[poiGridDict[poi.id]] != undefined
								? indexMasterGridsDict[poiGridDict[poi.id]]
								: undefined,
						internalDetails: poiDetailsDict[poi.id] != undefined ? poiDetailsDict[poi.id] : undefined,
					};
					response.data.push(tempObj);
				}),
			);
			return response;
		} catch (error) {
			console.error(error);
			return { count: 0, data: [] };
		}
	}

	async getMerchantIdsAgainstUser(userId: number, type: string) {
		let userMerchants: UserMerchant[] | ApiKeyUserMerchant[];
		if (type == "token") {
			userMerchants = await this.userMerchantRepository.find({ where: { userId: userId } });
		} else {
			userMerchants = await this.apiKeyUserMerchantRepository.find({ where: { userId: userId } });
		}
		const merchantIds = await Promise.all(
			userMerchants.map((eachUserMerchant) => {
				return eachUserMerchant.merchantId;
			}),
		);
		return merchantIds;
	}

	async deleteMerchantsAgainstUser(userId: number, query, type: string) {
		const merchantIds: number[] = query["merchantIds"] as number[];
		if (merchantIds.length == 0) {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: "Empty Array of merchantIds",
				},
				HttpStatus.BAD_REQUEST,
			);
		}
		try {
			if (type == "token") {
				await this.userMerchantRepository.delete({ userId: userId, merchantId: In(merchantIds) });
				return { response: "Success" };
			} else {
				await this.apiKeyUserMerchantRepository.delete({ userId: userId, merchantId: In(merchantIds) });
				return { response: "Success" };
			}
		} catch (err) {
			console.log(err);
			return { response: "Failed" };
		}
	}

	async places(query: PlacesQuery, token) {
		if (query.radius == undefined) {
			throw new HttpException("'radius' must be in the request", HttpStatus.BAD_REQUEST);
		}
		if (query.address == undefined && query.lat == undefined && query.lng == undefined) {
			throw new HttpException("'address' OR ('lat' and 'lng') must be in the request", HttpStatus.BAD_REQUEST);
		}
		const response = {
			count: 0,
			places: {
				educational_hubs: { count: 0, data: [] },
				religious_hubs: { count: 0, data: [] },
				merchants: { count: 0, data: [] },
				entertainment_hubs: { count: 0, data: [] },
				hospital_and_helathcare: { count: 0, data: [] },
				tansport_hubs_and_transits: { count: 0, data: [] },
			},
		};
		const educationalHubsTypes = ["school"];
		const religiousHubsTypes = ["religious"];
		const merchantsTypes = [
			"farmer_market",
			"auto_store",
			"beauty_parlour",
			"cafe",
			"clothing_store",
			"grocery",
			"jewelry_store",
			"loan_agency_count",
			"mandi",
			"pet_store",
			"petrol_pump",
			"pharmacy",
			"restaurant",
			"service_centre",
			"store",
			"wholesaler",
		];
		const entertainmentHubsTypes = ["popular_attraction", "mall", "event_venue"];
		const hospitalAndHealthCareTypes = ["clinic", "hospital"];
		const transportHubstypes = ["transport_stop"];
		const allTypes = [
			"farmer_market",
			"auto_store",
			"beauty_parlour",
			"cafe",
			"clothing_store",
			"grocery",
			"jewelry_store",
			"loan_agency_count",
			"mandi",
			"pet_store",
			"petrol_pump",
			"pharmacy",
			"restaurant",
			"service_centre",
			"store",
			"wholesaler",
			"school",
			"religious",
			"popular_attraction",
			"mall",
			"event_venue",
			"clinic",
			"hospital",
			"transport_stop",
		];
		const poifilterQuery = {
			within: { radius: query.radius, points: [{ lat: 0, lng: 0 }] },
			types: allTypes,
		};
		if (query.address) {
			const url = "http://" + process.env.GEOCODING_API_HOST + ":" + process.env.GEOCODING_API_PORT + "/geocode";
			console.log("URL: ", url);
			const address = { address: query["address"], shapedict: false };
			const headersRequest = {
				"Content-Type": "application/json",
				token: token,
			};
			let res;
			try {
				res = await firstValueFrom(this.httpService.post(url, address, { headers: headersRequest }));
			} catch (err) {
				console.log(err);
				throw new HttpException(
					{
						status: HttpStatus.FAILED_DEPENDENCY,
						error: "GeoCode Error",
					},
					HttpStatus.FAILED_DEPENDENCY,
				);
			}
			console.log("Res :", res.data);
			let latLongs = [];
			latLongs = res["data"][0]["geometry"]["coordinates"];
			console.log("LatLongs :", latLongs);
			poifilterQuery.within.points[0].lng = latLongs[0];
			poifilterQuery.within.points[0].lat = latLongs[1];
		} else {
			poifilterQuery.within.points[0].lng = query.lng;
			poifilterQuery.within.points[0].lat = query.lat;
		}
		const resp = await this._poiService.optimized_filter(poifilterQuery as unknown as FilterQuery);
		const data: Poi[] = resp["data"];
		response.count = resp["count"];
		data.forEach((poi: Poi) => {
			delete poi?.["index"];
			delete poi.rating;
			delete poi.votes;
			delete poi.createdBy;
			delete poi.status;
			delete poi.dataType;
			delete poi.indexStatus;
			if (educationalHubsTypes.includes(poi.type)) {
				response.places.educational_hubs.count = response.places.educational_hubs.count + 1;
				response.places.educational_hubs.data.push(poi);
				return;
			}
			if (religiousHubsTypes.includes(poi.type)) {
				response.places.religious_hubs.count = response.places.religious_hubs.count + 1;
				response.places.religious_hubs.data.push(poi);
				return;
			}
			if (entertainmentHubsTypes.includes(poi.type)) {
				response.places.entertainment_hubs.count = response.places.entertainment_hubs.count + 1;
				response.places.entertainment_hubs.data.push(poi);
				return;
			}
			if (hospitalAndHealthCareTypes.includes(poi.type)) {
				response.places.hospital_and_helathcare.count = response.places.hospital_and_helathcare.count + 1;
				response.places.hospital_and_helathcare.data.push(poi);
				return;
			}
			if (transportHubstypes.includes(poi.type)) {
				response.places.tansport_hubs_and_transits.count = response.places.tansport_hubs_and_transits.count + 1;
				response.places.tansport_hubs_and_transits.data.push(poi);
				return;
			}
			if (merchantsTypes.includes(poi.type)) {
				response.places.merchants.count = response.places.merchants.count + 1;
				response.places.merchants.data.push(poi);
				return;
			}
		});
		return response;
	}

	async pincodeScorecard(query) {
		const response = {
			dataSource: "datasutram",
			locationDetails: {},
			geometry: {},
			pincodeTrends: {},
		};
		const shapesQuery = { location: { Pincode: query["pincode"] }, childLevel: "Pincode" };
		const res = await (async () => {
			try {
				return await this._shapeService.multilevelShapesNew(shapesQuery as MultilevelShapesQuery);
			} catch (err) {
				console.error(err);
			}
		})();

		const shape = res["data"][0];

		if (shape) {
			const { name, taluka, City, District, State, index, internalDetails } = shape;

			response.locationDetails = {
				pincode: name || null,
				taluka: taluka || null,
				city: City || null,
				district: District || null,
				state: State || null,
				pincodeCategory: index?.pincode_category || null,
			};

			response.geometry = shape?.geometry;

			const pincodeTrends = { ...index, ...internalDetails };
			response.pincodeTrends = pincodeTrends;
		} else {
			throw new HttpException(
				`Could not find shape for given pincode- ${query["pincode"]}`,
				HttpStatus.NOT_FOUND,
			);
		}

		return response;
	}

	async geoHash7Scorecard(query) {
		const { geohash7, level } = query;
		if (!geohash7) throw new HttpException("GeoHash7 is required!", HttpStatus.BAD_REQUEST);
		if (geohash7.length !== 7) throw new HttpException("GeoHash7 must be of 7 characters!", HttpStatus.BAD_REQUEST);
		const { longitude, latitude } = geohash.decode(geohash7);
		if (!latitude || !longitude) {
			throw new HttpException("Provided GeoHash7 is invalid!", HttpStatus.BAD_REQUEST);
		}
		return await this.addressAndLatLngScorecard({ lat: latitude, lng: longitude, level });
	}

	async multiGeoHash7Scorecard(query: { geohash7s: string[]; level?: string }) {
		const { geohash7s, level } = query;
		if (!geohash7s || geohash7s.length == 0) throw new HttpException("geohash7s missing!", HttpStatus.BAD_REQUEST);
		if (!_.isArray(geohash7s)) {
			throw new HttpException("geohash7s must be an array!", HttpStatus.BAD_REQUEST);
		}
		if (geohash7s.length > this.bulkScorecardLimit) {
			throw new HttpException(
				`geohash7s array length must be less than ${this.bulkScorecardLimit}!`,
				HttpStatus.BAD_REQUEST,
			);
		}
		const invalidHashes = geohash7s.filter((h) => h.length !== 7);
		if (invalidHashes.length)
			throw new HttpException(
				`${invalidHashes.join(",")} ${invalidHashes.length > 1 ? "are" : "is an"} invalid geohash7!`,
				HttpStatus.BAD_REQUEST,
			);
		return await this.getMultipleScorecards(geohash7s, level);
	}

	async getMultipleScorecards(geohash7s: string[], level?: string) {
		let hashGridDict: _.Dictionary<
			| {
					gridId: number;
					geometry: { type: string; coordinates: number[] };
					locationDetails: { [x: string]: string };
			  }
			| { error: string }
		> = {};

		await (async () => {
			try {
				const grids = await this.gridRepository.find({ where: { hash: In(geohash7s) } });
				if (grids?.length) {
					grids.forEach((g) => {
						const { Pincode, Taluka, City, District, State } = g;
						hashGridDict[g.hash] = {
							gridId: Number(g.id),
							geometry: {
								type: "point",
								coordinates: [Number(g.longitude), Number(g.latitude)],
							},
							locationDetails: {
								pincode: Pincode ?? undefined,
								taluka: Taluka ?? undefined,
								city: City ?? undefined,
								district: District ?? undefined,
								state: State ?? undefined,
							},
						};
					});
				}
			} catch (error) {
				console.error(error);
			}
		})();

		const noEntryGrids = (() => {
			const exactGrids = Object.keys(hashGridDict);
			return geohash7s.filter((h) => !exactGrids.includes(h));
		})();
		if (noEntryGrids?.length) {
			hashGridDict = { ...(await this.getNoEntryGrids(noEntryGrids)), ...hashGridDict };
		}

		const gridTrendsDict = await (async () => {
			if (level != "pincode") {
				const gridIds = Object.values(hashGridDict)
					.map((h) => Number(h["gridId"]))
					.filter((v) => _.isFinite(v));
				return await this.getGridTrends(gridIds);
			} else return {};
		})();
		const pincodeTrendsDict = await (async () => {
			if (level != "grid") {
				const pincodes = Object.values(hashGridDict)
					.map((h) => h?.["locationDetails"]?.["pincode"])
					.filter((p) => p);
				return await this.getPincodeTrends(pincodes);
			} else return {};
		})();

		//send response
		const response = { data: [], count_to_decuct: 0 };
		return (() => {
			try {
				geohash7s.forEach((h) => {
					const tempObj = { hash: h };
					if (hashGridDict[h]?.["error"]) {
						tempObj["error"] = hashGridDict[h]?.["error"];
					} else {
						const gridTrends = gridTrendsDict?.[hashGridDict[h]?.["gridId"]];
						const pincodeTrends = pincodeTrendsDict?.[hashGridDict[h]?.["locationDetails"]?.["pincode"]];
						if (level === "pincode" && !pincodeTrends) {
							tempObj["error"] = "Pincode Scorecard Not found!";
						} else if (level === "grid" && !gridTrends) {
							tempObj["error"] = "Grid Scorecard Not found!";
						} else {
							tempObj["scorecard"] = {
								geometry: hashGridDict[h]?.["geometry"] ?? undefined,
								locationDetails: hashGridDict[h]?.["locationDetails"] ?? undefined,
								gridTrends,
								pincodeTrends,
							};
							response.count_to_decuct++;
						}
					}
					response.data.push(tempObj);
				});
			} catch (error) {
				console.error(error);
				return response;
			} finally {
				return response;
			}
		})();
	}

	async getPincodeTrends(pincodes: string[]) {
		if (!pincodes?.length) return {};
		const pincodeTrends = {};
		return await (async () => {
			try {
				const shapes = await this.shapeRepository.find({
					where: { Pincode: In(pincodes) },
					select: ["id", "Pincode"],
				});
				if (!shapes?.length) return {};
				const shapeIds = _.keyBy(shapes, "Pincode");
				const [shapeDetails, shapeIndexes] = await Promise.all([
					this.shapeDetailRepository.find({
						where: { shapeId: In(shapes.map((s) => s.id)) },
					}),
					this.connection.manager.query(
						`select * from shapeindex where "shapeId" in (${shapes.map((s) => s.id).join(",")})`,
					),
				]);
				const shapeDetailsKeyedByShapeId = _.groupBy(shapeDetails, "shapeId");
				const shapeIndexKeyedByShapeId = _.groupBy(shapeIndexes, "shapeId");
				Object.keys(shapeIds).forEach((pincode: string) => {
					const shapeId = shapeIds[pincode].id;
					const shapeDetailsNeeded = shapeDetailsKeyedByShapeId[shapeId];
					const shapeIndexNeeded = shapeIndexKeyedByShapeId[shapeId];
					if (shapeDetailsNeeded?.length || shapeIndexNeeded?.length) {
						pincodeTrends[pincode] = {};
						shapeDetailsNeeded?.forEach((sd) => {
							pincodeTrends[pincode][sd.key] = sd.dataType == "number" ? sd.unit : sd.value;
						});
						shapeIndexNeeded?.forEach((si) => {
							pincodeTrends[pincode][si.indexName] =
								si.indexType == "number" ? si?.indexValue : si?.categoricalValue;
						});
					}
				});
			} catch (error) {
				console.error(error);
				return {};
			} finally {
				return pincodeTrends;
			}
		})();
	}

	async getGridTrends(gridIds: number[]) {
		if (!gridIds?.length) return {};
		const gridTrends = {};
		return await (async () => {
			try {
				const indexMasters: {
					indexName: string;
					indexType: string;
					indexValue: string;
					categoricalValue: string;
					gridId: number;
				}[] = await this.connection.manager.query(
					`select * from indexmaster where "gridId" in (${gridIds.join(",")})`,
				);
				const indexMasterKeyedByGridId = _.groupBy(indexMasters, "gridId");
				Object.keys(indexMasterKeyedByGridId).forEach((h: string) => {
					const indexMastersNeeded = indexMasterKeyedByGridId[h];
					if (indexMastersNeeded?.length) {
						gridTrends[h] = {};
						indexMastersNeeded.forEach((i) => {
							gridTrends[h][i?.indexName] =
								i?.indexType == "number" ? i?.indexValue : i?.categoricalValue;
						});
					}
				});
			} catch (error) {
				console.error(error);
				return {};
			} finally {
				return gridTrends;
			}
		})();
	}

	async getNoEntryGrids(hashes: string[]) {
		const hashGridDict: _.Dictionary<
			| {
					gridId: number;
					geometry: { type: string; coordinates: number[] };
					locationDetails: { [x: string]: string };
			  }
			| { error: string }
		> = {};
		const nearbyHashMapping: _.Dictionary<string[]> = {};
		const hashCoordinateMap: _.Dictionary<number[]> = {};
		hashes.forEach((h) => {
			const { longitude, latitude } = geohash.decode(h);
			hashCoordinateMap[h] = [Number(longitude), Number(latitude)];
			const pi = Math.PI;
			const lat_increment = 1 / 110.574;
			const lng_increment = 1 / 111.32;
			const lat_max = Number(latitude) + Number(this.scorecardRadius) * lat_increment;
			const lat_min = Number(latitude) - Number(this.scorecardRadius) * lat_increment;
			const lng_max =
				Number(longitude) + Number(this.scorecardRadius) * (lng_increment / Math.cos((pi / 180) * lat_max));
			const lng_min =
				Number(longitude) - Number(this.scorecardRadius) * (lng_increment / Math.cos((pi / 180) * lat_min));
			nearbyHashMapping[h] = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
		});
		return await (async () => {
			try {
				const allHashes: string[] = _.union(..._.values(nearbyHashMapping));
				const grids = await this.gridRepository.find({ where: { hash: In(allHashes) } });
				const hashesInDb = grids.map((g) => g.hash);
				hashes.forEach((h) => {
					const intersectingHashes = _.intersection(hashesInDb, nearbyHashMapping[h]);
					if (intersectingHashes?.length) {
						const finalGrids = grids
							.filter((g) => intersectingHashes.includes(g.hash))
							.map((g) => {
								const distance = tf.distance(
									tf.point([Number(g.longitude), Number(g.latitude)]),
									tf.point(hashCoordinateMap[h]),
								);
								return { ...g, distance };
							});
						const grid = _.orderBy(finalGrids, "distance", "asc")[0];
						const { Pincode, Taluka, City, District, State } = grid;
						hashGridDict[h] = {
							gridId: Number(grid.id),
							geometry: {
								type: "point",
								coordinates: [Number(grid.longitude), Number(grid.latitude)],
							},
							locationDetails: {
								pincode: Pincode ?? undefined,
								taluka: Taluka ?? undefined,
								city: City ?? undefined,
								district: District ?? undefined,
								state: State ?? undefined,
							},
						};
					} else {
						hashGridDict[h] = { error: "No nearby grids found!" };
					}
				});
			} catch (error) {
				console.error(error);
				return hashGridDict;
			} finally {
				return hashGridDict;
			}
		})();
	}

	async addressAndLatLngScorecard(query) {
		const { lat, lng, address } = query;
		if (!address && !(lat && lng)) {
			throw new HttpException("Please provide either address or lat and lng", HttpStatus.BAD_REQUEST);
		}
		if (lat && lng) {
			if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
				throw new HttpException("Invalid Coordinates!", HttpStatus.BAD_REQUEST);
			}
		}

		// Geocoding Supplied Address or Reverse Geocoding Supplied Lat Lng
		let suppliedCoordinate: [number, number];
		let suppliedAddress: string;
		const headersRequest = {
			"Content-Type": "application/json",
		};
		if (address) {
			const req = { address, shapedict: false };
			const url = "http://" + process.env.GEOCODING_API_HOST + ":" + process.env.GEOCODING_API_PORT + "/geocode";
			const res = await (async () => {
				try {
					return await firstValueFrom(this.httpService.post(url, req, { headers: headersRequest }));
				} catch (err) {
					console.error(err);
					if (err?.response?.data?.statusCode != 400)
						throw new HttpException("GeoCode Error", HttpStatus.FAILED_DEPENDENCY);
				}
			})();
			if (!res?.["data"]?.length) {
				throw new HttpException("Bad Address!", HttpStatus.BAD_REQUEST);
			}
			suppliedCoordinate = res["data"][0]["geometry"]["coordinates"];
			suppliedAddress = address;
		} else {
			const req = { latitude: Number(lat), longitude: Number(lng) };
			const url =
				"http://" + process.env.GEOCODING_API_HOST + ":" + process.env.GEOCODING_API_PORT + "/reverse-geocode";
			const res = this.disableReverseGeocode
				? undefined
				: await (async () => {
						try {
							return await firstValueFrom(this.httpService.post(url, req, { headers: headersRequest }));
						} catch (err) {
							console.error(err);
							throw new HttpException("GeoCode Error", HttpStatus.FAILED_DEPENDENCY);
						}
				  })();
			suppliedCoordinate = [Number(lng), Number(lat)];
			suppliedAddress = res?.data?.address;
		}
		const hash = geohash.encode(suppliedCoordinate[1], suppliedCoordinate[0], 7);
		let grid = await (async () => {
			try {
				return await this.gridRepository.findOne({
					where: {
						hash: hash,
					},
				});
			} catch (err) {
				console.error(err);
				throw new HttpException("Cannot Get Grids", HttpStatus.FAILED_DEPENDENCY);
			}
		})();
		console.log(`Immediate Grid ${grid ? "" : "Not"} found!`, grid);
		if (grid == undefined) {
			const pi = Math.PI;
			const lat_increment = 1 / 110.574;
			const lng_increment = 1 / 111.32;
			const lat_max = Number(suppliedCoordinate[1]) + Number(this.scorecardRadius) * lat_increment;
			const lat_min = Number(suppliedCoordinate[1]) - Number(this.scorecardRadius) * lat_increment;
			const lng_max =
				Number(suppliedCoordinate[0]) +
				Number(this.scorecardRadius) * (lng_increment / Math.cos((pi / 180) * lat_max));
			const lng_min =
				Number(suppliedCoordinate[0]) -
				Number(this.scorecardRadius) * (lng_increment / Math.cos((pi / 180) * lat_min));
			const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
			const grids = await (async () => {
				try {
					const tempGrids = await this.gridRepository.find({
						where: {
							hash: In(withinGrids),
						},
					});
					let tempGridsWithDistance = tempGrids.map((g) => {
						const distance = tf.distance(
							tf.point([Number(g.longitude), Number(g.latitude)]),
							tf.point(suppliedCoordinate),
						);
						return { ...g, distance };
					});
					tempGridsWithDistance = _.orderBy(tempGridsWithDistance, "distance", "asc");
					return tempGridsWithDistance;
				} catch (err) {
					console.error(err);
					throw new HttpException("Cannot Get Grids", HttpStatus.FAILED_DEPENDENCY);
				}
			})();
			if (grids.length > 0) {
				grid = grids[0];
				console.log("Closest Grid Found!", grid);
				delete grid?.["distance"];
			} else {
				throw new HttpException(
					{
						status: HttpStatus.BAD_REQUEST,
						error: "No Nearby Grids found!",
					},
					HttpStatus.BAD_REQUEST,
				);
			}
		}
		let gridScorecard = undefined;
		let pincodeScorecard = undefined;
		const { Pincode, Taluka, City, District, State } = grid;
		const locationDetails = {
			pincode: Pincode ?? undefined,
			taluka: Taluka ?? undefined,
			city: City ?? undefined,
			district: District ?? undefined,
			state: State ?? undefined,
		};
		if (query?.level !== "pincode") {
			const indexmasters = await (async () => {
				try {
					return await this.indexMasterRepository.find({
						where: {
							grid: grid,
						},
					});
				} catch (err) {
					console.error(err);
					throw new HttpException("Cannot Get Indices", HttpStatus.FAILED_DEPENDENCY);
				}
			})();
			if (indexmasters.length) {
				gridScorecard = {};
				indexmasters.forEach((indexmaster) => {
					gridScorecard[indexmaster.indexName] =
						indexmaster.indexType == "number" ? indexmaster.indexValue : indexmaster.categoricalValue;
				});
			}
		}
		if (query?.level !== "grid") {
			await (async () => {
				try {
					const shapeGetInfo = await this.pincodeScorecard({ pincode: grid.Pincode });
					locationDetails["pincodeCategory"] = shapeGetInfo?.locationDetails?.["pincodeCategory"];
					pincodeScorecard = shapeGetInfo.pincodeTrends;
				} catch (err) {
					console.error(err);
				}
			})();
		}
		if (query.level === "grid" && !gridScorecard)
			throw new HttpException("Grid Scorecard Not Found", HttpStatus.BAD_REQUEST);
		if (query.level === "pincode" && !pincodeScorecard)
			throw new HttpException("Pincode Scorecard Not Found", HttpStatus.BAD_REQUEST);
		const response = {
			address: suppliedAddress,
			geometry: { type: "Point", coordinates: suppliedCoordinate },
			locationDetails,
			gridTrends: gridScorecard,
			pincodeTrends: pincodeScorecard,
		};
		return response;
	}

	async rent(query: PlacesQuery, token) {
		if (query.radius == undefined) {
			query.radius = 0.5;
		}
		if (query.address == undefined && query.lat == undefined && query.lng == undefined) {
			throw new HttpException("'address' OR ('lat' and 'lng') must be in the request", HttpStatus.BAD_REQUEST);
		}
		const response = {
			locationDetails: null,
			geometry: null,
			address: null,
			gridTrends: {
				residential_places_count: 0,
				office_area_concentration: 0,
				affluence: 0,
				income: 0,
			},
			financial_institutions: {
				count: 0,
				data: [],
			},
		};
		query["level"] = "grid";
		console.log("hERE");
		const res = await this.addressAndLatLngScorecard(query);
		response.address = res["address"];
		response.gridTrends.affluence = res["gridTrends"]["affluence"];
		response.gridTrends.income = res["gridTrends"]["income"];
		response.gridTrends.office_area_concentration = res["gridTrends"]["office_area_concentration"];
		response.gridTrends.residential_places_count = res["gridTrends"]["residential_places_count"];
		response.geometry = res.geometry;
		response.locationDetails = res.locationDetails;
		const types = ["ATM", "bank", "bc_agent"];
		const poifilterQuery = {
			within: { radius: query.radius, points: [{ lat: 0, lng: 0 }] },
			types: types,
		};
		if (query.address) {
			const url = "http://" + process.env.GEOCODING_API_HOST + ":" + process.env.GEOCODING_API_PORT + "/geocode";
			console.log("URL: ", url);
			const address = { address: query["address"], shapedict: false };
			const headersRequest = {
				"Content-Type": "application/json",
				token: token,
			};
			let res;
			try {
				res = await firstValueFrom(this.httpService.post(url, address, { headers: headersRequest }));
			} catch (err) {
				console.log(err);
				throw new HttpException(
					{
						status: HttpStatus.FAILED_DEPENDENCY,
						error: "GeoCode Error",
					},
					HttpStatus.FAILED_DEPENDENCY,
				);
			}
			console.log("Res :", res.data);
			let latLongs = [];
			latLongs = res["data"][0]["geometry"]["coordinates"];
			console.log("LatLongs :", latLongs);
			poifilterQuery.within.points[0].lng = latLongs[0];
			poifilterQuery.within.points[0].lat = latLongs[1];
		} else {
			poifilterQuery.within.points[0].lng = query.lng;
			poifilterQuery.within.points[0].lat = query.lat;
		}
		const resp = await this._poiService.optimized_filter(poifilterQuery as unknown as FilterQuery);
		(resp["data"] as Poi[]).forEach((poi: Poi) => {
			delete poi?.["index"];
			delete poi.rating;
			delete poi.votes;
			delete poi.createdBy;
			delete poi.status;
			delete poi.dataType;
			delete poi.indexStatus;
		});
		response.financial_institutions.count = resp["count"];
		response.financial_institutions.data = resp["data"] as Poi[];
		return response;
	}

	async fetchCounts(user: Partial<User | ApiKeyUser>) {
		try {
			const query = {
				tokenUserId: user?.["type"] == "token" ? user?.id : undefined,
				apiKeyUserId: user?.["type"] == "apikey" ? user?.id : undefined,
			};
			const merchanStatuses: Lead[] = await this.leadsRepository.find({ where: query });
			const response = {
				in_progress_count: 0,
				rejected_count: 0,
				onboarded_count: 0,
				lost_count: 0,
				like_count: 0,
				dislike_count: 0,
			};
			merchanStatuses.forEach((ms: Lead) => {
				if (ms.status == "in_progress") response.in_progress_count = response.in_progress_count + 1;
				if (ms.status == "onboarded") response.onboarded_count = response.onboarded_count + 1;
				if (ms.status == "rejected") response.rejected_count = response.rejected_count + 1;
				if (ms.status == "like") response.like_count = response.like_count + 1;
				if (ms.status == "dislike") response.dislike_count = response.dislike_count + 1;
				if (ms.status == "lost") response.lost_count = response.lost_count + 1;
			});
			return response;
		} catch (error) {
			console.error(error);
			return { response: "Failed!" };
		}
	}

	gridFiltersCheck(grid: Grid, rangeKeys, selectKeys): boolean {
		for (const k of Object.keys(rangeKeys)) {
			const kval = grid.indexmaster?.filter((i) => i.indexName === k)?.[0]?.indexValue;
			if (kval < rangeKeys[k]["min"] || kval > rangeKeys[k]["max"]) return false;
		}
		for (const k of Object.keys(selectKeys)) {
			const kval = grid.indexmaster?.filter((i) => i.indexName === k)?.[0]?.categoricalValue;
			if (kval?.length) {
				if (!selectKeys[k].includes(kval)) return false;
			} else return false;
		}
		return true;
	}

	poiInterDetailsCheck(poi, rangeKeys, selectKeys, booleanKeys): boolean {
		if (poi && Object.keys(poi)?.length) {
			for (const k of selectKeys) {
				const kval = poi?.[k?.key];
				if (k?.values.length == 0 && kval != undefined) continue;
				if (!k.values.includes(kval)) return false;
			}
			for (const k of rangeKeys) {
				const kval = poi?.[k?.key];
				if (kval < k?.values?.min || kval > k?.vales?.max) return false;
			}
			for (const k of booleanKeys) {
				const kval = poi?.[k?.key];
				if (kval !== k.values) return false;
			}
			return true;
		} else return false;
	}

	async intersectQuery(query: FetchMerchantsBodyDto, user: Partial<User | ApiKeyUser>) {
		const existingPoiFilterMappings: POIFilterUserTeam[] = await (async () => {
			try {
				if (user?.["type"] == "apikey") return undefined;
				const e = await this.connection.manager.query(`
				select * from poi_filter_user_team where "UserId" = ${user.id}
				`);
				if (e?.length) return e;
				const f = await this.connection.manager.query(`
				select * from poi_filter_user_team where "TeamId" in (select "teamId" from "user" where id = ${user.id})
				`);
				return f;
			} catch (error) {
				console.error(error);
			}
		})();
		const poiFilterIDs = existingPoiFilterMappings?.map((pf) => pf.POIFilterId);
		if (!poiFilterIDs.length) return this.locationSearch(query);
		const poiFilter: POIFilter[] = await this.connection.manager.query(`
			select * from poi_filter where id in (${poiFilterIDs.join(",")}) and "isActivated" = true
		`);
		if (!poiFilter?.[0]?.value?.length) return this.locationSearch(query);
		try {
			const filter: FetchMerchantsBodyDto = JSON.parse(poiFilter[0].value);
			console.log(filter);
			//Lets settle array quries first
			query.types =
				filter.types && query.types
					? _.intersection(query.types, filter.types)
					: filter.types && !query.types
					? filter.types
					: query.types;
			query.subTypes =
				filter.subTypes && query.subTypes
					? _.intersection(query.subTypes, filter.subTypes)
					: filter.subTypes && !query.subTypes
					? filter.subTypes
					: query.subTypes;
			if (query?.poiDetails || filter?.poiDetails)
				query.poiDetails = [...(query?.poiDetails || []), ...(filter?.poiDetails || [])];
			if (query?.grid || filter?.grid) this.intersectGridFilters(query, filter);
			return await this.intersectLocationSearch(query, filter);
		} catch (error) {
			console.error(error);
			return [];
		}
	}

	intersectGridFilters(query: FetchMerchantsBodyDto, filter: FetchMerchantsBodyDto) {
		if (query?.grid?.select && filter?.grid?.select) {
			function customizer(objValue, srcValue) {
				if (_.isArray(objValue) && _.isArray(srcValue)) {
					objValue = _.intersection(objValue, srcValue);
					return objValue;
				}
			}
			query.grid.select = _.mergeWith(query.grid.select, filter.grid.select, customizer);
			query.grid.select = _.omitBy(query.grid.select, _.isEmpty);
		} else if (query?.grid?.range && filter?.grid?.range) {
			function customizer(objValue, srcValue) {
				if (objValue["min"] && srcValue["min"]) {
					if (objValue["min"] > srcValue["min"]) {
						objValue["min"] = objValue["min"];
					} else {
						objValue["min"] = srcValue["min"];
					}
				}
				if (objValue["max"] && srcValue["max"]) {
					if (objValue["max"] < srcValue["max"]) {
						objValue["max"] = objValue["max"];
					} else {
						objValue["max"] = srcValue["max"];
					}
				}
				if ((objValue["max"] && !srcValue["max"]) || (!objValue["max"] && srcValue["max"])) {
					if (objValue["max"]) {
						objValue["max"] = objValue["max"];
					} else {
						objValue["max"] = srcValue["max"];
					}
				}
				if ((objValue["min"] && !srcValue["min"]) || (!objValue["min"] && srcValue["min"])) {
					if (objValue["min"]) {
						objValue["min"] = objValue["min"];
					} else {
						objValue["min"] = srcValue["min"];
					}
				}
				return objValue;
			}
			query.grid.range = _.mergeWith(query.grid.range, filter.grid.range, customizer);
		} else {
			query.grid = { ...query.grid, ...filter.grid };
		}
	}

	async locationSearch(query: FetchMerchantsBodyDto) {
		if (!query) return [];
		// Selecting all Grid IDs
		let radialGridsIds;
		let locationGridsIds;
		if (query["within"] || (query["location"] && query["without"])) {
			let latLongs: LatLong[] = [];
			latLongs = query?.["within"]?.["points"] ?? query?.["without"]?.["points"];
			let distance;
			if (query?.["within"]?.["radius"] || query?.["within"]?.["radius"]) {
				distance = query["within"]["radius"] ?? query["within"]["radius"];
			} else distance = 0.5;
			const pi = Math.PI;
			const lat_increment = 1 / 110.574;
			const lng_increment = 1 / 111.32;
			const gridBBoxes = latLongs.map((latLng) => {
				const lat_max = latLng.lat + distance * lat_increment;
				const lat_min = latLng.lat - distance * lat_increment;
				const lng_max = latLng.lng + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
				const lng_min = latLng.lng - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
				return geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
			});
			const radialGridsArr = await Promise.all(
				gridBBoxes.map(async (bbox) => {
					try {
						const tempGrids = await this.gridRepository
							.createQueryBuilder("grid")
							.where("grid.hash IN (:...hashes)", { hashes: bbox })
							.select("grid.id")
							.getMany();
						return tempGrids.map((g) => g.id);
					} catch (error) {
						return [];
					}
				}),
			);
			radialGridsIds = _.flatten(radialGridsArr);
			console.log("Radial Grids = ", radialGridsIds?.length);
		}
		if (!query["within"] && query["location"]) {
			const locationQueryObject = {};
			let locationQueryString = "";
			Object.keys(query["location"]).forEach((location, index) => {
				if (index === 0) {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += "grid." + location + " = :" + location;
				} else {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += " AND grid." + location + " = :" + location;
				}
			});
			if (Object.keys(locationQueryObject).length) {
				try {
					const locationGrids = await this.gridRepository
						.createQueryBuilder("grid")
						.select("grid.id")
						.where(locationQueryString, locationQueryObject)
						.getMany();
					locationGridsIds = locationGrids.map((g) => g.id);
					console.log("Grids in Location Search :", locationGridsIds.length);
				} catch (error) {
					console.log(error);
				}
			}
		}
		let radiallyFilteredGridIds;
		if (query["within"]) {
			radiallyFilteredGridIds = radialGridsIds;
		} else if (query["location"] && query["without"]) {
			radiallyFilteredGridIds = _.difference(locationGridsIds, radialGridsIds);
		} else if (query["location"] && !query["without"]) {
			radiallyFilteredGridIds = locationGridsIds;
		} else radiallyFilteredGridIds = [];
		console.log("Radially Filtered Grids = ", radiallyFilteredGridIds?.length);
		return radiallyFilteredGridIds;
	}

	haveSharedKeys<T extends object, U extends object>(obj1: T, obj2: U): boolean {
		return Object.keys(obj1).some((key) => key in obj2);
	}

	getCommonKeys(query1: Record<string, any>, query2: Record<string, any>): string[] {
		const keys1 = Object.keys(query1);
		const keys2 = Object.keys(query2);

		const commonKeys = keys1.filter((key) => keys2.includes(key));

		return commonKeys;
	}

	haveSameValues(query1: Record<string, any>, query2: Record<string, any>): boolean {
		const commonKeys = this.getCommonKeys(query1, query2);

		for (const key of commonKeys) {
			if (query1[key] !== query2[key]) {
				return false;
			}
		}

		return true;
	}

	async intersectLocationSearch(query1: FetchMerchantsBodyDto, query2: FetchMerchantsBodyDto) {
		// If Location Query
		if (
			query1?.location &&
			!query1?.within &&
			!query1?.without &&
			query2?.location &&
			!query2?.within &&
			!query2?.without
		) {
			if (!this.haveSharedKeys(query1.location, query2.location)) {
				query1.location = { ...query1.location, ...query2.location };
				return await this.locationSearch(query1);
			} else {
				if (!this.haveSameValues(query1.location, query2.location)) return [];
			}
		}
		// If Radial Query
		else if ((query1?.within || query1?.without) && (query2?.within || query2?.without)) {
			return _.intersection(await this.locationSearch(query1), await this.locationSearch(query2));
		}
		// If Assigned POI Filter does not contain Location or Radial Query
		else {
			return await this.locationSearch(query1);
		}
	}

	getPolygonCenter(input): [number, number] {
		const coords = _.flatten(input["_doc"]["geometry"]["coordinates"]);
		const allLats = _.orderBy(coords.map((el: [number, number]) => el[1])).filter((el) => el);
		const allLngs = _.orderBy(coords.map((el: [number, number]) => el[0])).filter((el) => el);
		const lat = (allLats[allLats.length - 1] + allLats[0]) / 2;
		const lng = (allLngs[allLngs.length - 1] + allLngs[0]) / 2;
		return [lng, lat];
	}

	lowerFirstLetter(str: string): string {
		return str.charAt(0).toLowerCase() + str.slice(1);
	}

	async recenter(query: FetchMerchantsBodyDto): Promise<FetchMerchantsBodyDto> {
		try {
			if (query?.within) {
				const latLongs: LatLong[] = query?.["within"]?.["points"];
				query.center = {
					lat: 0,
					lng: 0,
				};
				query.center.lat = latLongs[0].lat;
				query.center.lng = latLongs[0].lng;
			} else if (query?.location) {
				const name = query.location[Object.keys(query.location)[0]];
				const level = this.lowerFirstLetter(Object.keys(query.location)[0]);
				const shape = await this.demoShapesDBModel.findOne({ name: name, level: level });
				if (shape) {
					const [lat, lng] = this.getPolygonCenter(shape);
					query.center = {
						lat: lat,
						lng: lng,
					};
				}
			}
			return query;
		} catch (error) {
			console.error(error);
		}
	}

	typesForNearOppFetch = _.isArray(JSON.parse(String(process.env.POI_TYPES_FOR_NEARBY_FETCH)))
		? (JSON.parse(String(process.env.POI_TYPES_FOR_NEARBY_FETCH)) as string[])
		: [];

	async fetch_opp_close_to_poi_types(
		query: FetchMerchantsBodyDto,
		user: Partial<User>,
	): Promise<PoiPaginationDto | any> {
		try {
			query.byPassRecenter = true;
			const actualQuery = _.clone(query) as FetchMerchantsBodyDto;

			//create query such that it doesnt discard the needed pois
			const nearTypesQuery: FetchMerchantsBodyDto = {
				types: this.typesForNearOppFetch,
				byPassRecenter: true,
				byPassOppVisibility: true,
			};
			query?.location ? (nearTypesQuery.location = query?.location) : false;
			query?.within ? (nearTypesQuery.within = query.within) : false;
			query?.without ? (nearTypesQuery.without = query.without) : false;
			query?.center ? (nearTypesQuery.center = query?.center) : false;

			const competition: { count: number; data: Poi[] } = await this.fetchOpportunities(nearTypesQuery, user);
			if (!competition?.data?.length) throw new HttpException(`NO nearby competition!`, HttpStatus.NO_CONTENT);
			let finalResponse: {
				count: number;
				data: Poi[];
			};

			for (let index = 0; index < competition?.data?.length; index++) {
				const element = competition.data[index];
				actualQuery.center = { lat: 0, lng: 0 };
				actualQuery.center.lat = element?.["geometry"]?.["coordinates"][1];
				actualQuery.center.lng = element?.["geometry"]?.["coordinates"][0];
				const res: { count: number; data: Poi[] } = await this.fetchOpportunities(actualQuery, user);
				if (!res?.data?.length) {
					continue;
				} else {
					finalResponse = res;
					break;
				}
			}
			return finalResponse;
		} catch (error) {
			console.error(error);
			return { count: 0, data: [], opportunities_in_location: 0, filteredCount: 0, totalCount: 0 };
		}
	}
	async fetch_opp_close_to_poi_types_overview(
		query: FetchMerchantsBodyDto,
		user: Partial<User>,
	): Promise<PoiPaginationDto | any> {
		try {
			query.byPassRecenter = true;
			const actualQuery = _.clone(query) as FetchMerchantsBodyDto;

			//create query such that it doesnt discard the needed pois
			const nearTypesQuery: FetchMerchantsBodyDto = {
				types: this.typesForNearOppFetch,
				byPassRecenter: true,
				byPassOppVisibility: true,
			};
			query?.location ? (nearTypesQuery.location = query?.location) : false;
			query?.within ? (nearTypesQuery.within = query.within) : false;
			query?.without ? (nearTypesQuery.without = query.without) : false;
			query?.center ? (nearTypesQuery.center = query?.center) : false;

			const competition = await this.fetchOpportunities(nearTypesQuery, user);
			if (!competition) throw new HttpException(`NO nearby competition!`, HttpStatus.NO_CONTENT);
			let finalResponse;

			for (let index = 0; index < competition?.data?.length; index++) {
				const element = competition.data[index];
				actualQuery.center = { lat: 0, lng: 0 };
				actualQuery.center.lat = element?.["geometry"]?.["coordinates"][1];
				actualQuery.center.lng = element?.["geometry"]?.["coordinates"][0];
				const res = await this.fetchOpportunitiesOverview(actualQuery, user);
				if (!res) {
					continue;
				} else {
					finalResponse = res;
					break;
				}
			}
			if (!finalResponse) {
				return { total_opportunities: 0, types: {}, turnover: {}, entity_types: {} };
			}
			return finalResponse;
		} catch (error) {
			console.error(error);
			return { count: 0, data: [], opportunities_in_location: 0, filteredCount: 0, totalCount: 0 };
		}
	}

	validateOpportunityPayload(query: FetchMerchantsBodyDto): boolean {
		if (query.types?.length && (query.location || query.within || query.without)) {
			return true;
		}
		return false;
	}

	async fetchOpportunities(query: FetchMerchantsBodyDto, user: Partial<User>): Promise<PoiPaginationDto | any> {
		const chunkSize = 60000;
		if (!query?.byPassRecenter) {
			query = await this.recenter(query);
		}
		const userDefaultFilter = !query?.byPassOppVisibility ? await this.getUserDefaultPOIFilter(user) : {};
		const locationGrids = await this.intersectLocationQueryGrids(query, userDefaultFilter);
		const poiIDsagainstLocationGrids = await this.getPOIIDssAgainstGridIDs(locationGrids, user, chunkSize);
		const totalPOIsNumber = poiIDsagainstLocationGrids.length;

		if (!userDefaultFilter || !Object.keys(userDefaultFilter).length) {
			const queryPOIs = await this.filterPOIByPOIDetails(query, poiIDsagainstLocationGrids, chunkSize);
			const sortedPOIs = await this.sortByGSTTurnoverOrDistance(queryPOIs, query);
			const slicedPOIs = sortedPOIs?.length
				? await this.appendPOIDetailsToPOIs(sortedPOIs.slice(0, query?.count ?? 20))
				: [];
			return {
				count: slicedPOIs?.length,
				data: slicedPOIs,
				opportunities_in_location: totalPOIsNumber,
				filteredCount: queryPOIs?.length,
				totalCount: totalPOIsNumber,
			};
		} else {
			const totalPOIs = await this.filterPOIByPOIDetails(
				userDefaultFilter,
				poiIDsagainstLocationGrids,
				chunkSize,
			);
			const queryPOIs = await this.filterPOIByPOIDetails(query, poiIDsagainstLocationGrids, chunkSize);
			const filteredPOIs = _.intersectionBy(totalPOIs, queryPOIs, "id");
			const sortedPOIs = await this.sortByGSTTurnoverOrDistance(filteredPOIs, query);
			const count = query?.count ?? 20;
			const slicedPOIs = sortedPOIs?.length ? await this.appendPOIDetailsToPOIs(sortedPOIs.slice(0, count)) : [];
			return {
				count: slicedPOIs?.length,
				data: slicedPOIs,
				opportunities_in_location: totalPOIsNumber,
				filteredCount: filteredPOIs?.length,
				totalCount: totalPOIs?.length,
			};
		}
	}

	async fetchOpportunitiesOverview(
		query: FetchMerchantsBodyDto,
		user: Partial<User>,
	): Promise<PoiPaginationDto | any> {
		const chunkSize = 60000;
		if (!query?.byPassRecenter) {
			query = await this.recenter(query);
		}
		const userDefaultFilter = !query?.byPassOppVisibility ? await this.getUserDefaultPOIFilter(user) : {};
		const locationGrids = await this.intersectLocationQueryGrids(query, userDefaultFilter);
		const poiIDsagainstLocationGrids = await this.getPOIIDssAgainstGridIDs(locationGrids, user, chunkSize);
		const totalPOIs = userDefaultFilter
			? await this.filterPOIByPOIDetails(userDefaultFilter, poiIDsagainstLocationGrids, chunkSize)
			: await this.filterPOIByPOIDetails({} as any, poiIDsagainstLocationGrids, chunkSize);
		const queryPOIs = await this.filterPOIByPOIDetails(query, poiIDsagainstLocationGrids, chunkSize);
		const filteredPOIs = userDefaultFilter ? _.intersectionBy(totalPOIs, queryPOIs, "id") : queryPOIs;
		const types = _.countBy(filteredPOIs, "type");

		const [entityKey, turnoverKey] = ["business_entity", "turn_over_slab"];
		const detailsKeys = await this.poiDetailRepository.find({
			where: { key: In([entityKey, turnoverKey]), poiId: In(filteredPOIs.map((p) => p.id)) },
		});
		const entity_types = _.countBy(
			detailsKeys.filter((d) => d.key === entityKey),
			"value",
		);
		const turnover = _.countBy(
			detailsKeys.filter((d) => d.key === turnoverKey),
			"value",
		);

		return {
			total_opportunities: filteredPOIs?.length,
			types,
			turnover,
			entity_types,
		};
	}

	async getUserDefaultPOIFilter(user: Partial<User>) {
		let defaultFilter = null;
		try {
			if (user?.["type"] == "apikey") return undefined;
			const userMapping: POIFilterUserTeam[] = await this.connection.query(`
			select * from poi_filter_user_team where "UserId" = ${user.id}
			`);
			const teamMapping: POIFilterUserTeam[] = await this.connection.query(`
			select * from poi_filter_user_team where "TeamId" in (${user.teamId})
			`);
			const poiFilterIDs = _.uniq([...userMapping, ...teamMapping].map((el) => el.POIFilterId));
			if (poiFilterIDs?.length) {
				const poiFilters: POIFilter[] = await this.connection.query(`
				select * from poi_filter where id in (${poiFilterIDs}) and "isActivated" = true
				`);
				const orderedPoiFilters = poiFilterIDs
					.map((id) => poiFilters.find((el) => el.id == id))
					.filter((el) => el);
				defaultFilter = JSON.parse(orderedPoiFilters?.[0]?.value);
			}
		} catch (error) {
			console.error(error);
		}
		return defaultFilter;
	}

	async intersectLocationQueryGrids(query1: FetchMerchantsBodyDto, query2: FetchMerchantsBodyDto) {
		// If Location Query
		if (
			query1?.location &&
			!query1?.within &&
			!query1?.without &&
			query2?.location &&
			!query2?.within &&
			!query2?.without
		) {
			if (!this.haveSharedKeys(query1.location, query2.location)) {
				query1.location = { ...query1.location, ...query2.location };
				return await this.locationSearch(query1);
			} else {
				if (!this.haveSameValues(query1.location, query2.location)) return [];
			}
		}
		// If Radial Query
		else if ((query1?.within || query1?.without) && (query2?.within || query2?.without)) {
			return _.intersection(await this.locationSearch(query1), await this.locationSearch(query2));
		}
		// If Assigned POI Filter does not contain Location or Radial Query
		else {
			return await this.locationSearch(query1);
		}
	}

	async getPOIIDssAgainstGridIDs(gridIDs: number[], user: Partial<User>, chunkSize: number): Promise<number[]> {
		if (gridIDs?.length == 0) return [];
		// Get all POI IDs against Grid IDs
		const allPoiIDs = await (async () => {
			try {
				const gridPOIArrs = await Promise.all(
					_.chunk(gridIDs, chunkSize).map(async (arr) => {
						return this.poiGridRepository
							.createQueryBuilder("poi_grid")
							.where("poi_grid.gridId IN (:...gridIds)", { gridIds: arr })
							.getMany();
					}),
				);
				return _.flatten(gridPOIArrs).map((pg) => pg.poiId);
			} catch (error) {
				console.log(error);
			}
		})();

		// Filter out POIs in Leads and Lost Leads Table
		const leadPoiIDs = await (async () => {
			try {
				const leads = await this.connection.manager.query(`
				select "poiId" from lead
				`);
				const lostLeads = await this.connection.manager.query(`
				select "poiId" from lost_lead where "tokenUserId" = ${user.id} 
				`);
				return _.uniq([...leads.map((l) => l?.["poiId"]), ...lostLeads.map((l) => l?.["poiId"])]);
			} catch (error) {
				console.log(error);
			}
		})();
		const nonLeadPOIIDs = _.difference(allPoiIDs, leadPoiIDs);
		return nonLeadPOIIDs;
	}

	generatePOITableQuery(query: FetchMerchantsBodyDto, poiIds: number[]): string {
		try {
			let str = `select * from poi where id in (${poiIds.join(`,`)})`;
			if (query?.types?.length) str = str + ` and type in (${this.genrateStringArrQuery(query.types)})`;
			if (query?.subTypes?.length)
				str = str + ` and "subType" in (${this.genrateStringArrQuery(query.subTypes)})`;
			if (query?.category != undefined) str = str + ` and category = '${query.category}'`;
			return str;
		} catch (error) {
			console.error(error);
			return ``;
		}
	}

	generatePOIDetailsTableQuery(query: FetchMerchantsBodyDto, poiIds: number[]): string {
		let str = `SELECT * FROM poi_detail WHERE (poi_detail."poiId" IN (${poiIds.join(",")}))`;
		if (query?.["poiDetails"]?.length) {
			const internalRangeKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "number");
			const internalSelectKeys = query?.["poiDetails"]
				?.filter((f) => f.dataType === "string")
				.filter((f) => f?.["values"]?.length);
			const internalBooleanKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "boolean");
			try {
				const rangeQueries = internalRangeKeys.map((k) => {
					const comparator = (() => {
						if (!isNaN(k.min) && !isNaN(k.max)) {
							return `poi_detail."value" BETWEEN ${k.min} AND ${k.max}`;
						} else if (!isNaN(k.max)) {
							return `poi_detail."value" <= ${k.max}`;
						} else if (!isNaN(k.min)) {
							return `poi_detail."value" >= ${k.min}`;
						}
					})();
					if (comparator.length) return `(poi_detail."key" = '${k.key}' AND ${comparator})`;
					else return ``;
				});
				const selectQueries = internalSelectKeys.map((k) => {
					if (k.values?.length) {
						return `(poi_detail."key" = '${k.key}' AND poi_detail."value" in (${this.genrateStringArrQuery(
							k.values,
						)}))`;
					} else return ``;
				});
				const booleanQueries = internalBooleanKeys.map((k) => {
					if (k.values.length) {
						return `(poi_detail."key" = '${k.key}' AND poi_detail."value" in (${k.values}))`;
					}
				});
				if (rangeQueries?.length || selectQueries?.length || booleanQueries?.length) {
					str += ` AND (${[...rangeQueries, ...selectQueries, ...booleanQueries].join(" OR ")})`;
				}
			} catch (err) {
				console.error(err);
				return ``;
			}
		}
		return str;
	}

	async filterPOIByPOIDetails(query: FetchMerchantsBodyDto, poiIDs: number[], chunkSize: number): Promise<any[]> {
		if (poiIDs?.length == 0) return [];
		// Get POI Details against POI IDs from poi table and filter out POIs against POI Filter poi table attributes
		let POIs = await (async () => {
			try {
				const allPoiIDsArr = _.chunk(poiIDs, chunkSize);
				const poiDetailsArr = await Promise.all(
					allPoiIDsArr.map(async (arr: number[]) => {
						const queryString = this.generatePOITableQuery(query, arr);
						try {
							return await this.connection.manager.query(queryString);
						} catch (error) {
							console.error(error);
						}
					}),
				);
				return _.flatten(poiDetailsArr);
			} catch (error) {
				console.log(error);
			}
		})();

		// Creating POI InternalDetails Dictionary as per POI Details Payload Query from poi_detail table
		// No use of filtering by POI Internal Details attribute if not supplied in the Payload
		if (query?.poiDetails && Object.keys(query?.poiDetails)?.length) {
			try {
				const POIIDsArr = _.chunk(
					POIs.map((p) => p.id),
					chunkSize,
				);
				const poiInternalDetailsArr = await Promise.all(
					POIIDsArr.map(async (arr) => {
						const queryString = this.generatePOIDetailsTableQuery(query, arr);
						return await this.connection.manager.query(queryString);
					}),
				);
				const keyedPoiInternalDetails = _.groupBy(_.flatten(poiInternalDetailsArr), "poiId");
				POIs?.forEach((poi) => {
					const poiInternalDetails = {};
					if (keyedPoiInternalDetails[poi.id]) {
						keyedPoiInternalDetails[poi.id].forEach((el) => {
							poiInternalDetails[el.key] = el.value;
						});
						poi["internalDetails"] = poiInternalDetails;
					}
				});
			} catch (error) {
				console.error(error);
			}

			// Filter by poiDetails
			if (query?.["poiDetails"]?.length) {
				const internalRangeKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "number");
				const internalSelectKeys = query?.["poiDetails"]
					?.filter((f) => f.dataType === "string")
					.filter((f) => f?.["values"]?.length);
				const internalBooleanKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "boolean");
				POIs = POIs.filter((poi) =>
					this.poiInterDetailsCheck(
						poi["internalDetails"],
						internalRangeKeys,
						internalSelectKeys,
						internalBooleanKeys,
					),
				);
			}
		}

		// Restructuring POI Object
		const restructuredPOIs = POIs.map((poi) => {
			const { longitude, latitude, ...POI } = poi;
			return {
				...POI,
				geometry: {
					type: "Point",
					coordinates: [Number(longitude), Number(latitude)],
				},
			} as any;
		});
		return restructuredPOIs;
	}

	async sortByGSTTurnoverOrDistance(POIs: any[], query: FetchMerchantsBodyDto): Promise<any[]> {
		if (POIs?.length == 0) return [];
		if (query?.sortBy === "GST_turn_over") {
			const GSTKey = "GST_turnover_number";
			const GSTKeyValues = await this.poiDetailRepository.find({
				where: { key: GSTKey, poiId: In(POIs.map((p) => p.id)) },
			});
			const GSTValues = _.keyBy(GSTKeyValues, "poiId");
			let allGSTMerchantData = [];
			const [GSTTurnover, NonGSTTurnover] = [[], []];
			POIs.forEach((poi) => {
				const GSTValue = GSTValues?.[poi.id]?.value;
				if (GSTValue) {
					const p = poi;
					p["internalDetails"][GSTKey] = GSTValue;
					GSTTurnover.push(p);
				} else NonGSTTurnover.push(poi);
			});
			const sortedGSTTurnOver = _.orderBy(
				GSTTurnover,
				[
					(o) => {
						return Number(o?.internalDetails?.[GSTKey] ?? 0);
					},
				],
				"desc",
			);
			allGSTMerchantData = sortedGSTTurnOver.concat(NonGSTTurnover);
			return allGSTMerchantData as Poi[];
		} else {
			if (query?.center != undefined) {
				(POIs as Poi[]).forEach((poi: Poi) => {
					const distance = tf.distance(
						tf.point([Number(query["center"].lng), Number(query["center"].lat)]),
						tf.point([
							Number(poi?.["geometry"]?.["coordinates"]?.[0]),
							Number(poi?.["geometry"]?.["coordinates"]?.[1]),
						]),
					);
					poi["distance"] = Number(distance);
				});
				return _.orderBy(POIs, ["distance"], ["asc"]);
			} else return POIs;
		}
	}

	async appendPOIDetailsToPOIs(pois: any[]): Promise<any[]> {
		if (!pois.length) return [];
		const details = await this.poiDetailRepository.find({ where: { poiId: In(pois.map((p) => p.id)) } });
		const keyedDetails = _.groupBy(details, "poiId");
		pois.forEach((p) => {
			const pDetails = {};
			keyedDetails[p.id].forEach((kv) => (pDetails[kv.key] = kv.value));
			p["internalDetails"] = pDetails;
		});
		return pois;
	}

	async fetch_merchants(
		query: FetchMerchantsBodyDto,
		user: Partial<User | ApiKeyUser>,
	): Promise<Poi[] | PoiPaginationDto | any> {
		// Selecting all Grid IDs
		const radiallyFilteredGridIds = await this.intersectQuery(query, user);
		await this.recenter(query);
		const response = {
			count: 0,
			data: [],
			typeCount: {},
			opportunities_in_location: 0,
			totalCount: 0,
			filteredCount: 0,
		};
		if (radiallyFilteredGridIds?.length) {
			// Creating Grid Indices Dictionary
			const gridsChunkLength = 60000;
			const gridIndexDict = {};
			const statusDict = {};
			try {
				const gridIndexMasterArrs = await Promise.all(
					_.chunk(radiallyFilteredGridIds, gridsChunkLength).map(async (arr) => {
						return await this.gridRepository
							.createQueryBuilder("grid")
							.leftJoinAndSelect("grid.indexmaster", "indexmaster")
							.where("grid.id In (:...gridIds)", { gridIds: arr })
							.getMany();
					}),
				);
				const rangeKeys = query?.["grids"]?.["range"] ?? {};
				const selectKeys = query?.["grids"]?.["select"] ?? {};
				console.log(rangeKeys, selectKeys);
				if (Object.keys(rangeKeys).length || Object.keys(selectKeys).length) {
					_.flatten(gridIndexMasterArrs).forEach((g: Grid) => {
						if (this.gridFiltersCheck(g, rangeKeys, selectKeys)) {
							const indices = {};
							g.indexmaster.forEach(
								(i) =>
									(indices[i.indexName] =
										i.indexType === "string" ? i.categoricalValue : i.indexValue),
							);
							gridIndexDict[g.id] = {
								index: indices,
							};
						}
					});
				} else {
					_.flatten(gridIndexMasterArrs).forEach((g: Grid) => {
						const indices = {};
						g.indexmaster.forEach(
							(i) =>
								(indices[i.indexName] = i.indexType === "string" ? i.categoricalValue : i.indexValue),
						);
						gridIndexDict[g.id] = {
							index: indices,
						};
					});
				}
			} catch (error) {
				console.log(error);
			}
			const indexFilteredGridIds = Object.keys(gridIndexDict);
			console.log("The Index Filtered Grids", indexFilteredGridIds.length);

			// Creating Poi-GridID Dict
			const poiGridIDDict = {};
			let allPoiIDs;
			if (indexFilteredGridIds?.length) {
				try {
					const gridPOIArrs = await Promise.all(
						_.chunk(indexFilteredGridIds, gridsChunkLength).map(async (arr) => {
							return this.poiGridRepository
								.createQueryBuilder("poi_grid")
								.where("poi_grid.gridId IN (:...gridIds)", { gridIds: arr })
								.getMany();
						}),
					);
					_.flatten(gridPOIArrs).forEach((pg) => (poiGridIDDict[pg.poiId] = pg.gridId));
					allPoiIDs = Object.keys(poiGridIDDict);
				} catch (error) {
					console.log(error);
				}
				console.log("All POIs in Index Filtered Grids", allPoiIDs.length);
			}

			// Filtering POIs
			if (allPoiIDs?.length) {
				let poiDetails;
				let filteredPoiIDs;
				try {
					if (query?.status != undefined) {
						const ms: {
							poiId: number;
							status: string;
							comment: string;
							remarks: string;
							tags: string[];
							updatedAt: Date;
						}[] = await this.connection.manager.query(
							query?.status.length
								? `select * from lead where ${
										user["type"] == "token"
											? `"tokenUserId" = ${user.id}`
											: `"apiKeyUserId" = ${user.id}`
								  } and status in (${this.genrateStringArrQuery(
										query.status,
								  )}) order by "updatedAt" DESC`
								: `select * from lead where ${
										user["type"] == "token"
											? `"tokenUserId" = ${user.id}`
											: `"apiKeyUserId" = ${user.id}`
								  } order by "updatedAt" DESC`,
						);
						const ids = [];
						ms.forEach((o) => {
							statusDict[o.poiId] = {
								status: o.status,
								comment: o.comment,
								remarks: o.remarks,
								tags: o.tags,
								time: o.updatedAt,
							};
							ids.push(String(o.poiId));
						});
						const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
						const poiDetailsArr = await Promise.all(
							allPoiIDsArr.map(async (arr: number[]) => {
								try {
									arr = _.intersection(arr, ids);
									return await this.connection.manager.query(this.generateQuery(query, arr));
								} catch (error) {
									console.error(error);
								}
							}),
						);
						poiDetails = _.flatten(poiDetailsArr);
						filteredPoiIDs = poiDetails.map((p) => p.id);
					} else {
						let barredPoiIds = [];
						try {
							barredPoiIds = [
								...((await this.connection.manager.query(`select distinct("poiId") from lead`)) as {
									poiId: number;
								}[]),
								...((await this.connection.manager.query(
									`select * from lost_lead where ${
										user["type"] == "token" ? `"tokenUserId"` : `"apiKeyUserId"`
									} = ${user.id}`,
								)) as { poiId: number }[]),
							].map((o: { poiId: number }) => {
								return o.poiId;
							});
							console.log(`Barred POIids Length : `, barredPoiIds.length);
						} catch (error) {
							console.error(error);
						}
						const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
						const poiDetailsArr = await Promise.all(
							allPoiIDsArr.map(async (arr: number[]) => {
								try {
									return await this.connection.manager.query(
										this.generateQuery(query, arr, barredPoiIds),
									);
								} catch (error) {
									console.error(error);
								}
							}),
						);
						poiDetails = _.flatten(poiDetailsArr);
						filteredPoiIDs = poiDetails.map((p) => p.id);
						response.totalCount = Number(allPoiIDs.length) - Number(barredPoiIds.length);
						response.filteredCount = Number(filteredPoiIDs.length);
					}
				} catch (error) {
					console.log(error);
				}
				console.log("The POI of Selected Types", filteredPoiIDs.length);

				if (filteredPoiIDs?.length) {
					// Creating POI InternalDetails Dictionary
					const poiInternalDetailsDict = {};
					try {
						const filteredPoiIdsArr = _.chunk(filteredPoiIDs, gridsChunkLength);
						const poiInternalDetailsArr = await Promise.all(
							filteredPoiIdsArr.map(async (arr) => {
								return await this.poiDetailRepository
									.createQueryBuilder("poi_detail")
									.where("poi_detail.poiId IN (:...poiIds)", { poiIds: arr })
									.getMany();
							}),
						);
						_.flatten(poiInternalDetailsArr).forEach((d) => {
							if (poiInternalDetailsDict[d.poiId]) poiInternalDetailsDict[d.poiId][d.key] = d.value;
							else {
								poiInternalDetailsDict[d.poiId] = { [d.key]: d.value };
							}
						});
					} catch (error) {
						console.log(error);
					}
					console.log("The POI Internal Detail Sets done");

					let POIs;

					//Filter by poiDetails
					if (query?.["poiDetails"]?.length) {
						const internalRangeKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "number");
						const internalSelectKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "string");
						const internalBooleanKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "boolean");
						POIs = poiDetails
							.map((poi) => {
								if (
									this.poiInterDetailsCheck(
										poiInternalDetailsDict?.[poi.id],
										internalRangeKeys,
										internalSelectKeys,
										internalBooleanKeys,
									)
								) {
									const coordinates: number[] = [];
									//coordinates.push(Number(poi.latitude));
									coordinates.push(Number(poi.longitude));
									coordinates.push(Number(poi.latitude));
									const { latitude, longitude, ...POI } = poi;
									return {
										...POI,
										index: gridIndexDict?.[poiGridIDDict[poi.id]]?.index,
										geometry: { type: "Point", coordinates: coordinates },
										internalDetails: poiInternalDetailsDict?.[poi.id],
										leadDetails: statusDict?.[poi.id] ?? undefined,
									};
								} else return false;
							})
							.filter((p) => p);
					} else {
						POIs = poiDetails.map((poi) => {
							const { latitude, longitude, ...POI } = poi;
							const coordinates: number[] = [];
							//coordinates.push(Number(poi.latitude));
							coordinates.push(Number(poi.longitude));
							coordinates.push(Number(poi.latitude));
							return {
								...POI,
								index: gridIndexDict?.[poiGridIDDict[poi.id]]?.index,
								geometry: { type: "Point", coordinates: coordinates },
								internalDetails: poiInternalDetailsDict?.[poi.id],
								leadDetails: statusDict?.[poi.id] ?? undefined,
							};
						});
					}

					//Order by 'sortBy' in query
					if (query?.sortBy == "GST_turn_over") {
						POIs = this.sortByGSTTurnover(POIs);
					} else if (query?.center != undefined) {
						(POIs as Poi[]).forEach((poi: Poi) => {
							const distance = tf.distance(
								tf.point([Number(query["center"].lng), Number(query["center"].lat)]),
								tf.point([
									Number(poi?.["geometry"]?.["coordinates"]?.[0]),
									Number(poi?.["geometry"]?.["coordinates"]?.[1]),
								]),
							);
							poi["distance"] = Number(distance);
						});
						POIs = _.orderBy(POIs, ["distance"], ["asc"]);
					}

					//Filter by count
					if (query?.count == 0) {
						POIs = [];
					}
					if (query.count != undefined) {
						POIs = (POIs as Poi[]).slice(0, Number(query.count));
					}

					console.log("All POIs processed", POIs.length);
					const allTypes = POIs.map((p) => p.type);
					const typeCount = {};
					_.uniq(allTypes).forEach(
						(t: string) => (typeCount[t] = allTypes.filter((type) => type === t).length),
					);
					response.count = POIs.length;
					response.data = POIs;
					response.typeCount = typeCount;
					response.opportunities_in_location = allPoiIDs.length;
				}
			}
		}
		return response;
	}

	sortByGSTTurnover(POIs) {
		const GSTKey = "GST_turnover_number";
		let allGSTMerchantData = [];
		const GSTTurnover = POIs.filter((poi) => poi?.internalDetails?.[GSTKey]) || [];
		const NonGSTTurnover = POIs.filter((poi) => !poi?.internalDetails?.[GSTKey]);
		const sortedGSTTurnOver = _.orderBy(
			GSTTurnover,
			[
				(o) => {
					return Number(o?.internalDetails?.[GSTKey] ?? 0);
				},
			],
			"desc",
		);
		allGSTMerchantData = sortedGSTTurnOver.concat(NonGSTTurnover);
		return allGSTMerchantData as Poi[];
	}

	genrateStringArrQuery(arr: string[]): string {
		let res = ``;
		arr.forEach((s, i) => {
			if (i == 0) {
				res = `'${s}'`;
			} else {
				res = res + `,'${s}'`;
			}
		});
		return res;
	}

	generateQuery(query: FetchMerchantsBodyDto, poiIds: number[], barredPoiIds?: number[]): string {
		try {
			let str = `select * from poi where id in (${poiIds.join(`,`)})`;
			if (query?.types?.length) str = str + ` and type in (${this.genrateStringArrQuery(query.types)})`;
			if (query?.subTypes?.length)
				str = str + ` and "subType" in (${this.genrateStringArrQuery(query.subTypes)})`;
			if (query?.category != undefined) str = str + ` and category = '${query.category}'`;
			if (barredPoiIds?.length) str = str + ` and id not in (${barredPoiIds.join(`,`)})`;
			if (query?.gst?.includes("Gst") && !query?.gst?.includes("Non Gst"))
				str = str + ` and exists (select * from poi_detail where key = 'gstin' and "poiId" = poi.id)`;
			if (!query?.gst?.includes("Gst") && query?.gst?.includes("Non Gst"))
				str = str + ` and not exists (select * from poi_detail where key = 'gstin' and "poiId" = poi.id)`;
			return str;
		} catch (error) {
			console.error(error);
			return ``;
		}
	}

	async getPOIDetailsByIDs(IDs: number[]) {
		let pois = await (async () => {
			try {
				return await this.poiRepository.find({ where: { id: In(IDs) } });
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		if (!pois.length) return [];
		pois = pois.map((p) => {
			const { latitude, longitude, ...POI } = p;
			return {
				...POI,
				geometry: { type: "Point", coordinates: [Number(longitude), Number(latitude)] },
			};
		}) as any;
		const poiGridIDs = await (async () => {
			try {
				return await this.poiGridRepository.find({ where: { poiId: In(pois.map((p) => p.id)) } });
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const poiGridIDDict = _.keyBy(poiGridIDs, (p) => p.poiId);
		const gridIndexMasters = await (async () => {
			try {
				return await this.indexMasterRepository.find({
					where: { grid: In(poiGridIDs.map((p) => p.gridId)) },
				});
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const gridDetailsDict = _.groupBy(gridIndexMasters, (g) => g.grid);
		const poiDetails = await (async () => {
			try {
				return await this.poiDetailRepository.find({ where: { poiId: In(pois.map((p) => p.id)) } });
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const poiDetailsDict = _.groupBy(poiDetails, (p) => p.poiId);
		const poiBody = pois.map((poi) => {
			return {
				...poi,
				index: _.reduce(
					gridDetailsDict[poiGridIDDict[poi.id].gridId],
					(result, obj) => {
						result[obj.indexName] = obj.indexValue;
						return result;
					},
					{},
				),
				internalDetails: _.reduce(
					poiDetailsDict[poi.id],
					(result, obj) => {
						result[obj.key] = obj.value;
						return result;
					},
					{},
				),
			};
		});
		return poiBody;
	}
}
