import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { User } from "src/users/users.entity";
import { OrganisationsController } from "./organisations.controller";
import { Organisation } from "./organisations.entity";
import { JwtModule } from "@nestjs/jwt";
import { OrganisationsService } from "./organisations.service";
import { UserCredits } from "../user-history/user-credits.entity";
import { RolesGuardService } from "../helpers/roles-guard/roles-guard.service";
import { UserApiUsageHistory } from "../user-api-usage-history/user-api-usage-history.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { Shape } from "src/shape/shape.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { UpdateCreditsLogs } from "src/update-credits-logs/update-credits-logs.entity";
import { Team } from "src/team/team.entity";
import { TeamService } from "src/team/team.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
@Module({
	imports: [
		TypeOrmModule.forFeature([
			Organisation,
			User,
			Team,
			UserCredits,
			UserApiUsageHistory,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyUserApiUsageHistory,
			ApiKeyUserCredits,
			Shape,
			ApiKeyIp,
			UserIdIp,
			UpdateCreditsLogs,
		]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
	],
	controllers: [OrganisationsController],
	providers: [OrganisationsService, RolesGuardService, TeamService, KeyCloakService, CentralServerService],
})
export class OrganisationsModule {}
