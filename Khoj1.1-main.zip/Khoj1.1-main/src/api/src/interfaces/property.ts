import { Property } from "src/property/property.entity";
import { ApiProperty } from "@nestjs/swagger";
import { PoiStatus } from "src/poi/poi.entity";

export class PropertyQuery {

	@ApiProperty()
	location: any;

	@ApiProperty()
	city: string;

	@ApiProperty()
	landmark: string;

	@ApiProperty()
	pincode: number;

	@ApiProperty()
	limit: number;

	@ApiProperty()
	page: number;

	@ApiProperty()
	poiStatus: PoiStatus;

	@ApiProperty()
	types: string[];

	@ApiProperty()
	category?: string;

	@ApiProperty()
	count?: number;

	@ApiProperty()
	gst?: string[];
}

export class PropertyPaginationDto {
	@ApiProperty()
	page: number;

	@ApiProperty()
	limit: number;

	@ApiProperty()
	totalPages: number;

	@ApiProperty()
	data: Property[];
}
export class PropertyLatLng {
	@ApiProperty()
	latitude: number;

	@ApiProperty()
	longitude: number;

	@ApiProperty()
	distance: number;
}
export class PropertyReviewBody {
	@ApiProperty()
	propertyIds: number[];
}
export class PropertyIdBody {
	@ApiProperty()
	propertyId: number;
}
export class PropertyUpdate {
	@ApiProperty()
	id: number;

	@ApiProperty()
	name: string;

	@ApiProperty()
	building: string;

	@ApiProperty()
	street: string;

	@ApiProperty()
	town: string;

	@ApiProperty()
	city: string;

	@ApiProperty()
	landmark: string;

	@ApiProperty()
	latitude: number;

	@ApiProperty()
	longitude: number;

	@ApiProperty()
	pinCode: number;
}
