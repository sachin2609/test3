import { Entity, PrimaryColumn, Column, Index } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

@Entity()
export class UserMerchant {
	@ApiProperty()
	@Column()
	userId: number;

	@ApiProperty()
	@PrimaryColumn()
	merchantId: number;
}