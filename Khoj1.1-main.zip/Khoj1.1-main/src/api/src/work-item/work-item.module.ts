import { Module } from "@nestjs/common";
import { WorkItemService } from "./work-item.service";
import { WorkItemController } from "./work-item.controller";
import { WorkItem } from "./work-item.entity";
import { TypeOrmModule } from "@nestjs/typeorm";
import { JwtModule } from "@nestjs/jwt";
import { Property } from "src/property/property.entity";
import { PropertyGrid } from "../relations/property-grid/property-grid.entity";
import { UserGrid } from "../relations/user-grid/user-grid.entity";
import { User } from "../users/users.entity";
@Module({
	imports: [
		TypeOrmModule.forFeature([WorkItem, Property, PropertyGrid, UserGrid, User]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		})
	],
	providers: [WorkItemService],
	controllers: [WorkItemController],
	exports: [WorkItemService]
})
export class WorkItemModule {}
