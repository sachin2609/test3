import { Entity, PrimaryColumn, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class LayerSet {
	@PrimaryGeneratedColumn()
	id: number;

	@Column()
	layerSet: string;

	@Column()
	name: string;

	@Column()
	value: string;

	@Column()
	userId: string;
	
	@Column({ default: true })
	default: boolean;
}
