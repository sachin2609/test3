import { Entity, Column, PrimaryColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class CsvUploadedFiles {
	@ApiProperty()
	@PrimaryColumn()
	name: string;

	@ApiProperty()
	@PrimaryColumn()
	userId: number;

	@ApiProperty()
	@Column({nullable: true})
	description: string;

	@ApiProperty()
	@Column()
	path: string;
}
