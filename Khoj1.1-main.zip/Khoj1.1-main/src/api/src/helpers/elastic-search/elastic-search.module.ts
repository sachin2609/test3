import { Module } from '@nestjs/common';
import { ElasticsearchModule } from '@nestjs/elasticsearch';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Grid } from 'src/grid/grids.entity';
import { ElasticSearchController } from './elastic-search.controller';
import { ElasticSearchService } from './elastic-search.service';
import * as dotenv from 'dotenv';
import { Poi } from 'src/poi/poi.entity';
import { MongooseModule } from '@nestjs/mongoose';
import { DemoShapesDBSchema } from 'src/shape/shape.schema';
import { Shape } from 'src/shape/shape.entity';

@Module({
    imports: [
        ElasticsearchModule.register({
            node: process.env.ELASTIC_HOST,
        }),
        TypeOrmModule.forFeature([
            Grid,
            Poi,
            Shape
        ]),
        MongooseModule.forFeature([{ name: 'DemoShapesDB', schema: DemoShapesDBSchema }])
    ],
    controllers: [ElasticSearchController],
    providers: [ElasticSearchService]
})
export class ElasticSearchModule {}
