import { Test, TestingModule } from '@nestjs/testing';
import { TargetDetailsController } from './target-details.controller';

describe('TargetDetailsController', () => {
  let controller: TargetDetailsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TargetDetailsController],
    }).compile();

    controller = module.get<TargetDetailsController>(TargetDetailsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
