export class AddPromptLogDto {
	tokenUserId?: number;
	apiKeyUserId?: number;
	poiId: number;
	node: string;
	question?: string;
	answer: string;
	comment?: string;
}

export class FetchPromptLogDto {
	poiId: number[];
	userId?: number[];
	startDate?: Date;
	endDate?: Date;
}

export class UpdatePromptChainBody {
	id: number;
	promptsChain: PromptChain;
}

export class PromptChain {
	id: number;
	desc: string;
	type: string;
	options: string[];
}
