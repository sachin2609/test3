import { Injectable } from "@nestjs/common";
import { PoiDetail } from "./poi-details.entity";
import { Repository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
@Injectable()
export class PoiDetailsService {
	constructor(@InjectRepository(PoiDetail) private poiDetailsRepository: Repository<PoiDetail>) {}

	async create(poiDetailObjects: PoiDetail[]): Promise<PoiDetail[]> {
		return await this.poiDetailsRepository.save(poiDetailObjects);
	}

	async list(poiId?: number): Promise<PoiDetail[]> {
		if (poiId) {
			return await this.poiDetailsRepository.find({ where: {
				poiId: poiId
		}});
		} else {
			return await this.poiDetailsRepository.find();
		}
	}
}
