import { Module } from '@nestjs/common';
import { LayerShapeController } from './layer-shape.controller';
import { LayerShapeService } from './layer-shape.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Shapeindex } from '../../shape/shapeIndex.entity';
import { LayerDetail } from '../../layer-details/layer-details.entity';
import { Layer } from '../../layers/layers.entity';
import { LayerShape } from './layer-shape.entity';
import { ShapeService } from '../../shape/shape.service';
import { Shape } from '../../shape/shape.entity';
import { Grid } from '../../grid/grids.entity';
import { MongooseModule } from '@nestjs/mongoose';
import { DemoShapesDBSchema } from '../../shape/shape.schema';
import { MongoDatabaseModule } from 'src/helpers/mongo-database/mongo-database.module';
import { ShapeDetail } from '../../shape-details/shape-details.entity';
@Module({
	imports: [
		MongooseModule.forFeature([{ name: 'DemoShapesDB', schema: DemoShapesDBSchema }]),
		TypeOrmModule.forFeature([
			Shapeindex,
			LayerDetail,
			Layer,
			LayerShape,
			Shape,
			Grid,
			ShapeDetail
		]),
		MongoDatabaseModule
	],
	controllers: [LayerShapeController],
	providers: [LayerShapeService, ShapeService]
})
export class LayerShapeModule {}
