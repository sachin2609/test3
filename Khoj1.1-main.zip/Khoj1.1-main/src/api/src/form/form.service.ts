import { Injectable } from "@nestjs/common";
import { Repository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { QuestionService } from "../question/question.service";
import { Form } from "./form.entity";
import { Question } from "../question/question.entity";
import * as fs from "fs";
@Injectable()
export class FormService {
	constructor(
		@InjectRepository(Form) private formRepository: Repository<Form>,
		private _questionService: QuestionService
	) {}

	async list(query: Form): Promise<Question[]> {
		const form = await this.formRepository.findOne({ where: {id: query.id }});
		return await this._questionService.findByIds(form.questionIds);
	}

	async create(): Promise<Form[]> {
		const data = JSON.parse(fs.readFileSync("./src/files/form.json", "utf-8"));
		return await this.formRepository.save(data);
	}
}
