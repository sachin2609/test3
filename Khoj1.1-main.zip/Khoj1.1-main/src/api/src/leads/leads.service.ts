import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Lead, LostLead } from "src/leads/leads.entity";
import { Brackets, DataSource, In, Repository } from "typeorm";
import { LeadStatusUpdates } from "src/leads/leads.entity";
import { AddLeadDto } from "../interfaces/status-updates";
import { Poi } from "src/poi/poi.entity";
import { MerchantService } from "src/merchant/merchant.service";
import { isArray, countBy, intersection, keyBy, uniq } from "lodash";
import { TeamService } from "src/team/team.service";
import { Kpi } from "src/kpi/kpi.entity";
import { LeadQuery, LeadsFetchFilter, TimeLineQuery, TimeLineResponse } from "src/interfaces/leads";
import { Reminder, ReminderUpdate } from "src/reminders/reminders.entity";
import { Note } from "src/notes/notes.entity";
import { User } from "src/users/users.entity";
import { RemindersService } from "src/reminders/reminders.service";
import * as _ from "lodash";
import moment = require("moment");

@Injectable()
export class LeadsService {
	constructor(
		@InjectRepository(LeadStatusUpdates) private leadStatusUpdatesRepository: Repository<LeadStatusUpdates>,
		@InjectRepository(Lead) private leadRepository: Repository<Lead>,
		@InjectRepository(LostLead) private lostLeadRepository: Repository<LostLead>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(Kpi) private kpiRepository: Repository<Kpi>,
		@InjectRepository(Reminder) private reminderRepository: Repository<Reminder>,
		@InjectRepository(ReminderUpdate) private reminderUpdateRepository: Repository<ReminderUpdate>,
		@InjectRepository(Note) private noteRepository: Repository<Note>,
		private connection: DataSource,
		private _merchantService: MerchantService,
		private reminderService: RemindersService,
		private teamsService: TeamService,
	) {}

	lostLeadType = "lost";
	unreservedLeadType = "unreserved";

	async addLead(query: AddLeadDto, tokenUserId: number, apiKeyUserId: number): Promise<void> {
		const { poiId, status, visited, remarks, comment, tags } = query;
		if (!poiId || (!status && !tags && !_.isBoolean(visited)))
			throw new HttpException(`'poiId' and 'status' or 'tags' or ''visited is required!`, HttpStatus.BAD_REQUEST);

		// Check if given POI exists
		const existingPoi = await (async () => {
			try {
				return await this.poiRepository.findOne({ where: { id: query.poiId } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (!existingPoi) throw new HttpException(`POI with id : ${query.poiId} doesnt exist!`, HttpStatus.BAD_REQUEST);

		// Check if given POI is already in a lead pipeline and prevent from updating if in someone else's pipeline
		const existingLead = await (async () => {
			try {
				return await this.leadRepository.findOne({ where: { poiId: query.poiId } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (existingLead) {
			if (existingLead?.tokenUserId != tokenUserId && existingLead.apiKeyUserId !== apiKeyUserId)
				throw new HttpException(`This opp. is already being engaged by different user!`, HttpStatus.FORBIDDEN);
		}

		// Prevent from marking a POI as lost lead more than once per user
		if (status === this.lostLeadType) {
			const existingLostLead = await (async () => {
				try {
					return await this.lostLeadRepository.findOne({ where: { poiId, tokenUserId, apiKeyUserId } });
				} catch (error) {
					console.error(error);
				}
			})();
			if (existingLostLead)
				throw new HttpException(`Lead with ID ${poiId} is already lost for this user!`, HttpStatus.FORBIDDEN);
		}

		const leadQueryObj = {
			poiId,
			status: status ?? existingLead.status,
			visited,
			tokenUserId,
			apiKeyUserId,
			comment,
			remarks,
			tags: isArray(tags) ? tags : [],
		};
		const leadUpdateQueryObj = {
			poiId,
			status,
			visited,
			tokenUserId,
			apiKeyUserId,
			comment,
			remarks,
			tags: isArray(tags) ? tags : [],
		};
		const lostLeadQueryObj = { poiId, tokenUserId, apiKeyUserId };
		const queryRunner = this.connection.createQueryRunner();
		await queryRunner.connect();
		await queryRunner.startTransaction();
		try {
			const lead = queryRunner.manager.create(Lead, leadQueryObj);
			const statusUpdate = queryRunner.manager.create(LeadStatusUpdates, leadUpdateQueryObj);
			const lostLead = queryRunner.manager.create(LostLead, lostLeadQueryObj);
			if (!existingLead && ![this.lostLeadType, this.unreservedLeadType].includes(status)) {
				await queryRunner.manager.save<Lead>(lead);
			} else if ([this.lostLeadType, this.unreservedLeadType].includes(status)) {
				if (existingLead) await queryRunner.manager.delete<Lead>(Lead, poiId);
				if (status === this.lostLeadType) await queryRunner.manager.save<LostLead>(lostLead);
			} else {
				await queryRunner.manager.update<Lead>(Lead, poiId, lead);
			}
			await queryRunner.manager.save<LeadStatusUpdates>(statusUpdate);
			await queryRunner.commitTransaction();
		} catch (error) {
			console.error(error);
			await queryRunner.rollbackTransaction();
			throw new HttpException(`Failed to update lead status!`, HttpStatus.SERVICE_UNAVAILABLE);
		} finally {
			await queryRunner.release();
		}
	}

	async getLeadsForUser(leadQuery: LeadQuery, tokenUserId: number, apiKeyUserId: number): Promise<Partial<Lead>[]> {
		const { status, visited, tags, startTime, endTime, poiIDs, filters } = leadQuery;
		try {
			let activeLeads = await (async () => {
				let response = [];
				try {
					const res = await this.leadRepository
						.createQueryBuilder(`lead`)
						.where(
							() => {
								if (status?.length) {
									return `status IN (:...status)`;
								} else return `1=1`;
							},
							{ status },
						)
						.andWhere(
							() => {
								if (startTime && endTime) return `"updatedAt" between :startTime and :endTime`;
								else if (startTime) return `"updatedAt" >= :startTime`;
								else if (endTime) return `"updatedAt" <= :endTime`;
								else return `1=1`;
							},
							{
								startTime,
								endTime,
							},
						)
						.andWhere(
							() => {
								if (poiIDs?.length) return `"poiId" IN (:...poiIDs)`;
								else return `1=1`;
							},
							{ poiIDs },
						)
						.andWhere(
							() => {
								return tokenUserId ? `"tokenUserId" = :tokenUserId` : `"apikeyUserId" = :apikeyUserId`;
							},
							{ tokenUserId, apiKeyUserId },
						)
						.andWhere(
							() => {
								if (_.isBoolean(visited)) return `visited = :visited`;
								else return `1=1`;
							},
							{ visited },
						)
						.getMany();
					if (!res?.length) return [];

					const pendingVisitsLeads: number[] = await this.leadRepository
						.find({
							where: {
								visited: false,
								poiId: In(res.map((l) => l.poiId).filter((id) => _.isFinite(id))),
							},
						})
						.then((leads) => {
							return leads.map((l) => l.poiId).filter((id) => _.isFinite(id));
						})
						.catch((err) => {
							console.error(err);
							return [];
						});
					const contactPendingLeads: number[] = await this.leadRepository
						.createQueryBuilder(`lead`)
						.where(`ARRAY['visit later','call later']::character varying[] && tags`)
						.andWhere(`"poiId" IN (:...poiIds)`, {
							poiIds: res.map((l) => l.poiId).filter((id) => _.isFinite(id)),
						})
						.getMany()
						.then((leads) => {
							return leads.map((l) => l.poiId).filter((id) => _.isFinite(id));
						})
						.catch((err) => {
							console.error(err);
							return [];
						});

					const intrestedLeads: number[] = (
						(await this.connection.query(`
							WITH l as (
								SELECT DISTINCT ON ("poiId")
								id, "poiId", status, "createdAt", remarks
								FROM lead_status_updates
								WHERE status = 'in_progress'
								AND remarks IN ('Customer seems interested','Customer seems interested($)','Customer is interested($)','Customer was interested($)')
								AND "poiId" in (${res.map((l) => l.poiId).join(",")}) ORDER BY "poiId", "createdAt"
							),
							m as (
								SELECT "poiId" from lead where visited = true and "poiId" in (${res.map((l) => l.poiId).join(",")})
								INTERSECT
								SELECT DISTINCT "poiId"
								FROM lead_status_updates l1
								WHERE ARRAY['visit later','call later']::character varying[] && l1.tags
								AND NOT EXISTS (
									SELECT 1
									FROM lead_status_updates l2
									WHERE l1."poiId" = l2."poiId"
								  	AND ARRAY['visit later','call later']::character varying[] && l2.tags
								  	AND l2."createdAt" > l1."createdAt"
								)		
							)
							select "poiId" from l UNION select "poiId" from m;
							`)) as { poiId: number }[]
					).map((il) => il.poiId);

					if (!filters) {
						response = [...response, ...res];
					}
					if (filters?.length && filters.includes(LeadsFetchFilter.CONTACT_PENDING)) {
						response = [...response, ...res.filter((l) => contactPendingLeads.includes(Number(l?.poiId)))];
					}
					if (filters?.length && filters.includes(LeadsFetchFilter.PENDING_VISITS)) {
						response = [...response, ...res.filter((l) => pendingVisitsLeads.includes(Number(l?.poiId)))];
					}
					if (filters?.length && filters.includes(LeadsFetchFilter.INTRESTED)) {
						response = [...response, ...res.filter((l) => intrestedLeads.includes(Number(l?.poiId)))];
					}
					if (filters?.length && filters.includes(LeadsFetchFilter.OTHERS)) {
						response = [
							...response,
							...res.filter(
								(l) =>
									!contactPendingLeads.includes(Number(l?.poiId)) &&
									!pendingVisitsLeads.includes(Number(l?.poiId)) &&
									!intrestedLeads.includes(Number(l?.poiId)),
							),
						];
					}
				} catch (error) {
					console.error(error);
				} finally {
					return response;
				}
			})();
			const lostLeads = await (async () => {
				try {
					if (status?.includes(this.lostLeadType))
						return await this.leadRepository
							.createQueryBuilder(`lost_lead`)
							.where(
								() => {
									return tokenUserId
										? `"tokenUserId" = :tokenUserId`
										: `"apikeyUserId" = :apikeyUserId`;
								},
								{ tokenUserId, apiKeyUserId },
							)
							.andWhere(
								() => {
									if (leadQuery.startTime && leadQuery.endTime)
										return `"createdAt" between :startTime and :endTime`;
									else if (leadQuery.startTime) return `"createdAt" >= :startTime`;
									else if (leadQuery.endTime) return `"createdAt" <= :endTime`;
									else return `1=1`;
								},
								{
									startTime: leadQuery.startTime,
									endTime: leadQuery.endTime,
								},
							)
							.getMany();
					else return [];
				} catch (error) {
					console.error(error);
				}
			})();
			activeLeads =
				tags?.length > 0 ? activeLeads?.filter((lead) => intersection(lead.tags, tags)?.length) : activeLeads;
			return [...activeLeads, ...lostLeads];
		} catch (err) {
			console.error(err);
		}
	}

	async getLastUpdated(tokenUserId: number, apiKeyUserId: number, poiIds: number[]) {
		const latestReminder = await (async () => {
			try {
				const queryBuilder = this.reminderRepository
					.createQueryBuilder("reminder")
					.where("reminder.poiId in (:...poiIds)", { poiIds });
				apiKeyUserId
					? queryBuilder.andWhere("reminder.apiKeyUserId = :apiKeyUserId", { apiKeyUserId })
					: queryBuilder.andWhere("reminder.tokenUserId = :tokenUserId", { tokenUserId });
				queryBuilder.andWhere("reminder.isDeleted=false");
				return await queryBuilder.getMany();
			} catch (err) {
				console.error(err);
			}
		})();

		const latestLead = await (async () => {
			try {
				const queryBuilder = this.leadStatusUpdatesRepository
					.createQueryBuilder("lead_status_updates")
					.where("lead_status_updates.poiId in (:...poiIds)", { poiIds })
					.andWhere(
						new Brackets((qb) =>
							qb
								.where("lead_status_updates.visited IS NOT null")
								.orWhere("lead_status_updates.status IS NOT null"),
						),
					);
				apiKeyUserId
					? queryBuilder.andWhere("lead_status_updates.apiKeyUserId = :apiKeyUserId", { apiKeyUserId })
					: queryBuilder.andWhere("lead_status_updates.tokenUserId = :tokenUserId", { tokenUserId });
				return await queryBuilder.getMany();
			} catch (err) {
				console.error(err);
			}
		})();

		const latestKpi = await (async () => {
			try {
				const queryBuilder = this.kpiRepository
					.createQueryBuilder("kpi")
					.where("kpi.poiId in (:...poiIds)", { poiIds });
				apiKeyUserId
					? queryBuilder.andWhere("kpi.apiKeyUserId = :apiKeyUserId", { apiKeyUserId })
					: queryBuilder.andWhere("kpi.tokenUserId = :tokenUserId", { tokenUserId });
				queryBuilder.andWhere("kpi.action IN (:...actions)", {
					actions: ["Merchant Call", "Merchant Navigate"],
				});
				return await queryBuilder.getMany();
			} catch (err) {
				console.error(err);
			}
		})();

		const latestNote = await (async () => {
			try {
				const queryBuilder = this.noteRepository
					.createQueryBuilder("note")
					.where("note.poiId in (:...poiIds)", { poiIds });
				apiKeyUserId
					? queryBuilder.andWhere("note.apiKeyUserId = :apiKeyUserId", { apiKeyUserId })
					: queryBuilder.andWhere("note.tokenUserId = :tokenUserId", { tokenUserId });
				return await queryBuilder.getMany();
			} catch (err) {
				console.error(err);
			}
		})();
		const groupedRecords = _.groupBy([...latestReminder, ...latestLead, ...latestKpi, ...latestNote], "poiId");
		const latestRecords = {};
		poiIds.forEach((poiId) => {
			try {
				const allRecords = _.orderBy(
					groupedRecords[poiId].map((r) => r["updatedAt"] ?? r.createdAt),
					function (date) {
						return moment(date);
					},
					"desc",
				);
				latestRecords[poiId] = allRecords[0];
			} catch (error) {
				console.error(error);
			}
		});
		return latestRecords;
	}

	async fetchLeads(query: LeadQuery, tokenUserId: number, apiKeyUserId: number) {
		const leads = await this.getLeadsForUser(query, tokenUserId, apiKeyUserId);
		if (!leads.length) return [];
		const leadsDict = keyBy(leads, "poiId");
		const reminders = await this.reminderService.fetchReminder({
			userId: [apiKeyUserId ?? tokenUserId],
		});
		const remindersDict = keyBy(reminders, "poiId");
		const lastContacedDict = await (async () => {
			try {
				const resFromKpi: { action: string; poiId: number; createdAt: string }[] = await this.connection.query(`
					WITH ranked_actions AS (
						  SELECT "poiId", action, "createdAt", ROW_NUMBER() OVER (PARTITION BY "poiId" ORDER BY "createdAt" DESC) AS row_num
						  FROM kpi
						  WHERE "poiId" IN (${leads.map((l) => Number(l.poiId)).join(",")})
						  AND action IN ('Merchant Call', 'Merchant Navigate')
					)				
					SELECT "poiId", action, "createdAt"
					FROM ranked_actions
					WHERE row_num = 1;
				`);
				return _.groupBy(resFromKpi, "poiId");
			} catch (error) {
				console.error(error);
				return {};
			}
		})();
		const interstedLeadsIds: number[] = await (async () => {
			try {
				return (
					(await this.connection.query(`
						WITH l as (
							SELECT DISTINCT ON ("poiId")
							id, "poiId", status, "createdAt", remarks
							FROM lead_status_updates
							WHERE status = 'in_progress'
							AND remarks IN ('Customer seems interested','Customer seems interested($)','Customer is interested($)','Customer was interested($)')
							AND "poiId" in (${leads.map((l) => l.poiId).join(",")}) ORDER BY "poiId", "createdAt"
						),
						m as (
							SELECT "poiId" from lead where visited = true and "poiId" in (${leads.map((l) => l.poiId).join(",")})
							INTERSECT
							SELECT DISTINCT "poiId"
							FROM lead_status_updates l1
							WHERE ARRAY['visit later','call later']::character varying[] && l1.tags
							AND NOT EXISTS (
								SELECT 1
								FROM lead_status_updates l2
								WHERE l1."poiId" = l2."poiId"
							  AND ARRAY['visit later','call later']::character varying[] && l2.tags
							  AND l2."createdAt" > l1."createdAt"
							)		
						)
						select "poiId" from l UNION select "poiId" from m;
					`)) as { poiId: number }[]
				).map((il) => il.poiId);
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const pois = await this._merchantService.getPOIDetailsByIDs(leads.map((lead) => lead.poiId));
		const latestRecords = await this.getLastUpdated(
			tokenUserId,
			apiKeyUserId,
			leads.map((lead) => Number(lead.poiId)),
		);
		const leadsDTOs = pois.map((poi) => {
			const { status, visited, remarks, comment, tags, createdAt, updatedAt } = leadsDict[poi.id];
			poi["last_updated_at"] = latestRecords[poi.id] ?? null;
			const lastContacted = (() => {
				const lastContactRecord = lastContacedDict?.[poi.id]?.[0];
				if (lastContactRecord) {
					const lastCallRecord = lastContactRecord.action == "Merchant Call";
					const diff = moment(Date.now()).diff(lastContactRecord.createdAt, "days");
					const diffString = diff > 0 ? `${diff} days ago` : "today";
					return `${lastCallRecord ? "Called" : "Navigated"} ${diffString}`;
				} else {
					return `Yet to reach out!`;
				}
			})();
			const contactPending = ["visit later", "call later"].some((e) => tags.includes(e));
			const leadDetails = interstedLeadsIds?.includes(Number(poi.id))
				? {
						status,
						visited,
						remarks,
						comment,
						tags,
						createdAt,
						updatedAt,
						lastContacted,
						contactPending,
						interested: true,
				  }
				: {
						status,
						visited,
						remarks,
						comment,
						tags,
						createdAt,
						updatedAt,
						lastContacted,
						contactPending,
						interested: false,
				  };
			const reminderDetails = {
				message: remindersDict[poi.id]?.message,
				isActive: remindersDict[poi.id]?.isActive,
				remindAt: remindersDict[poi.id]?.remindAt,
				createdAt: remindersDict[poi.id]?.createdAt,
				updatedAt: remindersDict[poi.id]?.updatedAt,
				apiKeyUserId: remindersDict[poi.id]?.apiKeyUserId,
				tokenUserId: remindersDict[poi.id]?.tokenUserId,
				id: remindersDict[poi.id]?.id,
				details: remindersDict[poi.id]
					? this.formatReminder(remindersDict[poi.id]?.remindAt.getTime())
					: undefined,
			};
			return { ...poi, leadDetails, reminderDetails };
		});
		return _.orderBy(
			leadsDTOs,
			function (date) {
				return moment(date["last_updated_at"]);
			},
			"desc",
		);
	}

	formatReminder(timestamp: number): string {
		const now = moment();
		const reminderDate = moment(timestamp);

		if (!reminderDate.isValid()) {
			return "Invalid timestamp"; // The reminder time is in the past or invalid
		}

		if (reminderDate.isSame(now, "day")) {
			return `Reminder added for today at.`;
		} else if (reminderDate.isSame(now.clone().add(1, "day"), "day")) {
			return `Reminder added for tomorrow.`;
		} else if (reminderDate.isSame(now.clone().add(2, "day"), "day")) {
			return `Reminder added for the day after tomorrow.`;
		} else {
			return `Reminder added for ${reminderDate.format("Do MMM YYYY")}`;
		}
	}

	async getLeadCounts(tokenUserId: number, apiKeyUserId: number) {
		const activeLeads = await (async () => {
			try {
				return await this.leadRepository.find({ where: { tokenUserId, apiKeyUserId } });
			} catch (error) {
				console.error(error);
				throw new HttpException(`Cannot fetch the counts!`, HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		const lostLeads = await (async () => {
			try {
				return await this.lostLeadRepository.find({ where: { tokenUserId, apiKeyUserId } });
			} catch (error) {
				console.error(error);
				throw new HttpException(`Cannot fetch the counts!`, HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		const allLeads = [...activeLeads, ...lostLeads];
		const counts = countBy(allLeads, "status");
		return counts;
	}

	async getLeadStatusHistory(poiId: number) {
		if (!poiId) throw new HttpException(`'id' missing !`, HttpStatus.BAD_REQUEST);
		const statusUpdates = await (async () => {
			try {
				return await this.leadStatusUpdatesRepository.find({ where: { poiId } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (!statusUpdates.length) throw new HttpException(`Not a lead!`, HttpStatus.BAD_REQUEST);
		const involvedtokenUserIDs = uniq(statusUpdates.map((statusUpdate) => statusUpdate.tokenUserId));
		const users = await this.teamsService.getUsers(involvedtokenUserIDs);
		const userDTOs = await this.teamsService.userToUserDTOs(users);
		const userDict = keyBy(userDTOs, "id");
		const statusUpdateDTOs = statusUpdates.map((statusUpdate) => {
			const { tokenUserId, status, comment, remarks, tags, createdAt } = statusUpdate;
			const { id, firstName, lastName, email, phoneNumber, team } = userDict[tokenUserId];
			return {
				status,
				comment,
				remarks,
				tags,
				createdAt,
				user: { id, firstName, lastName, email, phoneNumber, team },
			};
		});
		return statusUpdateDTOs;
	}

	async getTimelinewithPoi(query: TimeLineQuery, tokenUserId?: User, apiKeyUserId?: User) {
		if (!query.poiId) throw new HttpException("Please provide a poiId", HttpStatus.BAD_REQUEST);
		const leads = await this.getLeadsForUser({ poiIDs: [query.poiId] }, tokenUserId?.id, apiKeyUserId?.id);
		const requiredLead = leads.find((lead) => Number(lead.poiId) === Number(query.poiId));
		const reminders = await this.reminderService.fetchReminder({
			poiId: [query.poiId],
			userId: [apiKeyUserId?.id ?? tokenUserId?.id],
		});
		const requiredReminder = reminders.find((reminder) => Number(reminder.poiId) === Number(query.poiId));

		const pois = await this._merchantService.getPOIDetailsByIDs([Number(query.poiId)]);

		const requiredPoi = pois[0];
		const timeline = await this.getTimeline(query, tokenUserId, apiKeyUserId);

		const lastRejectedStatus = await this.getLastRejectedDetail(requiredPoi.id);
		if (lastRejectedStatus) {
			requiredLead["lastRejected"] = {
				lastContacted: lastRejectedStatus.createdAt,
				product: null,
				remarks: lastRejectedStatus.remarks,
				comment: lastRejectedStatus.comment ?? "",
			};
		}

		return {
			count: 1,
			data: [
				{
					...requiredPoi,
					leadDetails: requiredLead,
					reminderDetails: requiredReminder,
					timelineDetails: timeline,
				},
			],
		};
	}

	async getTimeline(body: TimeLineQuery, tokenUser?: User, apiKeyUser?: User) {
		if (!body.poiId) {
			throw new HttpException("Please provide poiId", HttpStatus.BAD_REQUEST);
		}

		const userObj: { id: string; firstName: string; lastName: string } = { id: "", firstName: "", lastName: "" };
		if (tokenUser) {
			userObj.id = JSON.stringify(tokenUser.id);
			(userObj.firstName = tokenUser.firstName), (userObj.lastName = tokenUser.lastName);
		}
		if (apiKeyUser) {
			userObj.id = JSON.stringify(apiKeyUser.id);
			(userObj.firstName = apiKeyUser.firstName), (userObj.lastName = apiKeyUser.lastName);
		}

		const existingPoi = await (async () => {
			try {
				return await this.poiRepository.findOne({ where: { id: Number(body.poiId) } });
			} catch (error) {
				console.error(error);
			}
		})();

		if (!existingPoi) throw new HttpException(`Invalid 'poiId'!`, HttpStatus.BAD_REQUEST);
		let finalResponse: TimeLineResponse[];
		let handleVisitResponse: TimeLineResponse[] = [];
		try {
			let kpiUpdates: TimeLineResponse[] = [];
			let kpis: Kpi[] = [];

			// KPI
			try {
				kpis = await this.kpiRepository
					.createQueryBuilder("kpi")
					.where("kpi.poiId = :poiId", { poiId: body.poiId })
					.andWhere("(kpi.tokenUserId = :userId OR kpi.apiKeyUserId = :userId)", {
						userId: Number(body.userId),
					})
					.andWhere("(kpi.action = 'Merchant Call' OR kpi.action = 'Merchant Navigate')")
					.getMany();
			} catch (err) {
				console.error(err);
				throw new HttpException("could not fetch kpis", HttpStatus.SERVICE_UNAVAILABLE);
			}

			kpiUpdates = kpis.map((kpi) => {
				const timestamp = kpi.createdAt;
				Object.keys(kpi).map((key) => {
					if (key !== "action") {
						delete kpi[key];
					}
				});
				return {
					timestamp: timestamp,
					eventType: "KPI Action",
					eventDetails: {
						...kpi,
						title: kpi.action == "Merchant Call" ? "Called" : "Navigated",
					},
				} as TimeLineResponse;
			});

			// Reminders

			let updatedReminders: TimeLineResponse[] = [];
			let reminders: Reminder[] = [];
			let reminderUpdates: ReminderUpdate[] = [];

			try {
				reminders = await this.reminderRepository
					.createQueryBuilder("reminder")
					.where("reminder.poiId = :poiId", { poiId: body.poiId })
					.andWhere("(reminder.tokenUserId = :userId OR reminder.apiKeyUserId = :userId)", {
						userId: body.userId,
					})
					.andWhere("reminder.isDeleted = false")
					.getMany();
			} catch (err) {
				console.error(err);
				throw new HttpException("Failed at loading reminders", HttpStatus.SERVICE_UNAVAILABLE);
			}

			const reminderIds = reminders.map((reminder) => reminder.id);

			if (reminderIds?.length > 0) {
				try {
					reminderUpdates = await this.reminderUpdateRepository
						.createQueryBuilder("reminder_update")
						.where("reminder_update.reminderId IN (:...reminderIds)", { reminderIds })
						.getMany();
				} catch (err) {
					console.error(err);
					throw new HttpException("Could not fetch reminder updates", HttpStatus.BAD_REQUEST);
				}
				updatedReminders = reminderUpdates.map((reminderUpdate) => {
					let oldRemindAt = null;
					const dateFilteredReminders = reminderUpdates.filter(
						(reminderUpdateObj) =>
							(reminderUpdateObj.updatedFields.includes("date") ||
								reminderUpdateObj.updatedFields.includes("reminder_created")) &&
							reminderUpdate.reminderId === reminderUpdateObj.reminderId &&
							reminderUpdateObj.createdAt < reminderUpdate.createdAt,
					);

					oldRemindAt = dateFilteredReminders[0]; // Assume the first date is the latest initially

					for (let i = 1; i < dateFilteredReminders.length; i++) {
						if (dateFilteredReminders[i].createdAt > oldRemindAt.createdAt) {
							oldRemindAt = dateFilteredReminders[i]; // Update the latestDate if a later date is found
						}
					}
					// When Reminder is created
					if (reminderUpdate.updatedFields.includes("reminder_created")) {
						return {
							timestamp: reminderUpdate.createdAt,
							eventType: "Reminder",
							eventDetails: {
								id: reminderUpdate.id,
								reminderId: reminderUpdate.reminderId,
								updatedFields: reminderUpdate.updatedFields,
								title: "Reminder added",
								message: reminderUpdate.message,
								remindAt: reminderUpdate.remindAt,
							},
						};
						// When Reminder marked as Done
					} else if (reminderUpdate.updatedFields.includes("done")) {
						return {
							timestamp: reminderUpdate.createdAt,
							eventType: "Reminder",
							eventDetails: {
								id: reminderUpdate.id,
								reminderId: reminderUpdate.reminderId,
								updatedFields: reminderUpdate.updatedFields,
								title: "Reminder marked as Done",
							},
						};
					} else if (
						reminderUpdate.updatedFields.includes("date") &&
						reminderUpdate.updatedFields.includes("message")
					) {
						return {
							timestamp: reminderUpdate.createdAt,
							eventType: "Reminder",
							eventDetails: {
								id: reminderUpdate.id,
								reminderId: reminderUpdate.reminderId,
								updatedFields: reminderUpdate.updatedFields,
								title: "Reminder updated",
								message: reminderUpdate.message,
								remindAt: reminderUpdate.remindAt,
								oldRemindAt: oldRemindAt?.remindAt || null,
							},
						};
					} else if (reminderUpdate.updatedFields.includes("date")) {
						return {
							timestamp: reminderUpdate.createdAt,
							eventType: "Reminder",
							eventDetails: {
								id: reminderUpdate.id,
								reminderId: reminderUpdate.reminderId,
								updatedFields: reminderUpdate.updatedFields,
								title: "Reminder Date updated",
								remindAt: reminderUpdate.remindAt,
								oldRemindAt: oldRemindAt?.remindAt || null,
							},
						};
					} else if (reminderUpdate.updatedFields.includes("message")) {
						return {
							timestamp: reminderUpdate.createdAt,
							eventType: "Reminder",
							eventDetails: {
								id: reminderUpdate.id,
								reminderId: reminderUpdate.reminderId,
								updatedFields: reminderUpdate.updatedFields,
								title: "Reminder Description updated",
								message: reminderUpdate.message,
							},
						};
					}
				});
			}

			// Notes

			let notes: Note[] = [];
			try {
				notes = await this.noteRepository
					.createQueryBuilder("note")
					.where("note.poiId = :poiId", { poiId: body.poiId })
					.andWhere("(note.tokenUserId = :userId OR note.apiKeyUserId = :userId)", {
						userId: body.userId,
					})
					.andWhere("note.isDeleted = false")
					.getMany();
			} catch (err) {
				console.error(err);
				throw new HttpException("Could not fetch notes", HttpStatus.BAD_REQUEST);
			}

			const updatedNotes: TimeLineResponse[] = notes.map((note) => {
				const timestamp = note.createdAt;
				Object.keys(note).map((key) => {
					if (key !== "note") {
						delete note[key];
					}
				});
				return {
					timestamp: timestamp,
					eventType: "note",
					eventDetails: {
						title: "Notes added",
						message: note.note,
					},
				};
			});

			// Leads

			let leadStatusUpdates: LeadStatusUpdates[] = [];
			let leadStatusUpdateReponse = [];

			try {
				leadStatusUpdates = await this.leadStatusUpdatesRepository
					.createQueryBuilder("lead_status_updates")
					.where("lead_status_updates.poiId = :poiId", { poiId: body.poiId })
					.andWhere(
						"(lead_status_updates.tokenUserId = :userId OR lead_status_updates.apiKeyUserId = :userId)",
						{ userId: body.userId },
					)
					.andWhere(
						new Brackets((qb) =>
							qb
								.where("lead_status_updates.visited IS NOT null")
								.orWhere("lead_status_updates.status NOT IN (:...status)", {
									status: ["reserved", "unreserved", "lost"],
								}),
						),
					)
					.getMany();
			} catch (err) {
				console.error(err);
				throw new HttpException("Cannot fetch lead status", HttpStatus.BAD_REQUEST);
			}

			leadStatusUpdateReponse = leadStatusUpdates.map((leadStatus) => {
				const timestamp = leadStatus.createdAt;
				const { status, visited, remarks, comment, tags } = leadStatus;
				const isVisitUpdate = _.isBoolean(visited);

				return {
					timestamp: timestamp,
					eventType: `Merchant ${isVisitUpdate ? "Visit" : "Status"} Updates`,
					eventDetails: {
						title: isVisitUpdate
							? "Visit Confirmed"
							: status === "rejected"
							? "Removed from In Progress"
							: `Moved to ${(status ?? "")
									.split("_")
									.map((w) => w.charAt(0).toUpperCase() + w.slice(1))
									.join(" ")}`,
						status: status ?? undefined,
						visited: isVisitUpdate ? visited : undefined,
						message: remarks?.length ? remarks : undefined,
						comment: comment?.length ? comment : undefined,
						tags: isArray(tags) ? tags : undefined,
					},
				};
			});
			finalResponse = [...leadStatusUpdateReponse, ...updatedNotes, ...updatedReminders, ...kpiUpdates].sort(
				(a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(),
			);

			// Ommit repetitive records for "Visit Confirmed" after "Navigated Event"
			finalResponse.forEach((r) => {
				const secondLastRecord = handleVisitResponse[handleVisitResponse.length - 2];
				const lastRecord = handleVisitResponse[handleVisitResponse.length - 1];
				if (
					secondLastRecord?.eventDetails?.["title"] === "Navigated" &&
					lastRecord.eventDetails["title"] === "Visit Confirmed"
				) {
					if (r.eventDetails["visited"] === false) {
						handleVisitResponse.pop();
					} else if (r.eventDetails["visited"] === true) {
						handleVisitResponse[handleVisitResponse.length - 1] = r;
					} else handleVisitResponse.push(r);
				} else {
					handleVisitResponse.push(r);
				}
			});
			handleVisitResponse = handleVisitResponse.filter((f) => f?.eventDetails?.["visited"] !== false);
		} catch (error) {
			console.error(error);
			throw new HttpException("Could not get timeline", HttpStatus.BAD_REQUEST);
		} finally {
			return _.compact(handleVisitResponse.reverse());
		}
	}

	async getLastRejectedDetail(poiId: number): Promise<LeadStatusUpdates | null> {
		const leadRejectStatus = await this.leadStatusUpdatesRepository
			.createQueryBuilder("lead_status_updates")
			.where("lead_status_updates.poiId = :poiId", { poiId })
			.andWhere("lead_status_updates.status = :status", { status: "rejected" })
			.orderBy("lead_status_updates.createdAt", "DESC")
			.limit(1)
			.getOne();

		return leadRejectStatus;
	}
}
