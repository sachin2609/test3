import { Test, TestingModule } from '@nestjs/testing';
import { TargetGridShapeController } from './target-grid-shape.controller';

describe('TargetGridShapeController', () => {
  let controller: TargetGridShapeController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TargetGridShapeController],
    }).compile();

    controller = module.get<TargetGridShapeController>(TargetGridShapeController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
