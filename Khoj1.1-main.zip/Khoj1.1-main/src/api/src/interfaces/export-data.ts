export class ExportDataBody {
	userId?: number;

    userType?: string;

    layerName: string;

    layerProp: string;

    layerUrl: string;

    location: string;

    count: number;
}