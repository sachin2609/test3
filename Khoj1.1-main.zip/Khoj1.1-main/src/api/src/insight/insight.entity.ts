import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class Insight {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column("decimal")
	latitude: number;

	@ApiProperty()
	@Column("decimal")
	longitude: number;

	@ApiProperty()
	@Column("decimal")
	population: number;

	@ApiProperty()
	@Column("decimal")
	footfall: number;

	@ApiProperty()
	@Column("decimal")
	affluenceCategory: number;

	@ApiProperty()
	@Column("decimal")
	incomeCategory: number;
}
