import { Body, Controller, Post, Headers} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { GlobalServiceService } from 'src/helpers/global-service/global-service.service';
import { GridService } from 'src/grid/grid.service';
import { Grid } from 'src/grid/grids.entity';
import { Poi } from 'src/poi/poi.entity';
import { PoiService } from 'src/poi/poi.service';
import { Property } from 'src/property/property.entity';
import { PoiShapeService } from 'src/relations/poi-shape/poi-shape.service';
import { TargetShapeService } from 'src/relations/target-shape/target-shape.service';
import { TargetService } from 'src/target/target.service';
import { Repository } from 'typeorm';

@Controller('target-grid-shape')
export class TargetGridShapeController {
    constructor(
        private _targetService: TargetService,
        private _targetShapeService: TargetShapeService,
        private _jwtService: JwtService,
		private _globalService: GlobalServiceService
	) {}

    @Post('filter')
	async filter(@Headers() header,@Body() body): Promise<unknown> {
		try {
            const user = await this._globalService.decode(header["token"]);
		    console.log(user);
			const targetShapeRes = await this._targetShapeService.filter(user["id"],body);
            const targetShapeResData = targetShapeRes["data"] as Poi[];
            const targetGridRes = await this._targetService.filter(user["id"],body);
            const targetGridResData = targetGridRes["data"] as Poi[];
			let shapeIndex = {};
			let shapeDetails = {};
            await Promise.all(targetShapeResData.map(eachPoi => {
				shapeIndex[eachPoi.id] = eachPoi["index"];
				shapeDetails[eachPoi.id] = eachPoi["internalDetails"];
			}));
			const data = targetGridResData.filter(ar => targetShapeResData.find(rm => (rm.id === ar.id) ));
			const typeCountsDict = {};
			await Promise.all(data.map(eachPoi => {
				eachPoi["shapeIndex"] = shapeIndex[eachPoi.id];
				eachPoi["shapeDetails"] = shapeDetails[eachPoi.id];
				if (typeCountsDict[eachPoi.type]) {
					typeCountsDict[eachPoi.type] += 1;
				} else {
					typeCountsDict[eachPoi.type] = 1;
				}
			}));
			const responseDict = {};
			responseDict["count"] = data.length;
			responseDict["typeCount"] = typeCountsDict;
			responseDict['data'] = data;
			return responseDict;
		} catch(error) {
			console.log(error);
			return {
				count: 0,
				data: []
			};
		}
	}
}
