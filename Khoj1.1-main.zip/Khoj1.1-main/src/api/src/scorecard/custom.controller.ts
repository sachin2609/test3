import { Body, Controller, Headers, Post } from "@nestjs/common";
import { PoiService } from "src/poi/poi.service";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { MerchantService } from "src/merchant/merchant.service";
import { RolesGuardService } from "../helpers/roles-guard/roles-guard.service";
import { ShapeService } from "src/shape/shape.service";
import { RealIP } from "nestjs-real-ip";
import { PlacesQuery } from "src/interfaces/places";

@Controller("custom")
export class CustomController {
	constructor(
		private _merchantService: MerchantService,
		private _poiService: PoiService,
		private _rolesGuardService: RolesGuardService,
		private _shapeService: ShapeService,
	) {}

	@Roles("basic")
	@Post("places")
	async places(@Body() body: PlacesQuery, @Headers() header, @RealIP() ip: string) {
		try {
			const resp = await this._merchantService.places(body, header["token"]);
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					resp["count"] - 1,
					"/custom/places",
					ip,
					JSON.stringify(body),
				);
			} else {
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp["count"] - 1,
					"/custom/places",
					ip,
					JSON.stringify(body),
				);
			}
			return resp;
		} catch (error) {
			console.log(error);
			return {
				count: 0,
				data: [],
			};
		}
	}

	@Roles("basic")
	@Post("rent")
	async rent(@Body() body: PlacesQuery, @Headers() header, @RealIP() ip: string) {
		try {
			const resp = await this._merchantService.rent(body, header["token"]);
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					resp["financial_institutions"].count - 1,
					"/custom/rent",
					ip,
					JSON.stringify(body),
				);
			} else {
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp["financial_institutions"].count - 1,
					"/custom/rent",
					ip,
					JSON.stringify(body),
				);
			}
			return resp;
		} catch (error) {
			console.log(error);
			return {
				count: 0,
				data: [],
			};
		}
	}
}
