import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { InjectRepository } from "@nestjs/typeorm";
import { User } from "src/users/users.entity";
import { Between, In, Repository } from "typeorm";
import { Kpi } from "./kpi.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Answer } from "src/answer/answer.entity";
import { Poi } from "src/poi/poi.entity";
import { KpiQuery } from "src/interfaces/monitoring";
import * as _ from "lodash";

@Injectable()
export class KpiService {
	constructor(
		@InjectRepository(User) private usersRepository: Repository<User>,
		@InjectRepository(ApiKeyUser) private apiKeyUsersRepository: Repository<ApiKeyUser>,
		@InjectRepository(Kpi) private kpiRepository: Repository<Kpi>,
		@InjectRepository(Answer) private answerRepository: Repository<Answer>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		private jwtService: JwtService,
	) {}

	async addKpi(headers, query: Kpi): Promise<Kpi> {
		if (!query.latitude || !query.longitude)
			throw new HttpException("Latitude and Longitude is required!", HttpStatus.BAD_REQUEST);
		let user;
		if (headers?.["token"]) {
			user = (await this.jwtService.decode(headers["token"])) as JSON;
			query.tokenUserId = Number(user["id"]);
		} else {
			let apiKey;
			if (headers["apikey"]) {
				apiKey = headers["apikey"];
			}
			if (headers["api-key"]) {
				apiKey = headers["api-key"];
			}
			if (headers["apiKey"]) {
				apiKey = headers["apiKey"];
			}
			user = (await this.jwtService.decode(apiKey)) as JSON;
			query.apiKeyUserId = Number(user["id"]);
		}
		return await this.kpiRepository.save(query);
	}

	async getDayWiseSummary(headers) {
		try {
			const response = {
				first_name: "",
				last_name: "",
				email: "",
				phone_number: "",
				pam_rank: 0,
				no_merchants_interracted_with: 0,
				no_merchants_contacted: 0,
				total_merchants_in_pipeline: 0,
				total_merchants_left: 0,
			};
			const thisUser = this.jwtService.decode(
				headers["token"] || headers["apikey"] || headers["apiKey"] || headers["api-key"],
			);

			if (thisUser?.["type"] == "apikey") {
				const userFromDb = await this.apiKeyUsersRepository.findOne({ where: { id: Number(thisUser["id"]) } });
				response.first_name = userFromDb.firstName;
				response.last_name = userFromDb.lastName;
				response.email = userFromDb.email;
				response.phone_number = undefined;
				const ranks: { apiKeyUserId: number; count: number; rank: number; organisationId: number }[] =
					await this.kpiRepository
						.createQueryBuilder("kpi")
						.select([`"apiKeyUserId"`, `count(*)`, 'api_key_user."organisationId"'])
						.leftJoinAndSelect("api_key_user", `api_key_user`, `api_key_user.id = kpi."apiKeyUserId"`)
						.where(`action IN ('Merchant Status Update','Like','Merchant Call','Merchant Navigate')`)
						.andWhere(`api_key_user."organisationId" = :orgId`, {
							orgId: Number(userFromDb.organisationId),
						})
						.groupBy(`"apiKeyUserId"`)
						.addGroupBy(`api_key_user."organisationId"`)
						.addGroupBy(
							`api_key_user.id,api_key_user."firstName",api_key_user."lastName",api_key_user.email`,
						)
						.addGroupBy(`api_key_user.password,api_key_user."googleAccessToken",api_key_user.roles`)
						.orderBy(`count`, "DESC")
						.getRawMany();
				ranks.forEach((e, i) => {
					e.rank = Number(i) + 1;
				});
				console.log(ranks);
				ranks.forEach((e) => {
					if (e.apiKeyUserId == userFromDb.id) {
						response.pam_rank = e.rank;
					}
				});
				const merchantsInteractedWith: { count: number } = await this.kpiRepository
					.createQueryBuilder(`kpi`)
					.select(`COUNT(DISTINCT("poiId"))`)
					.where(`action IN ('Merchant Status Update','Like','Merchant Call','Merchant Navigate')`)
					.andWhere(`"createdAt" >= current_date`)
					.andWhere(`"apiKeyUserId" = :userId`, { userId: Number(userFromDb.id) })
					.getRawOne();
				response.no_merchants_interracted_with = Number(merchantsInteractedWith.count);
				const merchantsContactedWith: { count: number } = await this.kpiRepository
					.createQueryBuilder(`kpi`)
					.select(`COUNT(DISTINCT("poiId"))`)
					.where(`action IN ('Merchant Call','Merchant Navigate')`)
					.andWhere(`"createdAt" >= current_date`)
					.andWhere(`"apiKeyUserId" = :userId`, { userId: Number(userFromDb.id) })
					.getRawOne();
				response.no_merchants_contacted = Number(merchantsContactedWith.count);

				const lastAnswers = await this.answerRepository
					.createQueryBuilder("answer")
					.distinctOn([`"uniqueId"`])
					.where(`"apiKeyUserId" = :id`, { id: Number(userFromDb.id) })
					.orderBy(`"uniqueId","createdAt"`, "DESC")
					.getMany();
				lastAnswers.forEach((ans) => {
					if (ans.answer[0] == "in_progress") {
						response.total_merchants_in_pipeline = Number(response.total_merchants_in_pipeline) + 1;
					}
				});
				const remainingMerchants: { count: number } = await this.poiRepository
					.createQueryBuilder("poi")
					.select(`COUNT(*)`)
					.where(`category = 'merchant'`)
					.andWhere(
						`id NOT IN (
                            (select distinct("uniqueId") from answer) union (select distinct("merchantId") from user_merchant) union (select distinct("merchantId") from api_key_user_merchant) 
                        )`,
					)
					.getRawOne();
				response.total_merchants_left = Number(remainingMerchants.count);
				return response;
			} else {
				const userFromDb = await this.usersRepository.findOne({ where: { id: Number(thisUser["id"]) } });
				response.first_name = userFromDb.firstName;
				response.last_name = userFromDb.lastName;
				response.email = userFromDb.email;
				response.phone_number = userFromDb.phoneNumber;
				const ranks: { tokenUserId: number; count: number; rank: number; organisationId: number }[] =
					await this.kpiRepository
						.createQueryBuilder("kpi")
						.select([`"tokenUserId"`, `count(*)`, '"user"."organisationId"'])
						.leftJoinAndSelect("user", `user`, `"user".id = kpi."tokenUserId"`)
						.where(`action IN ('Merchant Status Update','Like','Merchant Call','Merchant Navigate')`)
						.andWhere(`"user"."organisationId" = :orgId`, { orgId: Number(userFromDb.organisationId) })
						.groupBy(`"tokenUserId"`)
						.addGroupBy(
							`"user"."organisationId","user".id,"user"."firstName","user"."lastName","user".email`,
						)
						.addGroupBy(`"user"."phoneNumber","user".password`)
						.orderBy(`count`, "DESC")
						.getRawMany();
				ranks.forEach((e, i) => {
					e.rank = Number(i) + 1;
				});
				ranks.forEach((e) => {
					if (e.tokenUserId == userFromDb.id) {
						response.pam_rank = e.rank;
					}
				});
				const merchantsInteractedWith: { count: number } = await this.kpiRepository
					.createQueryBuilder(`kpi`)
					.select(`COUNT(DISTINCT("poiId"))`)
					.where(`action IN ('Merchant Status Update','Like','Merchant Call','Merchant Navigate')`)
					.andWhere(`"createdAt" >= current_date`)
					.andWhere(`"tokenUserId" = :userId`, { userId: Number(userFromDb.id) })
					.getRawOne();
				response.no_merchants_interracted_with = Number(merchantsInteractedWith.count);
				const merchantsContactedWith: { count: number } = await this.kpiRepository
					.createQueryBuilder(`kpi`)
					.select(`COUNT(DISTINCT("poiId"))`)
					.where(`action IN ('Merchant Call','Merchant Navigate')`)
					.andWhere(`"createdAt" >= current_date`)
					.andWhere(`"tokenUserId" = :userId`, { userId: Number(userFromDb.id) })
					.getRawOne();
				response.no_merchants_contacted = Number(merchantsContactedWith.count);

				const lastAnswers = await this.answerRepository
					.createQueryBuilder("answer")
					.distinctOn([`"uniqueId"`])
					//.where(`answer = 'in_progress'`)
					.orderBy(`"uniqueId","createdAt"`, "DESC")
					.where(`"tokenUserId" = :id`, { id: Number(userFromDb.id) })
					.getMany();
				lastAnswers.forEach((ans) => {
					if (ans.answer[0] == "in_progress") {
						response.total_merchants_in_pipeline = Number(response.total_merchants_in_pipeline) + 1;
					}
				});
				const remainingMerchants: { count: number } = await this.poiRepository
					.createQueryBuilder("poi")
					.select(`COUNT(*)`)
					.where(`category = 'merchant'`)
					.andWhere(
						`id NOT IN (
                            (select distinct("uniqueId") from answer) union (select distinct("merchantId") from user_merchant) union (select distinct("merchantId") from api_key_user_merchant) 
                        )`,
					)
					.getRawOne();
				response.total_merchants_left = Number(remainingMerchants.count);
				return response;
			}
		} catch (error) {
			console.log(error);
			return {};
		}
	}

	async isInProgressAndLaunched(headers) {
		try {
			let total_merchants_in_pipeline = 0;
			let app_launched_count = 0;
			const thisUser = this.jwtService.decode(
				headers["token"] || headers["apikey"] || headers["apiKey"] || headers["api-key"],
			);
			if (thisUser?.["type"] == "apikey") {
				const lastAnswers = await this.answerRepository
					.createQueryBuilder("answer")
					.distinctOn([`"uniqueId"`])
					//.where(`answer = 'in_progress'`)
					.orderBy(`"uniqueId","createdAt"`, "DESC")
					.where(`"apiKeyUserId" = :id`, { id: Number(thisUser?.["id"]) })
					.getMany();
				lastAnswers.forEach((ans) => {
					if (ans.answer[0] == "in_progress") {
						total_merchants_in_pipeline = Number(total_merchants_in_pipeline) + 1;
					}
				});
				const applaunchedcount: { count: number } = await this.kpiRepository
					.createQueryBuilder("kpi")
					.select(`COUNT(*)`)
					.where(`action = 'App Launched'`)
					.andWhere(`"createdAt" >= current_date`)
					.andWhere(`"apiKeyUserId" = :userId`, { userId: Number(thisUser["id"]) })
					.getRawOne();
				app_launched_count = Number(applaunchedcount.count);
				if (total_merchants_in_pipeline && app_launched_count) {
					return true;
				} else {
					return false;
				}
			} else {
				const lastAnswers = await this.answerRepository
					.createQueryBuilder("answer")
					.distinctOn([`"uniqueId"`])
					//.where(`answer = 'in_progress'`)
					.orderBy(`"uniqueId","createdAt"`, "DESC")
					.where(`"tokenUserId" = :id`, { id: Number(thisUser?.["id"]) })
					.getMany();
				lastAnswers.forEach((ans) => {
					if (ans.answer[0] == "in_progress") {
						total_merchants_in_pipeline = Number(total_merchants_in_pipeline) + 1;
					}
				});
				console.log(total_merchants_in_pipeline);
				const applaunchedcount: { count: number } = await this.kpiRepository
					.createQueryBuilder("kpi")
					.select(`COUNT(*)`)
					.where(`action = 'App Launched'`)
					.andWhere(`"createdAt" >= current_date`)
					.andWhere(`"tokenUserId" = :userId`, { userId: Number(thisUser["id"]) })
					.getRawOne();
				app_launched_count = Number(applaunchedcount.count);
				console.log(app_launched_count);
				if (total_merchants_in_pipeline && app_launched_count == 1) {
					return true;
				} else {
					return false;
				}
			}
		} catch (error) {
			console.log(error);
			return;
		}
	}

	async fetchActions(query: KpiQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.actions) throw new HttpException(`'actions' missing!`, HttpStatus.BAD_REQUEST);
		if (!query?.userIds?.length) query.userIds = user?.["type"] == "token" ? [Number(user.id)] : [];
		const kpiQueryRes = await (async () => {
			try {
				const dbQuery = {
					tokenUserId: In(query.userIds),
					action: In(query.actions),
					// startTime and endTime are optional fields
				};

				if (query.startTime && query.endTime) {
					dbQuery["createdAt"] = Between(query.startTime, query.endTime);
				} else if (query.startTime) {
					dbQuery["createdAt"] = Between(query.startTime, new Date());
				} else if (query.endTime) {
					dbQuery["createdAt"] = Between(new Date(0), query.endTime);
				}

				const kpis = await this.kpiRepository.find({ where: dbQuery });
				return _.groupBy(kpis, "tokenUserId");
			} catch (error) {
				console.error(error);
			}
		})();
		const response = [];
		try {
			Object.keys(kpiQueryRes).forEach((uid) => {
				const tempObj = { userId: Number(uid), data: {} };
				tempObj.data = _.groupBy(kpiQueryRes[uid], "action");
				response.push(tempObj);
			});
		} catch (error) {
			console.error(error);
		}
		return response;
	}
}
