import { HttpException, HttpStatus, Inject, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Org } from "src/interfaces/organisation";
import { Organisation } from "src/organisations/organisations.entity";
import { User } from "src/users/users.entity";
import { Repository } from "typeorm";
import { AuthRequest } from "../interfaces/auth";
import * as bcrypt from "bcrypt";
import { MailerService } from "@nestjs-modules/mailer";
import { JwtService } from "@nestjs/jwt";
import { UserHistory } from "src/user-history/user-history.entity";
import { UserHistoryClass } from "src/interfaces/userHistory";
import { UserCredits } from "../user-history/user-credits.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyIp } from "./apiKey-ip.entity";
import { getRegistrationEmailTemplate } from "src/helpers/email-templates/registration-email-template";
import { TeamService } from "src/team/team.service";
import { UsersQuery } from "src/interfaces/users";
import { ApiKeyUsersService } from "src/api-key-users/api-key-users.service";
import * as moment from "moment";
import { CACHE_MANAGER } from "@nestjs/cache-manager";
import { Cache } from "cache-manager";

@Injectable()
export class AuthService {
	constructor(
		@InjectRepository(User) private userRepository: Repository<User>,
		@InjectRepository(Organisation) private organisationRepository: Repository<Organisation>,
		@InjectRepository(UserHistory) private userHistoryRepository: Repository<UserHistory>,
		@InjectRepository(UserCredits) private userCreditsRepository: Repository<UserCredits>,
		@InjectRepository(ApiKeyUser) private apiKeyUserRepository: Repository<ApiKeyUser>,
		@InjectRepository(ApiKeyOrganisation) private apiKeyOrganisationRepository: Repository<ApiKeyOrganisation>,
		@InjectRepository(ApiKeyUserCredits) private apiKeyUserCreditsRepository: Repository<ApiKeyUserCredits>,
		@InjectRepository(ApiKeyIp) private apiKeyIpRepository: Repository<ApiKeyIp>,
		@Inject(CACHE_MANAGER) private cacheManager: Cache,
		private readonly mailerService: MailerService,
		private readonly jwtService: JwtService,
		private teamService: TeamService,
		private apiKeyUserService: ApiKeyUsersService,
	) {}

	googleLogin(req: JSON): AuthRequest {
		if (!req["user"]) {
			return {
				email: null,
				firstName: null,
				lastName: null,
				picture: null,
				id: null,
				team: null,
				roles: null,
				googleAccessToken: null,
			};
		}
		const user = req["user"] as AuthRequest;
		return user;
	}

	async updateOrganisation(user: User) {
		//const email = user.email;
		// remove autospliting username with domain as organisation
		//var domain = email.substring(email.lastIndexOf("@") +1);
		//console.log(domain);
		//const org = domain.split('.', 1)[0];

		// adding each user belonging to organisation of their own initially with email as organisation
		if (user.email) {
			const org = user.email;
			console.log("Organisation found :", org);
			const organisationInDb = await this.organisationRepository.findOne({ where: { id: user.organisationId } });
			const userCreds = await this.userCreditsRepository.findOne({ where: { userId: user.id } });
			if (!userCreds) {
				const credsObject = new UserCredits();
				credsObject.userId = user.id;
				credsObject.creditsUsed = 0;
				await this.userCreditsRepository.save(credsObject);
			}
			if (organisationInDb) {
				console.log("Organisation already exist :", organisationInDb);
				user.organisationId = organisationInDb.id;
				await this.userRepository.save(user);
			} else {
				console.log("Creating new Organisation :", org);
				const tempOrg: Org = {
					organisation: org,
					googleClientId: "",
					googleClientSecret: "",
					awsS3BucketName: "",
					awsAccessKeyId: "",
					awsSecretAccessKey: "",
					credits: 1000,
				};
				await this.organisationRepository.save(tempOrg);
				const newOrganisation = await this.organisationRepository.findOne({ where: { organisation: org } });
				console.log("Organisation Created :", newOrganisation);
				user.organisationId = newOrganisation.id;
				await this.userRepository.save(user);
			}
		} else {
			const org = user.phoneNumber;
			console.log("Organisation found :", org);
			const organisationInDb = await this.organisationRepository.findOne({ where: { id: user.organisationId } });
			const userCreds = await this.userCreditsRepository.findOne({ where: { userId: user.id } });
			if (!userCreds) {
				const credsObject = new UserCredits();
				credsObject.userId = user.id;
				credsObject.creditsUsed = 0;
				await this.userCreditsRepository.save(credsObject);
			}
			if (organisationInDb) {
				console.log("Organisation already exist :", organisationInDb);
				user.organisationId = organisationInDb.id;
				await this.userRepository.save(user);
			} else {
				console.log("Creating new Organisation :", org);
				const tempOrg: Org = {
					organisation: org,
					googleClientId: "",
					googleClientSecret: "",
					awsS3BucketName: "",
					awsAccessKeyId: "",
					awsSecretAccessKey: "",
					credits: 1000,
				};
				await this.organisationRepository.save(tempOrg);
				const newOrganisation = await this.organisationRepository.findOne({ where: { organisation: org } });
				console.log("Organisation Created :", newOrganisation);
				user.organisationId = newOrganisation.id;
				await this.userRepository.save(user);
			}
		}
	}

	async updateApiKeyOrganisation(user: ApiKeyUser) {
		// remove autospliting username with domain as organisation
		//var domain = email.substring(email.lastIndexOf("@") +1);
		//console.log(domain);
		//const org = domain.split('.', 1)[0];

		// adding each user belonging to organisation of their own initially with email as organisation
		const org = user.email;
		console.log("Organisation found :", org);
		const organisationInDb = await this.apiKeyOrganisationRepository.findOne({
			where: { id: user.organisationId },
		});
		const userCreds = await this.apiKeyUserCreditsRepository.findOne({ where: { userId: user.id } });
		if (!userCreds) {
			const credsObject = new UserCredits();
			credsObject.userId = user.id;
			credsObject.creditsUsed = 0;
			await this.apiKeyUserCreditsRepository.save(credsObject);
		}
		if (organisationInDb) {
			console.log("Organisation already exist :", organisationInDb);
			user.organisationId = organisationInDb.id;
			await this.apiKeyUserRepository.save(user);
		} else {
			console.log("Creating new Organisation :", org);
			const tempOrg: Org = {
				organisation: org,
				googleClientId: "",
				googleClientSecret: "",
				awsS3BucketName: "",
				awsAccessKeyId: "",
				awsSecretAccessKey: "",
				credits: 1000,
			};
			await this.apiKeyOrganisationRepository.save(tempOrg);
			const newOrganisation = await this.apiKeyOrganisationRepository.findOne({ where: { organisation: org } });
			console.log("Organisation Created :", newOrganisation);
			user.organisationId = newOrganisation.id;
			await this.apiKeyUserRepository.save(user);
		}
	}

	async getApiKeyUserRegistrationEmailNew(user: ApiKeyUser) {
		const tempUser = {};
		tempUser["id"] = user.id;
		tempUser["firstName"] = user.firstName;
		tempUser["lastName"] = user.lastName;
		tempUser["email"] = user.email;
		tempUser["roles"] = user.roles;
		const time = new Date().getTime();
		console.log("Created Time: ", time);
		tempUser["createdTime"] = time;
		const token = this.jwtService.sign(tempUser);
		console.log("Email Verification token is :", token);
		const url = process.env.FRONTEND_LOGIN_URL + "/api/auth/verifyNew?token=" + token;
		const htmlForUser = getRegistrationEmailTemplate(user.firstName, user.lastName, "DS API");
		await this.mailerService
			.sendMail({
				to: user.email, // list of receivers
				from: process.env.MAILDEV_INCOMING_USER, // sender address
				subject: "Datasutram API Console | Registration", // Subject line
				text: "Verify :", // plaintext body
				html: htmlForUser, // HTML body content
			})
			.then(() => {
				console.log("Email Sent!");
			})
			.catch((err) => {
				console.log("Error in sending mail", err);
			});
		const html = `
		Hey!
		<br />
		Platform : ${process.env.FRONTEND_LOGIN_URL}
		<br />
		First Name : ${user.firstName}
		<br />
		Last Name : ${user.lastName}
		<br />
		Email : ${user.email}
		<br />
		To verify his/her email, <a href="${url}">click here</a>
		<br />
		Thanks,
		The DataSutram Team
		`;
		await this.mailerService
			.sendMail({
				to: process.env.LIST_OF_RECEIVERS_FOR_AUTH, // list of receivers
				from: process.env.MAILDEV_INCOMING_USER, // sender address
				subject: "Email Verification", // Subject line
				text: "Verify :", // plaintext body
				html: html, // HTML body content
			})
			.then(() => {
				console.log("Email Sent!");
			})
			.catch((err) => {
				console.log("Error in sending mail", err);
			});
	}

	async ping(token: string) {
		if (!token) throw new HttpException("Token not found", HttpStatus.UNAUTHORIZED);
		const user = await this.teamService.decodeUserJWT(token);
		if (user) {
			const loginTime = new Date().toISOString();
			const userHistoryObj: UserHistoryClass = {
				userId: user.id,
				loginTime: loginTime,
			};
			try {
				await this.userHistoryRepository.save(userHistoryObj);
				console.log("Ping...");
			} catch (err) {
				throw new HttpException("Cannot Add Ping Record!", HttpStatus.SERVICE_UNAVAILABLE);
			}
		}
	}

	async generateApiKey(body) {
		const user = await this.apiKeyUserRepository.findOne({ where: { email: body["email"] } });
		if (user == undefined) {
			throw new HttpException("Email not registered", HttpStatus.FORBIDDEN);
		}
		if (user.status == false || user.status == null) {
			throw new HttpException("Email not Verified", HttpStatus.FORBIDDEN);
		}
		if (user.password) {
			const password = user.password;
			const isMatch = await bcrypt.compare(body["password"], password);
			if (isMatch) {
				return user;
			} else {
				throw new HttpException("Incorrect Password or Username", HttpStatus.FORBIDDEN);
			}
		} else {
			return user;
		}
	}

	async signUpNewApiKeyUser(body) {
		console.log(body);
		const email = body["email"];
		const oldUser = await this.apiKeyUserRepository.findOne({ where: { email: email } });
		//console.log("OldUser: ",oldUser);
		if (oldUser) {
			throw new HttpException("Email already registered", HttpStatus.FORBIDDEN);
		} else {
			console.log("New User Found");
		}
		const tempUser = {};
		tempUser["email"] = body["email"];
		tempUser["firstName"] = body["firstname"];
		tempUser["lastName"] = body["lastname"];
		const password = body["password"];
		const saltOrRounds = 10;
		const hash = await bcrypt.hash(password, saltOrRounds);
		tempUser["password"] = hash;
		if (body["roles"]) {
			tempUser["roles"] = body["roles"];
		} else {
			tempUser["roles"] = ["admin"];
		}
		tempUser["organisationId"] = 0;
		const user = await this.apiKeyUserRepository.save(tempUser);
		console.log("New user Added :", user);
		await this.updateApiKeyOrganisation(user);
		await this.getApiKeyUserRegistrationEmailNew(user);
		return await this.apiKeyUserRepository.findOne({ where: { id: user.id } });
	}

	async updateApiKeyIp(token, ip) {
		const apiKeyIp = await this.apiKeyIpRepository.findOne({ where: { apiKey: token } });
		if (apiKeyIp == undefined) {
			const apiKeyIP: ApiKeyIp = { apiKey: token, ip: ip };
			await this.apiKeyIpRepository.save(apiKeyIP);
		} else {
			if (apiKeyIp.ip != ip) {
				await this.apiKeyIpRepository.delete(apiKeyIp);
				throw new HttpException("New device found.Try login again", HttpStatus.FORBIDDEN);
			}
		}
	}

	async getAppVersion(headers) {
		const token = headers["token"] || headers["api-key"] || headers["apiKey"] || headers["apikey"];
		const decodedUser = this.jwtService.decode(token);
		let organisation: Organisation | ApiKeyOrganisation;
		if (decodedUser["type"] == "token") {
			const userFromDb = await this.userRepository.findOne({ where: { id: Number(decodedUser["id"]) } });
			organisation = await this.organisationRepository.findOne({
				where: { id: Number(userFromDb.organisationId) },
			});
		}
		if (decodedUser["type"] == "apikey") {
			const userFromDb = await this.apiKeyUserRepository.findOne({ where: { id: Number(decodedUser["id"]) } });
			organisation = await this.apiKeyOrganisationRepository.findOne({
				where: { id: Number(userFromDb.organisationId) },
			});
		}
		return {
			latestVersionCode: organisation.latestVersionCode,
			latestVersionName: organisation.latestVersionName,
			forceUpdate: organisation.forceUpdate,
		};
	}

	async generateUserJWT(user: Partial<User>): Promise<string> {
		const { googleAccessToken, password, createdAt, updatedAt, createdBy, updatedBy, ...tempUser } = user;
		Object.assign(tempUser, {
			type: "token",
		});
		const token = await this.jwtService.signAsync(tempUser, {
			expiresIn: parseInt(process.env.JWT_EXPIRY),
		});
		return token;
	}

	async decodeApiKeyUsers(query: JSON): Promise<JSON> {
		try {
			let apiKey;
			if (query["apikey"]) {
				apiKey = query["apikey"];
			}
			if (query["api-key"]) {
				apiKey = query["api-key"];
			}
			if (query["apiKey"]) {
				apiKey = query["apiKey"];
			}
			const apiKeyUser = (await this.jwtService.decode(apiKey)) as JSON;
			console.log("user found", apiKeyUser);
			const tempQuery = { id: Number(apiKeyUser["id"]) } as UsersQuery;
			const dbUser = await this.apiKeyUserService.queryUsers(tempQuery);
			console.log(dbUser[0]);
			if (dbUser[0]) {
				apiKeyUser["roles"] = dbUser[0].roles;
			} else {
				throw new HttpException("Not Authorized", HttpStatus.UNAUTHORIZED);
			}
			console.log("user inside decode token", apiKeyUser);
			console.log("moment is", moment().format("X"));
			console.log("moment is", moment().toISOString());
			return apiKeyUser;
		} catch (err) {
			console.log(err);
			throw new HttpException("ApiKey Invalid", HttpStatus.UNAUTHORIZED);
		}
	}

	async blacklistToken(token: string): Promise<void> {
		try {
			await this.jwtService.verifyAsync(token);
		} catch (err) {
			console.error(err);
			throw new HttpException("Token Invalid!", HttpStatus.UNAUTHORIZED);
		}
		const decoded = this.jwtService.decode(token);
		const ttl = Math.round(decoded["exp"] - Date.now() / 1000);
		await this.cacheManager.set(token, true, { ttl });
	}
}
