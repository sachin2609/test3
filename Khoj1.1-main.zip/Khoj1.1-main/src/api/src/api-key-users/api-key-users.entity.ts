import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class ApiKeyUser {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	firstName: string;

	@ApiProperty()
	@Column()
	lastName: string;

	@ApiProperty()
	@Column()
	email: string;

	@ApiProperty()
	@Column({
		type: "varchar",
		array: true
	})
	roles: string[];

	@ApiProperty()
	@Column({nullable: true})
	googleAccessToken: string;

	@ApiProperty()
	@Column({nullable:true})
	organisationId: number;

	@ApiProperty()
	@Column({ default: false })
	status: boolean;

	@ApiProperty()
	@Column({ nullable: true })
	password: string;
}
