import { Test, TestingModule } from '@nestjs/testing';
import { TargetShapeService } from './target-shape.service';

describe('TargetShapeService', () => {
  let service: TargetShapeService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [TargetShapeService],
    }).compile();

    service = module.get<TargetShapeService>(TargetShapeService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
