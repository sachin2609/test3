import { Entity, Column, PrimaryGeneratedColumn, OneToMany, JoinColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
import { TargetDetail } from "src/target-details/target-details.entity";

export enum PoiStatus {
	pending = "pending",
	approved = "approved",
	rejected = "rejected"
}

@Entity()
export class Poi {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	name: string;

	@ApiProperty()
	@Column({ nullable: true })
	address: string;

	@ApiProperty()
	@Column()
	category: string;

	@ApiProperty()
	@Column()
	type: string;

	@ApiProperty()
	@Column({ nullable: true })
	subType: string;

	@ApiProperty()
	@Column("decimal", { nullable: true })
	votes: number;

	@ApiProperty()
	@Column("decimal", { nullable: true })
	rating: number;

	@ApiProperty()
	@Column("decimal")
	latitude: number;

	@ApiProperty()
	@Column("decimal")
	longitude: number;

	@ApiProperty()
	@Column({ default: 0 })
	createdBy: number;

	@ApiProperty()
	@Column({ default: "datasutram" })
	dataType: string;

	@ApiProperty()
	@Column({ default: PoiStatus.approved })
	status: PoiStatus;

	@ApiProperty()
	@OneToMany(
		() => TargetDetail,
		targetDetail => targetDetail.poi,
		{ cascade: true }
	)
	@JoinColumn()
	targetDetail: TargetDetail[];

	@ApiProperty()
	@Column({default: false})
	indexStatus: boolean
}
