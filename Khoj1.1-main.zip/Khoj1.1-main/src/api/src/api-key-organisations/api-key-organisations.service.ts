import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Operation, Org, UpdateCreditsBody } from "src/interfaces/organisation";
import { In, Repository } from "typeorm";
import { ApiKeyOrganisation } from "./api-key-organisations.entity";
import * as bcrypt from "bcrypt";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { OrganisationType, UpdateCreditsLogs } from "src/update-credits-logs/update-credits-logs.entity";
import { JwtService } from "@nestjs/jwt";

export interface OrgWithCreditsSpent extends ApiKeyOrganisation {
	creditsUsed: number;
}

@Injectable()
export class ApiKeyOrganisationsService {
	constructor(
		@InjectRepository(ApiKeyOrganisation) private apiKeyOrganisationsRepository: Repository<ApiKeyOrganisation>,
		@InjectRepository(ApiKeyUser) private apiKeyUserRepository: Repository<ApiKeyUser>,
		@InjectRepository(ApiKeyUserCredits) private apiKeyUserCreditsRepository: Repository<ApiKeyUserCredits>,
		@InjectRepository(ApiKeyUserApiUsageHistory)
		private apiKeyUserApiUsageHistoryRepository: Repository<ApiKeyUserApiUsageHistory>,
		@InjectRepository(UpdateCreditsLogs) private updateCreditsLogsRepository: Repository<UpdateCreditsLogs>,
		private _jwtService: JwtService,
	) {}

	throwHttpsError(error?: string) {
		throw new HttpException(
			{
				status: HttpStatus.BAD_REQUEST,
				error: "BAD REQUEST" + (error ? " : " + error : ""),
			},
			HttpStatus.BAD_REQUEST,
		);
	}

	async findOrgAgainstUser(email: string, id: number) {
		const user = await this.apiKeyUserRepository.findOne({ where: { email: email, id: id } });
		if (user) {
			console.log("organisationid", user["organisationId"]);
			const organisation = await this.apiKeyOrganisationsRepository.findOne({
				where: { id: user["organisationId"] },
			});
			console.log("organisation is", organisation);
			return organisation;
		} else {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: "No Such User Found",
				},
				HttpStatus.BAD_REQUEST,
			);
		}
	}

	async getOrgs(userId: number, roles: string[]): Promise<OrgWithCreditsSpent[]> {
		if (roles.includes("admin")) {
			const [orgs, userCredits, users] = await Promise.all([
				this.apiKeyOrganisationsRepository.find(),
				this.apiKeyUserCreditsRepository.find(),
				this.apiKeyUserRepository.find(),
			]);
			const theOrgs = orgs.map((o) => {
				const userIds = users.filter((u) => u.organisationId === o.id).map((u) => u.id);
				console.log(o.organisation, userIds);
				const credits =
					userIds?.length && userCredits?.length
						? userCredits
								.filter((c) => userIds.includes(c.userId))
								.map((c) => c.creditsUsed)
								.reduce((a, b) => a + b, 0)
						: 0;
				return {
					...o,
					creditsUsed: credits,
				};
			});
			return theOrgs;
		} else {
			const user = await this.apiKeyUserRepository.findOne({ where: { id: userId } });
			const organisation = await this.apiKeyOrganisationsRepository.findOne({
				where: { id: user.organisationId },
			});
			const userCredits = await this.apiKeyUserCreditsRepository.find({ where: { userId: user.id } });
			let creditsUsed = 0;
			userCredits.forEach((eachUserCredit) => {
				creditsUsed = creditsUsed + eachUserCredit.creditsUsed;
			});
			return [
				{
					...organisation,
					creditsUsed: creditsUsed,
				},
			];
		}
	}

	async addOrgs(body: Org[]): Promise<ApiKeyOrganisation[]> {
		let orgs = [];
		orgs = body
			.filter((o) => o?.organisation?.length)
			.map((o) => {
				return {
					organisation: o.organisation,
					credits: o?.credits ?? 0,
					awsAccessKeyId: o?.awsAccessKeyId ?? "",
					awsS3BucketName: o?.awsS3BucketName ?? "",
					awsSecretAccessKey: o?.awsSecretAccessKey ?? "",
					googleClientId: o?.googleClientId ?? "",
					googleClientSecret: o?.googleClientSecret ?? "",
				};
			});
		orgs.forEach(async (org) => {
			await this.apiKeyOrganisationsRepository.save(org);
		});
		return orgs;
	}

	async updateOrg(body: ApiKeyOrganisation): Promise<ApiKeyOrganisation> {
		const org = {};
		Object.keys(body).forEach((b) => (org[b] = body[b]));
		try {
			await this.apiKeyOrganisationsRepository.update({ id: body.id }, org);
		} catch (error) {
			this.throwHttpsError(error);
		}
		const updatedOrg = await this.apiKeyOrganisationsRepository.findOne({ where: { id: body.id } });
		if (updatedOrg) return updatedOrg;
		else this.throwHttpsError("No Organisation Found!");
	}

	async deleteOrg(id: number) {
		const users = await this.apiKeyUserRepository.find({ where: { organisationId: id } });
		if (users?.length) {
			this.throwHttpsError("Organisation has Users!");
		} else {
			const delResp = await this.apiKeyOrganisationsRepository.delete({ id: id });
			return delResp?.affected
				? { response: "Organisaiton Deleted" }
				: this.throwHttpsError("No Organisation Found!");
		}
	}

	async updateUser(body: ApiKeyUser): Promise<ApiKeyUser> {
		const user = {};
		Object.keys(body).forEach((b) => (user[b] = body[b]));
		try {
			await this.apiKeyUserRepository.update({ id: body.id }, user);
		} catch (error) {
			this.throwHttpsError(error);
		}
		const updatedUser = await this.apiKeyUserRepository.findOne({ where: { id: body.id } });
		if (updatedUser) return updatedUser;
		else this.throwHttpsError("No User Found!");
	}

	async addUsers(body: ApiKeyUser[]) {
		let users = [];
		users = body
			.filter((u) => u?.email?.length)
			.map((u) => {
				return {
					firstName: u?.firstName ?? "",
					lastName: u?.lastName ?? "",
					email: u.email,
					roles: u?.roles ?? ["basic"],
					googleAccessToken: u?.googleAccessToken ?? "",
					organisationId: u?.organisationId ?? null,
					status: u?.status ?? false,
					password: u?.password ?? this.throwHttpsError("Password Must be given"),
				};
			});
		for (const u of users) {
			const duplicateUser = await this.apiKeyUserRepository.findOne({ where: { email: u.email } });
			if (duplicateUser) {
				this.throwHttpsError("Duplicate Email cannot be used!");
			} else {
				try {
					const saltOrRounds = 10;
					const hash = await bcrypt.hash(u.password, saltOrRounds);
					u.password = hash;
					await this.apiKeyUserRepository.save(u);
				} catch (error) {
					this.throwHttpsError(error);
				}
			}
		}
		return users;
	}

	async deleteUser(id: number) {
		const delResp = await this.apiKeyUserRepository.delete({ id: id });
		return delResp?.affected ? { response: "User Deleted" } : this.throwHttpsError("No User Found!");
	}

	async getUsersAginstOrganisation(query): Promise<ApiKeyUser[]> {
		const users = await this.apiKeyUserRepository.find({
			where: {
				organisationId: query["organisationId"],
				status: true,
			},
		});
		const userIds: number[] = users.map((u) => u.id);
		const userCredits = await this.apiKeyUserCreditsRepository.find({
			where: {
				userId: In(userIds),
			},
		});
		const userCreditsDict = {};
		userCredits.forEach((eachCreditsObject) => {
			userCreditsDict[eachCreditsObject.userId] = eachCreditsObject.creditsUsed;
		});
		users.forEach((eachUser) => {
			delete eachUser.googleAccessToken;
			delete eachUser.roles;
			delete eachUser.status;
			delete eachUser.password;
			eachUser["creditsUsed"] = userCreditsDict?.[eachUser.id] ?? 0;
		});
		console.log("users found", users);
		return users;
	}

	async getAllUsers(userId: number, roles: string[], allStatus?: boolean): Promise<ApiKeyUser[]> {
		if (roles.includes("admin") || true) {
			const users = allStatus
				? await this.apiKeyUserRepository.find()
				: await this.apiKeyUserRepository.find({
						where: {
							status: true,
						},
				  });
			const userCredits = await this.apiKeyUserCreditsRepository.find();
			const userCreditsDict = {};
			userCredits.forEach((eachCreditsObject) => {
				userCreditsDict[eachCreditsObject.userId] = eachCreditsObject.creditsUsed;
			});
			const userApiUsageHistories = await this.apiKeyUserApiUsageHistoryRepository.find();
			const userApiUsageHistoryDict = {};
			userApiUsageHistories.forEach((eachUserApiUsageHistory: ApiKeyUserApiUsageHistory) => {
				if (userApiUsageHistoryDict[eachUserApiUsageHistory.userId] == undefined) {
					userApiUsageHistoryDict[eachUserApiUsageHistory.userId] = 1;
				} else {
					userApiUsageHistoryDict[eachUserApiUsageHistory.userId] =
						Number(userApiUsageHistoryDict[eachUserApiUsageHistory.userId]) + 1;
				}
			});
			users.forEach((eachUser) => {
				delete eachUser.googleAccessToken;
				delete eachUser.password;
				eachUser["creditsUsed"] = userCreditsDict?.[eachUser.id] ?? 0;
				eachUser["noOfRequest"] = userApiUsageHistoryDict?.[eachUser.id] ?? 0;
			});
			console.log(allStatus ? "all status " : "", "users", users.length);
			return users;
		} else {
			const user = await this.apiKeyUserRepository.findOne({ where: { id: userId } });
			const users = allStatus
				? await this.apiKeyUserRepository.find({ where: { organisationId: user.organisationId } })
				: await this.apiKeyUserRepository.find({
						where: { organisationId: user.organisationId, status: true },
				  });
			const userCredits = await this.apiKeyUserCreditsRepository.find();
			const userCreditsDict = {};
			userCredits.forEach((eachCreditsObject) => {
				userCreditsDict[eachCreditsObject.userId] = eachCreditsObject.creditsUsed;
			});
			const userApiUsageHistories = await this.apiKeyUserApiUsageHistoryRepository.find();
			const userApiUsageHistoryDict = {};
			userApiUsageHistories.forEach((eachUserApiUsageHistory: ApiKeyUserApiUsageHistory) => {
				if (userApiUsageHistoryDict[eachUserApiUsageHistory.userId] == undefined) {
					userApiUsageHistoryDict[eachUserApiUsageHistory.userId] = 1;
				} else {
					userApiUsageHistoryDict[eachUserApiUsageHistory.userId] =
						Number(userApiUsageHistoryDict[eachUserApiUsageHistory.userId]) + 1;
				}
			});
			users.forEach((eachUser) => {
				delete eachUser.googleAccessToken;
				delete eachUser.password;
				eachUser["creditsUsed"] = userCreditsDict?.[eachUser.id] ?? 0;
				eachUser["noOfRequest"] = userApiUsageHistoryDict?.[eachUser.id] ?? 0;
			});
			console.log(allStatus ? "all status " : "", "users", users.length);
			return users;
		}
	}

	async updateCredits(query: UpdateCreditsBody, headers) {
		if (query.credits == undefined || query.organisationId == undefined) {
			throw new HttpException(`orgainsation id and credits must be defined`, HttpStatus.BAD_REQUEST);
		}
		const org = await this.apiKeyOrganisationsRepository.findOne({ where: { id: query.organisationId } });
		if (org == undefined) {
			throw new HttpException(`Invalid organisation id : ${query.organisationId} `, HttpStatus.BAD_REQUEST);
		}
		const oldCredits = Number(org.credits);
		if (query.operation == undefined || query.operation == Operation.set) {
			org.credits = Number(query.credits);
		}
		if (query.operation == Operation.add) {
			org.credits = Number(query.credits) + Number(org.credits);
		}
		if (query.operation == Operation.deduct) {
			org.credits =
				Number(org.credits) - Number(query.credits) < 0 ? 0 : Number(org.credits) - Number(query.credits);
		}
		const token = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = this._jwtService.decode(token);
		const tempObj: UpdateCreditsLogs = {
			id: undefined,
			organisationId: Number(query.organisationId),
			organisationType: OrganisationType.token,
			oldCredits: oldCredits,
			credits: Number(query.credits),
			operation: query.operation == undefined ? Operation.set : query.operation,
			userId: Number(user["id"]),
			userType: user["type"],
			createdAt: undefined,
		};
		await this.updateCreditsLogsRepository.save(tempObj);
		return await this.apiKeyOrganisationsRepository.save(org);
	}
}
