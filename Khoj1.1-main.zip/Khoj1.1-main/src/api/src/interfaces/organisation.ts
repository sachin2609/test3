import { ApiProperty } from "@nestjs/swagger";

export class Org {
	@ApiProperty()
	organisation: string;

	@ApiProperty()
	googleClientId: string;

	@ApiProperty()
	googleClientSecret: string;

	@ApiProperty()
	awsS3BucketName: string;

	@ApiProperty()
	awsAccessKeyId: string;

	@ApiProperty()
	awsSecretAccessKey: string;

	@ApiProperty()
	credits: number;
}

export class UpdateCreditsRequest {
	credits: number;
	user_token: string;
	user_apikey: string;
}

export class UpdateCreditsBody {
	credits: number;
	organisationId: number;
	operation?: Operation;
}

export enum Operation {
	add = "add",
	set = "set",
	deduct = "deduct",
}
