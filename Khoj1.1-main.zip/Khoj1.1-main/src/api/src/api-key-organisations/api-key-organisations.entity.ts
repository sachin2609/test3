import { ApiProperty } from "@nestjs/swagger";
import { Entity, Column, PrimaryGeneratedColumn, PrimaryColumn } from "typeorm";

@Entity()
export class ApiKeyOrganisation {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@PrimaryColumn()
	organisation: string;

	@ApiProperty()
	@Column()
	googleClientId: string;

	@ApiProperty()
	@Column()
	googleClientSecret: string;

	@ApiProperty()
	@Column()
	awsS3BucketName: string;

	@ApiProperty()
	@Column()
	awsAccessKeyId: string;

	@ApiProperty()
	@Column()
	awsSecretAccessKey: string;

	@Column("decimal", { default: 0 })
	credits: number;

	@Column({ nullable: true, type: "decimal" })
	latestVersionCode?: number;

	@Column({ nullable: true })
	latestVersionName?: string;

	@Column({ nullable: true, type: "boolean" })
	forceUpdate?: boolean;
}
