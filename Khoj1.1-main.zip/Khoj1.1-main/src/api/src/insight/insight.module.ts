import { Module } from "@nestjs/common";
import { CacheModule } from "@nestjs/cache-manager";
import { InsightController } from "./insight.controller";
import { InsightService } from "./insight.service";
import { Insight } from "./insight.entity";
import { TypeOrmModule } from "@nestjs/typeorm";
import { TargetDetail } from "../target-details/target-details.entity";
import { PoiDetail } from "../poi-details/poi-details.entity";
import { Indexmaster } from "../index-master/index-master.entity";
import * as redisStore from "cache-manager-redis-store";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
@Module({
	imports: [
		TypeOrmModule.forFeature([Insight, PoiDetail, TargetDetail, Indexmaster, Shapeindex, ShapeDetail]),
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
	],
	controllers: [InsightController],
	providers: [InsightService],
})
export class InsightModule {}
