import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Answer } from "src/answer/answer.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Organisation } from "src/organisations/organisations.entity";
import { Poi } from "src/poi/poi.entity";
import { User } from "src/users/users.entity";
import { KpiController } from "./kpi.controller";
import { Kpi } from "./kpi.entity";
import { KpiService } from "./kpi.service";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";

@Module({
	imports: [
		TypeOrmModule.forFeature([Kpi, User, ApiKeyUser, Organisation, ApiKeyOrganisation, Answer, Poi]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
	],
	controllers: [KpiController],
	providers: [KpiService, SyslogService],
})
export class KpiModule {}
