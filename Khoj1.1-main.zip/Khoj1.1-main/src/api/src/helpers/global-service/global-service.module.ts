import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/users/users.entity';
import { GlobalServiceService } from './global-service.service';

@Module({
	imports:[
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		}),
		TypeOrmModule.forFeature([User])
	],
  	providers: [GlobalServiceService]
})
export class GlobalServiceModule {}
