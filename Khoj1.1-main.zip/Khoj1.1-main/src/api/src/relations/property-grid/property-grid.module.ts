import { Module } from "@nestjs/common";
import { PropertyGridController } from "./property-grid.controller";
import { PropertyGridService } from "./property-grid.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { PropertyGrid } from "./property-grid.entity";
import { Grid } from "src/grid/grids.entity";
import { Property } from "src/property/property.entity";

@Module({
	imports: [TypeOrmModule.forFeature([PropertyGrid, Grid, Property])],
	controllers: [PropertyGridController],
	providers: [PropertyGridService],
	exports: [PropertyGridService]
})
export class PropertyGridModule {}
