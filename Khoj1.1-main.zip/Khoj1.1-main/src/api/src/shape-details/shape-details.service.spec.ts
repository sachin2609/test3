import { Test, TestingModule } from '@nestjs/testing';
import { ShapeDetailsService } from './shape-details.service';

describe('ShapeDetailsService', () => {
  let service: ShapeDetailsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ShapeDetailsService],
    }).compile();

    service = module.get<ShapeDetailsService>(ShapeDetailsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
