import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class RiskAssessment {
	@PrimaryGeneratedColumn()
	id: number;

	@Column()
	ip: string;

	@Column()
	response: string;
}

export class EncryptedBody {
	body: string;
}

export class IPRiskBody {
	ip: string;
}
