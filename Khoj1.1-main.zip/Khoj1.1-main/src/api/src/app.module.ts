import { MiddlewareConsumer, Module, RequestMethod } from "@nestjs/common";
import { CacheModule } from "@nestjs/cache-manager";
// eslint-disable-next-line prettier/prettier
import type { RedisClientOptions } from "redis";
import { HttpModule } from "@nestjs/axios";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { PropertyModule } from "./property/property.module";
import { AuthModule } from "./auth/auth.module";
import { UsersModule } from "./users/users.module";
import { GridModule } from "./grid/grid.module";
import { IndexMasterModule } from "./index-master/index-master.module";
import { UserGridModule } from "./relations/user-grid/user-grid.module";
import { WorkItemModule } from "./work-item/work-item.module";
import { QuestionModule } from "./question/question.module";
import { AnswerModule } from "./answer/answer.module";
import { FormModule } from "./form/form.module";
import { UploadModule } from "./upload/upload.module";
import { InsightModule } from "./insight/insight.module";
import { InsghtGridModule } from "./relations/insght-grid/insght-grid.module";
import { PropertyDetailModule } from "./property-detail/property-detail.module";
import { PoiModule } from "./poi/poi.module";
import { PoiGridModule } from "./relations/poi-grid/poi-grid.module";
import { RolesGuardService } from "./helpers/roles-guard/roles-guard.service";
import * as dotenv from "dotenv";
import { APP_GUARD, APP_INTERCEPTOR } from "@nestjs/core";
import { JwtModule } from "@nestjs/jwt";
import { UserHistoryModule } from "./user-history/user-history.module";
import { PoiDetailsModule } from "./poi-details/poi-details.module";
import { TargetDetailsModule } from "./target-details/target-details.module";
import { OrganisationsModule } from "./organisations/organisations.module";
import { TargetModule } from "./target/target.module";
import { LayerSetModule } from "./layer-set/layer-set.module";
import { DeepDiveConfigModule } from "./deep-dive-config/deep-dive-config.module";
import { LayersModule } from "./layers/layers.module";
import { LayerDetailsModule } from "./layer-details/layer-details.module";
import "source-map-support/register";
import { CsvModule } from "nest-csv-parser";
import { PoiRoutesModule } from "./routing/poi-routes/poi-routes.module";
import { CsvProcessorModule } from "./csv-processor/csv-processor.module";
import { GlobalServiceModule } from "./helpers/global-service/global-service.module";
import { User } from "./users/users.entity";
import { Organisation } from "./organisations/organisations.entity";
import { ScheduleModule } from "@nestjs/schedule";
import { ShapeModule } from "./shape/shape.module";
import { MongooseModule } from "@nestjs/mongoose";
import { MongoDatabaseModule } from "./helpers/mongo-database/mongo-database.module";
import { ShapeDetailsModule } from "./shape-details/shape-details.module";
import { UserApiUsageHistoryModule } from "./user-api-usage-history/user-api-usage-history.module";
import { PoiShapeModule } from "./relations/poi-shape/poi-shape.module";
import { UserApiUsageHistory } from "./user-api-usage-history/user-api-usage-history.entity";
import { MerchantModule } from "./merchant/merchant.module";
import { SecurityModule } from "./security/security.module";
import { UserCredits } from "./user-history/user-credits.entity";
import { LayerShapeModule } from "./relations/layer-shape/layer-shape.module";
import { TargetShapeModule } from "./relations/target-shape/target-shape.module";
import { ScorecardModule } from "./scorecard/scorecard.module";
import { AcquisitionModule } from "./acquisition/acquisition.module";
import { PoiGridShapeModule } from "./poi-grid-shape/poi-grid-shape.module";
import { TargetGridShapeModule } from "./target-grid-shape/target-grid-shape.module";
import { ApiKeyUsersModule } from "./api-key-users/api-key-users.module";
import { ApiKeyOrganisationsModule } from "./api-key-organisations/api-key-organisations.module";
import { ApiKeyUserApiUsageModule } from "./api-key-user-api-usage/api-key-user-api-usage.module";
import { ApiKeyOrganisation } from "./api-key-organisations/api-key-organisations.entity";
import { ApiKeyUserApiUsageHistory } from "./api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "./api-key-users/api-key-users-credits.entity";
import { ApiKeyUser } from "./api-key-users/api-key-users.entity";
import * as redisStore from "cache-manager-redis-store";
import { GridService } from "./grid/grid.service";
import { DemoShapesDBSchema } from "./shape/shape.schema";
import { Grid } from "./grid/grids.entity";
import { Indexmaster } from "./index-master/index-master.entity";
import { PropertyGrid } from "./relations/property-grid/property-grid.entity";
import { Shape } from "./shape/shape.entity";
import { ApiKeyIp } from "./auth/apiKey-ip.entity";
import { ElasticSearchModule } from "./helpers/elastic-search/elastic-search.module";
import { UserIdIp } from "./auth/userId-ip.entity";
import { Shapeindex } from "./shape/shapeIndex.entity";
import { ShapeDetail } from "./shape-details/shape-details.entity";
import { ShapeService } from "./shape/shape.service";
import { Cache_Module } from "./helpers/cache/cache.module";
import { JiraModule } from "./helpers/jira/jira.module";
import { ExportDataModule } from "./export-data/export-data.module";
import { KpiModule } from "./kpi/kpi.module";
import { FrontEndConfigurationModule } from "./front-end-configuration/front-end-configuration.module";
import { UpdateCreditsLogsModule } from "./update-credits-logs/update-credits-logs.module";
import { TeamModule } from "./team/team.module";
import { Team } from "./team/team.entity";
import { LeadsModule } from "./leads/leads.module";
import { AppConfigsModule } from "./app-configs/app-configs.module";
import { PoiFilterModule } from "./poi-filter/poi-filter.module";
import { NotesModule } from "./notes/notes.module";
import { RemindersModule } from "./reminders/reminders.module";
import { MonitoringModule } from "./monitoring/monitoring.module";
import { PromptLogModule } from "./prompt-log/prompt-log.module";
import { SyslogService } from "./helpers/log-interceptor/syslog.service";
import { SetUserHeaderInterceptor } from "./helpers/user-header/user-header.decorator";
import { SupportModule } from "./support/support.module";
import compressionFilter from "./helpers/compression/compression-filter";
import * as shrinkRay from "shrink-ray-current";
import * as expressCompression from "compression";

dotenv.config();

@Module({
	imports: [
		TypeOrmModule.forRoot({
			type: "postgres",
			port: Number(process.env.POSTGRES_PORT),
			host: process.env.POSTGRES_HOST,
			username: process.env.POSTGRES_USER,
			password: process.env.POSTGRES_PASSWORD,
			database: process.env.POSTGRES_DB,
			entities: ["dist/**/*.entity{.ts,.js}"],
			synchronize: true,
			// logging: true
		}),
		TypeOrmModule.forFeature([
			User,
			Organisation,
			Team,
			UserApiUsageHistory,
			UserCredits,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyUserCredits,
			ApiKeyUserApiUsageHistory,
			Grid,
			Indexmaster,
			PropertyGrid,
			Shape,
			ApiKeyIp,
			UserIdIp,
			Shapeindex,
			ShapeDetail,
		]),
		PropertyModule,
		AuthModule,
		UsersModule,
		TeamModule,
		QuestionModule,
		AnswerModule,
		FormModule,
		GridModule,
		IndexMasterModule,
		WorkItemModule,
		UserGridModule,
		UploadModule,
		InsightModule,
		InsghtGridModule,
		PropertyDetailModule,
		PoiModule,
		PoiGridModule,
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		UserHistoryModule,
		PoiDetailsModule,
		TargetDetailsModule,
		OrganisationsModule,
		TargetModule,
		LayerSetModule,
		DeepDiveConfigModule,
		LayersModule,
		LayerDetailsModule,
		CsvModule,
		PoiRoutesModule,
		CsvProcessorModule,
		GlobalServiceModule,
		ScheduleModule.forRoot(),
		ShapeModule,
		MongoDatabaseModule,
		MongooseModule.forRoot(process.env.MONGO_URL),
		ShapeDetailsModule,
		UserApiUsageHistoryModule,
		PoiShapeModule,
		UserApiUsageHistoryModule,
		MerchantModule,
		SecurityModule,
		LayerShapeModule,
		TargetShapeModule,
		ScorecardModule,
		AcquisitionModule,
		PoiGridShapeModule,
		TargetGridShapeModule,
		ApiKeyUsersModule,
		ApiKeyOrganisationsModule,
		ApiKeyUserApiUsageModule,
		CacheModule.register<RedisClientOptions>({
			isGlobal: true,
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
		MongooseModule.forFeature([{ name: "DemoShapesDB", schema: DemoShapesDBSchema }]),
		ElasticSearchModule,
		HttpModule.register({
			timeout: 100000,
			maxRedirects: 100,
		}),
		MongoDatabaseModule,
		Cache_Module,
		JiraModule,
		ExportDataModule,
		KpiModule,
		FrontEndConfigurationModule,
		UpdateCreditsLogsModule,
		LeadsModule,
		AppConfigsModule,
		PoiFilterModule,
		NotesModule,
		RemindersModule,
		MonitoringModule,
		PromptLogModule,
		SupportModule,
	],
	controllers: [AppController],
	providers: [
		AppService,
		{ provide: APP_GUARD, useClass: RolesGuardService },
		GridService,
		ShapeService,
		SyslogService,
		{ provide: APP_INTERCEPTOR, useClass: SetUserHeaderInterceptor },
	],
})
export class AppModule {
	configure(consumer: MiddlewareConsumer) {
		if (process.env.ENABLE_COMPRESSION?.toLowerCase() !== "true") return;

		const compressionMiddleware = process.env.COMPRESSION_TECHNIQUE === "brotli" ? shrinkRay : expressCompression;
		const threshold = process.env.COMPRESSION_THRESHOLD ?? 1024;

		consumer
			.apply(compressionMiddleware({ filter: compressionFilter, threshold }))
			.forRoutes({ path: "*", method: RequestMethod.ALL });
	}
}
