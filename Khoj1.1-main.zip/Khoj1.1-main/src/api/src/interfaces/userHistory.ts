import { ApiProperty } from "@nestjs/swagger";

export class UserHistoryClass {
	@ApiProperty({ type: Number, description: "userID" })
	userId: number;

	@ApiProperty({ type: String, description: "propertyId" })
	loginTime: string;
}

export class DateQuery {
	@ApiProperty()
	startDate: string;

	@ApiProperty()
	endDate: string;
}
