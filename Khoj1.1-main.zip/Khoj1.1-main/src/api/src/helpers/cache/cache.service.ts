import { CACHE_MANAGER, Inject, Injectable } from "@nestjs/common";
import { HttpService } from "@nestjs/axios";
import { Cache } from "cache-manager";

@Injectable()
export class CacheService {

    constructor(
        private httpService: HttpService,
        @Inject(CACHE_MANAGER) private cacheManager: Cache,
    ) {}

    delay(ms: number) {
        return new Promise( resolve => setTimeout(resolve, ms) );
    }

    async deleteCache(token) {
        const headersRequest = {
            'Content-Type': 'application/json',
            'token': token,
        };
        const url = process.env.FRONTEND_LOGIN_URL+"/api/cache/delete";
        try{
            await this.httpService.get(url,{headers: headersRequest}).toPromise();
        } catch(err) {
            console.log(err);
        }
    }

    async gridFiltersCache(token) {
        const headersRequest = {
            'Content-Type': 'application/json',
            'token': token,
        };
        const url = process.env.FRONTEND_LOGIN_URL+"/api/grid/populate-filters";
        const body = {};
        try{
            await this.httpService.post(url,body,{headers: headersRequest}).toPromise();
        } catch(err) {
            console.log(err);
        }
    }

    async shapeFiltersCache(token) {
        const headersRequest = {
            'Content-Type': 'application/json',
            'token': token,
        };
        const url = process.env.FRONTEND_LOGIN_URL+"/api/shape/populate-filters";
        const body = {};
        try{
            await this.httpService.post(url,body,{headers: headersRequest}).toPromise();
        } catch(err) {
            console.log(err);
        }
    }

    async insightsCache(token) {
        const headersRequest = {
            'Content-Type': 'application/json',
            'token': token,
        };
        const url = process.env.FRONTEND_LOGIN_URL+"/api/insight/populate-get";
        try{
            await this.httpService.get(url,{headers: headersRequest}).toPromise();
        } catch(err) {
            console.log(err);
        }
    }

    async allPoiTypesCache(token) {
        const headersRequest = {
            'Content-Type': 'application/json',
            'token': token,
        };
        const url = process.env.FRONTEND_LOGIN_URL+"/api/poi/populate-allpoitypes";
        try{
            await this.httpService.get(url,{headers: headersRequest}).toPromise();
        } catch(err) {
            console.log(err);
        }
    }
    
    async poiInternalFiltersCache(token) {
        const headersRequest = {
            'Content-Type': 'application/json',
            'token': token,
        };
        const allPoiTypesUrl = process.env.FRONTEND_LOGIN_URL+"/api/poi/populate-allpoitypes";
        const url = process.env.FRONTEND_LOGIN_URL+"/api/poi/internal-filter";
        try{
            const res = await this.httpService.get(allPoiTypesUrl,{headers: headersRequest}).toPromise();
            const data = res.data as string[];
            //Individual requests
            for (let index = 0; index < data.length; index++) {
                const body = { types: [data[index]] };
                try {
                    await this.httpService.post(url,body,{headers: headersRequest}).toPromise();
                    this.delay(10000);
                } catch(err) {
                    console.log(err);
                }    
            }
            //All request
            try {
                const body = { types: data };
                await this.httpService.post(url,body,{headers: headersRequest}).toPromise();
            } catch(err) {
                console.log(err);
            }
        } catch(err) {
            console.log(err);
        }
    }

    async allLayerTypesCache(token) {
        const headersRequest = {
            'Content-Type': 'application/json',
            'token': token,
        };
        const url = process.env.FRONTEND_LOGIN_URL+"/api/layers/populate-alllayertypes";
        try{
            await this.httpService.get(url,{headers: headersRequest}).toPromise();
        } catch(err) {
            console.log(err);
        }
    }

    async layerInternalFiltersCache(token) {
        const headersRequest = {
            'Content-Type': 'application/json',
            'token': token,
        };
        const allLayerTypesUrl = process.env.FRONTEND_LOGIN_URL+"/api/layers/alllayertypes";
        const url = process.env.FRONTEND_LOGIN_URL+"/api/layers/populate-internal-filter";
        try{
            const res = await this.httpService.get(allLayerTypesUrl,{headers: headersRequest}).toPromise();
            const data = res.data as string[];
            //Individual requests
            for (let index = 0; index < data.length; index++) {
                const body = { types: [data[index]] };
                try {
                    await this.httpService.post(url,body,{headers: headersRequest}).toPromise();
                    this.delay(10000);
                } catch(err) {
                    console.log(err);
                }   
            }
            //All request
            try {
                const body = { types: data };
                await this.httpService.post(url,body,{headers: headersRequest}).toPromise();
            } catch(err) {
                console.log(err);
            }
        } catch(err) {
            console.log(err);
        }
    }

    async main(token: string) {
        //await this.deleteCache(token);
        await this.gridFiltersCache(token);
        await this.shapeFiltersCache(token);
        await this.insightsCache(token);
        await this.allPoiTypesCache(token);
        await this.poiInternalFiltersCache(token);
        await this.allLayerTypesCache(token);
        await this.layerInternalFiltersCache(token);
        return { response: "Success!" };
    }

}