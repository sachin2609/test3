import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from "typeorm";

@Entity()
export class Poiexported {
	@PrimaryGeneratedColumn()
	id: number;

	@Column()
	userId: number;

	@Column("decimal")
	latitude: number;

	@Column("decimal")
	longitude: number;

	@CreateDateColumn()
	createdAt: Date;

	@Column()
	filePath: string;
}
