import { Injectable } from "@nestjs/common";
import { Repository, In } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { PoiShape } from "./poi-shape.entity";
import { ShapeService } from "../../shape/shape.service";
import { MultilevelShapesQuery } from "../../interfaces/shapes";
import { Poi } from "../../poi/poi.entity";
import { Shapeindex } from "../../shape/shapeIndex.entity";
import * as _ from "lodash";
import { PoiDetail } from "src/poi-details/poi-details.entity";
@Injectable()
export class PoiShapeService {
	constructor(
		@InjectRepository(PoiShape) private poiShapeRepository: Repository<PoiShape>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(Shapeindex) private shapeIndexRepository: Repository<Shapeindex>,
		@InjectRepository(PoiDetail) private poiDetailRepository: Repository<PoiDetail>,
		private _shapeService: ShapeService,
	) {}

	async filter(query: MultilevelShapesQuery): Promise<unknown> {
		const shapeIds = await this._shapeService.returnShapeIdsmultilevelShapes(query);
		const poiShapeIndexDict = {};
		const shapeIndexDict = {};
		//console.log("shape ids inside poi filter", shapeIds);
		const shapeIndexes = await this.shapeIndexRepository
			.createQueryBuilder("shapeindex")
			.where('shapeindex."shapeId" IN (:...shapeIds)', { shapeIds: shapeIds })
			.select('"shapeId"')
			.addSelect('"indexName"')
			.addSelect('"indexValue"')
			.addSelect('"indexType"')
			.addSelect('"categoricalValue"')
			.getRawMany();
		shapeIndexes.forEach((eachIndex) => {
			if (!shapeIndexDict[eachIndex["shapeId"]]) {
				shapeIndexDict[eachIndex["shapeId"]] = {};
				if (eachIndex.indexType === "number") {
					shapeIndexDict[eachIndex["shapeId"]][eachIndex.indexName] = eachIndex.indexValue;
				} else {
					shapeIndexDict[eachIndex["shapeId"]][eachIndex.indexName] = eachIndex.categoricalValue;
				}
			} else {
				if (eachIndex.indexType === "number") {
					shapeIndexDict[eachIndex["shapeId"]][eachIndex.indexName] = eachIndex.indexValue;
				} else {
					shapeIndexDict[eachIndex["shapeId"]][eachIndex.indexName] = eachIndex.categoricalValue;
				}
			}
		});
		const poiShapeRelations = await this.poiShapeRepository.find({
			where: {
				shapeId: In(_.flattenDeep(shapeIds)),
			},
		});
		let poiIds = poiShapeRelations.map((eachRelation) => {
			poiShapeIndexDict[eachRelation.poiId] = shapeIndexDict[eachRelation.shapeId];
			return eachRelation.poiId;
		});
		//console.log("Lenth of PoiIds found :",poiIds.length);
		let poiIdsFromPoiDetails = [];
		if (query["poiDetails"]) {
			const poiDetails: any[] = query["poiDetails"];
			if (poiDetails.length == 0) {
				poiIdsFromPoiDetails = [];
			} else {
				await Promise.all(
					poiDetails.map(async (eachPoiDetail) => {
						if (eachPoiDetail.dataType == "string") {
							const tempPoiIdsFromString = [];
							const tempPoiIds = await this.poiDetailRepository
								.createQueryBuilder("poi_detail")
								.where(`key = :key AND value IN(:...values)`, {
									key: eachPoiDetail.key,
									values: eachPoiDetail.values,
								})
								.andWhere(`"poiId" IN (:...poiIds)`, { poiIds: poiIds })
								.select(`"poiId"`)
								.distinct(true)
								.getRawMany();
							await Promise.all(
								tempPoiIds.map((eachPoiId) => {
									tempPoiIdsFromString.push(eachPoiId.poiId);
								}),
							);
							poiIdsFromPoiDetails.push(tempPoiIdsFromString);
						}
						if (eachPoiDetail.dataType == "number") {
							//console.log("inside numbers query");
							const tempPoiIdsArray = [];
							console.log(eachPoiDetail);
							const tempPoiDetails = await this.poiDetailRepository
								.createQueryBuilder("poi_detail")
								.where("key = :key", { key: eachPoiDetail.key })
								.andWhere("unit BETWEEN :min and :max", {
									min: eachPoiDetail["values"]["min"],
									max: eachPoiDetail["values"]["max"],
								})
								.andWhere(`"poiId" IN (:...poiIds)`, { poiIds: poiIds })
								.select('"poiId"')
								.distinct(true)
								.getRawMany();

							console.log("temp poi details", tempPoiDetails);
							await Promise.all(
								tempPoiDetails.map((eachPoiDetailHere) => {
									tempPoiIdsArray.push(eachPoiDetailHere.poiId);
								}),
							);
							poiIdsFromPoiDetails.push(tempPoiIdsArray);
						}
					}),
				);
			}
			poiIds = _.intersection(...poiIdsFromPoiDetails, poiIds);
		}

		let pois;
		if (poiIds.length > 40000) {
			const poiIdsArr = _.chunk(poiIds, 40000);
			pois = await Promise.all(
				poiIdsArr.map(async (eachPoiIds) => {
					if (query.types) {
						return await this.poiRepository.find({
							where: {
								id: In(eachPoiIds),
								type: In(query.types),
							},
						});
					} else {
						return await this.poiRepository.find({
							where: {
								id: In(eachPoiIds),
							},
						});
					}
				}),
			);
			pois = _.flattenDeep(pois);
		} else {
			if (query.types) {
				pois = await this.poiRepository.find({
					where: {
						id: In(poiIds),
						type: In(query.types),
					},
				});
			} else {
				pois = await this.poiRepository.find({
					where: {
						id: In(poiIds),
					},
				});
			}
		}
		//Internal Details...
		const poiDetailDict = {};
		let poiDetails = [];
		console.log("PoiIds :", poiIds);
		if (poiIds.length > 40000) {
			const poiIdsArr = _.chunk(poiIds, 40000);
			poiDetails = await Promise.all(
				poiIdsArr.map(async (eachPoiIds) => {
					return await this.poiDetailRepository.find({ where: { poiId: In(eachPoiIds) } });
				}),
			);
			poiDetails = _.flattenDeep(poiDetails);
		} else {
			poiDetails = await this.poiDetailRepository.find({ where: { poiId: In(poiIds) } });
		}
		console.log("PoiDetails Length :", poiDetails.length);
		await Promise.all(
			poiDetails.map((eachObj) => {
				if (poiDetailDict[eachObj.poiId] != undefined) {
					poiDetailDict[eachObj.poiId][eachObj.key] = eachObj.value;
				} else {
					const tempObj = {};
					tempObj[eachObj.key] = eachObj.value;
					poiDetailDict[eachObj.poiId] = tempObj;
				}
			}),
		);
		//InternalDetails Done...
		const response = await this.prepareResponse(pois, poiShapeIndexDict, poiDetailDict);
		return response;
	}

	async prepareResponse(pois: Poi[], poiShapeIndexDict: any, poiDetailDict: any) {
		//console.log(poiDetailDict);
		const subCountsDict = {};
		await Promise.all(
			pois.map(async (eachPoi) => {
				eachPoi["internalDetails"] = poiDetailDict[eachPoi.id];
				eachPoi["geometry"] = {};
				eachPoi["geometry"]["type"] = "point";
				const coordinates: number[] = [];
				coordinates.push(Number(eachPoi.longitude));
				coordinates.push(Number(eachPoi.latitude));
				eachPoi["geometry"]["coordinates"] = coordinates;
				delete eachPoi.latitude;
				delete eachPoi.longitude;
				eachPoi["index"] = poiShapeIndexDict[eachPoi.id];
				if (subCountsDict[eachPoi.type]) {
					subCountsDict[eachPoi.type] += 1;
				} else {
					subCountsDict[eachPoi.type] = 1;
				}
			}),
		); /*
		pois.forEach(async eachPoi => {
			
		});*/
		const responseDict = {};
		responseDict["count"] = pois.length;
		responseDict["subTypeCount"] = subCountsDict;
		responseDict["data"] = pois;
		return responseDict;
	}
}
