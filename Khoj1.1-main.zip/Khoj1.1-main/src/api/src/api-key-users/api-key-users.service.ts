import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UsersQuery } from 'src/interfaces/users';
import { Repository } from 'typeorm';
import { ApiKeyUser } from './api-key-users.entity';

@Injectable()
export class ApiKeyUsersService {
    constructor(
		@InjectRepository(ApiKeyUser) private apiKeyUserRepository: Repository<ApiKeyUser>
	) {}

	async saveAll(data: ApiKeyUser[]): Promise<ApiKeyUser[]> {
		data.forEach((eachData: ApiKeyUser) => {
			this.apiKeyUserRepository.save(eachData);
		});
		return data;
	}

	async queryUsers(query): Promise<ApiKeyUser[]> {
		let queryString = "";
		Object.keys(query).forEach((eachkey, index) => {
			if (index === 0) {
				queryString += "api_key_user." + eachkey + " = :" + eachkey;
			} else {
				queryString += "AND api_key_user." + eachkey + " = :" + eachkey;
			}
		});
		return await this.apiKeyUserRepository.createQueryBuilder("api_key_user")
			.where(queryString, query)
			.getMany();
	}

	async findOrCreateUser(userObject: UsersQuery): Promise<ApiKeyUser> {
		const user = await this.apiKeyUserRepository.findOne({ where: { email: userObject.email }});
		if (user) {
			if (userObject.roles) {
				user.roles = userObject.roles;
			}
			user.googleAccessToken = userObject.googleAccessToken;
			return await this.apiKeyUserRepository.save(user);
		} else {
			console.log("user object is", userObject);
			const user = new ApiKeyUser();
			user.firstName = userObject.firstName;
			user.lastName = userObject.lastName;
			user.email = userObject.email;
			user.roles = ["basic","merchant_acquisition","merchant_scorecard","ip_risk_assessment"];
			user.googleAccessToken = userObject.googleAccessToken;
			return await this.apiKeyUserRepository.save(user);
		}
	}

	async findUser(query): Promise<ApiKeyUser> {
		if(query["email"] == undefined) {
			throw new HttpException('Please enter email',HttpStatus.BAD_REQUEST);
		} else {
			const user = await this.apiKeyUserRepository.findOne({ where: {email: query["email"] }});
			if(user == undefined) {
				throw new HttpException('Please enter valid email',HttpStatus.BAD_REQUEST);
			} else {
				return user;
			}
		}
	}

}
