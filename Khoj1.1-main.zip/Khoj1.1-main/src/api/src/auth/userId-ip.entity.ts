import { Entity, Column, PrimaryColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class UserIdIp {
	@ApiProperty()
	@PrimaryColumn()
	userId: number;

	@ApiProperty()
	@Column()
	ip: string;

	@ApiProperty()
	@Column({ nullable: true })
	otp: number;
}
