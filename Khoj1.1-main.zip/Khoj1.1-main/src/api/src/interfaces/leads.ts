export class LeadQuery {
	status?: string[];
	visited?: boolean;
	tags?: string[];
	startTime?: Date;
	endTime?: Date;
	poiIDs?: number[];
	filters?: LeadsFetchFilter[];
}

export enum LeadsFetchFilter {
	PENDING_VISITS = "pending visits",
	CONTACT_PENDING = "contact pending",
	INTRESTED = "interested",
	OTHERS = "others",
}

export class TimeLineQuery {
	poiId: number;
	userId: number;
}

export class TimeLineResponse {
	timestamp: Date;
	eventType: string;
	eventDetails: object;
}
