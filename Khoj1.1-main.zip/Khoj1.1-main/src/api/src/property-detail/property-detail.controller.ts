import { Controller } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
@ApiTags("property-detail")
@Controller("property-detail")
export class PropertyDetailController {}
