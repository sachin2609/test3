import { Injectable } from "@nestjs/common";
import { Repository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { Insight } from "./insight.entity";
import { TargetDetail } from "../target-details/target-details.entity";
import { PoiDetail } from "../poi-details/poi-details.entity";
import { Indexmaster } from "../index-master/index-master.entity";
import * as csv from "csv-parser";
import * as fs from "fs";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
@Injectable()
export class InsightService {
	constructor(
		@InjectRepository(Insight) private insightRepository: Repository<Insight>,
		@InjectRepository(TargetDetail) private targetDetailRepository: Repository<TargetDetail>,
		@InjectRepository(PoiDetail) private poiDetailRepository: Repository<PoiDetail>,
		@InjectRepository(Indexmaster) private indexmasterRepository: Repository<Indexmaster>,
		@InjectRepository(Shapeindex) private shapeIndexRepository: Repository<Shapeindex>,
		@InjectRepository(ShapeDetail) private shapeDetailRepository: Repository<ShapeDetail>
	) {}

	async create(): Promise<void> {
		const result = [];
		fs.createReadStream("./src/files/Location_data.csv")
			.pipe(csv())
			.on("data", data => {
				result.push(data);
			})
			.on("end", async () => {
				console.log(result);
				console.log("result length", result.length);
				for await (const data of result) {
					const tempInsight = new Insight();
					tempInsight.latitude = data["Latitude"];
					tempInsight.longitude = data["Longitude"];
					tempInsight.population = data["population"];
					tempInsight.footfall = data["footfall"];
					tempInsight.affluenceCategory = data["affluence_cat"];
					tempInsight.incomeCategory = data["income__cat"];
					try {
						const object = await this.insightRepository.save(tempInsight);
						console.log(object);
					} catch (error) {
						console.log(error);
					}
				}
			});
	}

	async list(query: Insight): Promise<Insight[]> {
		return await this.insightRepository.find({where: query});
	}

	async listInsights(): Promise<unknown> {
		const masterRespDict = {};
		const indexmasterIndexArr = [];
		const indexmasterIndexes = await this.indexmasterRepository.createQueryBuilder("indexmaster")
			.select('indexmaster."indexName"')
			.distinct(true)
			.getRawMany();
		await Promise.all(
			indexmasterIndexes.map(async eachIndex => {
				let data = await this.indexmasterRepository.findOne({ where: { indexName: eachIndex.indexName }});
				masterRespDict[data.indexName] = data.metrics;
			})
		);
		const poiInternalIndexes = await this.poiDetailRepository.createQueryBuilder("poi_detail")
			.select("key")
			.distinct(true)
			.getRawMany();
		await Promise.all(
			poiInternalIndexes.map(async eachIndex => {
				let data = await this.poiDetailRepository.findOne({ where: { key: eachIndex.key }});
				masterRespDict[data.key] = data.metrics;
			})
		);
		const targetInternalIndexes = await this.targetDetailRepository.createQueryBuilder("target_detail")
			.select("key")
			.distinct(true)
			.getRawMany();
		await Promise.all(
			targetInternalIndexes.map(async eachIndex => {
				let data = await this.targetDetailRepository.findOne({ where: { key: eachIndex.key }});
				masterRespDict[data.key] = data.metrics;
			})
		);
		const shapeIndexIndexes = await this.shapeIndexRepository.createQueryBuilder("shapeindex")
			.select('shapeindex."indexName"')
			.distinct(true)
			.getRawMany();
		await Promise.all(
			shapeIndexIndexes.map(async eachIndex => {
				let data = await this.shapeIndexRepository.findOne({ where: { indexName: eachIndex.indexName }});
				masterRespDict[data.indexName] = data.metrics;
			})
		);
		const shapeInternalIndexes = await this.shapeDetailRepository.createQueryBuilder("shape_detail")
			.select("key")
			.distinct(true)
			.getRawMany();
		await Promise.all(
			shapeInternalIndexes.map(async eachIndex => {
				let data = await this.shapeDetailRepository.findOne({ where: { key: eachIndex.key }});
				masterRespDict[data.key] = data.metrics;
			})
		);
		return masterRespDict;
	}
}
