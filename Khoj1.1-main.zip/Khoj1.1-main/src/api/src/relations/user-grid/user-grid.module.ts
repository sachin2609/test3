import { Module } from "@nestjs/common";
import { UserGridService } from "./user-grid.service";
import { UserGridController } from "./user-grid.controller";
import { TypeOrmModule } from "@nestjs/typeorm";
import { UserGrid } from "./user-grid.entity";
import { Grid } from "src/grid/grids.entity";

@Module({
	imports: [TypeOrmModule.forFeature([UserGrid, Grid])],
	providers: [UserGridService],
	controllers: [UserGridController]
})
export class UserGridModule {}
