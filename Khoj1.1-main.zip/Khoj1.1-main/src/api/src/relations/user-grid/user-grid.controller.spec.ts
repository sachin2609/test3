import { Test, TestingModule } from "@nestjs/testing";
import { UserGridController } from "./user-grid.controller";

describe("UserGridController", () => {
	let controller: UserGridController;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			controllers: [UserGridController]
		}).compile();

		controller = module.get<UserGridController>(UserGridController);
	});

	it("should be defined", () => {
		expect(controller).toBeDefined();
	});
});
