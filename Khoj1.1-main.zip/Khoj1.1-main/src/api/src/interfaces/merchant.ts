export class FetchMerchantsBodyDto {
	location?: { [x: string]: any };

	within?: object;

	without?: object;

	page?: number;

	types: string[];

	subTypes?: string[];

	status?: string[];

	tags?: string[];

	category?: string;

	count?: number;

	gst?: string[];

	center?: { lat: number; lng: number };

	poiDetails?: PoiDetailFilter[];

	grid?: { select: { [x: string]: string[] }; range: { [x: string]: { min: number; max: number } } };

	sortBy?: "distance" | "GST_turn_over";

	byPassRecenter?: boolean;

	byPassOppVisibility?: boolean;
}

export class PoiDetailFilter {
	key: string;
	dataType: string;
	values?: string[];
	max?: number;
	min?: number;
}
