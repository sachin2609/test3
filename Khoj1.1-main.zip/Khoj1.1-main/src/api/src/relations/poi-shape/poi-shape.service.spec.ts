import { Test, TestingModule } from '@nestjs/testing';
import { PoiShapeService } from './poi-shape.service';

describe('PoiShapeService', () => {
  let service: PoiShapeService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PoiShapeService],
    }).compile();

    service = module.get<PoiShapeService>(PoiShapeService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
