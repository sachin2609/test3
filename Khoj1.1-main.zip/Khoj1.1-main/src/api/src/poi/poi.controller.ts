import {
	Controller,
	Post,
	Body,
	Headers,
	Query,
	Get,
	UseInterceptors,
	HttpException,
	HttpStatus,
} from "@nestjs/common";
import { PoiService } from "./poi.service";
import { Poi } from "./poi.entity";
import { Property } from "../property/property.entity";
import { Repository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { Grid } from "../grid/grids.entity";
import { LatLng, Catchment, PoiQuery, PoiPaginationDto, PoiStatusUpdate } from "../interfaces/poi";
import { JwtService } from "@nestjs/jwt";
import { Header } from "../interfaces/header";
import { RedirectObject } from "../interfaces/redirect";
import { PropertyQuery } from "../interfaces/property";
import { POI } from "../interfaces/newPOI";
import { ApiTags, ApiBody, ApiHeader, ApiQuery, ApiResponse } from "@nestjs/swagger";
import { Roles, RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import _ = require("lodash");
import { GlobalServiceService } from "src/helpers/global-service/global-service.service";
import { GridService } from "src/grid/grid.service";
import { CacheInterceptorInterceptor } from "src/helpers/cache/cache-interceptor.interceptor";
import { CacheKey } from "src/helpers/cache/cache-key.decorator";
import { RealIP } from "nestjs-real-ip";
import { CachePopulateInterceptor } from "src/helpers/cache/cache-populate.interceptor";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { User } from "src/users/users.entity";
import { TeamService } from "src/team/team.service";

@ApiTags("poi")
@Controller("poi")
export class PoiController {
	constructor(
		private _poiService: PoiService,
		private _gridService: GridService,
		@InjectRepository(Property) private propertyRepository: Repository<Property>,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		private _jwtService: JwtService,
		private _globalService: GlobalServiceService,
		private _rolesGuardService: RolesGuardService,
		private teamService: TeamService,
	) {}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create POI" })
	@Post()
	async create(@Body() pois: Poi[]): Promise<void> {
		console.log(pois);
		return await this._poiService.create(pois);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Search POI" })
	@Post("search")
	@ApiBody({ type: Object })
	async search(@Body() query: JSON): Promise<Poi[]> {
		if (query["propertyId"]) {
			const property = await this.propertyRepository.findOne({ where: { id: query["propertyId"] } });
			console.log("property", property);
			return await this._poiService.search(property.latitude, property.longitude);
		} else if (query["gridId"]) {
			const grid = await this.gridRepository.findOne({ where: { id: query["gridId"] } });
			console.log("grid", grid);
			return await this._poiService.search(grid.latitude, grid.longitude);
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Dump society" })
	@Post("societies")
	async dumpSocieties(): Promise<void> {
		return await this._poiService.dumpSociety();
	}
	@Roles("basic")
	@ApiResponse({ description: "Dump Customer" })
	@ApiHeader({ name: "Token" })
	@Post("customers")
	async dumpCustomer(): Promise<void> {
		return await this._poiService.dumpCustomer();
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "SearchLatLong" })
	@Post("searchlatlng")
	@ApiBody({ type: LatLng })
	async searchLatLng(@Body() query: LatLng): Promise<Poi[]> {
		return await this._poiService.searchLatLong(query.latitude, query.longitude, query.types);
	}

	@Roles("basic")
	@Post("exportlatlng")
	@ApiBody({ type: LatLng })
	@ApiResponse({ description: "ExportLatLong" })
	@ApiHeader({ name: "header" })
	async exportLatLng(@Body() query: LatLng, @Headers() header: Header): Promise<RedirectObject> {
		const user = await this._jwtService.decode(header.token);
		let url;
		if (query["distance"]) {
			url = await this._poiService.exportLatLong(query.latitude, query.longitude, user["id"], query["distance"]);
		} else {
			url = await this._poiService.exportLatLong(query.latitude, query.longitude, user["id"]);
		}
		return { url: url };
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "DistanceCategory" })
	@Post("distancecategory")
	@ApiBody({ type: LatLng })
	async distancecategory(@Body() query: LatLng): Promise<unknown> {
		return await this._poiService.searchLatLongDistanceCategory(query);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/filter")
	@UseInterceptors(CacheInterceptorInterceptor)
	@ApiBody({ type: PropertyQuery })
	async filter(
		@Body() body: PropertyQuery,
		@Headers() header: Header,
		@RealIP() ip: string,
	): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			const resp = await this._poiService.optimized_filter(body);
			console.log("deducting ", resp["count"]);
			let credsResp;
			if (header.token) {
				credsResp = await this._rolesGuardService.updateCreds(
					header.token,
					Number(resp["count"]),
					"/poi/filter",
					ip,
					JSON.stringify(body),
				);
			} else {
				let apiKey;
				if (header["apikey"]) {
					apiKey = header["apikey"];
				}
				if (header["api-key"]) {
					apiKey = header["api-key"];
				}
				if (header["apiKey"]) {
					apiKey = header["apiKey"];
				}
				credsResp = await this._rolesGuardService.apiKeyUpdateCreds(
					apiKey,
					Number(resp["count"]),
					"/poi/filter",
					ip,
					JSON.stringify(body),
				);
			}
			console.log("response from creds deduction", credsResp);
			if (credsResp) {
				return resp;
			} else {
				throw new HttpException(
					{
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left",
					},
					HttpStatus.FORBIDDEN,
				);
			}
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("fetch-fresh-merchant")
	@ApiBody({ type: PropertyQuery })
	async fetch_fresh_merchant(
		@Body() body: PropertyQuery,
		@Headers() header: Header,
		@RealIP() ip: string,
	): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			const resp = await this._poiService.fetch_fresh_merchant(body);
			console.log("deducting ", resp["count"]);
			let credsResp;
			if (header.token) {
				credsResp = await this._rolesGuardService.updateCreds(
					header.token,
					Number(resp["count"]),
					"/poi/fetch-fresh-merchant",
					ip,
					JSON.stringify(body),
				);
			} else {
				let apiKey;
				if (header["apikey"]) {
					apiKey = header["apikey"];
				}
				if (header["api-key"]) {
					apiKey = header["api-key"];
				}
				if (header["apiKey"]) {
					apiKey = header["apiKey"];
				}
				credsResp = await this._rolesGuardService.apiKeyUpdateCreds(
					apiKey,
					Number(resp["count"]),
					"/poi/fetch-fresh-merchant",
					ip,
					JSON.stringify(body),
				);
			}
			console.log("response from creds deduction", credsResp);
			if (credsResp) {
				return resp;
			} else {
				throw new HttpException(
					{
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left",
					},
					HttpStatus.FORBIDDEN,
				);
			}
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "catchment" })
	@Post("/catchment")
	@ApiBody({ type: LatLng })
	async catchment(@Body() query: LatLng): Promise<Catchment> {
		return await this._poiService.catchment(query.latitude, query.longitude);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create new" })
	@Post("addnew")
	@ApiBody({ type: POI })
	async createnew(@Headers() headers: Header, @Body() body: POI): Promise<unknown> {
		console.log(body);
		const user = this._jwtService.decode(headers.token);
		return await this._poiService.createnew(user["id"], body);
	}

	@Roles("basic")
	@ApiResponse({ description: "getSubTypes" })
	@ApiHeader({ name: "Token" })
	@Get("subtypes")
	@ApiQuery({ type: POI, name: "query" })
	async getSubTypes(@Query() query: POI): Promise<string[]> {
		console.log(query);
		return await this._poiService.getSubTypes(query);
	}

	@Roles("basic")
	@ApiResponse({ description: "get added POIs" })
	@ApiHeader({ name: "Token" })
	@ApiQuery({ type: PoiQuery, name: "query" })
	@Get("newlyaddedPoi")
	async getNewlyAddedPois(@Query() query: PoiQuery): Promise<Poi[] | PoiPaginationDto> {
		console.log(query);
		return await this._poiService.getNewlyAddedPois(query);
	}

	@Roles("basic")
	@ApiResponse({ description: "Change POI status" })
	@ApiHeader({ name: "Token" })
	@ApiBody({ type: PoiStatusUpdate })
	@Post("updatePoiStatus")
	async updatePoiStatus(@Body() body: PoiStatusUpdate[]): Promise<void> {
		return await this._poiService.updatePoiStatus(body);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create new Store" })
	@Post("addNewStore")
	@ApiBody({ type: POI })
	async createnewstore(@Headers() headers: Header, @Body() body: POI): Promise<unknown> {
		console.log(body);
		const user = this._jwtService.decode(headers.token);
		return await this._poiService.createnewstore(user["id"], body);
	}

	@Roles("basic")
	@Post("internal-filter")
	@CacheKey("poi-internal-filters")
	@UseInterceptors(CacheInterceptorInterceptor)
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "filter" })
	@ApiBody({ type: Object })
	async filterPoiDetails(@Body() body): Promise<any> {
		try {
			return await this._poiService.filterPoiDetails(body);
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@Post("populate-internal-filter")
	@CacheKey("poi-internal-filters")
	@UseInterceptors(CachePopulateInterceptor)
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "filter" })
	@ApiBody({ type: Object })
	async populatefilterPoiDetails(@Body() body): Promise<any> {
		try {
			return await this._poiService.filterPoiDetails(body);
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@Post("mypoitypes")
	@CacheKey("poi-mypoitypes")
	@UseInterceptors(CacheInterceptorInterceptor)
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "allPoiNames" })
	@ApiBody({ type: Object })
	async myPoiTypes(@Body() body, @Headers() headers): Promise<any> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = (await this.teamService.decodeUserJWT(tokenAPIKey)) as Partial<User | ApiKeyUser>;
		return await this._poiService.getMyPoiTypes(body, user);
	}

	@Roles("basic")
	@Get("allpoitypes")
	@CacheKey("poi-allpoitypes")
	@UseInterceptors(CacheInterceptorInterceptor)
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "allPoiNames" })
	@ApiBody({ type: Object })
	async getAllPoiTypes(@Query() query): Promise<any> {
		try {
			return await this._poiService.getAllPoiTypes(query);
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("admin")
	@Get("populate-allpoitypes")
	@CacheKey("poi-allpoitypes")
	@UseInterceptors(CachePopulateInterceptor)
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "allPoiNames" })
	@ApiBody({ type: Object })
	async populateGetAllPoiTypes(@Query() query): Promise<any> {
		try {
			return await this._poiService.getAllPoiTypes(query);
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@Get("index-poi")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "filter" })
	@ApiBody({ type: Object })
	async indexPoi(): Promise<any> {
		try {
			return await this._poiService.indexPoi();
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "SearchLatLongNew" })
	@Post("searchlatlngnew")
	@ApiBody({ type: LatLng })
	async searchLatLngNew(@Body() query: LatLng) {
		return await this._poiService.searchLatLongNew(
			query.latitude,
			query.longitude,
			query.radius,
			query["type:subType"],
		);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("export-filter")
	@ApiBody({ type: PropertyQuery })
	async exportFilter(@Body() body: PropertyQuery, @Headers() header: Header) {
		const user = await this._jwtService.decode(header.token);
		const userId = user["id"];
		console.log(body);
		try {
			if (body["without"]) {
				body["within"] = body["without"];
				let within = null;
				let page = null;
				let limit = null;
				if (body["page"] && body["limit"]) {
					page = body["page"] - 1;
					limit = body["limit"];
					delete body["page"];
					delete body["limit"];
					console.log("Deleted 'page' and 'limit' from body");
				}
				const withinPoisRes = await this._poiService.filter(body);
				const withinPois = withinPoisRes["data"] as Poi[];
				if (body["within"]) {
					within = body["within"];
					delete body["within"];
					console.log("Deleted 'within' from body");
				}
				const allPoisRes = await this._poiService.filter(body);
				const allPois = allPoisRes["data"] as Poi[];
				console.log("Length of All pois : ", allPois.length);
				console.log("Length of Pois to be deleted :", withinPois.length);
				//const response = allPois.filter( poi => !withinPois.includes( poi ) );
				/*const response = allPois.filter(function(x) { 
					return withinPois.indexOf(x) < 0;
				});*/
				const response = allPois.filter(
					(ar) => !withinPois.find((rm) => rm.name === ar.name && ar.id === rm.id),
				);
				console.log("Length of Response Pois :", response.length); /*
				if(limit) {
					const splitedArray = _.chunk(response,limit);
					const totalPages = splitedArray.length;
					const responsePaginate : PoiPaginationDto = {
						page: page+1,
						limit: limit,
						totalPages: totalPages,
						data: splitedArray[page]
					}
					return responsePaginate;
				} else {
					//New Response------------
					let finalResponse = {};
					finalResponse["count"] = response.length;
					finalResponse["data"] = response;
					finalResponse["typeCount"] = {};
					await Promise.all(response.map(poi => {
						const subTypes = Object.keys(finalResponse["typeCount"]);
						if(subTypes.includes(poi.type)) {
							//console.log("Type encounterd :",poi.type);
							finalResponse["typeCount"][poi.type] = finalResponse["typeCount"][poi.type] +1;
						} else {
							finalResponse["typeCount"][poi.type] = 1;
						}
					}));
					console.log("here u go :",finalResponse["typeCount"]);
					return finalResponse;
					//return response;
				}*/
				if (body["responseType"]) {
					const responseIds: number[] = [];
					await Promise.all(
						response.map((eachPoi) => {
							responseIds.push(eachPoi.id);
						}),
					);
					const res = await this._poiService.getAggrigation(responseIds, body);
					if (res["shapes"]) {
						delete res["shapes"];
					}
					if (res["data"] == undefined) {
						res["data"] = [res["count"]];
					}
					return await this._globalService.exportCsv(res["data"], userId, "poi");
				} else {
					console.log("Length of Data sent to GlobalService :", response.length);
					await Promise.all(
						response.map(async (eachData) => {
							eachData["latitude"] = eachData["geometry"]["coordinates"][1];
							eachData["longitude"] = eachData["geometry"]["coordinates"][0];
							delete eachData["geometry"];
							await Promise.all(
								Object.keys(eachData["index"]).map((indexKey) => {
									eachData[indexKey] = eachData["index"][indexKey];
								}),
							);
							await Promise.all(
								Object.keys(eachData["internalDetails"]).map((indexKey) => {
									eachData[indexKey] = eachData["internalDetails"][indexKey];
								}),
							);
							delete eachData["index"];
							delete eachData["internalDetails"];
						}),
					);
					return await this._globalService.exportCsv(response, userId, "poi");
				}
			} else {
				if (body["responseType"]) {
					const res = await this._poiService.filter(body);
					if (res["shapes"]) {
						delete res["shapes"];
					}
					if (res["data"] == undefined) {
						res["data"] = [res["count"]];
					}
					return await this._globalService.exportCsv(res["data"], userId, "poi");
				} else {
					const res = await this._poiService.filter(body);
					console.log("Length of Data sent to GlobalService :", res["data"].length);
					await Promise.all(
						res["data"].map(async (eachData) => {
							eachData["latitude"] = eachData["geometry"]["coordinates"][1];
							eachData["longitude"] = eachData["geometry"]["coordinates"][0];
							delete eachData["geometry"];
							await Promise.all(
								Object.keys(eachData["index"]).map((indexKey) => {
									eachData[indexKey] = eachData["index"][indexKey];
								}),
							);
							await Promise.all(
								Object.keys(eachData["internalDetails"]).map((indexKey) => {
									eachData[indexKey] = eachData["internalDetails"][indexKey];
								}),
							);
							delete eachData["index"];
							delete eachData["internalDetails"];
						}),
					);
					return await this._globalService.exportCsv(res["data"], userId, "poi");
				}
			}
		} catch (error) {
			console.log(error);
			throw new HttpException("Bad Request", HttpStatus.BAD_REQUEST);
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "custom ep for wf" })
	@Post("wf-custom")
	@ApiBody({ type: LatLng })
	async wfCustom(@Body() body) {
		try {
			const response = {};
			body["types"] = ["doctor"];
			const doctorsFilter = await this._poiService.optimized_filter(body);
			const doctors = doctorsFilter["data"] as Poi[];
			//Old CODE from Here ........
			/*
			let totalCountForCategory = 0;
			let drCategory = {};
			//let totalCountForSpecilisation = 0;
			let drSubTypes = {};
			await Promise.all(doctors.map(eachDr => {
				if(eachDr["internalDetails"]["doctor_category"] != undefined) {
					totalCountForCategory = totalCountForCategory + 1;
					if (Object.keys(drCategory).includes(eachDr["internalDetails"]["doctor_category"])) {
						drCategory[eachDr["internalDetails"]["doctor_category"]] = Number(drCategory[eachDr["internalDetails"]["doctor_category"]]) + 1;
					} else {
						drCategory[eachDr["internalDetails"]["doctor_category"]] = 1;
					}
				}
				if (eachDr["subType"] != undefined) {
					if(Object.keys(drSubTypes).includes(eachDr["subType"])) {
						drSubTypes[eachDr["subType"]] = drSubTypes[eachDr["subType"]] + 1;
					} 
					else {
						drSubTypes[eachDr["subType"]] = 1;
					}
				}
			}));
			await Promise.all(Object.keys(drCategory).map(eachCategory => {
				let tempObj = {"count": Number(drCategory[eachCategory]),"percentage": 0}
				const percent = Number(((Number(drCategory[eachCategory]) / Number(totalCountForCategory)) * 100).toFixed(2));
				console.log("Percentage: ",percent)
				tempObj["percentage"] = percent;
				drCategory[eachCategory] = tempObj;
			}));
			let orderedCategory = {}
			_(drCategory).keys().sort().each(function(key) {
				orderedCategory[key] = drCategory[key];
			});
			response["doctors"]["category"] = orderedCategory;
			let orderedSubTypes = {}
			_(drSubTypes).keys().sort().each(function(key) {
				orderedSubTypes[key] = drSubTypes[key];
			});
			response["doctors"]["specialisation"] = orderedSubTypes;
			response["doctors"]["total"] = doctorsFilter["count"];
			*/
			//Old Code Upto Here .....
			//New Code from Here ....
			response["doctors"] = {};
			let totalCountForCategory = 0;
			const drCategory = {};
			await Promise.all(
				doctors.map((eachDr) => {
					if (eachDr["internalDetails"]) {
						if (eachDr["internalDetails"]["doctor_category"] != undefined) {
							totalCountForCategory = totalCountForCategory + 1;
							if (drCategory[eachDr["internalDetails"]["doctor_category"]]) {
								drCategory[eachDr["internalDetails"]["doctor_category"]]["count"] =
									Number(drCategory[eachDr["internalDetails"]["doctor_category"]]["count"]) + 1;
								if (eachDr.subType) {
									if (
										drCategory[eachDr["internalDetails"]["doctor_category"]]["specialisation"][
											eachDr.subType
										]
									) {
										drCategory[eachDr["internalDetails"]["doctor_category"]]["specialisation"][
											eachDr.subType
										] =
											Number(
												drCategory[eachDr["internalDetails"]["doctor_category"]][
													"specialisation"
												][eachDr.subType],
											) + 1;
									} else {
										drCategory[eachDr["internalDetails"]["doctor_category"]]["specialisation"][
											eachDr.subType
										] = 1;
									}
								}
							} else {
								const tempObj = {};
								tempObj["count"] = 1;
								tempObj["specialisation"] = {};
								if (eachDr["subType"]) {
									tempObj["specialisation"][eachDr.subType] = 1;
								}
								drCategory[eachDr["internalDetails"]["doctor_category"]] = tempObj;
							}
						}
					}
				}),
			);
			await Promise.all(
				Object.keys(drCategory).map((eachObj) => {
					if (eachObj) {
						drCategory[eachObj]["percentage"] = Number(
							((Number(drCategory[eachObj]["count"]) / Number(totalCountForCategory)) * 100).toFixed(2),
						);
						const orderedSpecilisation = {};
						_(drCategory[eachObj]["specialisation"])
							.keys()
							.sort()
							.each(function (key) {
								orderedSpecilisation[key] = drCategory[eachObj]["specialisation"][key];
							});
						drCategory[eachObj]["specialisation"] = orderedSpecilisation;
						const orderedObj = {};
						_(drCategory[eachObj])
							.keys()
							.sort()
							.each(function (key) {
								orderedObj[key] = drCategory[eachObj][key];
							});
						drCategory[eachObj] = orderedObj;
					}
				}),
			);
			const orderedDrCategory = {};
			_(drCategory)
				.keys()
				.sort()
				.each(function (key) {
					orderedDrCategory[key] = drCategory[key];
				});
			//console.log("DRCategory:",drCategory);
			response["doctors"]["category"] = orderedDrCategory;
			response["doctors"]["total"] = doctorsFilter["count"];
			//New Code upto Here ....
			/*
			let drSubTypes = {};
			await Promise.all(doctors.map(eachDr => {
				if(Object.keys(drSubTypes).includes(eachDr["subType"])) {
					drSubTypes[eachDr["subType"]] = drSubTypes[eachDr["subType"]] + 1;
				} 
				else if(eachDr["subType"] == undefined) {
					console.log("Skipped");
				} else {
					drSubTypes[eachDr["subType"]] = 1;
				}
			}));
			await Promise.all(Object.keys(drSubTypes).map(eachSubType => {
				let tempObj = {"count": Number(drSubTypes[eachSubType]),"percentage": 0}
				const percent = (Number(drSubTypes[eachSubType]) / Number(doctorsFilter["count"])) * 100;
				tempObj["percentage"] = percent;
				drSubTypes[eachSubType] = tempObj;
			}));
			drSubTypes["total"] = doctorsFilter["count"];
			response["doctor"] = drSubTypes;*/
			body["types"] = ["pharmacy", "hospital_and_clinics"];
			console.log("Body :", body);
			const pharmacyAndHospittalsFilter = await this._poiService.optimized_filter(body);
			response["pharmacy"] = Number(pharmacyAndHospittalsFilter["typeCount"]["pharmacy"]);
			response["hospital_and_clinics"] = Number(pharmacyAndHospittalsFilter["typeCount"]["hospital_and_clinics"]);
			body["types"] = ["branded_store", "grocery", "supermarket"];
			const shoppingFilter = await this._poiService.filter(body);
			const orderedShoppingFilterTypeCount = {};
			_(shoppingFilter["typeCount"])
				.keys()
				.sort()
				.each(function (key) {
					orderedShoppingFilterTypeCount[key] = shoppingFilter["typeCount"][key];
				});
			response["brand,grocery,supermarket"] = {
				total: shoppingFilter["count"],
				typeCount: orderedShoppingFilterTypeCount,
			};
			const gridsearch = await this._gridService.optimized_search(body);
			let count = 0;
			const grids = gridsearch["data"] as Grid[];
			console.log("HEEEEEHHHHHHHHHHHHHHHHHHHHHHHHHHHH :", grids[0], grids[1]);
			//let allIncomes :Number[]= [];
			response["demography"] = { "HIG_%": 0, "MIG_%": 0, "LIG_%": 0, population: 0 };
			response["footfall"] = 0;
			await Promise.all(
				grids.map((eachGrid) => {
					if (eachGrid["index"]["population"] != undefined) {
						response["demography"]["population"] =
							Number(response["demography"]["population"]) + Number(eachGrid["index"]["population"]);
					}
					if (eachGrid["index"]["footfall"] != undefined) {
						response["footfall"] = Number(response["footfall"]) + Number(eachGrid["index"]["footfall"]);
					}
					if (eachGrid["index"]["income_group"] != undefined) {
						if (eachGrid["index"]["income_group"] == "LIG") {
							response["demography"]["LIG_%"] = Number(response["demography"]["LIG_%"]) + 1;
							count = count + 1;
						}
						if (eachGrid["index"]["income_group"] == "MIG") {
							response["demography"]["MIG_%"] = Number(response["demography"]["MIG_%"]) + 1;
							count = count + 1;
						}
						if (eachGrid["index"]["income_group"] == "HIG") {
							response["demography"]["HIG_%"] = Number(response["demography"]["HIG_%"]) + 1;
							count = count + 1;
						}
					}
				}),
			);
			//let arr = [0];
			console.log("Demography Obj: ", response["demography"]);
			console.log("Count:", Number(gridsearch["count"]));
			console.log("Actual Count:", count);
			console.log("HERERE");
			response["demography"]["HIG_%"] = Number(
				((Number(response["demography"]["HIG_%"]) / count) * 100).toFixed(2),
			);
			response["demography"]["MIG_%"] = Number(
				((Number(response["demography"]["MIG_%"]) / count) * 100).toFixed(2),
			);
			response["demography"]["LIG_%"] = Number(
				((Number(response["demography"]["LIG_%"]) / count) * 100).toFixed(2),
			);
			/*
			allIncomes = _.uniqWith(allIncomes,_.isEqual);
			allIncomes = _(allIncomes).sortBy().value();
			const allIncomesArr = _.chunk(allIncomes,Math.ceil(allIncomes.length / 3));
			console.log(allIncomesArr);
			const lig = allIncomesArr[0];
			const mig = allIncomesArr[1];
			const hig = allIncomesArr[2];
			await Promise.all(grids.map(eachGrid => {
				if(lig.includes(Number(eachGrid["index"]["income"]))) {
					response["demography"]["LIG_%"] = Number(response["demography"]["LIG_%"]) + 1;
				}
				if(mig.includes(Number(eachGrid["index"]["income"]))) {
					response["demography"]["MIG_%"] = Number(response["demography"]["MIG_%"]) + 1;
				}
				if(hig.includes(Number(eachGrid["index"]["income"]))) {
					response["demography"]["HIG_%"] = Number(response["demography"]["HIG_%"]) + 1;
				}
			}));
			response["demography"]["LIG_%"] = (Number(response["demography"]["LIG_%"]) / Number(gridsearch["count"])) * 100;
			response["demography"]["MIG_%"] = (Number(response["demography"]["MIG_%"]) / Number(gridsearch["count"])) * 100;
			response["demography"]["HIG_%"] = (Number(response["demography"]["HIG_%"]) / Number(gridsearch["count"])) * 100;*/
			//Aff and BP starts
			if (body["within"]) {
				try {
					const grid = await this._gridService.gridsLatLongNew(
						body["within"]["points"][0]["lat"],
						body["within"]["points"][0]["lng"],
						0,
					);
					//console.log("Grid :",grid);
					//console.log("Grid :",grid["grids"][0]["index"]);
					response["affluence"] = this.numDifferentiation(
						Number(grid["grids"][0]["index"]["affluence"]["value"]),
					);
					response["business_potential"] = grid["grids"][0]["index"]["business_potential_value"]["value"];
				} catch (err) {
					console.log(err);
				}
			}
			//Aff and BP ends....
			return response;
		} catch (err) {
			console.log(err);
			return [];
		}
	}

	numDifferentiation(val) {
		if (val >= 10000000) {
			val = (val / 10000000).toFixed(2) + " Cr";
		} else if (val >= 100000) {
			val = (val / 100000).toFixed(2) + " Lac";
		}
		/*else if(val >= 1000) val = (val/1000).toFixed(2) + ' K';*/
		return val;
	}

	@Roles("basic")
	@Post("find-by-ids")
	async findByIds(@Body() body) {
		return await this._poiService.findByIds(body);
	}
}
