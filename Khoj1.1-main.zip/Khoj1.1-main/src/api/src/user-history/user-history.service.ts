import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { UserHistoryClass } from "src/interfaces/userHistory";
import { Between, In, Repository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { UserHistory } from "./user-history.entity";
import { User } from "src/users/users.entity";
import { MailerService } from "@nestjs-modules/mailer";
import { Organisation } from "src/organisations/organisations.entity";
// import { Cron } from "@nestjs/schedule";
// const plotly = require("plotly")("souvik_datasutram", "5OvSssFHwaUp5hloKYEy");
import * as _ from "lodash";
import * as moment from "moment";
import { Kpi } from "src/kpi/kpi.entity";

@Injectable()
export class UserHistoryService {
	pingRateInMins: number;
	constructor(
		@InjectRepository(UserHistory)
		private UserHistoryRepository: Repository<UserHistory>,
		@InjectRepository(User)
		private usersRepository: Repository<User>,
		@InjectRepository(Kpi) private kpiRepository: Repository<Kpi>,
		@InjectRepository(Organisation) private organisationRepository: Repository<Organisation>,
		private readonly mailerService: MailerService,
	) {
		this.pingRateInMins = !isNaN(Number(process?.env?.TIME_IN_MINUTES_PER_PING))
			? Number(process?.env?.TIME_IN_MINUTES_PER_PING)
			: 5;
	}

	async createOrUpdateUserHistory(userHistoryObject: UserHistoryClass): Promise<void> {
		console.log("The UserHistory object is : ", userHistoryObject);
		await this.UserHistoryRepository.save(userHistoryObject);
	}

	// @Cron("0 0 * * SUN")
	// handleCron(): void {
	// 	console.log("Running Every Weekend");
	// 	this.getWeeklyReportNew();
	// 	this.weeklyReportForOrgs();
	// }

	// async getWeeklyReportNew(): Promise<any> {
	// 	const x = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
	// 	const data = [];
	// 	const allLoginCounts = [];
	// 	const nowTime = new Date();
	// 	const startTime = new Date(nowTime.getTime() - 60 * 60 * 24 * 7 * 1000).toISOString();
	// 	const endTime = new Date().toISOString();
	// 	const dateArray = [];
	// 	for (let index = 6; index >= 0; index--) {
	// 		const element = new Date(nowTime.getTime() - 60 * 60 * 24 * index * 1000);
	// 		dateArray.push(element);
	// 	}
	// 	console.log("Dates:", dateArray);
	// 	const allUsers = await this.usersRepository.find();
	// 	await Promise.all(
	// 		allUsers.map(async (user) => {
	// 			const counts = [];
	// 			const countsNew = [];
	// 			const countsOld = await this.UserHistoryRepository.count({
	// 				where: {
	// 					userId: user.id,
	// 					loginTime: Between(startTime, endTime),
	// 				},
	// 			});
	// 			await Promise.all(
	// 				dateArray.map(async (date) => {
	// 					const startDATE = new Date(date.getTime() - 60 * 60 * 24 * 1000);
	// 					const day = startDATE.getDay();
	// 					const startDate = new Date(date.getTime() - 60 * 60 * 24 * 1000).toISOString();
	// 					const endDate = new Date(date.getTime()).toISOString();
	// 					const count = {};
	// 					count["countOfLogin"] = await this.UserHistoryRepository.count({
	// 						where: {
	// 							userId: user.id,
	// 							loginTime: Between(startDate, endDate),
	// 						},
	// 					});
	// 					count["day"] = day;
	// 					counts.push(count);
	// 				}),
	// 			);
	// 			counts.sort((a, b) => {
	// 				if (a.day > b.day) {
	// 					return 1;
	// 				}
	// 				if (b.day > a.day) {
	// 					return -1;
	// 				} else {
	// 					return 0;
	// 				}
	// 			});
	// 			await Promise.all(
	// 				counts.map(async (eachCount) => {
	// 					countsNew.push(eachCount["countOfLogin"]);
	// 				}),
	// 			);
	// 			const loginCount = {};
	// 			loginCount["activeHours"] = countsOld;
	// 			loginCount["userId"] = user.id;
	// 			loginCount["FirstName"] = user.firstName;
	// 			loginCount["LastName"] = user.lastName;
	// 			loginCount["email"] = user.email;
	// 			allLoginCounts.push(loginCount);
	// 			const trace = {
	// 				x: x,
	// 				y: countsNew,
	// 				type: "scatter",
	// 				name: user.firstName,
	// 			};
	// 			data.push(trace);
	// 		}),
	// 	);
	// 	console.log(allLoginCounts);
	// 	const layout = {
	// 		legend: { traceorder: "reversed" },
	// 	};
	// 	const graphOptions = {
	// 		layout: layout,
	// 		filename: "Weekly Report",
	// 		fileopt: "overwrite",
	// 	};
	// 	const finalHtml = await plotly.plot(data, graphOptions, async (err, msg) => {
	// 		if (err) {
	// 			return err;
	// 		} else {
	// 			const url = msg["url"];
	// 			console.log("URL is", url);
	// 			const rows = allLoginCounts;
	// 			let html = "<a href='" + url + "'> See Graph" + "</a>";
	// 			html += "<table>";
	// 			html += "<tr>";
	// 			for (const j in rows[0]) {
	// 				html += "<th>" + j + "</th>";
	// 			}
	// 			html += "</tr>";
	// 			for (let i = 0; i < rows.length; i++) {
	// 				html += "<tr>";
	// 				for (const j in rows[i]) {
	// 					html += "<td>" + rows[i][j] + "</td>";
	// 				}
	// 				html += "</tr>";
	// 			}
	// 			html += "</table>";
	// 			console.log("This is the URL =", url);

	// 			await this.mailerService
	// 				.sendMail({
	// 					to: process.env.LIST_OF_RECEIVERS, // list of receivers
	// 					from: process.env.MAILDEV_INCOMING_USER, // sender address
	// 					subject: "Weekly Report", // Subject line
	// 					text: "Report :", // plaintext body
	// 					html: html, // HTML body content
	// 				})
	// 				.then(() => {
	// 					console.log("Email Sent!");
	// 				})
	// 				.catch((err) => {
	// 					console.log("Error in sending mail", err);
	// 				});
	// 		}
	// 	});
	// 	console.log(finalHtml);
	// 	return finalHtml;
	// 	//document.getElementById("container").innerHTML = html;
	// }

	// async weeklyReportForOrgs() {
	// 	const x = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
	// 	const data = [];
	// 	const allLoginCounts = [];
	// 	const nowTime = new Date();
	// 	const startTime = new Date(nowTime.getTime() - 60 * 60 * 24 * 7 * 1000).toISOString();
	// 	const endTime = new Date().toISOString();
	// 	const dateArray = [];
	// 	for (let index = 6; index >= 0; index--) {
	// 		const element = new Date(nowTime.getTime() - 60 * 60 * 24 * index * 1000);
	// 		dateArray.push(element);
	// 	}
	// 	const allOrgs = await this.organisationRepository.find();
	// 	await Promise.all(
	// 		allOrgs.map(async (org) => {
	// 			const counts = [];
	// 			const countsNew = [];
	// 			let countsOld = 0;
	// 			const usersOfOrg = await this.usersRepository.find({ where: { organisationId: org.id } });
	// 			await Promise.all(
	// 				dateArray.map(async (date) => {
	// 					const startDATE = new Date(date.getTime() - 60 * 60 * 24 * 1000);
	// 					const day = startDATE.getDay();
	// 					const startDate = new Date(date.getTime() - 60 * 60 * 24 * 1000).toISOString();
	// 					const endDate = new Date(date.getTime()).toISOString();
	// 					const count = {};
	// 					count["countOfLogin"] = 0;
	// 					await Promise.all(
	// 						usersOfOrg.map(async (user) => {
	// 							const tempCountsOld = await this.UserHistoryRepository.count({
	// 								where: { userId: user.id, loginTime: Between(startTime, endTime) },
	// 							});
	// 							countsOld = countsOld + tempCountsOld;
	// 							const tempCount = await this.UserHistoryRepository.count({
	// 								where: {
	// 									userId: user.id,
	// 									loginTime: Between(startDate, endDate),
	// 								},
	// 							});
	// 							count["countOfLogin"] = count["countOfLogin"] + tempCount;
	// 						}),
	// 					);
	// 					count["day"] = day;
	// 					counts.push(count);
	// 				}),
	// 			);
	// 			counts.sort((a, b) => {
	// 				if (a.day > b.day) {
	// 					return 1;
	// 				}
	// 				if (b.day > a.day) {
	// 					return -1;
	// 				} else {
	// 					return 0;
	// 				}
	// 			});
	// 			await Promise.all(
	// 				counts.map(async (eachCount) => {
	// 					countsNew.push(eachCount["countOfLogin"]);
	// 				}),
	// 			);
	// 			const loginCount = {};
	// 			loginCount["activeHours"] = countsOld / 7;
	// 			loginCount["orgId"] = org.id;
	// 			loginCount["Organisation Name"] = org.organisation;
	// 			loginCount["GoogleClientId"] = org.googleClientId;
	// 			loginCount["AwsAccessKeyId"] = org.awsAccessKeyId;
	// 			allLoginCounts.push(loginCount);
	// 			const trace = {
	// 				x: x,
	// 				y: countsNew,
	// 				type: "scatter",
	// 				name: org.organisation,
	// 			};
	// 			data.push(trace);
	// 		}),
	// 	);
	// 	console.log(allLoginCounts);
	// 	const layout = {
	// 		legend: { traceorder: "reversed" },
	// 	};
	// 	const graphOptions = {
	// 		layout: layout,
	// 		filename: "Weekly Report",
	// 		fileopt: "overwrite",
	// 	};
	// 	const finalHtml = await plotly.plot(data, graphOptions, async (err, msg) => {
	// 		if (err) {
	// 			return err;
	// 		} else {
	// 			const url = msg["url"];
	// 			console.log("URL is", url);
	// 			const rows = allLoginCounts;
	// 			let html = "<a href='" + url + "'> See Graph" + "</a>";
	// 			html += "<table>";
	// 			html += "<tr>";
	// 			for (const j in rows[0]) {
	// 				html += "<th>" + j + "</th>";
	// 			}
	// 			html += "</tr>";
	// 			for (let i = 0; i < rows.length; i++) {
	// 				html += "<tr>";
	// 				for (const j in rows[i]) {
	// 					html += "<td>" + rows[i][j] + "</td>";
	// 				}
	// 				html += "</tr>";
	// 			}
	// 			html += "</table>";
	// 			console.log("This is the URL =", url);

	// 			await this.mailerService
	// 				.sendMail({
	// 					to: process.env.LIST_OF_RECEIVERS, // list of receivers
	// 					from: process.env.MAILDEV_INCOMING_USER, // sender address
	// 					subject: "Weekly Report", // Subject line
	// 					text: "Report :", // plaintext body
	// 					html: html, // HTML body content
	// 				})
	// 				.then(() => {
	// 					console.log("Email Sent!");
	// 				})
	// 				.catch((err) => {
	// 					console.log("Error in sending mail", err);
	// 				});
	// 		}
	// 	});
	// 	console.log(finalHtml);
	// 	return finalHtml;
	// 	//document.getElementById("container").innerHTML = html;
	// }

	// async getWeeklyReportOrgWise(query: DateQuery) {
	// 	//let finalUrls = [];
	// 	const pingRate = Number(process.env.TIME_IN_MINUTES_PER_PING);
	// 	console.log("Ping Rate :", pingRate);
	// 	let x = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
	// 	const nowTime = new Date();
	// 	console.log("Now Date:", nowTime);
	// 	const startTime = new Date(nowTime.getTime() - 60 * 60 * 24 * 7 * 1000).toISOString();
	// 	const endTime = new Date().toISOString();
	// 	const dateArray = [];
	// 	for (let index = 6; index >= 0; index--) {
	// 		const element = new Date(nowTime.getTime() - 60 * 60 * 24 * index * 1000);
	// 		dateArray.push(element);
	// 		const day = element.getDay();
	// 		if (day == 0) {
	// 			x[6] = x[6] + " : " + element.toISOString().split("T")[0];
	// 		} else {
	// 			x[day - 1] = x[day - 1] + " : " + element.toISOString().split("T")[0];
	// 		}
	// 	}
	// 	console.log("Dates:", dateArray);
	// 	let html = `<h2>Weekly Report for ${process.env.FRONTEND_LOGIN_URL}</h2><br>From: ${
	// 		startTime.split("T")[0]
	// 	} To: ${endTime.split("T")[0]}`;
	// 	const organisations = await this.organisationRepository.find();
	// 	await Promise.all(
	// 		organisations.map(async (eachOrg) => {
	// 			const allLoginCounts = [];
	// 			const data = [];
	// 			const allUsers = await this.usersRepository.find({ where: { organisationId: eachOrg.id } });
	// 			await Promise.all(
	// 				allUsers.map(async (user) => {
	// 					const counts = [];
	// 					const countsNew = [];
	// 					const countsOld =
	// 						(await this.UserHistoryRepository.count({
	// 							where: {
	// 								userId: user.id,
	// 								loginTime: Between(startTime, endTime),
	// 							},
	// 						})) * pingRate;
	// 					await Promise.all(
	// 						dateArray.map(async (date) => {
	// 							const startDATE = new Date(date.getTime() - 60 * 60 * 24 * 1000);
	// 							const day = startDATE.getDay();
	// 							const startDate = new Date(date.getTime() - 60 * 60 * 24 * 1000).toISOString();
	// 							const endDate = new Date(date.getTime()).toISOString();
	// 							const count = {};
	// 							count["countOfLogin"] =
	// 								(await this.UserHistoryRepository.count({
	// 									where: {
	// 										userId: user.id,
	// 										loginTime: Between(startDate, endDate),
	// 									},
	// 								})) * pingRate;
	// 							count["day"] = day;
	// 							counts.push(count);
	// 						}),
	// 					);
	// 					counts.sort((a, b) => {
	// 						if (a.day > b.day) {
	// 							return 1;
	// 						}
	// 						if (b.day > a.day) {
	// 							return -1;
	// 						} else {
	// 							return 0;
	// 						}
	// 					});
	// 					await Promise.all(
	// 						counts.map(async (eachCount) => {
	// 							countsNew.push(eachCount["countOfLogin"]);
	// 						}),
	// 					);
	// 					const loginCount = {};
	// 					loginCount["activeMinutes"] = countsOld;
	// 					loginCount["userId"] = user.id;
	// 					loginCount["FirstName"] = user.firstName;
	// 					loginCount["LastName"] = user.lastName;
	// 					loginCount["email"] = user.email;
	// 					allLoginCounts.push(loginCount);
	// 					const trace = {
	// 						x: x,
	// 						y: countsNew,
	// 						type: "scatter",
	// 						name: user.firstName,
	// 					};
	// 					data.push(trace);
	// 				}),
	// 			);
	// 			console.log(allLoginCounts);
	// 			const layout = {
	// 				legend: { traceorder: "reversed" },
	// 			};
	// 			const graphOptions = {
	// 				layout: layout,
	// 				filename: "Weekly Report",
	// 			};
	// 			//console.log("DATA: ",data);
	// 			// const user = await this.usersRepository.findOne({ where: { id: userId } });
	// 			await plotly.plot(data, graphOptions, async (err, msg) => {
	// 				if (err) {
	// 					return err;
	// 				} else {
	// 					let resObj = { organisation: eachOrg.organisation, url: "", allLoginCounts: allLoginCounts };
	// 					const url = msg["url"];
	// 					resObj["url"] = url;
	// 					console.log("URL is", url);
	// 					const rows = allLoginCounts;
	// 					html +=
	// 						`<br><h3>For Organisation : ${eachOrg["organisation"]}</h3>` +
	// 						"<a href='" +
	// 						url +
	// 						"'> See Graph" +
	// 						"</a>";
	// 					html += "<table>";
	// 					html += "<tr>";
	// 					for (const j in rows[0]) {
	// 						html += "<th>" + j + "</th>";
	// 					}
	// 					html += "</tr>";
	// 					for (let i = 0; i < rows.length; i++) {
	// 						html += "<tr>";
	// 						for (const j in rows[i]) {
	// 							html += "<td>" + rows[i][j] + "</td>";
	// 						}
	// 						html += "</tr>";
	// 					}
	// 					html += "</table>";
	// 					console.log("This is the URL =", url);
	// 				}
	// 			});
	// 		}),
	// 	)
	// 		.then(async () => {
	// 			await this.mailerService
	// 				.sendMail({
	// 					to: process.env.LIST_OF_RECEIVERS, // list of receivers
	// 					from: process.env.MAILDEV_INCOMING_USER, // sender address
	// 					subject: `Weekly Report of ${process.env.FRONTEND_LOGIN_URL}`, // Subject line
	// 					text: "Report :", // plaintext body
	// 					html: html, // HTML body content
	// 				})
	// 				.then(() => {
	// 					console.log("Email Sent!");
	// 					return { response: "Success!" };
	// 				})
	// 				.catch((err) => {
	// 					console.log("Error in sending mail", err);
	// 				});
	// 		})
	// 		.catch((err) => {
	// 			console.log(err);
	// 			return { response: "Failed!" };
	// 		});
	//
	// 	const wait=ms=>new Promise(resolve => setTimeout(resolve, ms));
	// 	wait(15*1000).then(async () => {
	// 		await this.mailerService.sendMail({
	// 			to: process.env.LIST_OF_RECEIVERS, // list of receivers
	// 			from: process.env.MAILDEV_INCOMING_USER, // sender address
	// 			subject: `Weekly Report of ${process.env.FRONTEND_LOGIN_URL}`, // Subject line
	// 			text: "Report :", // plaintext body
	// 			html: html // HTML body content
	// 		})
	// 		.then(() => {
	// 			console.log("Email Sent!");
	// 			return {"response":"Success!"};
	// 		})
	// 		.catch(err => {
	// 			console.log("Error in sending mail", err);
	// 		});
	// 	})
	// 	.catch((err) => {
	// 		console.log(err);
	// 		return {"response": "Failed!"};
	// 	});
	// 	*/
	// }

	// async getWeeklyReportOrgWiseNew(query: DateQuery) {
	// 	const pingRate = Number(process.env.TIME_IN_MINUTES_PER_PING);
	// 	console.log("Ping Rate :", pingRate);
	// 	const startTime = query.startDate;
	// 	const start = new Date(startTime);
	// 	const endTime = query.endDate;
	// 	const end = new Date(endTime);
	// 	if (end.getTime() - start.getTime() < 0) {
	// 		throw new HttpException(
	// 			{
	// 				status: HttpStatus.BAD_REQUEST,
	// 				error: "End Date must be greater than Start date",
	// 			},
	// 			HttpStatus.BAD_REQUEST,
	// 		);
	// 	}
	// 	let x = [];
	// 	let dateArray = [];
	// 	let diff = end.getTime();
	// 	let index = 0;
	// 	while (diff >= start.getTime()) {
	// 		const element = new Date(end.getTime() - 60 * 60 * 24 * index * 1000);
	// 		dateArray.push(element);
	// 		const day = element.getDay();
	// 		if (day == 0) {
	// 			x.push("Sun : " + element.toISOString().split("T")[0]);
	// 		}
	// 		if (day == 1) {
	// 			x.push("Mon : " + element.toISOString().split("T")[0]);
	// 		}
	// 		if (day == 2) {
	// 			x.push("Tue : " + element.toISOString().split("T")[0]);
	// 		}
	// 		if (day == 3) {
	// 			x.push("Wed : " + element.toISOString().split("T")[0]);
	// 		}
	// 		if (day == 4) {
	// 			x.push("Thu : " + element.toISOString().split("T")[0]);
	// 		}
	// 		if (day == 5) {
	// 			x.push("Fri : " + element.toISOString().split("T")[0]);
	// 		}
	// 		if (day == 6) {
	// 			x.push("Sat : " + element.toISOString().split("T")[0]);
	// 		}
	// 		index = index + 1;
	// 		diff = end.getTime() - 60 * 60 * 24 * index * 1000;
	// 	}
	// 	console.log(x);
	// 	console.log("Dates:", dateArray);
	// 	let html = `<h2>Weekly Report for ${process.env.FRONTEND_LOGIN_URL}</h2><br>From: ${
	// 		startTime.split("T")[0]
	// 	} To: ${endTime.split("T")[0]}`;
	// 	const organisations = await this.organisationRepository.find();
	// 	await Promise.all(
	// 		organisations.map(async (eachOrg) => {
	// 			const allLoginCounts = [];
	// 			const data = [];
	// 			const allUsers = await this.usersRepository.find({ where: { organisationId: eachOrg.id } });
	// 			await Promise.all(
	// 				allUsers.map(async (user) => {
	// 					const counts = [];
	// 					const countsNew = [];
	// 					const countsOld =
	// 						(await this.UserHistoryRepository.count({
	// 							where: {
	// 								userId: user.id,
	// 								loginTime: Between(startTime, endTime),
	// 							},
	// 						})) * pingRate;
	// 					await Promise.all(
	// 						dateArray.map(async (date) => {
	// 							const startDATE = new Date(date.getTime() - 60 * 60 * 24 * 1000);
	// 							const day = startDATE.getDay();
	// 							const startDate = new Date(date.getTime() - 60 * 60 * 24 * 1000).toISOString();
	// 							const endDate = new Date(date.getTime()).toISOString();
	// 							const count = {};
	// 							count["countOfLogin"] =
	// 								(await this.UserHistoryRepository.count({
	// 									where: {
	// 										userId: user.id,
	// 										loginTime: Between(startDate, endDate),
	// 									},
	// 								})) * pingRate;
	// 							count["day"] = day;
	// 							count["date"] = date.getTime();
	// 							counts.push(count);
	// 						}),
	// 					);
	// 					counts.sort((a, b) => {
	// 						if (a.date > b.date) {
	// 							return 1;
	// 						}
	// 						if (b.date > a.date) {
	// 							return -1;
	// 						} else {
	// 							return 0;
	// 						}
	// 					});
	// 					//console.log("COUNTS:",counts);
	// 					await Promise.all(
	// 						counts.map(async (eachCount) => {
	// 							countsNew.push(eachCount["countOfLogin"]);
	// 						}),
	// 					);
	// 					const loginCount = {};
	// 					loginCount["activeMinutes"] = countsOld;
	// 					loginCount["userId"] = user.id;
	// 					loginCount["FirstName"] = user.firstName;
	// 					loginCount["LastName"] = user.lastName;
	// 					loginCount["email"] = user.email;
	// 					allLoginCounts.push(loginCount);
	// 					const trace = {
	// 						x: x,
	// 						y: countsNew,
	// 						type: "scatter",
	// 						name: user.firstName,
	// 						mode: "lines+markers",
	// 					};
	// 					data.push(trace);
	// 				}),
	// 			);
	// 			console.log(allLoginCounts);
	// 			const layout = {
	// 				legend: { traceorder: "reversed" },
	// 			};
	// 			const graphOptions = {
	// 				layout: layout,
	// 				filename: "Usage Report",
	// 			};
	// 			console.log("DATA:", data);
	// 			await plotly.plot(data, graphOptions, async (err, msg) => {
	// 				if (err) {
	// 					return err;
	// 				} else {
	// 					//console.log("MSG:",msg);
	// 					let resObj = { organisation: eachOrg.organisation, url: "", allLoginCounts: allLoginCounts };
	// 					const url = msg["url"];
	// 					resObj["url"] = url;
	// 					console.log("URL is", url);
	// 					const rows = allLoginCounts;
	// 					html +=
	// 						`<br><h3>For Organisation : ${eachOrg["organisation"]}</h3>` +
	// 						"<a href='" +
	// 						url +
	// 						"'> See Graph" +
	// 						"</a>";
	// 					html += "<table>";
	// 					html += "<tr>";
	// 					for (const j in rows[0]) {
	// 						html += "<th>" + j + "</th>";
	// 					}
	// 					html += "</tr>";
	// 					for (let i = 0; i < rows.length; i++) {
	// 						html += "<tr>";
	// 						for (const j in rows[i]) {
	// 							html += "<td>" + rows[i][j] + "</td>";
	// 						}
	// 						html += "</tr>";
	// 					}
	// 					html += "</table>";
	// 					console.log("This is the URL =", url);
	// 				}
	// 			});
	// 		}),
	// 	); /*.then(async () => {
	// 		console.log("HTML: ",html);
	// 		await this.mailerService.sendMail({
	// 			to: process.env.LIST_OF_RECEIVERS, // list of receivers
	// 			from: process.env.MAILDEV_INCOMING_USER, // sender address
	// 			subject: `Weekly Report of ${process.env.FRONTEND_LOGIN_URL}`, // Subject line
	// 			text: "Report :", // plaintext body
	// 			html: html // HTML body content
	// 		})
	// 		.then(() => {
	// 			console.log("Email Sent!");
	// 			//return {"response":"Success!"};
	// 		})
	// 		.catch(err => {
	// 			console.log("Error in sending mail", err);
	// 		});
	// 	})
	// 	.catch((err) => {
	// 		console.log(err);
	// 		return {"response": "Failed!"};
	// 	});*/

	// 	const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
	// 	wait(10 * 1000)
	// 		.then(async () => {
	// 			await this.mailerService
	// 				.sendMail({
	// 					to: process.env.LIST_OF_RECEIVERS, // list of receivers
	// 					from: process.env.MAILDEV_INCOMING_USER, // sender address
	// 					subject: `Weekly Report of ${process.env.FRONTEND_LOGIN_URL}`, // Subject line
	// 					text: "Report :", // plaintext body
	// 					html: html, // HTML body content
	// 				})
	// 				.then(() => {
	// 					console.log("Email Sent!");
	// 					return { response: "Success!" };
	// 				})
	// 				.catch((err) => {
	// 					console.log("Error in sending mail", err);
	// 				});
	// 		})
	// 		.catch((err) => {
	// 			console.log(err);
	// 			return { response: "Failed!" };
	// 		});
	// }

	async loginTime(
		query: { startTime: Date; endTime: Date; teamIds: number[]; userIds: number[] },
		userId: number,
		roles: string[],
	) {
		const { startTime, endTime, teamIds, userIds } = query;
		if (!moment(startTime).isValid() || !moment(endTime).isValid || moment(startTime).isAfter(moment(endTime))) {
			throw new HttpException(
				"StartTime and EndTime Not Specified / Invalid or Incorrect",
				HttpStatus.BAD_REQUEST,
			);
		}
		if (!userIds?.length && !teamIds?.length) {
			throw new HttpException("User IDs or Team IDs are required!", HttpStatus.BAD_REQUEST);
		}

		let userIDs: number[];
		if (!roles.includes("admin")) {
			userIDs = [userId];
		} else {
			const teamUsers = teamIds?.length
				? await (async () => {
						try {
							return await this.usersRepository.find({
								where: {
									teamId: In(query?.teamIds),
								},
							});
						} catch (err) {
							console.error(err);
							throw new HttpException("Error in fetching Users for Team IDs", HttpStatus.BAD_REQUEST);
						}
				  })()
				: [];
			const teamUserIDs = teamUsers.map((user) => user.id);
			if (teamIds?.length && userIds?.length) {
				userIDs = _.intersection(teamUserIDs, userIds);
			} else if (teamIds?.length) {
				userIDs = teamUserIDs;
			} else {
				userIDs = userIds;
			}
		}
		if (!userIDs?.length) {
			return [];
		}

		const userPingEntries = await (async () => {
			try {
				const pings = await this.kpiRepository.find({
					where: {
						createdAt: Between(startTime, endTime),
						action: "Ping",
						tokenUserId: In(userIDs),
					},
					select: ["tokenUserId", "createdAt"],
				});
				return _.groupBy(pings, "tokenUserId");
			} catch (error) {
				console.error(error);
				throw new HttpException(
					"Cannot find additional users histories with the userIds",
					HttpStatus.SERVICE_UNAVAILABLE,
				);
			}
		})();
		const usages = [];
		for (const userId of userIDs) {
			const user = await this.usersRepository.findOne({ where: { id: Number(userId) } });
			const pings = _.orderBy(userPingEntries[userId], "createdAt", "asc");
			const usageTime = this.getUsageTimeInMins(pings);
			usages.push({
				name: `${user.firstName} ${user.lastName}`,
				userId: user.id,
				email: user?.email ?? undefined,
				phoneNumber: user?.phoneNumber ?? undefined,
				loginTime: this.minsToHrs(usageTime),
			});
		}
		return usages;
	}

	getUsageTimeInMins(kpiUsages?: Kpi[]): number {
		const timeStamps = kpiUsages?.map((k) => k?.createdAt) ?? [];
		if (!timeStamps.length) return 0;
		else {
			const sessions: { startTime: Date; endTime: Date }[] = [];
			let startTime;
			for (const [index, t] of timeStamps.entries()) {
				if (!startTime) startTime = t;
				if (timeStamps[index + 1]) {
					const diff = moment(timeStamps[index + 1]).diff(moment(t), "seconds");
					if (diff > this.pingRateInMins * 60) {
						const session = { startTime, endTime: new Date(t) };
						sessions.push(session);
						startTime = null;
					}
				} else {
					sessions.push({ startTime: new Date(startTime), endTime: new Date(t) });
				}
			}
			const totalTime = sessions
				.map((s) => moment(s.endTime).diff(moment(s.startTime), "seconds"))
				.reduce((a, b) => a + b, 0);
			return totalTime / 60;
		}
	}

	minsToHrs(val: number) {
		let response;
		if (val >= 60) {
			const hrs = val / 60;
			const mins = val % 60;
			response = hrs.toFixed(0) + " hrs " + mins.toFixed(0) + " mins";
			return response;
		} else {
			response = val.toFixed(0) + " mins";
			return response;
		}
	}
}
