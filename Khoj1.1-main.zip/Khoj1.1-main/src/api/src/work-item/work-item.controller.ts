import { Controller, Get, Headers, Query, Body, Post } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import {
	WorkItemPaginationDto,
	WorkItemQuery,
	WorkItemResponse,
	WorkItemUsers
} from "src/interfaces/work-item";
import { WorkItemService } from "./work-item.service";
import { WorkItem } from "./work-item.entity";
import { Header } from "../interfaces/header";
import { ApiTags, ApiQuery, ApiHeader, ApiBody, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
@ApiTags("work-item")
@Controller("work-item")
export class WorkItemController {
	constructor(private _workItemService: WorkItemService, private _jwtService: JwtService) {}

	@Roles("basic")
	@Get()
	@ApiQuery({ type: WorkItemQuery, name: "query" })
	@ApiHeader({ name: "header" })
	@ApiResponse({ description: "get work-items" })
	async list(
		@Query() workItemQuery: WorkItemQuery,
		@Headers() header: JSON
	): Promise<WorkItemPaginationDto | WorkItemResponse[]> {
		const user = this._jwtService.decode(header["token"]);
		return await this._workItemService.list(workItemQuery, user["id"]);
	}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "create workItem" })
	@ApiBody({ type: WorkItem })
	async create(@Body() workitems: WorkItem[], @Headers() header: Header): Promise<WorkItem[]> {
		const user = this._jwtService.decode(header.token);
		workitems.forEach(eachWorkItem => {
			eachWorkItem.userId = user["id"];
		});
		return await this._workItemService.save(workitems);
	}

	@Roles("basic")
	@Post("close")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "close" })
	@ApiBody({ type: Object })
	async close(@Body() workItem: JSON): Promise<WorkItem[]> {
		console.log("woritem is", workItem["workItemId"]);
		return await this._workItemService.close(Number(workItem["workItemId"]), workItem["status"]);
	}

	@Roles("basic")
	@Post("query")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "query workItems" })
	@ApiBody({ type: WorkItem })
	async queryWorkItem(@Body() workItem: WorkItem): Promise<WorkItem[]> {
		return await this._workItemService.queryWorkItem(workItem);
	}

	@Roles("basic")
	@Post("getusers")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "getUsers" })
	@ApiBody({ type: WorkItem })
	async getUsers(@Body() workItems: WorkItem[]): Promise<WorkItemUsers[]> {
		return await this._workItemService.getUsers(workItems);
	}
}
