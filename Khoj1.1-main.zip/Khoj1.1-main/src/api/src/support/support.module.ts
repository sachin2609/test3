import { Module } from "@nestjs/common";
import { SupportController } from "./support.controller";
import { SupportService } from "./support.service";
import { JwtModule } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Poi } from "src/poi/poi.entity";
import { Team } from "src/team/team.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { User } from "src/users/users.entity";
import { TeamService } from "src/team/team.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
import { MulterModule } from "@nestjs/platform-express";

@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		MulterModule.register({ dest: String(process.env.PATH_TO_SAVE_FILES) }),
		TypeOrmModule.forFeature([User, Team, ApiKeyUser, Poi, UserCredits]),
	],
	controllers: [SupportController],
	providers: [SupportService, TeamService, KeyCloakService, CentralServerService],
})
export class SupportModule {}
