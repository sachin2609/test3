import { Test, TestingModule } from "@nestjs/testing";
import { PoiDetailsController } from "./poi-details.controller";

describe("PoiDetailsController", () => {
	let controller: PoiDetailsController;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			controllers: [PoiDetailsController]
		}).compile();

		controller = module.get<PoiDetailsController>(PoiDetailsController);
	});

	it("should be defined", () => {
		expect(controller).toBeDefined();
	});
});
