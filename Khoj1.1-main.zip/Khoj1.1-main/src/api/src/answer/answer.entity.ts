import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

@Entity()
export class Answer {
	@PrimaryGeneratedColumn()
	@ApiProperty()
	id: number;

	@Column()
	@ApiProperty()
	questionId: number;

	@Column({ nullable: true })
	@ApiProperty({ nullable: true })
	faId?: string;

	@Column({nullable: true})
	@ApiProperty({nullable: true})
	tokenUserId?: number;

	@Column({nullable: true})
	@ApiProperty({nullable: true})
	apiKeyUserId?: number;

	@Column()
	@ApiProperty()
	uniqueId: number;

	@Column({nullable: true})
	@ApiProperty({nullable: true})
	workItemId?: number;

	@Column("simple-array")
	@ApiProperty()
	answer: string[];

	@Column({ nullable: true })
	@ApiProperty()
	remarks?: string;

	@Column({nullable: true})
	@ApiProperty()
	comment?: string;

	@ApiProperty()
	@CreateDateColumn()
	createdAt: Date;
}
