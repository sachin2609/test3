import { ApiProperty } from "@nestjs/swagger";
import { Kpi } from "src/kpi/kpi.entity";
import { Note } from "src/notes/notes.entity";
import { ReminderUpdate } from "src/reminders/reminders.entity";
import { Column, CreateDateColumn, Entity, PrimaryColumn, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class Lead {
	@ApiProperty()
	@PrimaryColumn({ type: "integer" })
	poiId: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	tokenUserId?: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	apiKeyUserId?: number;

	@ApiProperty()
	@Column()
	status: string;

	@ApiProperty()
	@Column({ default: false })
	visited: boolean;

	@ApiProperty()
	@Column({ nullable: true })
	remarks?: string;

	@ApiProperty()
	@Column({ nullable: true })
	comment?: string;

	@ApiProperty()
	@Column({ type: "varchar", array: true })
	tags?: string[];

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt: Date;

	@ApiProperty()
	@UpdateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)", onUpdate: "CURRENT_TIMESTAMP(6)" })
	updatedAt?: Date;
}

@Entity()
export class LeadStatusUpdates {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id?: number;

	@ApiProperty()
	@PrimaryColumn({ type: "integer" })
	poiId: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	tokenUserId?: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	apiKeyUserId?: number;

	@ApiProperty()
	@Column({ nullable: true })
	status: string;

	@ApiProperty()
	@Column({ nullable: true })
	visited: boolean;

	@ApiProperty()
	@Column({ nullable: true })
	remarks?: string;

	@ApiProperty()
	@Column({ nullable: true })
	comment?: string;

	@ApiProperty()
	@Column({ type: "varchar", array: true })
	tags?: string[];

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt?: Date;
}

@Entity()
export class LostLead {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column({ type: "integer" })
	poiId: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	tokenUserId?: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	apiKeyUserId?: number;

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt: Date;
}
