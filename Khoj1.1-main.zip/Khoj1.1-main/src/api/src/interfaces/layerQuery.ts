import { ApiProperty } from "@nestjs/swagger";
import { Poi, PoiStatus } from "src/poi/poi.entity";
export class LayerQuery {
	@ApiProperty()
	city: string;

	@ApiProperty()
	landmark: string;

	@ApiProperty()
	pincode: number;

	@ApiProperty()
	limit: number;

	@ApiProperty()
	page: number;

	@ApiProperty()
	types: string[];
}

