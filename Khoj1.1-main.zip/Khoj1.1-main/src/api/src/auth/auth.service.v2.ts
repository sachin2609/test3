import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { TeamService } from "src/team/team.service";
import { User } from "src/users/users.entity";
import * as bcrypt from "bcrypt";
import { JwtService } from "@nestjs/jwt";
import { InjectRepository } from "@nestjs/typeorm";
import { UserOtp } from "src/users/user-otp.entity";
import { Repository } from "typeorm";
import { MailerService } from "@nestjs-modules/mailer";
import { getOTPMailTemplate } from "src/helpers/email-templates/otp-email-template";
import axios from "axios";

enum UserError {
	USER_NOT_FOUND = "User Not Found",
	UNAUTHORIZED_USER = "Unauthorized User",
	UNVERIFIED_USER = "Unverified User",
}

@Injectable()
export class AuthServiceV2 {
	saltRounds = 10;
	timeOutInMins = 5;
	constructor(
		@InjectRepository(UserOtp) private userOtpRepository: Repository<UserOtp>,
		private teamService: TeamService,
		private jwtService: JwtService,
		private mailerService: MailerService,
	) {}

	async generateUserJWT(user: Partial<User>): Promise<string> {
		const { googleAccessToken, password, createdAt, updatedAt, createdBy, updatedBy, ...tempUser } = user;
		Object.assign(tempUser, {
			type: "token",
		});
		const token = await this.jwtService.signAsync(tempUser, {
			expiresIn: parseInt(process.env.JWT_EXPIRY),
		});
		return token;
	}

	async generateAppUserJWT(user: Partial<User>): Promise<string> {
		const { googleAccessToken, password, createdAt, updatedAt, createdBy, updatedBy, ...tempUser } = user;
		Object.assign(tempUser, {
			type: "token",
		});
		const timeOut = process?.env?.JWT_EXPIRY_FOR_APP;
		const token = await this.jwtService.signAsync(tempUser, {
			expiresIn: parseInt(timeOut ?? "3600s"),
		});
		return token;
	}

	async checkUserSanity(email?: string, phoneNumber?: string): Promise<{ error?: UserError; existingUser?: User }> {
		if (!email && !phoneNumber) throw new HttpException("Email or Phone Number Required", HttpStatus.BAD_REQUEST);
		const users = await this.teamService.getUsers(null, null, null, email, phoneNumber);
		const user = users?.[0];
		if (!user) return { error: UserError.USER_NOT_FOUND };
		if (!user.isAuthorized) return { error: UserError.UNAUTHORIZED_USER, existingUser: user };
		return { existingUser: user };
	}

	async userSignUp(user: Partial<User>): Promise<string> {
		const { email, phoneNumber, firstName, lastName, password } = user;
		const { error, existingUser } = await this.checkUserSanity(email, phoneNumber);
		const hashedPassword = await bcrypt.hash(password, this.saltRounds);
		if (error === UserError.USER_NOT_FOUND) {
			try {
				await this.teamService.createUser({
					email,
					phoneNumber,
					firstName,
					lastName,
					password: hashedPassword,
				});
				return "New User Registered!";
			} catch (err) {
				console.error(err);
				throw new HttpException("Cannot Register User", HttpStatus.SERVICE_UNAVAILABLE);
			}
		}
		if (existingUser?.password?.length) {
			throw new HttpException("User Already Exists", HttpStatus.CONFLICT);
		} else {
			try {
				await this.teamService.updateUser({ id: existingUser.id, password: hashedPassword }, existingUser.id);
				return "Existing User Updated!";
			} catch (err) {
				console.error(err);
				throw new HttpException("Cannot Register User", HttpStatus.SERVICE_UNAVAILABLE);
			}
		}
	}

	async userSignIn(email: string, phoneNumber: string, password: string): Promise<string> {
		const { error, existingUser } = await this.checkUserSanity(email, phoneNumber);
		if (error === UserError.USER_NOT_FOUND) throw new HttpException("User Not Found", HttpStatus.BAD_REQUEST);
		if (error === UserError.UNAUTHORIZED_USER)
			throw new HttpException("Unauthorized User!", HttpStatus.UNAUTHORIZED);
		if (error === UserError.UNVERIFIED_USER) throw new HttpException("Unverified User!", HttpStatus.UNAUTHORIZED);
		if (!existingUser.password) throw new HttpException("Password Not Set", HttpStatus.UNAUTHORIZED);
		const isPasswordCorrect = await bcrypt.compare(password, existingUser.password);
		if (!isPasswordCorrect) throw new HttpException("Incorrect Password", HttpStatus.UNAUTHORIZED);
		return await this.generateUserJWT(existingUser);
	}

	isOTPStale(userOTP: UserOtp): boolean {
		if (!userOTP?.updatedAt) return true;
		const currentTime = new Date();
		const timeDiffInMins = (currentTime.getTime() - userOTP.updatedAt.getTime()) / 1000 / 60;
		return timeDiffInMins > this.timeOutInMins;
	}

	async sendUserVerificationOTP(email: string, phoneNumber: string): Promise<string | number> {
		const { error, existingUser } = await this.checkUserSanity(email, phoneNumber);
		if (error === UserError.USER_NOT_FOUND) throw new HttpException("User Not Found", HttpStatus.BAD_REQUEST);
		if (error === UserError.UNAUTHORIZED_USER)
			throw new HttpException("Unauthorized User! Please contact Admin!", HttpStatus.UNAUTHORIZED);
		const userOTP = await this.userOtpRepository.findOne({ where: { userId: existingUser.id } });
		const isOTPStale = this.isOTPStale(userOTP);
		if (!isOTPStale) throw new HttpException("OTP Already Sent!", HttpStatus.CONFLICT);
		const OTP = Math.floor(100000 + Math.random() * 900000);
		try {
			await this.userOtpRepository.save({ userId: existingUser.id, otp: OTP });
		} catch (err) {
			console.error(err);
			throw new HttpException("Cannot Send OTP", HttpStatus.SERVICE_UNAVAILABLE);
		}
		try {
			const message = existingUser?.email
				? await this.sendOTPMail(existingUser, OTP)
				: await this.sendOTPSMS(existingUser, OTP);
			return message;
		} catch (err) {
			throw new HttpException("Cannot Send OTP", HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async verifyUserOTP(email: string, phoneNumber: string, otp: number): Promise<boolean> {
		if (!otp) throw new HttpException("OTP Required!", HttpStatus.BAD_REQUEST);
		const { error, existingUser } = await this.checkUserSanity(email, phoneNumber);
		if (error === UserError.USER_NOT_FOUND) throw new HttpException("User Not Found!", HttpStatus.BAD_REQUEST);
		if (error === UserError.UNAUTHORIZED_USER)
			throw new HttpException("Unauthorized User! Please contact Admin.", HttpStatus.UNAUTHORIZED);
		const userOTP = await this.userOtpRepository.findOne({ where: { userId: existingUser.id } });
		if (!userOTP?.otp) throw new HttpException("OTP Not Found!", HttpStatus.BAD_REQUEST);
		const isOTPStale = this.isOTPStale(userOTP);
		if (userOTP.otp !== otp) throw new HttpException("Incorrect OTP!", HttpStatus.UNAUTHORIZED);
		if (isOTPStale) throw new HttpException("OTP Expired!", HttpStatus.UNAUTHORIZED);
		await this.teamService.updateUser({ id: existingUser.id, isVerified: true }, existingUser.id);
		return true;
	}

	async resetUserPassword(email: string, phoneNumber: string, password: string, otp: number): Promise<void> {
		const { error, existingUser } = await this.checkUserSanity(email, phoneNumber);
		if (error === UserError.USER_NOT_FOUND) throw new HttpException("User Not Found", HttpStatus.NOT_FOUND);
		if (error === UserError.UNAUTHORIZED_USER)
			throw new HttpException("Unauthorized User! Please contact Admin!", HttpStatus.UNAUTHORIZED);
		if (error === UserError.UNVERIFIED_USER) throw new HttpException("Unverified User!", HttpStatus.UNAUTHORIZED);
		const isValidOTP = await this.verifyUserOTP(email, phoneNumber, otp);
		if (!isValidOTP) throw new HttpException("Invalid OTP", HttpStatus.UNAUTHORIZED);
		const hashedPassword = await bcrypt.hash(password, this.saltRounds);
		await this.teamService.updateUser({ id: existingUser.id, password: hashedPassword }, existingUser.id);
		await this.userOtpRepository.delete({ userId: existingUser.id });
	}

	async sendOTPMail(user: User, otp: number): Promise<string> {
		const htmlForUser = getOTPMailTemplate(user.firstName, user.lastName, otp);
		return await this.mailerService
			.sendMail({
				to: user.email, // list of receivers
				from: process.env.MAILDEV_INCOMING_USER, // sender address
				subject: "Data Sutram | OTP", // Subject line
				text: "Verify :", // plaintext body
				html: htmlForUser, // HTML body content
			})
			.then(() => {
				return "OTP Mail Sent Successfully";
			})
			.catch((err) => {
				console.error("Error in sending mail", err);
				throw new Error("Error in sending mail" + err);
			});
	}

	async sendOTPSMS(user: User, otp: number): Promise<number> {
		return otp;
	}

	async appLogin(query: { phoneNumber: string; code: string }) {
		if (!query.phoneNumber || !query.code)
			throw new HttpException(`'phoneNumber' and 'code' required!`, HttpStatus.BAD_REQUEST);
		const config = {
			method: "POST",
			maxBodyLength: Infinity,
			url: process.env.CENTRAL_SERVER_URL + `/app-user/validate`,
			headers: {
				"Content-Type": "application/json",
			},
			data: query,
		};
		const res: { data: { domain: string; ssoProvider: string; logo: string } } = await (async () => {
			try {
				return await axios(config);
			} catch (err) {
				console.error(err);
				throw new HttpException(
					`Incorrect Credentials - ${err.response.data.message}`,
					HttpStatus.SERVICE_UNAVAILABLE,
				);
			}
		})();
		if (!res?.data) throw new HttpException(`Incorrect PhoneNumber or Code!`, HttpStatus.SERVICE_UNAVAILABLE);
		const appDomain = String(res.data.domain)
			?.split("/")
			?.filter((x) => x.includes("."))?.[0];
		const serverDomain = String(process.env.FRONTEND_LOGIN_URL)
			?.split("/")
			?.filter((x) => x.includes("."))?.[0];
		// if (appDomain != serverDomain) throw new HttpException(`URLs mismatch!`, HttpStatus.FORBIDDEN);
		const { error, existingUser } = await this.checkUserSanity(null, query.phoneNumber);
		if (error === UserError.USER_NOT_FOUND) throw new HttpException("User Not Found", HttpStatus.BAD_REQUEST);
		if (error === UserError.UNAUTHORIZED_USER)
			throw new HttpException("Unauthorized User!", HttpStatus.UNAUTHORIZED);
		if (error === UserError.UNVERIFIED_USER) throw new HttpException("Unverified User!", HttpStatus.UNAUTHORIZED);
		return await this.generateAppUserJWT(existingUser);
	}

	async pwaLogin(query: { phoneNumber: string }) {
		const { phoneNumber } = query;
		if (!phoneNumber) throw new HttpException(`'phoneNumber' required!`, HttpStatus.BAD_REQUEST);
		if (!phoneNumber.match(/^\d{10}$/)) throw new HttpException(`Invalid 'phoneNumber'!`, HttpStatus.BAD_REQUEST);
		const { error, existingUser } = await this.checkUserSanity(null, query.phoneNumber);
		if (error === UserError.USER_NOT_FOUND) throw new HttpException("User Not Found", HttpStatus.BAD_REQUEST);
		if (error === UserError.UNAUTHORIZED_USER)
			throw new HttpException("Unauthorized User!", HttpStatus.UNAUTHORIZED);
		if (error === UserError.UNVERIFIED_USER) throw new HttpException("Unverified User!", HttpStatus.UNAUTHORIZED);
		return await this.generateAppUserJWT(existingUser);
	}
}
