import { Test, TestingModule } from "@nestjs/testing";
import { PropertyGridController } from "./property-grid.controller";

describe("PropertyGridController", () => {
	let controller: PropertyGridController;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			controllers: [PropertyGridController]
		}).compile();

		controller = module.get<PropertyGridController>(PropertyGridController);
	});

	it("should be defined", () => {
		expect(controller).toBeDefined();
	});
});
