import { Module } from "@nestjs/common";
import { PoiGridController } from "./poi-grid.controller";
import { PoiGridService } from "./poi-grid.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { PoiGrid } from "./poi-grid.entity";
@Module({
	imports: [TypeOrmModule.forFeature([PoiGrid])],
	controllers: [PoiGridController],
	providers: [PoiGridService]
})
export class PoiGridModule {}
