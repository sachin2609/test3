import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { UsersService } from "./users.service";
import { UsersController } from "./users.controller";
import { User } from "./users.entity";
import { TeamService } from "src/team/team.service";
import { Team } from "src/team/team.entity";
import { JwtModule } from "@nestjs/jwt";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
import { UserCredits } from "src/user-history/user-credits.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";

@Module({
	imports: [
		TypeOrmModule.forFeature([User, Team, UserCredits, UserApiUsageHistory]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
	],
	controllers: [UsersController],
	providers: [UsersService, TeamService, KeyCloakService, CentralServerService],
})
export class UsersModule {}
