import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { AppConfigsController } from "./app-configs.controller";
import { AppConfigs } from "./app-configs.entity";
import { AppConfigsService } from "./app-configs.service";
import { TeamService } from "src/team/team.service";
import { Team } from "src/team/team.entity";
import { User } from "src/users/users.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { JwtModule } from "@nestjs/jwt";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";

@Module({
	imports: [
		TypeOrmModule.forFeature([AppConfigs, Team, User, UserCredits]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
	],
	controllers: [AppConfigsController],
	providers: [AppConfigsService, TeamService, KeyCloakService, CentralServerService, SyslogService],
})
export class AppConfigsModule {}
