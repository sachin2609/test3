import {
	Body,
	Controller,
	Delete,
	Get,
	Headers,
	Param,
	Patch,
	Post,
	UploadedFile,
	UseInterceptors,
} from "@nestjs/common";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { Team } from "./team.entity";
import { TeamService } from "./team.service";
import { FileInterceptor } from "@nestjs/platform-express";

@Controller("team")
export class TeamController {
	constructor(private teamService: TeamService) {}

	@Roles(Role.CLIENT_ADMIN, Role.ADMIN, Role.TEAM_ADMIN)
	@Get()
	async getMyTeams(@Headers() headers) {
		const user = await this.teamService.decodeUserJWT(headers["token"]);
		const teams = await this.teamService.getTeams(null, [user.id]);
		const teamDTOs = await this.teamService.teamToTeamDTOs(teams);
		return {
			count: teamDTOs.length,
			data: teamDTOs,
		};
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN)
	@Get("all")
	async getTeams() {
		const teams = await this.teamService.getAllTeams();
		return {
			count: teams.length,
			data: teams,
		};
	}

	@Roles(Role.CLIENT_ADMIN, Role.ADMIN)
	@Post("create")
	async createTeam(@Headers() headers, @Body() body: Partial<Team>) {
		const user = await this.teamService.decodeUserJWT(headers["token"]);
		await this.teamService.createTeam(body, user.id);
		return { message: "Team Created Successfully!" };
	}

	@Roles(Role.CLIENT_ADMIN, Role.ADMIN)
	@Patch("update")
	async updateTeam(@Headers() headers, @Body() body: Partial<Team>) {
		const user = await this.teamService.decodeUserJWT(headers["token"]);
		await this.teamService.updateTeam(body, user.id);
		return { message: "Team Updated Successfully!" };
	}

	@Roles(Role.ADMIN)
	@Delete("delete/:id")
	async deleteTeam(@Param("id") id: number) {
		await this.teamService.deleteTeam(id);
		return { message: "Team Deleted Successfully!" };
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN, Role.TEAM_ADMIN)
	@Post("upload")
	@UseInterceptors(FileInterceptor("file"))
	async addTeams(@UploadedFile() file, @Headers() headers) {
		try {
			const user = await this.teamService.decodeUserJWT(headers["token"]);
			// Array to store the parsed CSV data
			const teams: Partial<Team>[] = ((await this.teamService.processCsv(file, "team")) as Partial<Team>[]).map(
				(u) => {
					const ownerId = Number(u.ownerId);
					return { ...u, isAuthorized: true, isVerified: true, onboardedCount: 0, ownerId: ownerId };
				},
			);
			const teamsNotNotAdded = await this.teamService.createMultipleTeams(teams, user.id);
			if (teamsNotNotAdded.length === teams.length) {
				return {
					message: "No Teams Added!",
					data: teamsNotNotAdded,
				};
			} else if (teamsNotNotAdded.length === 0) {
				return {
					message: "All Teams Added!",
				};
			} else {
				return {
					message: "Some Teams Added!",
					data: teamsNotNotAdded,
				};
			}
		} catch (error) {
			throw error;
		}
	}
}
