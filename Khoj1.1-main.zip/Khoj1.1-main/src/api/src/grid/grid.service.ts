import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { Repository, In } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Grid } from './grids.entity';
import * as fs from 'fs';
import * as geohash from 'ngeohash';
import { Indexmaster } from '../index-master/index-master.entity';
import * as _ from 'lodash';
import * as stats from 'stats-lite';
import { GridWithIndexRangesNew, Indexquery } from '../interfaces/grid';
import { PropertyGrid } from '../relations/property-grid/property-grid.entity';
import * as dotenv from 'dotenv';
import { InjectModel } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import { DemoShapesDB } from 'src/shape/shape.schema';
import { Shape } from 'src/shape/shape.entity';
import { Shapeindex } from 'src/shape/shapeIndex.entity';
import { ShapeService } from 'src/shape/shape.service';
import { LatLong } from 'src/interfaces/poi';
import { CoordinateAnalysisBody, PincodeAnalysisBody } from 'src/interfaces/analysis';
import * as mongo from 'mongodb';
const mongoClient = mongo.MongoClient;
dotenv.config();
const { fuzzy } = require('fast-fuzzy');

@Injectable()
export class GridService {
	constructor(
		@InjectModel('DemoShapesDB') private demoShapesDBModel: mongoose.Model<DemoShapesDB>,
		@InjectRepository(Grid) private gridsRepository: Repository<Grid>,
		@InjectRepository(Indexmaster) private indexMasterRepository: Repository<Indexmaster>,
		@InjectRepository(PropertyGrid) private propertGridRepository: Repository<PropertyGrid>,
		@InjectRepository(Shape) private shapesRepository: Repository<Shape>,
		@InjectRepository(Shapeindex) private shapeIndexRepository: Repository<Shapeindex>,
		private httpService: HttpService,
		private _shapeService: ShapeService
	) {}

	async create(): Promise<Grid[]> {
		const grids = JSON.parse(fs.readFileSync("./src/files/gridMasterIndex7.json", "utf-8"));
		grids.forEach(async grid => {
			await this.gridsRepository.save(grid);
		});
		return null;
		//return await this.gridsRepository.save(datas);
	}

	async nearestGrid(lat: number, long: number): Promise<unknown> {
		await this.gridsRepository.find();
		const hashed = geohash.encode(lat, long, 7);
		const max = {};
		max["value"] = 0;
		max["id"] = "";
		//grids.forEach(grid => {
		//const compared = this.similarity(grid.hash, hashed);
		//if (compared > max["value"]) {
		//max["value"] = compared;
		//max["id"] = grid.id;
		//}
		//});
		try {
			const grid = await this.gridsRepository.findOne({ where: { hash: hashed }});
			max["id"] = grid.id;
			max["value"] = 1;
			return max;
		} catch (error) {
			console.log(error);
			max["id"] = 0;
			max["value"] = 0.1;
			return max;
		}
		return max;
	}
	async populateGrids(): Promise<void> {
		const grids = geohash.bboxes(18.3923745, 72.744053, 19.275664, 73.016472, 7);
		for await (const eachGrid of grids) {
			const gridPresent = await this.gridsRepository.find({ where: { hash: eachGrid }});
			if (gridPresent.length) {
			} else {
				const tempGrid = new Grid();
				tempGrid.hash = eachGrid;
				tempGrid.State = "Maharashtra";
				tempGrid.City = "";
				tempGrid.Locality = "";

				await this.gridsRepository.save(tempGrid);
			}
		}
	}

	similarity(s1: string, s2: string, fastFuzzy:boolean): number {
		let longer = s1;
		let shorter = s2;
		if (s1.length < s2.length) {
			longer = s2;
			shorter = s1;
		}
		if(fastFuzzy === true) {
			return fuzzy(shorter,longer,{ normalizeWhitespace: true, ignoreCase: true, ignoreSymbols: true});
		} else {
			const longerLength = Number(longer.length);
			if (longerLength == 0) {
				return 1.0;
			}
			return (longerLength - this.editDistance(longer, shorter)) / longerLength;
		}
	}

	editDistance(s1: string, s2: string): number {
		s1 = s1.toLowerCase();
		s2 = s2.toLowerCase();

		const costs = [];
		for (let i = 0; i <= s1.length; i++) {
			let lastValue = i;
			for (let j = 0; j <= s2.length; j++) {
				if (i == 0) costs[j] = j;
				else {
					if (j > 0) {
						let newValue = costs[j - 1];
						if (s1.charAt(i - 1) != s2.charAt(j - 1))
							newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
						costs[j - 1] = lastValue;
						lastValue = newValue;
					}
				}
			}
			if (i > -1) costs[s2.length] = lastValue;
		}
		return costs[s2.length];
	}

	async getFilters(query){
		let cluster = {"type":"select","values": []};
		if(query["pincode"] && query["city"]) {
			throw new HttpException("Cant both query pincode and city",400);
		}
		if(query["pincode"]) {
			let values = [];
			console.log(query["pincode"]);
			const clusters = await this.gridsRepository
				.createQueryBuilder("grid")
				.select('"Cluster"')
				.where('"Pincode" = :pincode',{ pincode: String(query["pincode"]) })
				.distinct(true)
				.getRawMany();
			//console.log(clusters);
			await Promise.all(clusters.map(eachObj => {
				if(String(eachObj["Cluster"]) != "-1") {
					values.push(String(eachObj["Cluster"]));
				} else {
					console.log("Cluster = -1 found...Rejected !")
				}
			}));
			cluster["values"] = values;
		}
		if(query["city"]) {
			console.log("Here in CITY");
			let values = [];
			console.log(query["city"]);
			const clusters = await this.gridsRepository
				.createQueryBuilder("grid")
				.select('"Cluster"')
				.where('"City" = :city',{ city: String(query["city"]) })
				.distinct(true)
				.getRawMany();
			//console.log(clusters);
			await Promise.all(clusters.map(eachObj => {
				if(String(eachObj["Cluster"]) != "-1") {
					values.push(String(eachObj["Cluster"]));
				} else {
					console.log("Cluster = -1 found...Rejected !")
				}
			}));
			cluster["values"] = values;
		}
		/*if(! query["location"]) {
			throw new HttpException({
				status: HttpStatus.BAD_REQUEST,
				error: "Request body must contain 'location'"
			},HttpStatus.BAD_REQUEST);
		}
		let gridsSearchedArr = [];
		if (query["location"]) {
			const locationQueryObject = {};
			let locationQueryString = "";
			Object.keys(query["location"]).forEach((location, index) => {
				if (index === 0) {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += "grid." + location + " = :" + location;
				} else {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += " AND grid." + location + " = :" + location;
				}
			});
			if (Object.keys(locationQueryObject).length) {
				try {
					const locationGrids = await getRepository(Grid)
						.createQueryBuilder("grid")
						.select("grid.id")
						.where(locationQueryString, locationQueryObject)
						.getMany();
					const locationGridIds = await locationGrids.map(eachGrid => {
						return eachGrid.id;
					});
					gridsSearchedArr.push(locationGridIds);
				} catch (error) {
					console.log(error);
				}
			}
		}
		gridsSearchedArr = _.flattenDeep(gridsSearchedArr) as number[];
		const filters = await getRepository(Indexmaster)
			.createQueryBuilder("indexmaster")
			.where('"gridId" IN(:...gridIds)',{gridIds : gridsSearchedArr})
			.distinctOn(["indexmaster.indexName"])
			.select("indexmaster.indexName")
			.getMany();*/

    //const gridsFilter = {};
    //const rangedKeys = [
    //"demand",
    //"pharmacyCount",
    //"societyCount",
    //"societyDemand",
    //"affluence",
    //"affluenceClass",
    //"population"
    //];
    //const grids = await this.gridsRepository.find();
    //rangedKeys.forEach(eachGridKey => {
    //gridsFilter[eachGridKey] = {};
    //gridsFilter[eachGridKey]["min"] = 1000;
    //gridsFilter[eachGridKey]["max"] = 0;
    //});
    //grids.forEach(eachGrid => {
    //rangedKeys.forEach(eachKey => {
    //if (eachGrid[eachKey] < gridsFilter[eachKey]["min"]) {
    //gridsFilter[eachKey]["min"] = eachGrid[eachKey];
    //}
    //if (eachGrid[eachKey] > gridsFilter[eachKey]["max"]) {
    //gridsFilter[eachKey]["max"] = eachGrid[eachKey];
    //}
    //});
    //});
    //return gridsFilter as JSON;
    const response = {};
    let filtersForNumberType = [];
    if (query?.['keys']?.length) {
      filtersForNumberType = await this.indexMasterRepository
        .createQueryBuilder('indexmaster')
        .where(`"indexType" = 'number'`)
        .andWhere(`"indexName" IN(:...keys)`, { keys: query['keys'] as string[] })
        .select(['"indexName"', '"indexType"'])
        .distinctOn(['indexmaster.indexName'])
        .getRawMany();
    } else {
      filtersForNumberType = await this.indexMasterRepository
        .createQueryBuilder('indexmaster')
        .where(`"indexType" = 'number'`)
        .select(['"indexName"', '"indexType"'])
        .distinctOn(['indexmaster.indexName'])
        .getRawMany();
    }
    console.log('calculating...');
    await Promise.all(
      filtersForNumberType.map(async (eachFilter) => {
        const MaxMin = { /* max: maxMin.max, min: maxMin.min ,*/ type: 'range' };
        response[eachFilter.indexName] = MaxMin;
      })
    );
    let filtersForOtherType = [];
    if (query?.['keys']?.length) {
      filtersForOtherType = await this.indexMasterRepository
        .createQueryBuilder('indexmaster')
        .where(`"indexType" = 'string'`)
        .andWhere(`"indexName" IN(:...keys)`, { keys: query['keys'] as string[] })
        .select(['"indexName"', '"indexType"', '"categoricalValue"', '"indexValue"'])
        .distinctOn(['indexmaster.indexName', 'indexmaster.categoricalValue'])
        .getRawMany();
    } else {
      filtersForOtherType = await this.indexMasterRepository
        .createQueryBuilder('indexmaster')
        .where(`"indexType" = 'string'`)
        .select(['"indexName"', '"indexType"', '"categoricalValue"', '"indexValue"'])
        .distinctOn(['indexmaster.indexName', 'indexmaster.categoricalValue'])
        .getRawMany();
    }
    const filterForStrWithGrpBy = _.chain(filtersForOtherType)
      .groupBy('indexName')
      .map((value, key) => ({ indexName: key, data: value }))
      .value();
    console.log('HAHA:', filterForStrWithGrpBy);
    await Promise.all(
      filterForStrWithGrpBy.map(async (eachObj) => {
        const maxMin = { type: 'select' };
        const sortedCategoricalValues = _.sortBy(eachObj['data'], 'indexValue');
        maxMin['values'] = await sortedCategoricalValues.map((eachCategory) => {
          return eachCategory['categoricalValue'];
        });
        response[eachObj.indexName] = maxMin;
      })
    );
    response['cluster'] = cluster;
    console.log('returning object', response);
    return response as JSON;
    /*
		let localities = await getRepository(Grid)
			.createQueryBuilder("grid")
			.select("grid.Locality")
			.distinct(true)
			.getRawMany();
		localities = localities.map(eachWard => {
			return eachWard.grid_Locality;
		});
		let cities = await getRepository(Grid)
			.createQueryBuilder("grid")
			.select("grid.City")
			.distinct(true)
			.getRawMany();
		cities = cities.map(eachCity => {
			return eachCity.grid_City;
		});
		let states = await getRepository(Grid)
			.createQueryBuilder("grid")
			.select("grid.State")
			.distinct(true)
			.getRawMany();
		states = states.map(eachCity => {
			return eachCity.grid_State;
		});*/
		//const returnFilters = {};
		/*
		maxMinValues.forEach(eachDict => {
			returnFilters[Object.keys(eachDict)[0]] = eachDict[Object.keys(eachDict)[0]];
		});/*
		returnFilters["States"] = states;
		returnFilters["Cities"] = cities;
		returnFilters["Localities"] = localities;*/
		
	}

	async generateLatLong(): Promise<void> {
		const grids = await this.gridsRepository.find();
		for await (const eachGrid of grids) {
			const latlng = geohash.decode(eachGrid.hash);
			eachGrid.latitude = latlng.latitude;
			eachGrid.longitude = latlng.longitude;
			await this.gridsRepository.save(eachGrid);
		}
	}
	percentRank(arr: number[], v: number): number {
		//if (typeof v !== "number") throw new TypeError("v must be a number");
		for (let i = 0, l = Number(arr.length); i < l; i++) {
			if (v <= arr[i]) {
				while (i < l && v === arr[i]) i++;
				if (i === 0) return 0;
				if (v !== arr[i - 1]) {
					i += (v - arr[i - 1]) / (arr[i] - arr[i - 1]);
				}
				return i / l;
			}
		}
		return 1;
	}

	async getAggrigation(responseIds: number[] , query, metrics?: boolean) { 
		if(responseIds.length == 0) {
			return {"count": 0};
		}
		if(query["responseType"] == "count") {
			responseIds = [...new Set(responseIds)];
			const count = responseIds.length; /*
			const count = await this.gridsRepository.count({
				where: { id: In(responseIds) }
			});*/
			const response = {"count": count};
			if(query["requiredShapes"] == true) {
				response["shapes"] = [];
				const Level = Object.keys(query["location"])[0].toLowerCase();
				const LevelName = String(query["location"][Object.keys(query["location"])[0]]).toLowerCase();
				console.log("Level :"+Level+" LevelName :"+LevelName);
				/*
				const Query = 'shape."'+Level+'" = '+"'"+LevelName+"'";
				console.log(Query);
				let finalObjects: any[] = await this.shapesRepository.createQueryBuilder("shape")
					.where(Query)
					.distinct(true)
					.getMany();
				console.log("ObjectIds :",finalObjects);
				finalObjects = [{objectId: '"60544962c8fed19c2a72381d"'} , {objectId: '"60544962c8fed19c2a72381c"'}];
				let finalObjectIdsFromPostgres:mongoose.ObjectId[] = [];
				await Promise.all(finalObjects.map(eachObject => {
					let newObjectIdString = String(eachObject.objectId.slice(1,-1));
					newObjectIdString =String('"'+newObjectIdString+'"');
					console.log(newObjectIdString)
					//finalObjectIdsFromPostgres.push(new ObjectId(newObjectIdString));
					finalObjectIdsFromPostgres.push(new mongoose.Types.ObjectId(newObjectIdString));
				}));
				console.log("bdjkbc :",finalObjectIdsFromPostgres);*/
				const shapesFromMongoReturned = await this.demoShapesDBModel.find({ where: {
					level : Level , name: String(LevelName)
			}});
				console.log("random query test", await this.demoShapesDBModel.findOne());
				console.log("Shapes :",shapesFromMongoReturned);
				response["shapes"] = shapesFromMongoReturned;
			}
			return response;
		}
		else if(metrics === true) {
			console.log("HEREHEREHERE");
			responseIds = [...new Set(responseIds)];
			const count = responseIds.length;
			console.log("Length of ResponseIds :",count);
			let finalResponse = {};
			finalResponse["count"] = count;
			finalResponse["data"] = [];
			if(query["locationIndex"]) {
				await Promise.all(Object.keys(query["locationIndex"]).map(async eachKey => {
					try {
						const indexMaster = await this.indexMasterRepository
							.createQueryBuilder("indexmaster")
							.select(['"indexValue"','metrics'])
							.where('"indexName" = :indexName AND "gridId" IN(:...gridIds)',{indexName: eachKey, gridIds: responseIds})
							.getRawMany();
						const indexValues = await Promise.all(indexMaster.map(eachIndexMaster => {
							return Number(eachIndexMaster["indexValue"]);
						}));
						if(query["locationIndex"][eachKey] == "mean") {
							const mean = stats.mean(indexValues);
							let tempObj = {};
							tempObj["value"] = mean;
							tempObj["unit"] = indexMaster[0]["metrics"];
							const resObj = {"key": eachKey ,"value": tempObj ,"aggregationType": "mean", "indexType": "locationIndex"};
							finalResponse["data"].push(resObj);
						}
						if(query["locationIndex"][eachKey] == "median") {
							const median = stats.median(indexValues);
							let tempObj = {};
							tempObj["value"] = median;
							tempObj["unit"] = indexMaster[0]["metrics"];
							const resObj = {"key": eachKey ,"value": tempObj ,"aggregationType": "median", "indexType": "locationIndex"};
							finalResponse["data"].push(resObj);
						}
						if(query["locationIndex"][eachKey] == "mode") {
							let mode; 
							mode = stats.mode(indexValues);
							if (typeof mode != "number"){
									mode = Array.from(mode);
							}
							console.log(mode);
							let tempObj = {};
							tempObj["value"] = mode;
							tempObj["unit"] = indexMaster[0]["metrics"];
							const resObj = {"key": eachKey ,"value": tempObj ,"aggregationType": "mode", "indexType": "locationIndex"};
							finalResponse["data"].push(resObj);
						}
						if(query["locationIndex"][eachKey] == "sum") {
							const sum = stats.sum(indexValues);
							let tempObj = {};
							tempObj["value"] = sum;
							tempObj["unit"] = indexMaster[0]["metrics"];
							const resObj = {"key": eachKey ,"value": tempObj ,"aggregationType": "sum", "indexType": "locationIndex"};
							finalResponse["data"].push(resObj);
						}
						if(query["locationIndex"][eachKey] == "categorical") {
							if(indexValues.length >= 1) {
								//console.log("Aggrigation Type : categorical");
								const valuePairs = await this.indexMasterRepository
									.createQueryBuilder("indexmaster")
									.select(['"indexValue"','"categoricalValue"'])
									.where('"indexName" = :indexName',{indexName: eachKey})
									.distinct(true)
									.getRawMany();
								const values = valuePairs.map(eachObj => { return eachObj["indexValue"]});
								let resObj = {"key": eachKey ,"value":{} ,"aggregationType": "categorial", "indexType": "locationIndex"};
								await Promise.all(values.map(async eachVal => {
									let count = 0;
									await Promise.all(indexValues.map(val => {
										if(Number(val) == Number(eachVal)) {
											count = count +1;
										}
									}));
									const percent = count/indexValues.length * 100;
									let categorialValue;
									await Promise.all(valuePairs.map(eachObj => {
										if(eachObj["indexValue"] == eachVal) {
											categorialValue = eachObj["categoricalValue"]
										}
									}));
									let tempObj = {};
									tempObj["value"] = percent.toFixed(2);
									tempObj["unit"] = "Percentage";
									resObj["value"][categorialValue] = tempObj;
								}));
								finalResponse["data"].push(resObj);
							}
						}
						if(query["locationIndex"][eachKey] == "categorical-median") {
							const median = stats.median(indexValues);
                    	    //console.log("Aggrigation Type : Categorial-Median");
                    	    const valuePairs = await this.indexMasterRepository
                    	        .createQueryBuilder("indexmaster")
                    	        .select('"categoricalValue"')
                    	        .where('"indexName" = :indexName AND "indexValue" = :indexValue',{indexName: eachKey , indexValue: median})
                    	        .distinct(true)
                    	        .getRawMany();
							if(valuePairs.length > 0) {
								let tempObj = {};
								tempObj["value"] = valuePairs[0]["categoricalValue"];
								tempObj["unit"] = indexMaster[0]["metrics"];
								let resObj = {"key": eachKey ,"value": tempObj ,"aggregationType": "categorial-median", "indexType": "locationIndex"};
								finalResponse["data"].push(resObj);
							}
						}
					} catch(err) {
						console.log(err);
					}
				}));
			}
			if(query["requiredShapes"] == true) {
				finalResponse["shapes"] = [];
				const Level = Object.keys(query["location"])[0].toLowerCase();
				const LevelName = String(query["location"][Object.keys(query["location"])[0]]).toLowerCase();
				console.log("Level :"+Level+" LevelName :"+LevelName);
				/*
				const Query = 'shape."'+Level+'" = '+"'"+LevelName+"'";
				console.log(Query);
				let finalObjects: any[] = await this.shapesRepository.createQueryBuilder("shape")
					.where(Query)
					.distinct(true)
					.getMany();
				console.log("ObjectIds :",finalObjects);
				finalObjects = [{objectId: '"60544962c8fed19c2a72381d"'} , {objectId: '"60544962c8fed19c2a72381c"'}];
				let finalObjectIdsFromPostgres:mongoose.ObjectId[] = [];
				await Promise.all(finalObjects.map(eachObject => {
					let newObjectIdString = String(eachObject.objectId.slice(1,-1));
					newObjectIdString =String('"'+newObjectIdString+'"');
					console.log(newObjectIdString)
					//finalObjectIdsFromPostgres.push(new ObjectId(newObjectIdString));
					finalObjectIdsFromPostgres.push(new mongoose.Types.ObjectId(newObjectIdString));
				}));
				console.log("bdjkbc :",finalObjectIdsFromPostgres);*/
				const shapesFromMongoReturned = await this.demoShapesDBModel.find({ where: {
					level : Level , name: String(LevelName)
			}});
				finalResponse["shapes"] = shapesFromMongoReturned;
			}
			return finalResponse;
		}
		else if(query["responseType"] == "aggregation") {
			responseIds = [...new Set(responseIds)];
			const count = responseIds.length;
			console.log("Length of ResponseIds :",count);
			let finalResponse = {};
			finalResponse["count"] = count;
			finalResponse["data"] = [];
			if(query["locationIndex"]) {
				await Promise.all(Object.keys(query["locationIndex"]).map(async eachKey => {
					try {
						const indexMaster = await this.indexMasterRepository
							.createQueryBuilder("indexmaster")
							.select('"indexValue"')
							.where('"indexName" = :indexName AND "gridId" IN(:...gridIds)',{indexName: eachKey, gridIds: responseIds})
							.getRawMany();
						const indexValues = await Promise.all(indexMaster.map(eachIndexMaster => {
							return Number(eachIndexMaster["indexValue"]);
						}));
						if(query["locationIndex"][eachKey] == "mean") {
							const mean = stats.mean(indexValues);
							const resObj = {"key": eachKey ,"value": mean ,"aggregationType": "mean", "indexType": "locationIndex"};
							finalResponse["data"].push(resObj);
						}
						if(query["locationIndex"][eachKey] == "median") {
							const median = stats.median(indexValues);
							const resObj = {"key": eachKey ,"value": median ,"aggregationType": "median", "indexType": "locationIndex"};
							finalResponse["data"].push(resObj);
						}
						if(query["locationIndex"][eachKey] == "mode") {
							let mode; 
							mode = stats.mode(indexValues);
							if (typeof mode != "number"){
									mode = Array.from(mode);
							}
							console.log(mode);
							const resObj = {"key": eachKey ,"value": mode ,"aggregationType": "mode", "indexType": "locationIndex"};
							finalResponse["data"].push(resObj);
						}
						if(query["locationIndex"][eachKey] == "sum") {
							const sum = stats.sum(indexValues);
							const resObj = {"key": eachKey ,"value": sum ,"aggregationType": "sum", "indexType": "locationIndex"};
							finalResponse["data"].push(resObj);
						}
						if(query["locationIndex"][eachKey] == "categorical") {
							//console.log("Aggrigation Type : categorical");
							const valuePairs = await this.indexMasterRepository
								.createQueryBuilder("indexmaster")
								.select(['"indexValue"','"categoricalValue"'])
								.where('"indexName" = :indexName',{indexName: eachKey})
								.distinct(true)
								.getRawMany();
							const values = valuePairs.map(eachObj => { return eachObj["indexValue"]});
							let resObj = {"key": eachKey ,"value":{} ,"aggregationType": "categorial", "indexType": "locationIndex"};
							await Promise.all(values.map(async eachVal => {
								let count = 0;
								await Promise.all(indexValues.map(val => {
									if(Number(val) == Number(eachVal)) {
										count = count +1;
									}
								}));
								const percent = count/indexValues.length * 100;
								let categorialValue;
								await Promise.all(valuePairs.map(eachObj => {
									if(eachObj["indexValue"] == eachVal) {
										categorialValue = eachObj["categoricalValue"]
									}
								}));
								resObj["value"][categorialValue] = percent.toFixed(2);
							}));
							finalResponse["data"].push(resObj);
						}
						if(query["locationIndex"][eachKey] == "categorical-median") {
							const median = stats.median(indexValues);
                    	    //console.log("Aggrigation Type : Categorial-Median");
                    	    const valuePairs = await this.indexMasterRepository
                    	        .createQueryBuilder("indexmaster")
                    	        .select('"categoricalValue"')
                    	        .where('"indexName" = :indexName AND "indexValue" = :indexValue',{indexName: eachKey , indexValue: median})
                    	        .distinct(true)
                    	        .getRawMany();
							if(valuePairs.length > 0) {
								let resObj = {"key": eachKey ,"value":valuePairs[0]["categoricalValue"] ,"aggregationType": "categorial-median", "indexType": "locationIndex"};
								finalResponse["data"].push(resObj);
							}
						}
					} catch(err) {
						console.log(err);
					}
				}));
			}
			if(query["requiredShapes"] == true) {
				finalResponse["shapes"] = [];
				const Level = Object.keys(query["location"])[0].toLowerCase();
				const LevelName = String(query["location"][Object.keys(query["location"])[0]]).toLowerCase();
				console.log("Level :"+Level+" LevelName :"+LevelName);
				/*
				const Query = 'shape."'+Level+'" = '+"'"+LevelName+"'";
				console.log(Query);
				let finalObjects: any[] = await this.shapesRepository.createQueryBuilder("shape")
					.where(Query)
					.distinct(true)
					.getMany();
				console.log("ObjectIds :",finalObjects);
				finalObjects = [{objectId: '"60544962c8fed19c2a72381d"'} , {objectId: '"60544962c8fed19c2a72381c"'}];
				let finalObjectIdsFromPostgres:mongoose.ObjectId[] = [];
				await Promise.all(finalObjects.map(eachObject => {
					let newObjectIdString = String(eachObject.objectId.slice(1,-1));
					newObjectIdString =String('"'+newObjectIdString+'"');
					console.log(newObjectIdString)
					//finalObjectIdsFromPostgres.push(new ObjectId(newObjectIdString));
					finalObjectIdsFromPostgres.push(new mongoose.Types.ObjectId(newObjectIdString));
				}));
				console.log("bdjkbc :",finalObjectIdsFromPostgres);*/
				const shapesFromMongoReturned = await this.demoShapesDBModel.find({ where: {
					level : Level , name: String(LevelName)
			}});
				finalResponse["shapes"] = shapesFromMongoReturned;
			}
			return finalResponse;
		}	
	}

  async search(query: JSON): Promise<Grid[] | unknown> {
    /*
		if(! query["location"]) {
			throw new HttpException({
				status: HttpStatus.BAD_REQUEST,
				error: "Request must contain 'location'"
			},HttpStatus.BAD_REQUEST);
		}*/
		//For WFSL
		/*
		if(query["location"] && query["within"]) {
			delete query["location"];
		}*/
    const gridsSearchedArr = [];
    if (query['grids'] || query['location'] || query['within'] || query['cluster']) {
      if (query['grids']) {
        if (query['grids']['range']) {
          if (Object.keys(query['grids']['range']).length) {
            await Promise.all(
              Object.keys(query['grids']['range']).map(async (eachKey) => {
                console.log('eachRanged key');
                let gridsQueryString = '';
                const gridsQueryObject = {};
                gridsQueryString +=
                  'indexmaster."indexName" = :' +
                  eachKey +
                  'name AND indexmaster."indexValue" BETWEEN :' +
                  eachKey +
                  'min AND :' +
                  eachKey +
                  'max';
                gridsQueryObject[eachKey + 'min'] = query['grids']['range'][eachKey]['min'];
                gridsQueryObject[eachKey + 'max'] = query['grids']['range'][eachKey]['max'];
                gridsQueryObject[eachKey + 'name'] = eachKey;
                try {
                  const response = await this.gridsRepository
                    .createQueryBuilder('grid')
                    .leftJoinAndSelect('grid.indexmaster', 'indexmaster')
                    .where(gridsQueryString, gridsQueryObject)
                    .select('grid.id')
                    .getMany();
                  const gridIds = response.map((eachResp) => {
                    return eachResp.id;
                  });
                  gridsSearchedArr.push(gridIds);
                  return gridIds;
                } catch (error) {
                  console.error(error);
                  return [];
                }
              })
            );
          }
        }
        if (query['grids']['select']) {
          if (Object.keys(query['grids']['select']).length) {
            await Promise.all(
              Object.keys(query['grids']['select']).map(async (eachKey) => {
                console.log('eachSelect key', eachKey);
                try {
                  const someIndexes = await this.indexMasterRepository
                    .createQueryBuilder('indexmaster')
                    .select('indexmaster."gridId"')
                    .where('indexmaster."indexName" = :indexName', { indexName: eachKey })
                    .andWhere('indexmaster."categoricalValue" IN (:...categoricalValues)', {
                      categoricalValues: query['grids']['select'][eachKey],
                    })
                    .getRawMany();
                  const gridIds = someIndexes.map((eachIndex) => {
                    return eachIndex['gridId'];
                  });
                  gridsSearchedArr.push(_.flattenDeep(gridIds));
                  return gridIds;
                } catch (error) {
                  console.log(error);
                  return [];
                }
              })
            );
            console.log('gridsSelectResponse', gridsSearchedArr);
          }
        }
      }
      if (query['location']) {
        const locationQueryObject = {};
        let locationQueryString = '';
        Object.keys(query['location']).forEach((location, index) => {
          if (index === 0) {
            locationQueryObject[location] = query['location'][location];
            locationQueryString += 'grid.' + location + ' = :' + location;
          } else {
            locationQueryObject[location] = query['location'][location];
            locationQueryString += ' AND grid.' + location + ' = :' + location;
          }
        });
        if (Object.keys(locationQueryObject).length) {
          try {
            const locationGrids = await this.gridsRepository
              .createQueryBuilder('grid')
              .select('grid.id')
              .where(locationQueryString, locationQueryObject)
              .getMany();
            const locationGridIds = await locationGrids.map((eachGrid) => {
              return eachGrid.id;
            });
            gridsSearchedArr.push(locationGridIds);
          } catch (error) {
            console.log(error);
          }
        }
      }
      if (query['within']) {
        let distance = query['within']['radius'];
        distance = distance;
        const withinGridsArr: number[][] = await Promise.all(
          query['within']['points'].map(async (eachLatLong) => {
            //const eachTarget = await this.gridsRepository.findOne({ id: eachId });
            /*
						const point = tf.point([eachpoint.lat,eachpoint.lng]);
						const topLeft = tf.destination(point, distance, angleA);
						const bottomRight = tf.destination(point, distance, angleB);
						const withinGrids = geohash.bboxes(
							topLeft["geometry"]["coordinates"][0],
							topLeft["geometry"]["coordinates"][1],
							bottomRight["geometry"]["coordinates"][0],
							bottomRight["geometry"]["coordinates"][1],
							7
						);
						*/
            //const eachTarget = await this.propertyRepository.findOne({ id: eachId });
            //const point = tf.point([eachTarget.latitude, eachTarget.longitude]);
            //new try
            const pi = Math.PI;
            const lat_increment = 1 / 110.574;
            const lng_increment = 1 / 111.32;
            const lat_max = Number(eachLatLong.lat) + distance * lat_increment;
            const lat_min = Number(eachLatLong.lat) - distance * lat_increment;
            const lng_max =
              Number(eachLatLong.lng) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
            const lng_min =
              Number(eachLatLong.lng) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
            const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
            try {
              const tempGrid = await this.gridsRepository
                .createQueryBuilder('grid')
                .where('grid.hash IN (:...hashes)', { hashes: withinGrids })
                .select('grid.id')
                .getMany();

							const tempGridIds = tempGrid.map(eachGrid => {
								return eachGrid.id;
							});
							return tempGridIds;
						} catch (error) {
							console.log("error is", error);
							return null;
						}
					})
				);
				const tempGrids = _.flattenDeep(withinGridsArr);
				gridsSearchedArr.push(tempGrids);
			}
			if(query["cluster"]) {
				let tempGrids = [];
				console.log("Here");
				const Grids = await this.gridsRepository.find({ where: {Cluster: query["cluster"] }});
				//console.log("Length : ",tempGrids.length);
				await Promise.all(Grids.map(eachGrid => {
					tempGrids.push(eachGrid.id);
				}));
				gridsSearchedArr.push(tempGrids);
			}
		}
		let responseIds = [];
		gridsSearchedArr.forEach((eachArr, index) => {
			if (index === 0) {
				responseIds = eachArr;
			} else {
				responseIds = _.intersection(responseIds, eachArr);
			}
		});
		try {
			if(query["responseType"] == "count") {
				return await this.getAggrigation(responseIds , query);
			} 
			else if(query["responseType"] == "aggregation") {
				return await this.getAggrigation(responseIds , query);
			}
			else if(responseIds.length > 10000) {
				let response = [];
				responseIds = _.chunk(responseIds,10000);
				await Promise.all(responseIds.map(async eachResponseIds => {
					const grids = await this.gridsRepository
						.createQueryBuilder("grid")
						.leftJoinAndSelect("grid.indexmaster", "indexmaster")
						.where("grid.id IN (:...gridIds)", { gridIds: eachResponseIds })
						.getMany();
					await Promise.all(
						grids.map(async eachGrid => {
							if (!eachGrid["index"]) {
								eachGrid["index"] = {};
							}
							eachGrid.indexmaster.forEach(eachIndex => {
								if (eachIndex.indexType === 'string') {
									eachGrid["index"][eachIndex.indexName] = eachIndex.categoricalValue;
								} else {
									let tempObj = {};
									tempObj["value"] = eachIndex.indexValue;
									tempObj["unit"] = eachIndex.metrics;
									eachGrid["index"][eachIndex.indexName] = eachIndex.indexValue;
								}
							});
							delete eachGrid.indexmaster;
						})
					);
					response.push(grids);
				}));
				response = _.flattenDeep(response);
				let resObj = {};
				resObj["count"] = response.length;
				resObj["data"] = [];
				await Promise.all(response.map(eachres => {
					eachres["geometry"] = {};
					eachres["geometry"]["type"] = "point";
					let coordinates: number[] = [];
					coordinates.push(Number(eachres["longitude"]));
					coordinates.push(Number(eachres["latitude"]));
					eachres["geometry"]["coordinates"] = coordinates;
					delete eachres["latitude"];
					delete eachres["longitude"];
					resObj["data"].push(eachres);
				}));
				return  resObj;
			}
			else {
				console.log("HERE");
				console.log("Length of ResponseIds :",responseIds.length);
				if(responseIds.length == 0) {
					responseIds = [0];
				}
				const grids = await this.gridsRepository
					.createQueryBuilder("grid")
					.leftJoinAndSelect("grid.indexmaster", "indexmaster")
					.where("grid.id IN (:...gridIds)", { gridIds: responseIds })
					.getMany();
				await Promise.all(
					grids.map(async eachGrid => {
						if (!eachGrid["index"]) {
							eachGrid["index"] = {};
						}
						eachGrid.indexmaster.forEach(eachIndex => {
							//console.log("index type is", eachIndex.indexType);
							if (eachIndex.indexType === 'string') {
								eachGrid["index"][eachIndex.indexName] = eachIndex.categoricalValue;
							} else {
								let tempObj = {};
								tempObj["value"] = eachIndex.indexValue;
								tempObj["unit"] = eachIndex.metrics;
								eachGrid["index"][eachIndex.indexName] = eachIndex.indexValue;
							}
						});
						delete eachGrid.indexmaster;
					})
				);
				let resObj = {};
				resObj["count"] = grids.length;
				resObj["data"] = [];
				await Promise.all(grids.map(eachres => {
					eachres["geometry"] = {};
					eachres["geometry"]["type"] = "point";
					let coordinates: number[] = [];
					coordinates.push(Number(eachres["longitude"]));
					coordinates.push(Number(eachres["latitude"]));
					eachres["geometry"]["coordinates"] = coordinates;
					delete eachres["latitude"];
					delete eachres["longitude"];
					resObj["data"].push(eachres);
				}));
				return  resObj;
				//return grids;
				//return grids;
				//For IndexRanges and IndexLockRanges
			}
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	gridFiltersCheck(grid: Grid, rangeKeys, selectKeys): boolean {
		for (let k of Object.keys(rangeKeys)) {
			let kval = grid.indexmaster?.filter(i => i.indexName === k)?.[0]?.indexValue;
			if (kval < rangeKeys[k]["min"] || kval > rangeKeys[k]["max"])
				return false;
		}
		for (let k of Object.keys(selectKeys)) {
			let kval = grid.indexmaster?.filter(i => i.indexName === k)?.[0]?.categoricalValue;
			if (kval?.length) {
				if (!selectKeys[k].includes(kval))
					return false;
			} else return false;
		}
		return true;
	}

  async optimized_search(query) {
    // Selecting all Grid IDs
    let radialGridsIds;
    let locationGridsIds;
    if (query['within'] || (query['location'] && query['without'])) {
      let latLongs: LatLong[] = [];
      latLongs = query?.['within']?.['points'] ?? query?.['without']?.['points'];
      let distance;
      if (query?.['within']?.['radius'] || query?.['within']?.['radius']) {
        distance = query['within']['radius'] ?? query['within']['radius'];
      } else distance = 0.5;
      const pi = Math.PI;
      const lat_increment = 1 / 110.574;
      const lng_increment = 1 / 111.32;
      const gridBBoxes = latLongs.map((latLng) => {
        const lat_max = latLng.lat + distance * lat_increment;
        const lat_min = latLng.lat - distance * lat_increment;
        const lng_max = latLng.lng + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
        const lng_min = latLng.lng - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
        return geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
      });
      const radialGridsArr = await Promise.all(
        gridBBoxes.map(async (bbox) => {
          try {
            const tempGrids = await this.gridsRepository
              .createQueryBuilder('grid')
              .where('grid.hash IN (:...hashes)', { hashes: bbox })
              .select('grid.id')
              .getMany();
            return tempGrids.map((g) => g.id);
          } catch (error) {
            return [];
          }
        })
      );
      radialGridsIds = _.flatten(radialGridsArr);
      console.log('Radial Grids = ', radialGridsIds?.length);
    }
    if (!query['within'] && query['location']) {
      const locationQueryObject = {};
      let locationQueryString = '';
      Object.keys(query['location']).forEach((location, index) => {
        if (index === 0) {
          locationQueryObject[location] = query['location'][location];
          locationQueryString += 'grid.' + location + ' = :' + location;
        } else {
          locationQueryObject[location] = query['location'][location];
          locationQueryString += ' AND grid.' + location + ' = :' + location;
        }
      });
      if (Object.keys(locationQueryObject).length) {
        try {
          const locationGrids = await this.gridsRepository
            .createQueryBuilder('grid')
            .select('grid.id')
            .where(locationQueryString, locationQueryObject)
            .getMany();
          locationGridsIds = locationGrids.map((g) => g.id);
          console.log('Grids in Location Search :', locationGridsIds.length);
        } catch (error) {
          console.log(error);
        }
      }
    }
    let radiallyFilteredGridIds;
    if (query['within']) {
      radiallyFilteredGridIds = radialGridsIds;
    } else if (query['location'] && query['without']) {
      radiallyFilteredGridIds = _.difference(locationGridsIds, radialGridsIds);
    } else if (query['location'] && !query['without']) {
      radiallyFilteredGridIds = locationGridsIds;
    } else radiallyFilteredGridIds = [];
    console.log('Radially Filtered Grids = ', radiallyFilteredGridIds?.length);

    const response = {
      count: 0,
      data: [],
      typeCount: {},
    };

    if (radiallyFilteredGridIds?.length) {
      const gridsChunkLength = 60000;
      const gridIndexDict = {};
      try {
        const gridIndexMasterArrs = await Promise.all(
          _.chunk(radiallyFilteredGridIds, gridsChunkLength).map(async (arr) => {
            return await this.gridsRepository
              .createQueryBuilder('grid')
              .leftJoinAndSelect('grid.indexmaster', 'indexmaster')
              .where('grid.id In (:...gridIds)', { gridIds: arr })
              .getMany();
          })
        );
        const rangeKeys = query?.['grids']?.['range'] ?? {};
        const selectKeys = query?.['grids']?.['select'] ?? {};
        console.log(rangeKeys, selectKeys);
        if (Object.keys(rangeKeys).length || Object.keys(selectKeys).length) {
          _.flatten(gridIndexMasterArrs).forEach((g: Grid) => {
            if (this.gridFiltersCheck(g, rangeKeys, selectKeys)) {
              const indices = {};
              g.indexmaster.forEach(
                (i) =>
                  (indices[i.indexName] =
                    i.indexType === 'string' ? i.categoricalValue : i.indexValue)
              );
              gridIndexDict[g.id] = {
                index: indices,
              };
            }
          });
        } else {
          _.flatten(gridIndexMasterArrs).forEach((g: Grid) => {
            const indices = {};
            g.indexmaster.forEach(
              (i) =>
                (indices[i.indexName] =
                  i.indexType === 'string' ? i.categoricalValue : i.indexValue)
            );
            gridIndexDict[g.id] = {
              index: indices,
            };
          });
        }
      } catch (error) {
        console.log(error);
      }
      const indexFilteredGridIds = Object.keys(gridIndexDict).map((e) => Number(e));
      console.log('The Index Filtered Grids', indexFilteredGridIds.length);


			let responseIds = indexFilteredGridIds;

			try {
				if(query["responseType"] == "count") {
					return await this.getAggrigation(responseIds , query);
				} 
				else if(query["responseType"] == "aggregation") {
					return await this.getAggrigation(responseIds , query);
				} else {
					let responseIdsChunks = _.chunk(responseIds, 50000);
					let response = []
					await Promise.all(responseIdsChunks.map(async eachChunk => {
						const grids = await this.gridsRepository.find({ where: { id: In(eachChunk) }});
						grids.map(eachres => {
							eachres["index"] = gridIndexDict?.[eachres?.id]?.index;
							eachres["geometry"] = {};
							eachres["geometry"]["type"] = "point";
							let coordinates: number[] = [];
							coordinates.push(Number(eachres["longitude"]));
							coordinates.push(Number(eachres["latitude"]));
							eachres["geometry"]["coordinates"] = coordinates;
							delete eachres["latitude"];
							delete eachres["longitude"];
						});
						response.push(grids);
					}));
					response = _.flatten(response);
					return {
						count: response?.length,
						data: response
					}
				}
			} catch (error) {
				console.log(error);
				return [];
			}
		} else {
			return response;
		}
	}

	async getById(id: number): Promise<Grid> {
		return await this.gridsRepository.findOne({ where: { id: id }});
	}

	async getIndex(query: Indexquery): Promise<unknown> {
		let gridIds = [];
		if (query.type === "grid") {
			try {
				gridIds = query.ids;
				const responseArr = [];
				await Promise.all(
					gridIds.map(async eachId => {
						const indexes = await this.indexMasterRepository.find({ where: {
							grid: eachId
					}});
						const tempObject = {};
						tempObject["gridId"] = eachId;
						indexes.forEach(eachIndex => {
							tempObject[eachIndex.indexName] = eachIndex.indexValue;
						});
						responseArr.push(tempObject);
					})
				);
				return responseArr;
			} catch (error) {
				console.log(error);
				return null;
			}
		}
	}

	async writeGridsToFile(): Promise<void> {
		const grids = JSON.stringify(await this.gridsRepository.find());
		// eslint-disable-next-line @typescript-eslint/no-empty-function
		fs.writeFile("./src/files/allGrids.json", grids, function() {});
	}

	async gridsLatLong(
		latitude: number,
		longitude: number,
		radius: number
	): Promise<Grid[] | GridWithIndexRangesNew> {
		//const point = tf.point([latitude, longitude]);
		let distance = 0.07;
		if (radius) {
			distance = radius;
		}
		/*
		const topLeft = tf.destination(point, distance, angleA);
		const bottomRight = tf.destination(point, distance, angleB);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		*/
		const pi = Math.PI;
		const lat_increment = 1/110.574;
    	const lng_increment = 1/111.320;
		const lat_max = Number(latitude) + distance * lat_increment;
    	const lat_min = Number(latitude) - distance * lat_increment;
		const lng_max = Number(longitude) + distance * (lng_increment/Math.cos((pi/180) * (lat_max)));
    	const lng_min = Number(longitude) - distance * (lng_increment/Math.cos((pi/180) * (lat_min)));
		const withinGrids = geohash.bboxes(
			lat_min,
			lng_min,
			lat_max,
			lng_max,
			7
		);
		try {
			const grids = await this.gridsRepository
				.createQueryBuilder("grid")
				.leftJoinAndSelect("grid.indexmaster", "indexmaster")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.getMany();
			await Promise.all(
				grids.map(async eachGrid => {
					if (!eachGrid["index"]) {
						eachGrid["index"] = {};
					}
					eachGrid.indexmaster.forEach(eachIndex => {
						if(eachIndex.indexType == "number") {
							eachGrid["index"][eachIndex.indexName] = eachIndex.indexValue;
						} else {
							eachGrid["index"][eachIndex.indexName] = eachIndex.categoricalValue;
						}
					});
					delete eachGrid.indexmaster;
				})
			);
			const indexRanges = {};
			const response: GridWithIndexRangesNew = {
				indexRanges: indexRanges,
				grids: grids
			};
			return response;
		} catch (error) {
			return [];
		}
	}

	async gridsLatLongNew(
		latitude: number,
		longitude: number,
		radius: number
	): Promise<Grid[] | GridWithIndexRangesNew> {
		//const point = tf.point([latitude, longitude]);
		let distance = 0.07;
		if (radius) {
			distance = radius;
		}
		/*
		const topLeft = tf.destination(point, distance, angleA);
		const bottomRight = tf.destination(point, distance, angleB);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		*/
		const pi = Math.PI;
		const lat_increment = 1/110.574;
    	const lng_increment = 1/111.320;
		const lat_max = Number(latitude) + distance * lat_increment;
    	const lat_min = Number(latitude) - distance * lat_increment;
		const lng_max = Number(longitude) + distance * (lng_increment/Math.cos((pi/180) * (lat_max)));
    	const lng_min = Number(longitude) - distance * (lng_increment/Math.cos((pi/180) * (lat_min)));
		const withinGrids = geohash.bboxes(
			lat_min,
			lng_min,
			lat_max,
			lng_max,
			7
		);
		try {
			const grids = await this.gridsRepository
				.createQueryBuilder("grid")
				.leftJoinAndSelect("grid.indexmaster", "indexmaster")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.getMany();
			await Promise.all(
				grids.map(async eachGrid => {
					if (!eachGrid["index"]) {
						eachGrid["index"] = {};
					}
					eachGrid.indexmaster.forEach(eachIndex => {
						let tempObj = {};
						tempObj["value"] = eachIndex.indexValue;
						tempObj["categoricalValue"] = eachIndex.categoricalValue;
						eachGrid["index"][eachIndex.indexName] = tempObj;
					});
					delete eachGrid.indexmaster;
				})
			);
			const indexRanges = {};
			const response: GridWithIndexRangesNew = {
				indexRanges: indexRanges,
				grids: grids
			};
			return response;
		} catch (error) {
			return [];
		}
	}

	async update(grids: Grid[]): Promise<Grid[]> {
		await Promise.all(
			grids.map(async grid => {
				await this.gridsRepository.update({ hash: grid.hash }, {Cluster: grid.Cluster });
			})
		);

		return grids;
	}

  async indexRanges(query): Promise<unknown> {
    if (!query['location']) {
      throw new HttpException(
        {
          status: HttpStatus.BAD_REQUEST,
          error: "Request must contain 'location'",
        },
        HttpStatus.BAD_REQUEST
      );
    }
    let gridsSearchedArr = [];
    if (query['location']) {
      const locationQueryObject = {};
      let locationQueryString = '';
      Object.keys(query['location']).forEach((location, index) => {
        if (index === 0) {
          locationQueryObject[location] = query['location'][location];
          locationQueryString += 'grid.' + location + ' = :' + location;
        } else {
          locationQueryObject[location] = query['location'][location];
          locationQueryString += ' AND grid.' + location + ' = :' + location;
        }
      });
      if (Object.keys(locationQueryObject).length) {
        try {
          const locationGrids = await this.gridsRepository
            .createQueryBuilder('grid')
            .select('grid.id')
            .where(locationQueryString, locationQueryObject)
            .getMany();
          const locationGridIds = await locationGrids.map((eachGrid) => {
            return eachGrid.id;
          });
          gridsSearchedArr = locationGridIds;
        } catch (error) {
          console.log(error);
        }
      }
    }
    if (gridsSearchedArr.length == 0) {
      gridsSearchedArr = [0];
    }
    const indexMasters = await this.indexMasterRepository
      .createQueryBuilder('indexmaster')
      .select(['"indexName"', '"indexValue"'])
      .where('"gridId" IN (:...gridIds)', { gridIds: gridsSearchedArr })
      .getRawMany();
    console.log('Length: ', indexMasters.length);
    const res = {};
    await Promise.all(
      indexMasters.map((eachObj) => {
        if (res[eachObj['indexName']] === undefined) {
          res[eachObj['indexName']] = {
            min: Number(eachObj['indexValue']),
            max: Number(eachObj['indexValue']),
          };
        } else {
          const min = Number(res[eachObj['indexName']]['min']);
          const max = Number(res[eachObj['indexName']]['max']);
          if (Number(eachObj['indexValue']) > max) {
            res[eachObj['indexName']]['max'] = Number(eachObj['indexValue']);
          }
          if (Number(eachObj['indexValue']) < min) {
            res[eachObj['indexName']]['min'] = Number(eachObj['indexValue']);
          }
        }
      })
    );
    return res;
    //return [];
  }

	async getInfo(query,token) {
		let response = {
			"location_attributes" : {},
			"pincode_attributes":{},
		};
		const requiredKeys = [
			"affluence_category",
			"income_group",
			"branded_area",
			"high_risk_%",
			"medium_risk_%",
			"low_risk_%",
			"market_area%",
			"office_area%",
			"residential_area%"
		];
		if(query["address"]) {
			const url = process.env.FRONTEND_LOGIN_URL+"/apis/geocode";
            console.log("URL: ",url);
            const address = { "address": query["address"] , "shapedict":false };
            const headersRequest = {
                'Content-Type': 'application/json',
				'token': token
            };
            let res;			
            try {
                res = await this.httpService.post(url,address,{headers: headersRequest}).toPromise();
            } catch(err) {
                console.log(err);
                throw new HttpException({
                    status: HttpStatus.FAILED_DEPENDENCY,
                    error: "GeoCode Error"
                },HttpStatus.FAILED_DEPENDENCY);
            }
            console.log("Res :",res.data);
            let latLongs = [];
            latLongs = res["data"][0]["geometry"]["coordinates"];
            console.log("LatLongs :",latLongs);
            const hash = geohash.encode(latLongs[1],latLongs[0],7);
            console.log("Hash :",hash);
            const grid = await this.gridsRepository.findOne({ where: {hash: hash }});
            if(grid == undefined) {
                throw new HttpException({
                    status: HttpStatus.BAD_REQUEST,
                    error: "Bad Address"
                },HttpStatus.BAD_REQUEST);
            }
            console.log("Grid :",grid);
			const indexmasters = await this.indexMasterRepository.find({ where: {grid: grid }});
			console.log("indexMasters : ",indexmasters.length);
			await Promise.all(indexmasters.map(eachIndexMaster => {
				if(requiredKeys.includes(eachIndexMaster.indexName)) {
					if(eachIndexMaster.indexType == "number") {
						response["location_attributes"][eachIndexMaster.indexName] = eachIndexMaster.indexValue;
					} else {
						response["location_attributes"][eachIndexMaster.indexName] = eachIndexMaster.categoricalValue;
					}
				}
			}));
			response["latitude"] = grid.latitude;
			response["longitude"] = grid.longitude;
			response["Pincode"] = grid.Pincode;
			response["District"] = grid.District;
			response["State"] = grid.State;
			const shapeGetInfo = await this._shapeService.getInfo({"pincode": grid.Pincode});
			delete shapeGetInfo["Pincode"];
			delete shapeGetInfo["District"];
			delete shapeGetInfo["State"];
			response["pincode_attributes"] = shapeGetInfo;
		} else {
			let latLongs = [query["lat"],query["lng"]];
            console.log("LatLongs :",latLongs);
            const hash = geohash.encode(latLongs[1],latLongs[0],7);
            console.log("Hash :",hash);
            const grid = await this.gridsRepository.findOne({ where: {hash: hash }});
            if(grid == undefined) {
                throw new HttpException({
                    status: HttpStatus.BAD_REQUEST,
                    error: "Bad Address"
                },HttpStatus.BAD_REQUEST);
            }
			console.log("Grid :",grid);
			const indexmasters = await this.indexMasterRepository.find({ where: {grid: grid }});
			console.log("indexMasters : ",indexmasters.length);
			await Promise.all(indexmasters.map(eachIndexMaster => {
				if(requiredKeys.includes(eachIndexMaster.indexName)) {
					if(eachIndexMaster.indexType == "number") {
						response["location_attributes"][eachIndexMaster.indexName] = eachIndexMaster.indexValue;
					} else {
						response["location_attributes"][eachIndexMaster.indexName] = eachIndexMaster.categoricalValue;
					}
				}
			}));
			response["latitude"] = grid.latitude;
			response["longitude"] = grid.longitude;
			response["Pincode"] = grid.Pincode;
			response["District"] = grid.District;
			response["State"] = grid.State;
			const shapeGetInfo = await this._shapeService.getInfo({"pincode": grid.Pincode});
			delete shapeGetInfo["Pincode"];
			delete shapeGetInfo["District"];
			delete shapeGetInfo["State"];
			response["pincode_attributes"] = shapeGetInfo;
		}
		return response;
	}

	async pincodeAnalysis(query: PincodeAnalysisBody) {
		const url = String(process.env.MONGO_URL);
		const response = {
			locationDetails: {
				pincode: null,
				district: null,
				state: null,
				country: "india",
			},
			geometry: {
				type: null,
				coordinates: null
			}
		};
		if(query.pincode == undefined) {
			throw new HttpException("pincode must be in body",HttpStatus.BAD_REQUEST);
		}
		const shape = await this.shapesRepository.findOne({ where: {level: "Pincode",name: String(query.pincode) }});
		if(shape == undefined) {
			throw new HttpException("Pincode : "+query.pincode+" not found",HttpStatus.EXPECTATION_FAILED);
		}
		const shapeFromMongo = await ( await mongoClient.connect(url,{ useUnifiedTopology: true }))
				.db(String(process.env.MONGO_DB))
				.collection("ShapesDB")
				.findOne({ where: { _id: new mongo.ObjectId(shape.objectId) }});
		console.log(shapeFromMongo);
		response.locationDetails.district = shape.District;
		response.locationDetails.pincode = shape.Pincode;
		response.locationDetails.state = shape.State;
		response.geometry.type = shapeFromMongo["geometry"]?.["type"];
		response.geometry.coordinates = shapeFromMongo["geometry"]?.["coordinates"];
		return response;
	}

  async coordinatesAnalysis(query: CoordinateAnalysisBody) {
    if ((query.lat && query.lng) == undefined) {
      throw new HttpException('lat and lng must be in body', HttpStatus.BAD_REQUEST);
    }
    const response = {
      locationDetails: {
        pincode: null,
        taluka: null,
        district: null,
        state: null,
        country: 'india',
        residential_location: null,
      },
    };
    const hash = geohash.encode(query.lat, query.lng, 7);
    console.log('Hash :', hash);
    let grid = await this.gridsRepository.findOne({
      where: {
        hash: hash,
      },
    });
    if (grid == undefined) {
      const pi = Math.PI;
      const lat_increment = 1 / 110.574;
      const lng_increment = 1 / 111.32;
      const lat_max = Number(query.lat) + 2 * lat_increment;
      const lat_min = Number(query.lat) - 2 * lat_increment;
      const lng_max = Number(query.lng) + 2 * (lng_increment / Math.cos((pi / 180) * lat_max));
      const lng_min = Number(query.lng) - 2 * (lng_increment / Math.cos((pi / 180) * lat_min));
      const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
      let gridIds: number[] = [];
      try {
        const tempGrid = await this.gridsRepository
          .createQueryBuilder('grid')
          .where('grid.hash IN (:...hashes)', { hashes: withinGrids })
          .select('grid.id')
          .getMany();

        gridIds = tempGrid.map((eachGrid) => {
          return Number(eachGrid.id);
        });
      } catch (error) {
        console.log('Error:', error);
      }
      if (gridIds.length > 0) {
        grid = await this.gridsRepository.findOne({
          where: {
            id: gridIds[0],
          },
        });
      } else {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            error: 'No data found!',
          },
          HttpStatus.BAD_REQUEST
        );
      }
    }
    const indexMasters = await this.indexMasterRepository.find({
      where: {
        grid: grid,
      },
    });
    let footfall = 0;
    let affluence = 0;
    indexMasters.forEach((eachIndexMaster) => {
      if (eachIndexMaster.indexName == 'footfall') {
        footfall = Number(eachIndexMaster.indexValue);
      }
      if (eachIndexMaster.indexName == 'affluence') {
        affluence = Number(eachIndexMaster.indexValue);
      }
    });
    response.locationDetails.district = grid.District;
    response.locationDetails.pincode = grid.Pincode;
    response.locationDetails.state = grid.State;
    response.locationDetails.taluka = grid.Taluka;
    if (footfall == 0 && affluence == 0) {
      response.locationDetails.residential_location = false;
    } else {
      response.locationDetails.residential_location = true;
    }
    return response;
  }
}
