import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { MongooseModule } from '@nestjs/mongoose';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GlobalServiceModule } from 'src/helpers/global-service/global-service.module';
import { GlobalServiceService } from 'src/helpers/global-service/global-service.service';
import { Grid } from 'src/grid/grids.entity';
import { MongoDatabaseModule } from 'src/helpers/mongo-database/mongo-database.module';
import { PoiDetail } from 'src/poi-details/poi-details.entity';
import { Poi } from 'src/poi/poi.entity';
import { ShapeDetail } from 'src/shape-details/shape-details.entity';
import { Shape } from 'src/shape/shape.entity';
import { DemoShapesDBSchema } from 'src/shape/shape.schema';
import { ShapeService } from 'src/shape/shape.service';
import { Shapeindex } from 'src/shape/shapeIndex.entity';
import { TargetDetail } from 'src/target-details/target-details.entity';
import { User } from 'src/users/users.entity';
import { PoiShapeController } from '../poi-shape/poi-shape.controller';
import { PoiShape } from '../poi-shape/poi-shape.entity';
import { PoiShapeService } from '../poi-shape/poi-shape.service';
import { TargetShapeController } from './target-shape.controller';
import { TargetShapeService } from './target-shape.service';

@Module({
	imports: [
		MongooseModule.forFeature([{ name: 'DemoShapesDB', schema: DemoShapesDBSchema }]),
		TypeOrmModule.forFeature([
			Poi,
			PoiShape,
			Shape,
			Grid,
			Shapeindex,
			ShapeDetail,
			PoiDetail,
            TargetDetail,
			User
		]),
		MongoDatabaseModule,
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		}),
		GlobalServiceModule
	],
	controllers: [TargetShapeController],
	providers: [TargetShapeService, ShapeService, GlobalServiceService]
})
export class TargetShapeModule {}
