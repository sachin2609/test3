import { Controller, Get, Post, Body, Headers, UseInterceptors, HttpException, HttpStatus } from "@nestjs/common";
import { ShapeService } from "./shape.service";
import { DemoShapesDB } from "./shape.schema";
import { MultilevelShapesQuery } from "../interfaces/shapes";
import { JwtService } from "@nestjs/jwt";
import { GlobalServiceService } from "src/helpers/global-service/global-service.service";
import { CacheInterceptorInterceptor } from "src/helpers/cache/cache-interceptor.interceptor";
import { CacheKey } from "src/helpers/cache/cache-key.decorator";
import { Roles, RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { RealIP } from "nestjs-real-ip";
import { CachePopulateInterceptor } from "src/helpers/cache/cache-populate.interceptor";

@Controller("shape")
export class ShapeController {
	constructor(
		private _shapeService: ShapeService,
		private _jwtService: JwtService,
		private _globalService: GlobalServiceService,
		private _rolesGuardService: RolesGuardService,
	) {}

	@Get()
	async findOne(): Promise<unknown> {
		console.log("getting");
		return await this._shapeService.findOne();
	}

	@Roles("basic")
	@Post("filters")
	@CacheKey("shape-filters")
	@UseInterceptors(CacheInterceptorInterceptor)
	async filters(@Body() body) {
		console.log(body);
		return await this._shapeService.getFilters(body);
	}

	@Roles("basic")
	@Post("populate-filters")
	@CacheKey("shape-filters")
	@UseInterceptors(CachePopulateInterceptor)
	async populatefilters(@Body() body) {
		console.log(body);
		return await this._shapeService.getFilters(body);
	}

	@Roles("basic")
	@Post()
	async create(@Body() body: DemoShapesDB): Promise<DemoShapesDB> {
		return await this._shapeService.create(body);
	}

	@Roles("basic")
	@Post("levelsearch")
	async multilevelSearch(@Body() body: MultilevelShapesQuery): Promise<DemoShapesDB[]> {
		try {
			return await this._shapeService.multilevelShapes(body);
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@Post("copyshapesfrommongo")
	async copyShapesFromMongoToSql(): Promise<void> {
		return await this._shapeService.dumpShapesFromMongo();
	}

	@Roles("basic")
	@Post("copyclustersfrommongo")
	async copyClustersFromMongoToSql(): Promise<any> {
		return await this._shapeService.dumpClustersFromMongo();
	}

	@Roles("basic")
	@Post("populateShapeDetails")
	async populateShapeDetails(): Promise<void> {
		console.log("Starting.....");
		return await this._shapeService.populateShapeDetails();
	}

	@Roles("basic")
	@Post("internal-filter")
	@CacheKey("shape-internal-filters")
	@UseInterceptors(CacheInterceptorInterceptor)
	async filterShapeDetails(@Body() body): Promise<any> {
		try {
			return await this._shapeService.filterShapeDetails(body);
		} catch (error) {
			return [];
			console.log(error);
		}
	}

	@Roles("admin")
	@Post("populate-internal-filter")
	@CacheKey("shape-internal-filters")
	@UseInterceptors(CachePopulateInterceptor)
	async populatefilterShapeDetails(@Body() body): Promise<any> {
		try {
			return await this._shapeService.filterShapeDetails(body);
		} catch (error) {
			return [];
			console.log(error);
		}
	}

	@Roles("basic")
	@Post("levelsearch-new")
	@UseInterceptors(CacheInterceptorInterceptor)
	async multilevelSearchNew(
		@Body() body: MultilevelShapesQuery,
		@Headers() header,
		@RealIP() ip: string,
	): Promise<unknown> {
		try {
			const resp = await this._shapeService.multilevelShapesNew(body);
			console.log("deducting ", resp["count"]);
			let credsResp;
			if (header.token) {
				credsResp = await this._rolesGuardService.updateCreds(
					header.token,
					resp["count"],
					"/shape/levelsearch-new",
					ip,
					JSON.stringify(body),
				);
			} else {
				credsResp = await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp["count"],
					"/shape/levelsearch-new",
					ip,
					JSON.stringify(body),
				);
			}
			console.log("response from creds deduction", credsResp);
			if (credsResp) {
				return resp;
			} else {
				throw new HttpException(
					{
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left",
					},
					HttpStatus.FORBIDDEN,
				);
			}
		} catch (error) {
			console.log(error);
			return {
				count: 0,
				data: [],
			};
		}
	}


	@Roles("basic")
	@Post("export-filter")
	async exportFilter(@Body() body: MultilevelShapesQuery, @Headers() header) {
		const user = await this._jwtService.decode(header.token);
		const userId = user["id"];
		const responseBody = await this._shapeService.multilevelShapesNew(body);
		const data: any[] = responseBody["data"];
		await Promise.all(
			data.map(async (eachData) => {
				if (Object.keys(eachData["index"]).length != 0) {
					await Promise.all(
						Object.keys(eachData["index"]).map((indexKey) => {
							eachData[indexKey] = eachData["index"][indexKey];
						}),
					);
				}
				if (Object.keys(eachData["internalDetails"]).length != 0) {
					await Promise.all(
						Object.keys(eachData["internalDetails"]).map((indexKey) => {
							eachData[indexKey] = eachData["internalDetails"][indexKey];
						}),
					);
				}
				delete eachData["index"];
				delete eachData["internalDetails"];
				eachData["type"] = eachData["geometry"]["type"];
				eachData["coordinates"] = String(eachData["geometry"]["coordinates"]);
				delete eachData["geometry"];
			}),
		);
		return await this._globalService.exportCsv(data, userId, "shape");
	}

	@Roles("basic")
	@Post("get-info")
	async getInfo(@Body() body) {
		return await this._shapeService.getInfo(body);
	}
}
