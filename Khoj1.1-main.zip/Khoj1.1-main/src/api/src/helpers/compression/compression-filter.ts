import { Request, Response } from "express";

export default function filterRouteForCompression(req: Request, res: Response): boolean {
	const enableCompression = res.getHeader("enable-compression");
	if (enableCompression) res.removeHeader("enable-compression");
	return !!enableCompression;
}
