import { Test, TestingModule } from "@nestjs/testing";
import { PropertyGridService } from "./property-grid.service";

describe("PropertyGridService", () => {
	let service: PropertyGridService;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			providers: [PropertyGridService]
		}).compile();

		service = module.get<PropertyGridService>(PropertyGridService);
	});

	it("should be defined", () => {
		expect(service).toBeDefined();
	});
});
