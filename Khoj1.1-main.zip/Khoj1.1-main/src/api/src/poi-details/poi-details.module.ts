import { Module } from "@nestjs/common";
import { PoiDetailsController } from "./poi-details.controller";
import { PoiDetailsService } from "./poi-details.service";
import { PoiDetail } from "./poi-details.entity";
import { TypeOrmModule } from "@nestjs/typeorm";
@Module({
	imports: [TypeOrmModule.forFeature([PoiDetail])],
	controllers: [PoiDetailsController],
	providers: [PoiDetailsService]
})
export class PoiDetailsModule {}
