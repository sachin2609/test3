import { Controller, Post, Body } from "@nestjs/common";
import { PropertyGrid } from "./property-grid.entity";
import { PropertyGridService } from "./property-grid.service";
import { ApiTags, ApiBody, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
@ApiTags("property-grid")
@Controller("property-grid")
export class PropertyGridController {
	constructor(private _propertyGridService: PropertyGridService) {}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Create Property-Grids" })
	@ApiBody({ type: PropertyGrid })
	async create(@Body() propertyGrids: PropertyGrid[]): Promise<PropertyGrid[]> {
		return await this._propertyGridService.create(propertyGrids);
	}
}
