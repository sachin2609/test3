import { HttpException, HttpStatus, Inject, Injectable } from "@nestjs/common";
import { Model } from "mongoose";
import { InjectModel } from "@nestjs/mongoose";
import { DemoShapesDB } from "./shape.schema";
import { MultilevelShapesQuery } from "../interfaces/shapes";
import { Shape } from "./shape.entity";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository, In } from "typeorm";
import { Grid } from "../grid/grids.entity";
import { Shapeindex } from "./shapeIndex.entity";
import * as mongoose from "mongoose";
import * as _ from "lodash";
import { Db, ObjectId } from "mongodb";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import * as tf from "@turf/turf";
import * as geohash from "ngeohash";
import * as dotenv from "dotenv";
import { LatLong } from "../interfaces/poi";
import * as mongo from "mongodb";
dotenv.config();
const mongoClient = mongo.MongoClient;
//const angleA = process.env.BBOX_ANGLE_A;
//const angleB = process.env.BBOX_ANGLE_B;
const url = String(process.env.MONGO_URL);

@Injectable()
export class ShapeService {
	constructor(
		@InjectModel("DemoShapesDB") private demoShapesDBModel: Model<DemoShapesDB>,
		@InjectRepository(Shape) private shapesRepository: Repository<Shape>,
		@InjectRepository(Shapeindex) private shapeIndexRepository: Repository<Shape>,
		@InjectRepository(Grid) private gridsRepository: Repository<Grid>,
		@InjectRepository(ShapeDetail) private shapeDetailsRepository: Repository<ShapeDetail>,
		@Inject("DATABASE_CONNECTION") private db: Db,
	) {}

	async findOne(): Promise<unknown> {
		let resp;
		try {
			resp = (await mongoClient.connect(url, { useUnifiedTopology: true }))
				.db(String(process.env.MONGO_DB))
				.collection("ShapesDB")
				.find();
			console.log("response is", resp);
		} catch (error) {
			console.log("error is", error);
		}
		return resp;
	}

	async create(query: DemoShapesDB): Promise<DemoShapesDB> {
		console.log("body to save", query);
		return await this.demoShapesDBModel.create(query);
	}

	async average(array) {
		// Add together and then divide by the length
		return (
			_.reduce(
				array,
				function (sum, num) {
					return sum + num;
				},
				0,
			) / array.length
		);
	}

	async multilevelShapes(query: MultilevelShapesQuery): Promise<DemoShapesDB[]> {
		let shapeIds = [];
		let level, childLevel, name;
		if (query["within"]) {
			let distance = query["within"]["radius"];
			distance = distance / 2;
			const withinGridsArr: number[][] = await Promise.all(
				query["within"]["points"].map(async (eachpoint) => {
					//const eachTarget = await this.gridsRepository.findOne({ where : { id: eachId }});
					/*
          const point = tf.point([eachpoint.lat,eachpoint.lng]);
          const topLeft = tf.destination(point, distance, angleA);
          const bottomRight = tf.destination(point, distance, angleB);
          const withinGrids = geohash.bboxes(
            topLeft["geometry"]["coordinates"][0],
            topLeft["geometry"]["coordinates"][1],
            bottomRight["geometry"]["coordinates"][0],
            bottomRight["geometry"]["coordinates"][1],
            7
          );
          */
					const pi = Math.PI;
					const lat_increment = 1 / 110.574;
					const lng_increment = 1 / 111.32;
					const lat_max = Number(eachpoint.lat) + distance * lat_increment;
					const lat_min = Number(eachpoint.lat) - distance * lat_increment;
					const lng_max = Number(eachpoint.lng) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
					const lng_min = Number(eachpoint.lng) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
					const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
					console.log(withinGrids);
					try {
						const tempGrid = await this.gridsRepository
							.createQueryBuilder("grid")
							.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
							.select("grid.id")
							.getMany();
						const tempGridIds = tempGrid.map((eachGrid) => {
							return eachGrid.id;
						});
						return tempGridIds;
					} catch (error) {
						console.log("error is", error);
						return null;
					}
				}),
			);
			const tempGrids = _.flattenDeep(withinGridsArr);
			if (query["childLevel"] == "cluster") {
				const clusterIdObj = await this.gridsRepository
					.createQueryBuilder("grid")
					.select('"Cluster"')
					.where("id IN (:...gridIds)", { gridIds: tempGrids })
					.distinct(true)
					.getRawMany();
				const clusterIds = [];
				await Promise.all(
					clusterIdObj.map((eachObj) => {
						if (eachObj["Cluster"] != -1) {
							clusterIds.push(eachObj["Cluster"]);
						}
					}),
				);
				console.log(clusterIds);
				const clusters = await this.db
					.collection("ClustersDB")
					.find({
						where: {
							cluster_id: { $in: clusterIds },
						},
					})
					.toArray();
				console.log("Length of Clusters Found :", clusters.length);
				shapeIds = await Promise.all(
					clusters.map(async (eachCluster) => {
						const objId = '"' + eachCluster["_id"] + '"';
						const shape = await this.shapesRepository.findOne({
							where: {
								objectId: objId,
							},
						});
						if (shape === undefined) {
							console.log("Undefined Shape found");
						} else {
							return shape.id;
						}
					}),
				);
			} else {
				const pincodesObj = await this.gridsRepository
					.createQueryBuilder("grid")
					.select('"Pincode"')
					.where("id IN (:...gridIds)", { gridIds: tempGrids })
					.distinct(true)
					.getRawMany();
				const pincodes = [];
				await Promise.all(
					pincodesObj.map((eachObj) => {
						pincodes.push(eachObj["Pincode"]);
					}),
				);
				console.log(pincodes);
				const shapes = await this.shapesRepository.find({
					where: {
						Pincode: In(pincodes),
					},
				});
				console.log("Length of Shapes :", shapes.length);
				await Promise.all(
					shapes.map((eachShape) => {
						shapeIds.push(eachShape.id);
					}),
				);
			}
			let finalIds = shapeIds;
			if (finalIds.length == 0) {
				finalIds = [0];
			}
			const finalObjects = await this.shapesRepository
				.createQueryBuilder("shape")
				.leftJoinAndSelect("shape.shapeindex", "shapeindex")
				.where("shape.id IN (:...finalIds)", { finalIds: finalIds })
				.getMany();
			console.log("Length of FinalObjs :", finalObjects.length);
			//console.log(finalObjects);
			const objectIdShapeIndexDict = {};
			const finalObjectIdsFromPostgres = finalObjects.map((eachObject) => {
				objectIdShapeIndexDict[eachObject.objectId] = eachObject.shapeindex;
				const newObjectIdString = eachObject.objectId.slice(1, -1);
				return new mongoose.mongo.ObjectId(newObjectIdString);
			});
			//console.log(finalObjectIdsFromPostgres);
			let shapesFromMongoReturned = await this.demoShapesDBModel.find({
				_id: {
					$in: finalObjectIdsFromPostgres,
				},
			});
			//remove this if section after population of clusters on mongo
			if (shapesFromMongoReturned.length == 0) {
				console.log("Inside Cluster Section");
				shapesFromMongoReturned = await this.db
					.collection("ClustersDB")
					.find({
						where: {
							_id: {
								$in: finalObjectIdsFromPostgres,
							},
						},
					})
					.toArray();
				console.log(shapesFromMongoReturned);
				console.log("Length of shapesFromMongoReturned", shapesFromMongoReturned.length);
				const responseObjects = [];
				await Promise.all(
					shapesFromMongoReturned.map(async (eachShape) => {
						//Searching for internalPropeerty
						const shape = await this.shapesRepository.findOne({
							where: {
								objectId: eachShape._id,
							},
						});
						const internalShapeProps = await this.shapeDetailsRepository.find({
							where: {
								shapeId: shape.id,
							},
						});
						//console.log("Internal-Prop :",internalShapeProps);
						//console.log(eachShape);
						const tempObject: unknown = {};
						tempObject["internalDetails"] = {};
						await Promise.all(
							internalShapeProps.map(async (eachObj) => {
								tempObject["internalDetails"][eachObj.key] = eachObj.value;
							}),
						);
						tempObject["geometry"] = eachShape["geometry"];
						const currentIndexes: Shapeindex[] = objectIdShapeIndexDict['"' + eachShape._id + '"'];
						const indexesDict = {};
						currentIndexes.forEach((eachIndex) => {
							indexesDict[eachIndex.indexName] = eachIndex.indexValue;
						});
						tempObject["index"] = indexesDict;
						tempObject["name"] = eachShape.pincode;
						tempObject["level"] = "cluster";
						tempObject["city"] = eachShape.city;
						tempObject["locality"] = eachShape["locality"];
						tempObject["weight"] = eachShape["weight"];
						tempObject["store"] = eachShape["store"];
						tempObject["pincode"] = eachShape["pincode"];
						tempObject["cluster_id"] = eachShape["cluster_id"];
						responseObjects.push(tempObject);
					}),
				);
				//For WFSL
				await Promise.all(
					responseObjects.map(async (eachShape) => {
						const latArr = [];
						const longArr = [];
						//console.log(eachShape["geometry"]["coordinates"][0]);
						await Promise.all(
							eachShape["geometry"]["coordinates"][0].map((eachArr) => {
								//console.log(eachArr);
								latArr.push(eachArr[1]);
								longArr.push(eachArr[0]);
							}),
						);
						//console.log("LatArr :",latArr);
						//console.log("LongArr :",longArr);
						const centerLat = await this.average(latArr);
						const centerLong = await this.average(longArr);
						eachShape["id"] = eachShape["cluster_id"];
						delete eachShape["cluster_id"];
						eachShape["longitude"] = centerLong;
						eachShape["latitude"] = centerLat;
						//eachShape["internal-property"] = {};
						//eachShape["internal-property"] = { "weight": eachShape["weight"] , "store": eachShape["store"]};
						delete eachShape["store"];
						delete eachShape["weight"];
					}),
				);
				//starting index filter and shapeDetails filter
				console.log("Length of ResponseObj:", responseObjects.length);
				let finalResponse = [];
				if (query["grids"]) {
					await Promise.all(
						responseObjects.map(async (eachResponseObj) => {
							const testArr = [];
							await Promise.all(
								Object.keys(query["grids"]).map(async (eachKey) => {
									const min = query["grids"][eachKey]["min"];
									const max = query["grids"][eachKey]["max"];
									if (eachResponseObj["index"][eachKey] === undefined) {
										eachResponseObj["index"][eachKey] = -1;
									}
									if (
										Number(eachResponseObj["index"][eachKey]) >= min &&
										Number(eachResponseObj["index"][eachKey]) <= max
									) {
										testArr.push(true);
									} else {
										testArr.push(false);
									}
								}),
							);
							if (!testArr.includes(false)) {
								finalResponse.push(eachResponseObj);
							}
						}),
					);
				}
				if (!query["grids"]) {
					console.log("IndexFilters not found");
					finalResponse = responseObjects;
				}
				console.log("Length of FinalResponse After indexFilter:", finalResponse.length);
				let ultimateResponse = [];
				if (query["shapeDetails"]) {
					let shapeDetailsQuery = [];
					shapeDetailsQuery = query["shapeDetails"];
					await Promise.all(
						finalResponse.map(async (eachResponseObj) => {
							const testArr = [];
							await Promise.all(
								shapeDetailsQuery.map((eachQueryObj) => {
									if (eachQueryObj["dataType"] == "number") {
										const min = eachQueryObj["values"]["min"];
										const max = eachQueryObj["values"]["max"];
										if (eachResponseObj["internalDetails"][eachQueryObj["key"]] === undefined) {
											eachResponseObj["internalDetails"][eachQueryObj["key"]] = -1;
										}
										if (
											Number(eachResponseObj["internalDetails"][eachQueryObj["key"]]) >= min &&
											Number(eachResponseObj["internalDetails"][eachQueryObj["key"]]) <= max
										) {
											testArr.push(true);
										} else {
											testArr.push(false);
										}
									} else {
										let values = [];
										values = eachQueryObj["values"];
										if (values.includes(eachResponseObj["internalDetails"][eachQueryObj["key"]])) {
											testArr.push(true);
										} else {
											testArr.push(false);
										}
									}
								}),
							);
							if (!testArr.includes(false)) {
								ultimateResponse.push(eachResponseObj);
							}
						}),
					);
				}
				if (!query["shapeDetails"]) {
					console.log("Internal Filters not found");
					ultimateResponse = finalResponse;
				}
				console.log("Length of FinalResponse After internalFilter:", ultimateResponse.length);
				//Ending index filter and shapeDetails filter
				return ultimateResponse;
			}
			console.log("Length of shapesFromMongoReturned", shapesFromMongoReturned.length);
			const responseObjects = [];
			shapesFromMongoReturned.forEach((eachShape) => {
				const tempObject: unknown = {};
				tempObject["geometry"] = eachShape["_doc"]["geometry"];
				const currentIndexes: Shapeindex[] = objectIdShapeIndexDict['"' + eachShape._id + '"'];
				const indexesDict = {};
				currentIndexes.forEach((eachIndex) => {
					indexesDict[eachIndex.indexName] = eachIndex.indexValue;
				});
				tempObject["index"] = indexesDict;
				tempObject["name"] = eachShape.name;
				tempObject["level"] = eachShape["_doc"]["level"];
				responseObjects.push(tempObject);
			});
			//starting index filter and shapeDetails filter
			console.log("Length of ResponseObj:", responseObjects.length);
			let finalResponse = [];
			if (query["grids"]) {
				await Promise.all(
					responseObjects.map(async (eachResponseObj) => {
						const testArr = [];
						await Promise.all(
							Object.keys(query["grids"]).map(async (eachKey) => {
								const min = query["grids"][eachKey]["min"];
								const max = query["grids"][eachKey]["max"];
								if (eachResponseObj["index"][eachKey] === undefined) {
									eachResponseObj["index"][eachKey] = -1;
								}
								if (
									Number(eachResponseObj["index"][eachKey]) >= min &&
									Number(eachResponseObj["index"][eachKey]) <= max
								) {
									testArr.push(true);
								} else {
									testArr.push(false);
								}
							}),
						);
						if (!testArr.includes(false)) {
							finalResponse.push(eachResponseObj);
						}
					}),
				);
			}
			if (!query["grids"]) {
				console.log("IndexFilters not found");
				finalResponse = responseObjects;
			}
			console.log("Length of FinalResponse After indexFilter:", finalResponse.length);
			let ultimateResponse = [];
			if (query["shapeDetails"]) {
				let shapeDetailsQuery = [];
				shapeDetailsQuery = query["shapeDetails"];
				await Promise.all(
					finalResponse.map(async (eachResponseObj) => {
						const testArr = [];
						await Promise.all(
							shapeDetailsQuery.map((eachQueryObj) => {
								const min = eachQueryObj["values"]["min"];
								const max = eachQueryObj["values"]["max"];
								if (eachResponseObj["internalDetails"][eachQueryObj["key"]] === undefined) {
									eachResponseObj["internalDetails"][eachQueryObj["key"]] = -1;
								}
								if (
									Number(eachResponseObj["internalDetails"][eachQueryObj["key"]]) >= min &&
									Number(eachResponseObj["internalDetails"][eachQueryObj["key"]]) <= max
								) {
									testArr.push(true);
								} else {
									testArr.push(false);
								}
							}),
						);
						if (!testArr.includes(false)) {
							ultimateResponse.push(eachResponseObj);
						}
					}),
				);
			}
			if (!query["shapeDetails"]) {
				console.log("Internal Filters not found");
				ultimateResponse = finalResponse;
			}
			console.log("Length of FinalResponse After internalFilter:", ultimateResponse.length);
			//Ending index filter and shapeDetails filter
			return ultimateResponse;

			//Doneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
		}
		if (query.location.State) {
			console.log("inside state");
			level = "State";
			name = query.location.State;
		}
		if (query.location.City) {
			console.log("inside city");
			level = "City";
			name = query.location.City;
			console.log("Name is : ", name);
		}
		if (query.location.Locality) {
			console.log("inside locality");
			level = "Locality";
			name = query.location.Locality;
		}
		if (query.location.Pincode) {
			console.log("inside pincode");
			level = "Pincode";
			name = query.location.Pincode;
		}
		if (query.location.District) {
			console.log("inside district");
			level = "District";
			name = query.location.District;
		}
		if (query.location.Country) {
			console.log("inside country");
			level = "Country";
			name = query.location.Country;
		}
		if (!query.childLevel) {
			const queryString = `"${level}" = :name`;
			const finalObjects = await this.shapesRepository
				.createQueryBuilder("shape")
				.leftJoinAndSelect("shape.shapeindex", "shapeindex")
				.where(queryString, { name: name })
				.getMany();
			const objectIdShapeIndexDict = {};
			const finalObjectIdsFromPostgres = finalObjects.map((eachObject) => {
				objectIdShapeIndexDict[eachObject.objectId] = eachObject.shapeindex;
				const newObjectIdString = eachObject.objectId;
				return new mongoose.Types.ObjectId(eachObject.objectId);
			});
			const shapesFromMongoReturned = await this.demoShapesDBModel.find({
				_id: {
					$in: finalObjectIdsFromPostgres,
				},
			});
			const responseObjects = [];
			shapesFromMongoReturned.forEach((eachShape) => {
				const tempObject: unknown = {};
				tempObject["geometry"] = eachShape["_doc"]["geometry"];
				let currentIndexes: Shapeindex[] = objectIdShapeIndexDict[eachShape._id];
				//console.log("object id shape index dict", objectIdShapeIndexDict);
				if (!currentIndexes) {
					currentIndexes = [];
				}
				const indexesDict = {};
				currentIndexes.forEach((eachIndex) => {
					indexesDict[eachIndex.indexName] = eachIndex.indexValue;
				});
				tempObject["index"] = indexesDict;
				tempObject["name"] = eachShape.name;
				tempObject["level"] = eachShape["_doc"]["level"];
				responseObjects.push(tempObject);
			});
			return responseObjects;
		} else {
			const queryDict = {};
			queryDict["level"] = query.childLevel;
			queryDict[level] = name;
			console.log("Haha :", queryDict);
			let pincodeIdsAgainstIndexes = [];
			let pincodeIdsAgainstIndexesIntersected;
			let shapesQueryFlag = false;
			if (query["shapes"]) {
				shapesQueryFlag = true;
				pincodeIdsAgainstIndexes = await Promise.all(
					Object.keys(query["shapes"]).map(async (eachKey) => {
						let pincodeQueryString = "";
						const pincodeQueryObject = {};
						pincodeQueryString +=
							'shapeindex."indexName" = :' +
							eachKey +
							'name AND shapeindex."indexValue" BETWEEN :' +
							eachKey +
							"min AND :" +
							eachKey +
							"max";
						pincodeQueryObject[eachKey + "min"] = query["shapes"][eachKey]["min"];
						pincodeQueryObject[eachKey + "max"] = query["shapes"][eachKey]["max"];
						pincodeQueryObject[eachKey + "name"] = eachKey;
						try {
							const response = await this.shapesRepository
								.createQueryBuilder("shape")
								.leftJoinAndSelect("shape.shapeindex", "shapeindex")
								.where(pincodeQueryString, pincodeQueryObject)
								.select("shape.id")
								.getMany();
							return response.map((eachResp) => {
								return eachResp.id;
							});
						} catch (error) {
							console.log(error);
						}
					}),
				);
				pincodeIdsAgainstIndexes.forEach((eachIdsArr, index) => {
					if (index === 0) {
						pincodeIdsAgainstIndexesIntersected = _.flattenDeep(eachIdsArr);
					} else {
						pincodeIdsAgainstIndexesIntersected = _.intersection(
							pincodeIdsAgainstIndexesIntersected,
							_.flattenDeep(eachIdsArr),
						);
					}
				});
			}
			const pincodesFromLocation = await this.shapesRepository.find({ where: queryDict });
			let pincodeIdsFromLocation = pincodesFromLocation.map((eachPincode) => {
				return eachPincode.id;
			});
			pincodeIdsFromLocation = _.flattenDeep(pincodeIdsFromLocation);
			pincodeIdsAgainstIndexes = _.flattenDeep(pincodeIdsAgainstIndexesIntersected);
			//will be from query["shapes"]
			if (shapesQueryFlag === true) {
				const finalIds = _.intersection(pincodeIdsAgainstIndexes, pincodeIdsFromLocation);
				const finalObjects = await this.shapesRepository
					.createQueryBuilder("shape")
					.leftJoinAndSelect("shape.shapeindex", "shapeindex")
					.where("shape.id IN (:...finalIds)", { finalIds: finalIds })
					.getMany();
				const objectIdShapeIndexDict = {};
				const finalObjectIdsFromPostgres = finalObjects.map((eachObject) => {
					objectIdShapeIndexDict[eachObject.objectId] = eachObject.shapeindex;
					const newObjectIdString = eachObject.objectId;
					return new mongoose.Types.ObjectId(eachObject.objectId);
				});
				const shapesFromMongoReturned = await this.demoShapesDBModel.find({
					_id: {
						$in: finalObjectIdsFromPostgres,
					},
				});
				const responseObjects = [];
				shapesFromMongoReturned.forEach((eachShape) => {
					const tempObject: unknown = {};
					tempObject["geometry"] = eachShape["_doc"]["geometry"];
					let currentIndexes: Shapeindex[] = objectIdShapeIndexDict[eachShape._id];
					//console.log("object id shape index dict", objectIdShapeIndexDict);
					if (!currentIndexes) {
						currentIndexes = [];
					}
					const indexesDict = {};
					currentIndexes.forEach((eachIndex) => {
						indexesDict[eachIndex.indexName] = eachIndex.indexValue;
					});
					tempObject["index"] = indexesDict;
					tempObject["name"] = eachShape.name;
					tempObject["level"] = eachShape["_doc"]["level"];
					responseObjects.push(tempObject);
				});
				return responseObjects;
			} else {
				let finalIds = pincodeIdsFromLocation;
				if (finalIds.length == 0) {
					finalIds = [0];
				}
				const finalObjects = await this.shapesRepository
					.createQueryBuilder("shape")
					.leftJoinAndSelect("shape.shapeindex", "shapeindex")
					.where("shape.id IN (:...finalIds)", { finalIds: finalIds })
					.getMany();
				console.log("Length of FinalObjs :", finalObjects.length);
				console.log(finalObjects);
				const objectIdShapeIndexDict = {};
				const finalObjectIdsFromPostgres = finalObjects.map((eachObject) => {
					objectIdShapeIndexDict[eachObject.objectId] = eachObject.shapeindex;
					const newObjectIdString = eachObject.objectId;
					return new mongoose.mongo.ObjectId(newObjectIdString);
				});
				console.log(finalObjectIdsFromPostgres);
				let shapesFromMongoReturned = await this.demoShapesDBModel.find({
					_id: {
						$in: finalObjectIdsFromPostgres,
					},
				});
				//remove this if section after population of clusters on mongo
				if (shapesFromMongoReturned.length == 0) {
					console.log("Inside Cluster Section");
					shapesFromMongoReturned = await this.db
						.collection("ClustersDB")
						.find({
							where: {
								_id: {
									$in: finalObjectIdsFromPostgres,
								},
							},
						})
						.toArray();
					console.log(shapesFromMongoReturned);
					console.log("Length of shapesFromMongoReturned", shapesFromMongoReturned.length);
					const responseObjects = [];
					await Promise.all(
						shapesFromMongoReturned.map(async (eachShape) => {
							//Searching for internalPropeerty
							const shape = await this.shapesRepository.findOne({ where: { objectId: eachShape._id } });
							const internalShapeProps = await this.shapeDetailsRepository.find({
								where: { shapeId: shape.id },
							});
							console.log("Internal-Prop :", internalShapeProps);
							//console.log(eachShape);
							const tempObject: unknown = {};
							tempObject["internalDetails"] = {};
							await Promise.all(
								internalShapeProps.map(async (eachObj) => {
									tempObject["internalDetails"][eachObj.key] = eachObj.value;
								}),
							);
							tempObject["geometry"] = eachShape["geometry"];
							const currentIndexes: Shapeindex[] = objectIdShapeIndexDict['"' + eachShape._id + '"'];
							const indexesDict = {};
							currentIndexes.forEach((eachIndex) => {
								indexesDict[eachIndex.indexName] = eachIndex.indexValue;
							});
							tempObject["index"] = indexesDict;
							tempObject["name"] = eachShape.pincode;
							tempObject["level"] = "cluster";
							tempObject["city"] = eachShape.city;
							tempObject["locality"] = eachShape["locality"];
							tempObject["weight"] = eachShape["weight"];
							tempObject["store"] = eachShape["store"];
							tempObject["pincode"] = eachShape["pincode"];
							tempObject["cluster_id"] = eachShape["cluster_id"];
							responseObjects.push(tempObject);
						}),
					);
					//For WFSL
					await Promise.all(
						responseObjects.map(async (eachShape) => {
							const latArr = [];
							const longArr = [];
							//console.log(eachShape["geometry"]["coordinates"][0]);
							await Promise.all(
								eachShape["geometry"]["coordinates"][0].map((eachArr) => {
									//console.log(eachArr);
									latArr.push(eachArr[1]);
									longArr.push(eachArr[0]);
								}),
							);
							//console.log("LatArr :",latArr);
							//console.log("LongArr :",longArr);
							eachShape["id"] = eachShape["cluster_id"];
							delete eachShape["cluster_id"];
							const centerLat = await this.average(latArr);
							const centerLong = await this.average(longArr);
							eachShape["longitude"] = centerLong;
							eachShape["latitude"] = centerLat; /*
						eachShape["internal-property"] = {};
						eachShape["internal-property"] = { "weight": eachShape["weight"] , "store": eachShape["store"]};*/
							delete eachShape["store"];
							delete eachShape["weight"];
						}),
					);
					//starting index filter and shapeDetails filter
					console.log("Length of ResponseObj:", responseObjects.length);
					let finalResponse = [];
					if (query["grids"]) {
						await Promise.all(
							responseObjects.map(async (eachResponseObj) => {
								const testArr = [];
								await Promise.all(
									Object.keys(query["grids"]).map(async (eachKey) => {
										const min = query["grids"][eachKey]["min"];
										const max = query["grids"][eachKey]["max"];
										if (eachResponseObj["index"][eachKey] === undefined) {
											eachResponseObj["index"][eachKey] = -1;
										}
										if (
											Number(eachResponseObj["index"][eachKey]) >= min &&
											Number(eachResponseObj["index"][eachKey]) <= max
										) {
											testArr.push(true);
										} else {
											testArr.push(false);
										}
									}),
								);
								if (!testArr.includes(false)) {
									finalResponse.push(eachResponseObj);
								}
							}),
						);
					}
					if (!query["grids"]) {
						console.log("IndexFilters not found");
						finalResponse = responseObjects;
					}
					console.log("Length of FinalResponse After indexFilter:", finalResponse.length);
					let ultimateResponse = [];
					if (query["shapeDetails"]) {
						let shapeDetailsQuery = [];
						shapeDetailsQuery = query["shapeDetails"];
						await Promise.all(
							finalResponse.map(async (eachResponseObj) => {
								const testArr = [];
								await Promise.all(
									shapeDetailsQuery.map((eachQueryObj) => {
										if (eachQueryObj["dataType"] == "number") {
											const min = eachQueryObj["values"]["min"];
											const max = eachQueryObj["values"]["max"];
											if (eachResponseObj["internalDetails"][eachQueryObj["key"]] === undefined) {
												eachResponseObj["internalDetails"][eachQueryObj["key"]] = -1;
											}
											if (
												Number(eachResponseObj["internalDetails"][eachQueryObj["key"]]) >=
													min &&
												Number(eachResponseObj["internalDetails"][eachQueryObj["key"]]) <= max
											) {
												testArr.push(true);
											} else {
												testArr.push(false);
											}
										} else {
											let values = [];
											values = eachQueryObj["values"];
											if (
												values.includes(eachResponseObj["internalDetails"][eachQueryObj["key"]])
											) {
												testArr.push(true);
											} else {
												testArr.push(false);
											}
										}
									}),
								);
								if (!testArr.includes(false)) {
									ultimateResponse.push(eachResponseObj);
								}
							}),
						);
					}
					if (!query["shapeDetails"]) {
						console.log("Internal Filters not found");
						ultimateResponse = finalResponse;
					}
					console.log("Length of FinalResponse After internalFilter:", ultimateResponse.length);
					//Ending index filter and shapeDetails filter
					return ultimateResponse;
				}
				//-----------------------------------------------------------------------------------------
				console.log("Length of shapesFromMongoReturned", shapesFromMongoReturned.length);
				const responseObjects = [];
				shapesFromMongoReturned.forEach((eachShape) => {
					const tempObject: unknown = {};
					tempObject["geometry"] = eachShape["_doc"]["geometry"];
					let currentIndexes: Shapeindex[] = objectIdShapeIndexDict[eachShape._id];
					//console.log("object id shape index dict", objectIdShapeIndexDict);
					if (!currentIndexes) {
						currentIndexes = [];
					}
					const indexesDict = {};
					currentIndexes.forEach((eachIndex) => {
						indexesDict[eachIndex.indexName] = eachIndex.indexValue;
					});
					tempObject["index"] = indexesDict;
					tempObject["name"] = eachShape.name;
					tempObject["level"] = eachShape["_doc"]["level"];
					responseObjects.push(tempObject);
				});
				//starting index filter and shapeDetails filter
				console.log("Length of ResponseObj:", responseObjects.length);
				let finalResponse = [];
				if (query["grids"]) {
					await Promise.all(
						responseObjects.map(async (eachResponseObj) => {
							const testArr = [];
							await Promise.all(
								Object.keys(query["grids"]).map(async (eachKey) => {
									const min = query["grids"][eachKey]["min"];
									const max = query["grids"][eachKey]["max"];
									if (eachResponseObj["index"][eachKey] === undefined) {
										eachResponseObj["index"][eachKey] = -1;
									}
									if (
										Number(eachResponseObj["index"][eachKey]) >= min &&
										Number(eachResponseObj["index"][eachKey]) <= max
									) {
										testArr.push(true);
									} else {
										testArr.push(false);
									}
								}),
							);
							if (!testArr.includes(false)) {
								finalResponse.push(eachResponseObj);
							}
						}),
					);
				}
				if (!query["grids"]) {
					console.log("IndexFilters not found");
					finalResponse = responseObjects;
				}
				console.log("Length of FinalResponse After indexFilter:", finalResponse.length);
				let ultimateResponse = [];
				if (query["shapeDetails"]) {
					let shapeDetailsQuery = [];
					shapeDetailsQuery = query["shapeDetails"];
					await Promise.all(
						finalResponse.map(async (eachResponseObj) => {
							const testArr = [];
							await Promise.all(
								shapeDetailsQuery.map((eachQueryObj) => {
									if (eachQueryObj["dataType"] == "number") {
										const min = eachQueryObj["values"]["min"];
										const max = eachQueryObj["values"]["max"];
										if (eachResponseObj["internalDetails"][eachQueryObj["key"]] === undefined) {
											eachResponseObj["internalDetails"][eachQueryObj["key"]] = -1;
										}
										if (
											Number(eachResponseObj["internalDetails"][eachQueryObj["key"]]) >= min &&
											Number(eachResponseObj["internalDetails"][eachQueryObj["key"]]) <= max
										) {
											testArr.push(true);
										} else {
											testArr.push(false);
										}
									} else {
										let values = [];
										values = eachQueryObj["values"];
										if (values.includes(eachResponseObj["internalDetails"][eachQueryObj["key"]])) {
											testArr.push(true);
										} else {
											testArr.push(false);
										}
									}
								}),
							);
							if (!testArr.includes(false)) {
								ultimateResponse.push(eachResponseObj);
							}
						}),
					);
				}
				if (!query["shapeDetails"]) {
					console.log("Internal Filters not found");
					ultimateResponse = finalResponse;
				}
				console.log("Length of FinalResponse After internalFilter:", ultimateResponse.length);
				//Ending index filter and shapeDetails filter
				return ultimateResponse;
			}
		}
	}

	async dumpShapesFromMongo(): Promise<void> {
		console.log("Starting ...");
		const shapes = await this.demoShapesDBModel.find().exec();
		//const shapes = await this.db.collection("WfClustersDB2").find().toArray();
		for await (const eachShape of shapes) {
			const psqlShape = new Shape();
			const indexConversionDict = {
				affluence: "avg",
				life_style_index: "avg",
				income: "avg",
				visibility: "avg",
				high_street: "avg",
				accessibility: "avg",
				food_and_beverages: "sum",
				worship_index: "sum",
				financial: "sum",
				work_hub: "sum",
				religious_hub: "sum",
				personal_care: "sum",
				entertainment: "sum",
				retail_stores: "sum",
				transport_hub: "sum",
				kirana: "sum",
				medical: "sum",
				apparels_hub: "sum",
				educational: "sum",
				footfall: "sum",
				commercial: "sum",
				population: "sum",
			};
			psqlShape.level = eachShape["_doc"]["level"];
			Object.keys(eachShape).forEach((eachKey) => {
				//console.log("eachKey is", eachKey);
				//console.log("value is", eachShape[eachKey]);
			});
			psqlShape.name = eachShape.name;
			psqlShape.objectId = eachShape._id;
			psqlShape.City = eachShape["_doc"]["city"];
			psqlShape.District = eachShape["_doc"]["district"];
			psqlShape.Pincode = eachShape["_doc"]["pincode"];
			psqlShape.State = eachShape["_doc"]["state"];
			const indexesRequestDict = {};
			indexesRequestDict[this.capitalizeFirstLetter(psqlShape.level)] = psqlShape.name;
			const grids = await this.gridsRepository
				.createQueryBuilder("grid")
				.leftJoinAndSelect("grid.indexmaster", "indexmaster")
				.getMany();
			const indexes = grids.map((eachGrid) => {
				return eachGrid.indexmaster;
			});
			const flattenedIndexes = _.flattenDeep(indexes);
			const shapeIndexArr: Shapeindex[] = [];
			Object.keys(indexConversionDict).forEach((eachIndexKey) => {
				const shapeIndex = new Shapeindex();
				if (indexConversionDict[eachIndexKey] === "avg") {
					let totalValue = 0,
						avgValue,
						indexCount = 0;
					flattenedIndexes.forEach((eachIndex) => {
						if (eachIndex.indexName === eachIndexKey) {
							totalValue += Number(eachIndex.indexValue);
							indexCount++;
						}
					});
					avgValue = totalValue / indexCount;
					if (avgValue) {
						shapeIndex.indexName = eachIndexKey;
						shapeIndex.indexValue = avgValue;
						shapeIndexArr.push(shapeIndex);
					}
				} else if (indexConversionDict[eachIndexKey] === "sum") {
					let totalValue = 0;
					flattenedIndexes.forEach((eachIndex) => {
						if (eachIndex.indexName === eachIndexKey) {
							totalValue += Number(eachIndex.indexValue);
						}
					});
					if (totalValue) {
						shapeIndex.indexName = eachIndexKey;
						shapeIndex.indexValue = totalValue;
						shapeIndexArr.push(shapeIndex);
					}
				} else {
					console.log("can't aggregate ", eachIndexKey);
				}
			});
			psqlShape.shapeindex = shapeIndexArr;
			await this.shapesRepository.save(psqlShape);
		}
		console.log("Done");
	}

	capitalizeFirstLetter(inputString: string): string {
		if (typeof inputString !== "string") return "";
		return inputString.charAt(0).toUpperCase() + inputString.slice(1);
	}

	async dumpClustersFromMongo() {
		console.log("Starting...");
		const shapes = await this.demoShapesDBModel.find({ level: "cluster" });
		console.log("clusters from shapes db", shapes);
		return [];
		console.log("Total number of Clusters found :", shapes.length);
		for await (const eachShape of shapes) {
			//const shapeDetails = new ShapeDetail();
			const psqlShape = new Shape();
			const indexConversionDict = {
				affluence: "avg",
				life_style_index: "avg",
				income: "avg",
				visibility: "avg",
				high_street: "avg",
				accessibility: "avg",
				food_and_beverages: "sum",
				worship_index: "sum",
				financial: "sum",
				work_hub: "sum",
				religious_hub: "sum",
				personal_care: "sum",
				entertainment: "sum",
				retail_stores: "sum",
				transport_hub: "sum",
				kirana: "sum",
				medical: "sum",
				apparels_hub: "sum",
				educational: "sum",
				footfall: "sum",
				commercial: "sum",
				population: "sum",
			};
			console.log("shape from mongo", eachShape);
			psqlShape.level = "cluster";
			psqlShape.name = this.capitalizeFirstLetter(eachShape["pincode"]);
			psqlShape.name = eachShape["cluster_id"];
			psqlShape.objectId = eachShape._id;
			psqlShape.City = eachShape["city"];
			psqlShape.District = eachShape["district"];
			psqlShape.Pincode = eachShape["pincode"];
			psqlShape.State = eachShape["state"];
			//console.log("PSQL Shape: ",psqlShape);
			const indexesRequestDict = {};
			indexesRequestDict[this.capitalizeFirstLetter(psqlShape.level)] = psqlShape.name;
			const grids = await this.gridsRepository
				.createQueryBuilder("grid")
				.leftJoinAndSelect("grid.indexmaster", "indexmaster")
				.where('"Pincode" = :pincode', { pincode: eachShape["pincode"] }) //searching from clusterId
				.getMany();
			const indexes = grids.map((eachGrid) => {
				return eachGrid.indexmaster;
			});
			const flattenedIndexes = _.flattenDeep(indexes);
			const shapeIndexArr: Shapeindex[] = [];
			Object.keys(indexConversionDict).forEach((eachIndexKey) => {
				const shapeIndex = new Shapeindex();
				if (indexConversionDict[eachIndexKey] === "avg") {
					let totalValue = 0,
						avgValue,
						indexCount = 0;
					flattenedIndexes.forEach((eachIndex) => {
						if (eachIndex.indexName === eachIndexKey) {
							totalValue += Number(eachIndex.indexValue);
							indexCount++;
						}
					});
					avgValue = totalValue / indexCount;
					if (avgValue) {
						shapeIndex.indexName = eachIndexKey;
						shapeIndex.indexValue = avgValue;
						shapeIndexArr.push(shapeIndex);
					}
				} else if (indexConversionDict[eachIndexKey] === "sum") {
					let totalValue = 0;
					flattenedIndexes.forEach((eachIndex) => {
						if (eachIndex.indexName === eachIndexKey) {
							totalValue += Number(eachIndex.indexValue);
						}
					});
					if (totalValue) {
						shapeIndex.indexName = eachIndexKey;
						shapeIndex.indexValue = totalValue;
						shapeIndexArr.push(shapeIndex);
					}
				} else {
					console.log("can't aggregate ", eachIndexKey);
				}
			});
			psqlShape.shapeindex = shapeIndexArr;
			console.log("final shape to be saved", psqlShape);
			console.log("grids length", indexes.length);
			await this.shapesRepository.save(psqlShape);
			console.log("Saved");
		}
	}

	async populateShapeDetails(): Promise<void> {
		//Only For Clusters
		const shapes = await this.shapesRepository.find({ where: { level: "cluster" } });
		console.log("Number of Shapes Found :", shapes.length);
		await Promise.all(
			shapes.map(async (eachShape) => {
				console.log(eachShape.objectId);
				//console.log("Here");
				const newObjectIdString = String(eachShape.objectId.slice(1, -1));
				//console.log("Then :",newObjectIdString);
				//const mongoId = new String(new mongoose.Types.ObjectId(eachShape.objectId));
				// console.log("MongoId :",mongoId);
				//const id = new ObjectID(eachShape.objectId);
				const clusterFromMongo = await this.db
					.collection("ClustersDB")
					.findOne({ where: { _id: new ObjectId(newObjectIdString) } });
				console.log("Cluster with ObjectId :" + eachShape.objectId + " Found!");
				const shapeDetailsWeight = new ShapeDetail();
				shapeDetailsWeight.shapeId = eachShape.id;
				shapeDetailsWeight.key = "weight";
				shapeDetailsWeight.dataType = "number";
				shapeDetailsWeight.value = String(clusterFromMongo["weight"]);
				const shapeDetailsStore = new ShapeDetail();
				shapeDetailsStore.shapeId = eachShape.id;
				shapeDetailsStore.key = "store";
				shapeDetailsStore.dataType = "number";
				shapeDetailsStore.value = String(clusterFromMongo["store"]);
				await this.shapeDetailsRepository.save(shapeDetailsWeight);
				await this.shapeDetailsRepository.save(shapeDetailsStore);
				console.log("Saved");
			}),
		);
	}

	async filterShapeDetails(query) {
		console.log("inside filter shape details");
		if (!query["types"]) {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: "Request body must contain 'types'",
				},
				HttpStatus.BAD_REQUEST,
			);
		}
		const types = query["types"] as string[];

		const shapes = await this.shapesRepository.find({ where: { level: In(types) } });
		const shapeIds = [];
		await Promise.all(
			shapes.map((eachShape) => {
				shapeIds.push(eachShape.id);
			}),
		);

		let requestedKeys = [];
		if (query?.["keys"]?.length) {
			requestedKeys = query["keys"] as string[];
		}

		let reqShapeDetail = [];
		try {
			if (query?.["keys"]?.length) {
				reqShapeDetail = await this.shapeDetailsRepository
					.createQueryBuilder("shape_detail")
					.select(["key", '"dataType"'])
					.distinct(true)
					.where(`"shapeId" IN (SELECT id FROM shape WHERE level IN(:...types))`, { types: types })
					.andWhere(`key IN(:...keys)`, { keys: requestedKeys })
					.getRawMany();
			} else {
				reqShapeDetail = await this.shapeDetailsRepository
					.createQueryBuilder("shape_detail")
					.select(["key", '"dataType"'])
					.distinct(true)
					.where(`"shapeId" IN(SELECT id FROM shape WHERE level IN(:...types))`, { types: types })
					.getRawMany();
			}
		} catch (err) {
			console.log(err);
		}
		//const reqShapeDetail = await this.shapeDetailsRepository.find({ where: { shapeId:shapes[0].id }});
		const reqKeys = [];

		await Promise.all(
			reqShapeDetail.map((eachshapeDetail) => {
				const tempObj = {};
				tempObj["key"] = eachshapeDetail.key;
				tempObj["dataType"] = eachshapeDetail.dataType;
				reqKeys.push(tempObj);
			}),
		);
		await Promise.all(
			reqKeys.map(async (eachKey) => {
				if (eachKey.dataType == "number") {
					console.log("Number Type found.");
					const values = await this.filterQuery(types, eachKey["key"]);
					const units: number[] = values.map((eachValue) => {
						return eachValue.unit;
					});
					const min = Math.min.apply(Math, units);
					const max = Math.max.apply(Math, units);
					eachKey["values"] = { min: min, max: max };
				} else {
					const values = await this.shapeDetailsRepository
						.createQueryBuilder("shape_detail")
						.where('key = :key AND "shapeId" IN (SELECT id FROM shape WHERE level IN(:...types))', {
							key: eachKey["key"],
							types: types,
						})
						.select(["value", "unit"])
						.distinct(true)
						.getRawMany();
					const sortedValues = _.sortBy(values, "unit");
					if (sortedValues.length > Number(process.env.MINIMUM_LIMIT_FOR_FILTER)) {
						eachKey["values"] = "Not Filterable";
					} else {
						eachKey["values"] = sortedValues.map((eachValue) => {
							return eachValue.value;
						});
					}
				}
			}),
		);

		return reqKeys;
	}
	async filterQuery(types: string[], key) {
		return await this.shapeDetailsRepository
			.createQueryBuilder("shape_detail")
			.where('key = :key AND "shapeId" IN (SELECT id FROM shape WHERE level IN(:...types))', {
				key: key,
				types: types,
			})
			.select("unit")
			.distinct(true)
			.getRawMany();
	}

	async getFilteredShapeIdArrays(query: MultilevelShapesQuery, intersectionArray: number[][]): Promise<number[][]> {
		try {
			// filter section against shape indexes
			if (query["shapes"]) {
				if (query["shapes"]["range"]) {
					if (Object.keys(query["shapes"]["range"]).length) {
						await Promise.all(
							Object.keys(query["shapes"]["range"]).map(async (eachKey) => {
								let pincodeQueryString = "";
								const pincodeQueryObject = {};
								pincodeQueryString +=
									'shapeindex."indexName" = :' +
									eachKey +
									'name AND shapeindex."indexValue" BETWEEN :' +
									eachKey +
									"min AND :" +
									eachKey +
									"max";
								pincodeQueryObject[eachKey + "min"] = query["shapes"]["range"][eachKey]["min"];
								pincodeQueryObject[eachKey + "max"] = query["shapes"]["range"][eachKey]["max"];
								pincodeQueryObject[eachKey + "name"] = eachKey;
								try {
									const response = await this.shapesRepository
										.createQueryBuilder("shape")
										.leftJoinAndSelect("shape.shapeindex", "shapeindex")
										.where(pincodeQueryString, pincodeQueryObject)
										.select("shape.id")
										.getMany();
									const shapeIds = response.map((eachResp) => {
										return eachResp.id;
									});
									intersectionArray.push(_.flattenDeep(shapeIds));
								} catch (error) {
									console.log(error);
								}
							}),
						);
					}
				}
				if (query["shapes"]["select"]) {
					if (Object.keys(query["shapes"]["select"]).length) {
						const shapeSelectResponse = await Promise.all(
							Object.keys(query["shapes"]["select"]).map(async (eachKey) => {
								console.log("eachSelect key", eachKey);
								try {
									const someIndexes = await this.shapeIndexRepository
										.createQueryBuilder("shapeindex")
										.select('shapeindex."shapeId"')
										.where('shapeindex."indexName" = :indexName', { indexName: eachKey })
										.andWhere('shapeindex."categoricalValue" IN (:...categoricalValues)', {
											categoricalValues: query["shapes"]["select"][eachKey],
										})
										.getRawMany();
									const shapeIds = someIndexes.map((eachIndex) => {
										return eachIndex["shapeId"];
									});
									intersectionArray.push(_.flattenDeep(shapeIds));
									return shapeIds;
								} catch (error) {
									console.log(error);
									return [];
								}
							}),
						);
						console.log("pincodes against select indexes", shapeSelectResponse);
					}
				}
			}

			// filtering against shapes internal properties
			let shapeIdsFromShapeDetails = [];
			if (query["shapeDetails"]) {
				const intersectionStatus = 0;
				const shapeDetails: any[] = query["shapeDetails"];
				if (shapeDetails.length == 0) {
					shapeIdsFromShapeDetails = [];
				} else {
					await Promise.all(
						shapeDetails.map(async (eachShapeDetail, index) => {
							if (eachShapeDetail.dataType == "number") {
								const tempShapeIdsArray = [];
								let tempShapeDetails = [];
								try {
									tempShapeDetails = await this.shapeDetailsRepository
										.createQueryBuilder("shape_detail")
										.where("key = :key", { key: eachShapeDetail.key })
										.andWhere("unit BETWEEN :min and :max", {
											min: eachShapeDetail["values"]["min"],
											max: eachShapeDetail["values"]["max"],
										})
										.select('"shapeId"')
										.distinct(true)
										.getRawMany();
								} catch (error) {
									console.log(error);
								}
								await Promise.all(
									tempShapeDetails.map((eachShapeDetailHere) => {
										tempShapeIdsArray.push(eachShapeDetailHere.shapeId);
									}),
								);
								intersectionArray.push(_.flattenDeep(tempShapeIdsArray));
							} else {
								console.log("DataType : ", eachShapeDetail["dataType"]);
								const tempShapeIdsFromString = [];
								const tempShapeIds = await this.shapeDetailsRepository
									.createQueryBuilder("shape_detail")
									.where("key = :key AND value IN(:...values)", {
										key: eachShapeDetail.key,
										values: eachShapeDetail.values,
									})
									.select('"shapeId"')
									.distinct(true)
									.getRawMany();
								await Promise.all(
									tempShapeIds.map((eachShapeId) => {
										tempShapeIdsFromString.push(eachShapeId.shapeId);
									}),
								);
								intersectionArray.push(_.flattenDeep(tempShapeIdsFromString));
							}
						}),
					);
				}
			}

			if (query["within"]) {
				let latLongs: LatLong[] = [];
				latLongs = query["within"]["points"];
				let distance = query["within"]["radius"];
				distance = distance;
				const withinGridsArr: number[][] = await Promise.all(
					query["within"]["points"].map(async (eachLatLong) => {
						const pi = Math.PI;
						const lat_increment = 1 / 110.574;
						const lng_increment = 1 / 111.32;
						const lat_max = Number(eachLatLong.lat) + distance * lat_increment;
						const lat_min = Number(eachLatLong.lat) - distance * lat_increment;
						const lng_max =
							Number(eachLatLong.lng) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
						const lng_min =
							Number(eachLatLong.lng) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
						const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
						try {
							const tempGrid = await this.gridsRepository
								.createQueryBuilder("grid")
								.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
								.select("grid.id")
								.getMany();

							const tempGridIds = tempGrid.map((eachGrid) => {
								return eachGrid.id;
							});
							return tempGridIds;
						} catch (error) {
							return null;
						}
					}),
				);
				const gridIds = _.flattenDeep(withinGridsArr);
				const level = [];
				const shapeIdsFromWithinQuery = [];
				if (query["childLevel"]) {
					const gridLevel = await this.gridsRepository
						.createQueryBuilder("grid")
						.select(['"' + query["childLevel"] + '"'])
						.distinct(true)
						.where("id IN(:...gridIds)", { gridIds: gridIds })
						.getRawMany();
					await Promise.all(
						gridLevel.map((eachObj) => {
							level.push(eachObj[query["childLevel"]]);
						}),
					);
					const shape = await this.shapesRepository
						.createQueryBuilder("shape")
						.select("id")
						.where("level = :level AND name IN(:...levelNames)", {
							level: query["childLevel"],
							levelNames: level,
						})
						.distinct(true)
						.getRawMany();
					await Promise.all(
						shape.map((eachObj) => {
							shapeIdsFromWithinQuery.push(eachObj["id"]);
						}),
					);
				}
				intersectionArray.push(_.flattenDeep(shapeIdsFromWithinQuery));
			}
		} catch (error) {
			console.error(error);
			return [];
		} finally {
			return intersectionArray;
		}
	}

	async multilevelShapesNew(query: MultilevelShapesQuery): Promise<unknown> {
		let level, childLevel, name;
		if (query.location != undefined) {
			if (query.location.State) {
				console.log("inside state");
				level = "State";
				name = query.location.State;
			}
			if (query.location.City) {
				console.log("inside city");
				level = "City";
				name = query.location.City;
			}
			if (query.location.Locality) {
				console.log("inside locality");
				level = "Locality";
				name = query.location.Locality;
			}
			if (query.location.Pincode) {
				console.log("inside pincode");
				level = "Pincode";
				name = query.location.Pincode;
			}
			if (query.location.District) {
				console.log("inside district");
				level = "District";
				name = query.location.District;
			}
			if (query.location.Country) {
				console.log("inside country");
				level = "Country";
				name = query.location.Country;
			}
			if (query.location.Cluster) {
				console.log("inside Cluster");
				level = "Cluster";
				name = query.location.Cluster;
			}
			if (query.location.Taluka) {
				console.log("inside Taluka");
				level = "Taluka";
				name = query.location.Taluka;
			}
		}
		if (query.childLevel === level && query.location != undefined) {
			delete query.childLevel;
		}
		console.log("level is", level);
		console.log("query is", query);
		if (!query.childLevel) {
			if (!name) name = query["name"];
			if (!level) level = query["level"];
			const intersectionArray = [];
			await this.getFilteredShapeIdArrays(query, intersectionArray);

			//let queryString = `"${level}" = :name`;
			const locationObjects = await this.shapesRepository
				.createQueryBuilder("shape")
				.leftJoinAndSelect("shape.shapeindex", "shapeindex")
				.where("shape.name = :name", { name: name })
				.andWhere("shape.level = :level", { level: level })
				.getMany();
			const locationQueryIds = locationObjects.map((eachObject) => {
				return eachObject.id;
			});
			intersectionArray.push(locationQueryIds);

			let finalIds = [];
			// The intersection Array is operated on to generate final list of shape ids from all the requests
			intersectionArray.forEach((eachArray, index) => {
				if (index === 0) {
					finalIds = eachArray;
				} else {
					finalIds = _.intersection(finalIds, eachArray);
				}
			});
			if (finalIds.length == 0) {
				finalIds = [0];
			}

			const finalObjects = await this.shapesRepository
				.createQueryBuilder("shape")
				.leftJoinAndSelect("shape.shapeindex", "shapeindex")
				.where(`shape.id IN (:...ids)`, { ids: finalIds })
				.getMany();

			const objectIdShapeIndexDict = {};
			const objectIdShapeInternalDetailsDict = {};
			const shapeIdShapeInternalDetailsDict = {};
			const shapesInternalDetails = await this.shapeDetailsRepository.find({
				where: {
					shapeId: In(finalIds),
				},
			});
			shapesInternalDetails.forEach((eachDetail) => {
				const eachShapeInternalDetailsDict = {};
				if (!shapeIdShapeInternalDetailsDict[eachDetail.shapeId]) {
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId] = {};
					const tempObj = {};
					tempObj["value"] = eachDetail.value;
					tempObj["unit"] = eachDetail.metrics;
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId][eachDetail.key] = eachDetail.value;
				} else {
					const tempObj = {};
					tempObj["value"] = eachDetail.value;
					tempObj["unit"] = eachDetail.metrics;
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId][eachDetail.key] = eachDetail.value;
				}
			});
			const finalObjectIdsFromPostgres = finalObjects.map((eachObject) => {
				objectIdShapeIndexDict[eachObject.objectId] = eachObject.shapeindex;
				objectIdShapeInternalDetailsDict[eachObject.objectId] = shapeIdShapeInternalDetailsDict[eachObject.id];
				const newObjectIdString = eachObject.objectId;
				return new mongoose.Types.ObjectId(eachObject.objectId);
			});
			const shapesFromMongoReturned = await this.demoShapesDBModel.find({
				_id: {
					$in: finalObjectIdsFromPostgres,
				},
			});
			const responseObjects = [];
			shapesFromMongoReturned.forEach((eachShape) => {
				const tempObject: unknown = {};
				tempObject["geometry"] = eachShape["_doc"]["geometry"];
				let currentIndexes: Shapeindex[] = objectIdShapeIndexDict[eachShape._id];
				//console.log("object id shape index dict", objectIdShapeIndexDict);
				if (!currentIndexes) {
					currentIndexes = [];
				}
				const indexesDict = {};
				currentIndexes.forEach((eachIndex) => {
					//console.log("index type is", eachIndex.indexType);
					if (eachIndex.indexType === "string") {
						indexesDict[eachIndex.indexName] = eachIndex.categoricalValue;
					} else {
						/*
						let tempObj = {};
						tempObj["value"] = eachIndex.indexValue;
						tempObj["unit"] = eachIndex.metrics;
						*/
						indexesDict[eachIndex.indexName] = eachIndex.indexValue;
					}
				});
				const orderedIndexDict = {};
				_(indexesDict)
					.keys()
					.sort()
					.each(function (key) {
						orderedIndexDict[key] = indexesDict[key];
					});
				const internalDetails = objectIdShapeInternalDetailsDict[eachShape._id];
				const orderedInternalDetails = {};
				_(internalDetails)
					.keys()
					.sort()
					.each(function (key) {
						orderedInternalDetails[key] = internalDetails[key];
					});
				tempObject["id"] = eachShape._id;
				tempObject["index"] = orderedIndexDict;
				tempObject["internalDetails"] = orderedInternalDetails;
				tempObject["name"] = eachShape.name;
				tempObject["level"] = eachShape["_doc"]["level"];
				tempObject["State"] = eachShape["_doc"]["state"];
				tempObject["District"] = eachShape["_doc"]["district"];
				tempObject["Pincode"] = eachShape["_doc"]["pincode"];
				tempObject["City"] = eachShape["_doc"]["city"];
				//Ordering....
				const orderedTempObject = {};
				_(tempObject)
					.keys()
					.sort()
					.each(function (key) {
						orderedTempObject[key] = tempObject[key];
					});
				responseObjects.push(orderedTempObject);
			});
			const responseBody = {};
			responseBody["count"] = shapesFromMongoReturned.length;
			responseBody["data"] = responseObjects;
			return responseBody;
		} else {
			console.log("no child level");
			const intersectionArray = [];
			await this.getFilteredShapeIdArrays(query, intersectionArray);
			// getting all the pincodes against a location query
			if (query["location"]) {
				const pincodesFromLocation = await this.shapesRepository.find({
					where: { level: query.childLevel, [level]: name },
				});
				const pincodeIdsFromLocation = pincodesFromLocation.map((p) => p.id);
				intersectionArray.push(_.flattenDeep(pincodeIdsFromLocation));
				console.log(pincodesFromLocation.length, intersectionArray.length);
			}
			let pincodeIdsAgainstIndexes = [];
			let pincodeIdsAgainstIndexesIntersected;
			const shapesQueryFlag = false;

			let finalIds = [];
			// The intersection Array is operated on to generate final list of shape ids from all the requests
			intersectionArray.forEach((eachArray, index) => {
				if (index === 0) {
					finalIds = eachArray;
				} else {
					finalIds = _.intersection(finalIds, eachArray);
				}
			});
			if (finalIds.length == 0) {
				finalIds = [0];
			}
			const finalObjects = await this.shapesRepository
				.createQueryBuilder("shape")
				.leftJoinAndSelect("shape.shapeindex", "shapeindex")
				.where("shape.id IN (:...finalIds)", { finalIds: finalIds })
				.getMany();
			const objectIdShapeIndexDict = {};
			const objectIdShapeInternalDetailsDict = {};
			const shapeIdShapeInternalDetailsDict = {};
			const shapesInternalDetails = await this.shapeDetailsRepository.find({
				where: {
					shapeId: In(finalIds),
				},
			});
			shapesInternalDetails.forEach((eachDetail) => {
				const eachShapeInternalDetailsDict = {};
				if (!shapeIdShapeInternalDetailsDict[eachDetail.shapeId]) {
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId] = {};
					const tempObj = {};
					tempObj["value"] = eachDetail.value;
					tempObj["unit"] = eachDetail.metrics;
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId][eachDetail.key] = eachDetail.value;
				} else {
					const tempObj = {};
					tempObj["value"] = eachDetail.value;
					tempObj["unit"] = eachDetail.metrics;
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId][eachDetail.key] = eachDetail.value;
				}
			});
			const finalObjectIdsFromPostgres = finalObjects.map((eachObject) => {
				objectIdShapeIndexDict[eachObject.objectId] = eachObject.shapeindex;
				objectIdShapeInternalDetailsDict[eachObject.objectId] = shapeIdShapeInternalDetailsDict[eachObject.id];

				const newObjectIdString = eachObject.objectId;
				return new mongoose.mongo.ObjectId(newObjectIdString);
			});
			const shapesFromMongoReturned = await this.demoShapesDBModel.find({
				_id: {
					$in: finalObjectIdsFromPostgres,
				},
			});
			const responseObjects = [];
			shapesFromMongoReturned.forEach((eachShape) => {
				const tempObject: unknown = {};
				tempObject["geometry"] = eachShape["_doc"]["geometry"];
				let currentIndexes: Shapeindex[] = objectIdShapeIndexDict[eachShape._id];
				//console.log("object id shape index dict", objectIdShapeIndexDict);
				if (!currentIndexes) {
					currentIndexes = [];
				}
				const indexesDict = {};
				currentIndexes.forEach((eachIndex) => {
					if (eachIndex.indexType === "string") {
						indexesDict[eachIndex.indexName] = eachIndex.categoricalValue;
					} else {
						const tempObj = {};
						tempObj["value"] = eachIndex.indexValue;
						tempObj["unit"] = eachIndex.metrics;
						indexesDict[eachIndex.indexName] = eachIndex.indexValue;
					}
				});
				const orderedIndexDict = {};
				_(indexesDict)
					.keys()
					.sort()
					.each(function (key) {
						orderedIndexDict[key] = indexesDict[key];
					});
				const internalDetails = objectIdShapeInternalDetailsDict[eachShape._id];
				const orderedInternalDetails = {};
				_(internalDetails)
					.keys()
					.sort()
					.each(function (key) {
						orderedInternalDetails[key] = internalDetails[key];
					});
				tempObject["id"] = eachShape._id;
				tempObject["index"] = orderedIndexDict;
				tempObject["internalDetails"] = orderedInternalDetails;
				tempObject["name"] = eachShape.name;
				tempObject["level"] = eachShape["_doc"]["level"];
				tempObject["State"] = eachShape["_doc"]["state"];
				tempObject["District"] = eachShape["_doc"]["district"];
				tempObject["Pincode"] = eachShape["_doc"]["pincode"];
				tempObject["City"] = eachShape["_doc"]["city"];
				//Ordering....
				const orderedTempObject = {};
				_(tempObject)
					.keys()
					.sort()
					.each(function (key) {
						orderedTempObject[key] = tempObject[key];
					});
				responseObjects.push(orderedTempObject);
			});
			const responseBody = {};
			responseBody["count"] = shapesFromMongoReturned.length;
			responseBody["data"] = responseObjects;
			return responseBody;
		}
	}

	async multilevelShapesScorecard(query: MultilevelShapesQuery): Promise<unknown> {
		let level, childLevel, name;
		if (query.location != undefined) {
			if (query.location.State) {
				console.log("inside state");
				level = "State";
				name = query.location.State;
			}
			if (query.location.City) {
				console.log("inside city");
				level = "City";
				name = query.location.City;
			}
			if (query.location.Locality) {
				console.log("inside locality");
				level = "Locality";
				name = query.location.Locality;
			}
			if (query.location.Pincode) {
				console.log("inside pincode");
				level = "Pincode";
				name = query.location.Pincode;
			}
			if (query.location.District) {
				console.log("inside district");
				level = "District";
				name = query.location.District;
			}
			if (query.location.Country) {
				console.log("inside country");
				level = "Country";
				name = query.location.Country;
			}
			if (query.location.Cluster) {
				console.log("inside Cluster");
				level = "Cluster";
				name = query.location.Cluster;
			}
		}
		if (query.childLevel === level && query.location != undefined) {
			delete query.childLevel;
		}
		console.log("level is", level);
		console.log("query is", query);
		if (!query.childLevel) {
			console.log("inside child level");
			//let queryString = `"${level}" = :name`;
			const finalObjects = await this.shapesRepository
				.createQueryBuilder("shape")
				.leftJoinAndSelect("shape.shapeindex", "shapeindex")
				.where("shape.name = :name", { name: name })
				.andWhere("shape.level = :level", { level: level })
				.getMany();
			const finalIds = finalObjects.map((eachObject) => {
				return eachObject.id;
			});
			const objectIdShapeIndexDict = {};
			const objectIdShapeInternalDetailsDict = {};
			const shapeIdShapeInternalDetailsDict = {};
			const shapesInternalDetails = await this.shapeDetailsRepository.find({
				where: {
					shapeId: In(finalIds),
				},
			});
			shapesInternalDetails.forEach((eachDetail) => {
				const eachShapeInternalDetailsDict = {};
				if (!shapeIdShapeInternalDetailsDict[eachDetail.shapeId]) {
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId] = {};
					const tempObj = {};
					tempObj["value"] = eachDetail.value;
					tempObj["unit"] = eachDetail.metrics;
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId][eachDetail.key] = tempObj;
				} else {
					const tempObj = {};
					tempObj["value"] = eachDetail.value;
					tempObj["unit"] = eachDetail.metrics;
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId][eachDetail.key] = tempObj;
				}
			});
			const finalObjectIdsFromPostgres = finalObjects.map((eachObject) => {
				objectIdShapeIndexDict[eachObject.objectId] = eachObject.shapeindex;
				objectIdShapeInternalDetailsDict[eachObject.objectId] = shapeIdShapeInternalDetailsDict[eachObject.id];
				const newObjectIdString = eachObject.objectId;
				return new mongoose.Types.ObjectId(eachObject.objectId);
			});
			const shapesFromMongoReturned = await this.demoShapesDBModel.find({
				_id: {
					$in: finalObjectIdsFromPostgres,
				},
			});
			const responseObjects = [];
			shapesFromMongoReturned.forEach((eachShape) => {
				const tempObject: unknown = {};
				tempObject["geometry"] = eachShape["_doc"]["geometry"];
				let currentIndexes: Shapeindex[] = objectIdShapeIndexDict[eachShape._id];
				//console.log("object id shape index dict", objectIdShapeIndexDict);
				if (!currentIndexes) {
					currentIndexes = [];
				}
				const indexesDict = {};
				currentIndexes.forEach((eachIndex) => {
					//console.log("index type is", eachIndex.indexType);
					if (eachIndex.indexType === "string") {
						indexesDict[eachIndex.indexName] = eachIndex.categoricalValue;
					} else {
						/*
						let tempObj = {};
						tempObj["value"] = eachIndex.indexValue;
						tempObj["unit"] = eachIndex.metrics;
						*/
						indexesDict[eachIndex.indexName] = eachIndex.indexValue;
					}
				});
				const orderedIndexDict = {};
				_(indexesDict)
					.keys()
					.sort()
					.each(function (key) {
						orderedIndexDict[key] = indexesDict[key];
					});
				const internalDetails = objectIdShapeInternalDetailsDict[eachShape._id];
				const orderedInternalDetails = {};
				_(internalDetails)
					.keys()
					.sort()
					.each(function (key) {
						orderedInternalDetails[key] = internalDetails[key];
					});
				tempObject["id"] = eachShape._id;
				tempObject["index"] = orderedIndexDict;
				tempObject["internalDetails"] = orderedInternalDetails;
				tempObject["name"] = eachShape.name;
				tempObject["level"] = eachShape["_doc"]["level"];
				tempObject["State"] = eachShape["_doc"]["state"];
				tempObject["District"] = eachShape["_doc"]["district"];
				tempObject["Pincode"] = eachShape["_doc"]["pincode"];
				tempObject["City"] = eachShape["_doc"]["city"];
				//Ordering....
				const orderedTempObject = {};
				_(tempObject)
					.keys()
					.sort()
					.each(function (key) {
						orderedTempObject[key] = tempObject[key];
					});
				responseObjects.push(orderedTempObject);
			});
			const responseBody = {};
			responseBody["count"] = shapesFromMongoReturned.length;
			responseBody["data"] = responseObjects;
			return responseBody;
		} else {
			console.log("no child level");
			const intersectionArray = [];
			// getting all the pincodes against a location query
			if (query["location"]) {
				const queryDict = {};
				queryDict["level"] = query.childLevel;
				queryDict[level] = name;
				const pincodesFromLocation = await this.shapesRepository.find({ where: queryDict });
				const pincodeIdsFromLocation = pincodesFromLocation.map((eachPincode) => {
					return eachPincode.id;
				});
				intersectionArray.push(_.flattenDeep(pincodeIdsFromLocation));
			}
			let pincodeIdsAgainstIndexes = [];
			let pincodeIdsAgainstIndexesIntersected;
			const shapesQueryFlag = false;
			// filter section against shape indexes
			if (query["shapes"]) {
				if (query["shapes"]["range"]) {
					if (Object.keys(query["shapes"]["range"]).length) {
						pincodeIdsAgainstIndexes = await Promise.all(
							Object.keys(query["shapes"]["range"]).map(async (eachKey) => {
								let pincodeQueryString = "";
								const pincodeQueryObject = {};
								pincodeQueryString +=
									'shapeindex."indexName" = :' +
									eachKey +
									'name AND shapeindex."indexValue" BETWEEN :' +
									eachKey +
									"min AND :" +
									eachKey +
									"max";
								pincodeQueryObject[eachKey + "min"] = query["shapes"]["range"][eachKey]["min"];
								pincodeQueryObject[eachKey + "max"] = query["shapes"]["range"][eachKey]["max"];
								pincodeQueryObject[eachKey + "name"] = eachKey;
								try {
									const response = await this.shapesRepository
										.createQueryBuilder("shape")
										.leftJoinAndSelect("shape.shapeindex", "shapeindex")
										.where(pincodeQueryString, pincodeQueryObject)
										.select("shape.id")
										.getMany();
									const shapeIds = response.map((eachResp) => {
										return eachResp.id;
									});
									intersectionArray.push(_.flattenDeep(shapeIds));
								} catch (error) {
									console.log(error);
								}
							}),
						);
						console.log("pincodes against indexes", pincodeIdsAgainstIndexes);
					}
				}
				if (query["shapes"]["select"]) {
					if (Object.keys(query["shapes"]["select"]).length) {
						const shapeSelectResponse = await Promise.all(
							Object.keys(query["shapes"]["select"]).map(async (eachKey) => {
								console.log("eachSelect key", eachKey);
								try {
									const someIndexes = await this.shapeIndexRepository
										.createQueryBuilder("shapeindex")
										.select('shapeindex."shapeId"')
										.where('shapeindex."indexName" = :indexName', { indexName: eachKey })
										.andWhere('shapeindex."categoricalValue" IN (:...categoricalValues)', {
											categoricalValues: query["shapes"]["select"][eachKey],
										})
										.getRawMany();
									const shapeIds = someIndexes.map((eachIndex) => {
										return eachIndex["shapeId"];
									});
									intersectionArray.push(_.flattenDeep(shapeIds));
									return shapeIds;
								} catch (error) {
									console.log(error);
									return [];
								}
							}),
						);
						console.log("pincodes against select indexes", shapeSelectResponse);
					}
				}
			}

			// filtering against shapes internal properties
			let shapeIdsFromShapeDetails = [];
			if (query["shapeDetails"]) {
				const intersectionStatus = 0;
				const shapeDetails: any[] = query["shapeDetails"];
				if (shapeDetails.length == 0) {
					shapeIdsFromShapeDetails = [];
				} else {
					await Promise.all(
						shapeDetails.map(async (eachShapeDetail, index) => {
							if (eachShapeDetail.dataType == "number") {
								const tempShapeIdsArray = [];
								let tempShapeDetails = [];
								try {
									tempShapeDetails = await this.shapeDetailsRepository
										.createQueryBuilder("shape_detail")
										.where("key = :key", { key: eachShapeDetail.key })
										.andWhere("unit BETWEEN :min and :max", {
											min: eachShapeDetail["values"]["min"],
											max: eachShapeDetail["values"]["max"],
										})
										.select('"shapeId"')
										.distinct(true)
										.getRawMany();
								} catch (error) {
									console.log(error);
								}
								await Promise.all(
									tempShapeDetails.map((eachShapeDetailHere) => {
										tempShapeIdsArray.push(eachShapeDetailHere.shapeId);
									}),
								);
								intersectionArray.push(_.flattenDeep(tempShapeIdsArray));
							} else {
								console.log("DataType : ", eachShapeDetail["dataType"]);
								const tempShapeIdsFromString = [];
								const tempShapeIds = await this.shapeDetailsRepository
									.createQueryBuilder("shape_detail")
									.where("key = :key AND value IN(:...values)", {
										key: eachShapeDetail.key,
										values: eachShapeDetail.values,
									})
									.select('"shapeId"')
									.distinct(true)
									.getRawMany();
								await Promise.all(
									tempShapeIds.map((eachShapeId) => {
										tempShapeIdsFromString.push(eachShapeId.shapeId);
									}),
								);
								intersectionArray.push(_.flattenDeep(tempShapeIdsFromString));
							}
						}),
					);
				}
				// push shape ids found after applying shape details filter to intersection array
			}

			if (query["within"]) {
				let latLongs: LatLong[] = [];
				latLongs = query["within"]["points"];
				let distance = query["within"]["radius"];
				distance = distance;
				const withinGridsArr: number[][] = await Promise.all(
					query["within"]["points"].map(async (eachLatLong) => {
						//const eachTarget = await this.propertyRepository.findOne({ where : { id: eachId }});
						//const point = tf.point([eachTarget.latitude, eachTarget.longitude]);
						/*
            const point = tf.point([eachLatLong.lat, eachLatLong.lng]);
            const topLeft = tf.destination(point, distance, angleA);
            const bottomRight = tf.destination(point, distance, angleB);
            const withinGrids = geohash.bboxes(
              topLeft["geometry"]["coordinates"][0],
              topLeft["geometry"]["coordinates"][1],
              bottomRight["geometry"]["coordinates"][0],
              bottomRight["geometry"]["coordinates"][1],
              7
            );
            */
						const pi = Math.PI;
						const lat_increment = 1 / 110.574;
						const lng_increment = 1 / 111.32;
						const lat_max = Number(eachLatLong.lat) + distance * lat_increment;
						const lat_min = Number(eachLatLong.lat) - distance * lat_increment;
						const lng_max =
							Number(eachLatLong.lng) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
						const lng_min =
							Number(eachLatLong.lng) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
						const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
						try {
							const tempGrid = await this.gridsRepository
								.createQueryBuilder("grid")
								.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
								.select("grid.id")
								.getMany();

							const tempGridIds = tempGrid.map((eachGrid) => {
								return eachGrid.id;
							});
							return tempGridIds;
						} catch (error) {
							return null;
						}
					}),
				);
				console.log(withinGridsArr);
				//Souvik Coding from Here
				const gridIds = _.flattenDeep(withinGridsArr);
				const level = [];
				const shapeIdsFromWithinQuery = [];
				if (query["childLevel"]) {
					const gridLevel = await this.gridsRepository
						.createQueryBuilder("grid")
						.select(['"' + query["childLevel"] + '"'])
						.distinct(true)
						.where("id IN(:...gridIds)", { gridIds: gridIds })
						.getRawMany();
					await Promise.all(
						gridLevel.map((eachObj) => {
							level.push(eachObj[query["childLevel"]]);
						}),
					);
					//level = ["1","3","4","5","7","8","9","34","56","55","66","78","23","13","11"];
					const shape = await this.shapesRepository
						.createQueryBuilder("shape")
						.select("id")
						.where("level = :level AND name IN(:...levelNames)", {
							level: query["childLevel"],
							levelNames: level,
						})
						.distinct(true)
						.getRawMany();
					//console.log("Shape",shape);
					await Promise.all(
						shape.map((eachObj) => {
							shapeIdsFromWithinQuery.push(eachObj["id"]);
						}),
					);
					//console.log("ShapeIds from within query :",shapeIdsFromWithinQuery);
				}
				// append with code here to find the shapes from the withinGridsArr
				// souvik
				// end of code block to handle shape search from found grids using shape name
				intersectionArray.push(_.flattenDeep(shapeIdsFromWithinQuery));
				// the line above pushes the array of shape ids found against the within query to intersection Array to handle intersecting each modular blocks for final end query
			}

			let finalIds = [];
			// The intersection Array is operated on to generate final list of shape ids from all the requests
			intersectionArray.forEach((eachArray, index) => {
				if (index === 0) {
					finalIds = eachArray;
				} else {
					finalIds = _.intersection(finalIds, eachArray);
				}
			});
			if (finalIds.length == 0) {
				finalIds = [0];
			}
			const finalObjects = await this.shapesRepository
				.createQueryBuilder("shape")
				.leftJoinAndSelect("shape.shapeindex", "shapeindex")
				.where("shape.id IN (:...finalIds)", { finalIds: finalIds })
				.getMany();
			const objectIdShapeIndexDict = {};
			const objectIdShapeInternalDetailsDict = {};
			const shapeIdShapeInternalDetailsDict = {};
			const shapesInternalDetails = await this.shapeDetailsRepository.find({
				where: {
					shapeId: In(finalIds),
				},
			});
			shapesInternalDetails.forEach((eachDetail) => {
				const eachShapeInternalDetailsDict = {};
				if (!shapeIdShapeInternalDetailsDict[eachDetail.shapeId]) {
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId] = {};
					const tempObj = {};
					tempObj["value"] = eachDetail.value;
					tempObj["unit"] = eachDetail.metrics;
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId][eachDetail.key] = tempObj;
				} else {
					const tempObj = {};
					tempObj["value"] = eachDetail.value;
					tempObj["unit"] = eachDetail.metrics;
					shapeIdShapeInternalDetailsDict[eachDetail.shapeId][eachDetail.key] = tempObj;
				}
			});
			const finalObjectIdsFromPostgres = finalObjects.map((eachObject) => {
				objectIdShapeIndexDict[eachObject.objectId] = eachObject.shapeindex;
				objectIdShapeInternalDetailsDict[eachObject.objectId] = shapeIdShapeInternalDetailsDict[eachObject.id];

				const newObjectIdString = eachObject.objectId;
				return new mongoose.mongo.ObjectId(newObjectIdString);
			});
			const shapesFromMongoReturned = await this.demoShapesDBModel.find({
				_id: {
					$in: finalObjectIdsFromPostgres,
				},
			});
			const responseObjects = [];
			shapesFromMongoReturned.forEach((eachShape) => {
				const tempObject: unknown = {};
				tempObject["geometry"] = eachShape["_doc"]["geometry"];
				let currentIndexes: Shapeindex[] = objectIdShapeIndexDict[eachShape._id];
				//console.log("object id shape index dict", objectIdShapeIndexDict);
				if (!currentIndexes) {
					currentIndexes = [];
				}
				const indexesDict = {};
				currentIndexes.forEach((eachIndex) => {
					if (eachIndex.indexType === "string") {
						indexesDict[eachIndex.indexName] = eachIndex.categoricalValue;
					} else {
						const tempObj = {};
						tempObj["value"] = eachIndex.indexValue;
						tempObj["unit"] = eachIndex.metrics;
						indexesDict[eachIndex.indexName] = eachIndex.indexValue;
					}
				});
				const orderedIndexDict = {};
				_(indexesDict)
					.keys()
					.sort()
					.each(function (key) {
						orderedIndexDict[key] = indexesDict[key];
					});
				const internalDetails = objectIdShapeInternalDetailsDict[eachShape._id];
				const orderedInternalDetails = {};
				_(internalDetails)
					.keys()
					.sort()
					.each(function (key) {
						orderedInternalDetails[key] = internalDetails[key];
					});
				tempObject["id"] = eachShape._id;
				tempObject["index"] = orderedIndexDict;
				tempObject["internalDetails"] = orderedInternalDetails;
				tempObject["name"] = eachShape.name;
				tempObject["level"] = eachShape["_doc"]["level"];
				tempObject["State"] = eachShape["_doc"]["state"];
				tempObject["District"] = eachShape["_doc"]["district"];
				tempObject["Pincode"] = eachShape["_doc"]["pincode"];
				tempObject["City"] = eachShape["_doc"]["city"];
				//Ordering....
				const orderedTempObject = {};
				_(tempObject)
					.keys()
					.sort()
					.each(function (key) {
						orderedTempObject[key] = tempObject[key];
					});
				responseObjects.push(orderedTempObject);
			});
			const responseBody = {};
			responseBody["count"] = shapesFromMongoReturned.length;
			responseBody["data"] = responseObjects;
			return responseBody;
		}
	}

	async returnShapeIdsmultilevelShapes(query: MultilevelShapesQuery): Promise<number[]> {
		let level, childLevel, name;
		if (query.location != undefined) {
			if (query.location.State) {
				console.log("inside state");
				level = "State";
				name = query.location.State;
			}
			if (query.location.City) {
				console.log("inside city");
				level = "City";
				name = query.location.City;
			}
			if (query.location.Locality) {
				console.log("inside locality");
				level = "Locality";
				name = query.location.Locality;
			}
			if (query.location.Pincode) {
				console.log("inside pincode");
				level = "Pincode";
				name = query.location.Pincode;
			}
			if (query.location.Taluka) {
				console.log("inside taluka");
				level = "Taluka";
				name = query.location.Taluka;
			}
			if (query.location.District) {
				console.log("inside district");
				level = "District";
				name = query.location.District;
			}
			if (query.location.Country) {
				console.log("inside country");
				level = "Country";
				name = query.location.Country;
			}
			if (query.location.Cluster) {
				console.log("inside Cluster");
				level = "Cluster";
				name = query.location.Cluster;
			}
		}
		if (query.childLevel === level && query.location != undefined) {
			delete query.childLevel;
		}
		console.log("query is", query);
		if (!query.childLevel) {
			console.log("no child level");
			//let queryString = `"${level}" = :name`;
			const finalObjects = await this.shapesRepository
				.createQueryBuilder("shape")
				.leftJoinAndSelect("shape.shapeindex", "shapeindex")
				.where("shape.name = :name", { name: name })
				.andWhere("shape.level = :level", { level: level })
				.getMany();
			console.log("final objects are", finalObjects);
			const finalIds = finalObjects.map((eachObject) => {
				return eachObject.id;
			});
			return finalIds;
		} else {
			console.log("inside child level");
			const intersectionArray = [];
			if (query.location != undefined) {
				const queryDict = {};
				queryDict["level"] = query.childLevel;
				queryDict[level] = name;
				const pincodesFromLocation = await this.shapesRepository.find({ where: queryDict });
				const pincodeIdsFromLocation = pincodesFromLocation.map((eachPincode) => {
					return eachPincode.id;
				});
				intersectionArray.push(_.flattenDeep(pincodeIdsFromLocation));
			}
			let pincodeIdsAgainstIndexes = [];
			let pincodeIdsAgainstIndexesIntersected;
			const shapesQueryFlag = false;

			// getting all the pincodes against a location query

			// filter section against shape indexes
			if (query["shapes"]) {
				if (query["shapes"]["range"]) {
					if (Object.keys(query["shapes"]["range"]).length) {
						pincodeIdsAgainstIndexes = await Promise.all(
							Object.keys(query["shapes"]["range"]).map(async (eachKey) => {
								let pincodeQueryString = "";
								const pincodeQueryObject = {};
								pincodeQueryString +=
									'shapeindex."indexName" = :' +
									eachKey +
									'name AND shapeindex."indexValue" BETWEEN :' +
									eachKey +
									"min AND :" +
									eachKey +
									"max";
								pincodeQueryObject[eachKey + "min"] = query["shapes"]["range"][eachKey]["min"];
								pincodeQueryObject[eachKey + "max"] = query["shapes"]["range"][eachKey]["max"];
								pincodeQueryObject[eachKey + "name"] = eachKey;
								try {
									const response = await this.shapesRepository
										.createQueryBuilder("shape")
										.leftJoinAndSelect("shape.shapeindex", "shapeindex")
										.where(pincodeQueryString, pincodeQueryObject)
										.select("shape.id")
										.getMany();
									const shapeIds = response.map((eachResp) => {
										return eachResp.id;
									});
									intersectionArray.push(_.flattenDeep(shapeIds));
								} catch (error) {
									console.log(error);
								}
							}),
						);
						console.log("pincodes against indexes", pincodeIdsAgainstIndexes);
					}
				}
				if (query["shapes"]["select"]) {
					if (Object.keys(query["shapes"]["select"]).length) {
						const shapeSelectResponse = await Promise.all(
							Object.keys(query["shapes"]["select"]).map(async (eachKey) => {
								console.log("eachSelect key", eachKey);
								try {
									const someIndexes = await this.shapeIndexRepository
										.createQueryBuilder("shapeindex")
										.select('shapeindex."shapeId"')
										.where('shapeindex."indexName" = :indexName', { indexName: eachKey })
										.andWhere('shapeindex."categoricalValue" IN (:...categoricalValues)', {
											categoricalValues: query["shapes"]["select"][eachKey],
										})
										.getRawMany();
									const shapeIds = someIndexes.map((eachIndex) => {
										return eachIndex["shapeId"];
									});
									intersectionArray.push(_.flattenDeep(shapeIds));
									return shapeIds;
								} catch (error) {
									console.log(error);
									return [];
								}
							}),
						);
						console.log("pincodes against select indexes", shapeSelectResponse);
					}
				}
			}

			// filtering against shapes internal properties
			let shapeIdsFromShapeDetails = [];
			if (query["shapeDetails"]) {
				const intersectionStatus = 0;
				const shapeDetails: any[] = query["shapeDetails"];
				if (shapeDetails.length == 0) {
					shapeIdsFromShapeDetails = [];
				} else {
					await Promise.all(
						shapeDetails.map(async (eachShapeDetail, index) => {
							if (eachShapeDetail.dataType == "number") {
								const tempShapeIdsArray = [];
								let tempShapeDetails = [];
								try {
									tempShapeDetails = await this.shapeDetailsRepository
										.createQueryBuilder("shape_detail")
										.where("key = :key", { key: eachShapeDetail.key })
										.andWhere("unit BETWEEN :min and :max", {
											min: eachShapeDetail["values"]["min"],
											max: eachShapeDetail["values"]["max"],
										})
										.select('"shapeId"')
										.distinct(true)
										.getRawMany();
								} catch (error) {
									console.log(error);
								}
								await Promise.all(
									tempShapeDetails.map((eachShapeDetailHere) => {
										tempShapeIdsArray.push(eachShapeDetailHere.shapeId);
									}),
								);
								intersectionArray.push(_.flattenDeep(tempShapeIdsArray));
								//if (index === 0)
								//{
								//shapeIdsFromShapeDetails = tempShapeIdsArray;
								//} else {
								//shapeIdsFromShapeDetails = _.intersection(shapeIdsFromShapeDetails, tempShapeIdsArray);
								//}
							} else {
								console.log("DataType : ", eachShapeDetail["dataType"]);
								const tempShapeIdsFromString = [];
								const tempShapeIds = await this.shapeDetailsRepository
									.createQueryBuilder("shape_detail")
									.where("key = :key AND value IN(:...values)", {
										key: eachShapeDetail.key,
										values: eachShapeDetail.values,
									})
									.select('"shapeId"')
									.distinct(true)
									.getRawMany();
								await Promise.all(
									tempShapeIds.map((eachShapeId) => {
										tempShapeIdsFromString.push(eachShapeId.shapeId);
									}),
								);
								intersectionArray.push(_.flattenDeep(tempShapeIdsFromString));
								//if (index === 0)
								//{
								//shapeIdsFromShapeDetails = tempShapeIdsFromString;
								//} else {
								//shapeIdsFromShapeDetails = _.intersection(shapeIdsFromShapeDetails, tempShapeIdsFromString);
								//}
							}
						}),
					);
				}
				// push shape ids found after applying shape details filter to intersection array
				intersectionArray.push(_.flattenDeep(shapeIdsFromShapeDetails));
				console.log("Length after ShapeDetails filter :", shapeIdsFromShapeDetails.length);
			}

			if (query["within"]) {
				let latLongs: LatLong[] = [];
				latLongs = query["within"]["points"];
				let distance = query["within"]["radius"];
				distance = distance;
				const withinGridsArr: number[][] = await Promise.all(
					query["within"]["points"].map(async (eachLatLong) => {
						//const eachTarget = await this.propertyRepository.findOne({ where : { id: eachId }});
						//const point = tf.point([eachTarget.latitude, eachTarget.longitude]);
						/*
            const point = tf.point([eachLatLong.lat, eachLatLong.lng]);
            const topLeft = tf.destination(point, distance, angleA);
            const bottomRight = tf.destination(point, distance, angleB);
            const withinGrids = geohash.bboxes(
              topLeft["geometry"]["coordinates"][0],
              topLeft["geometry"]["coordinates"][1],
              bottomRight["geometry"]["coordinates"][0],
              bottomRight["geometry"]["coordinates"][1],
              7
            );
            */
						const pi = Math.PI;
						const lat_increment = 1 / 110.574;
						const lng_increment = 1 / 111.32;
						const lat_max = Number(eachLatLong.lat) + distance * lat_increment;
						const lat_min = Number(eachLatLong.lat) - distance * lat_increment;
						const lng_max =
							Number(eachLatLong.lng) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
						const lng_min =
							Number(eachLatLong.lng) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
						const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
						try {
							const tempGrid = await this.gridsRepository
								.createQueryBuilder("grid")
								.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
								.select("grid.id")
								.getMany();

							const tempGridIds = tempGrid.map((eachGrid) => {
								return eachGrid.id;
							});
							return tempGridIds;
						} catch (error) {
							return null;
						}
					}),
				);
				console.log(withinGridsArr);
				//Souvik Coding from Here
				const gridIds = _.flattenDeep(withinGridsArr);
				const level = [];
				const shapeIdsFromWithinQuery = [];
				if (query["childLevel"]) {
					const gridLevel = await this.gridsRepository
						.createQueryBuilder("grid")
						.select(['"' + query["childLevel"] + '"'])
						.distinct(true)
						.where("id IN(:...gridIds)", { gridIds: gridIds })
						.getRawMany();
					await Promise.all(
						gridLevel.map((eachObj) => {
							level.push(eachObj[query["childLevel"]]);
						}),
					);
					//level = ["1","3","4","5","7","8","9","34","56","55","66","78","23","13","11"];
					const shape = await this.shapesRepository
						.createQueryBuilder("shape")
						.select("id")
						.where("level = :level AND name IN(:...levelNames)", {
							level: query["childLevel"],
							levelNames: level,
						})
						.distinct(true)
						.getRawMany();
					//console.log("Shape",shape);
					await Promise.all(
						shape.map((eachObj) => {
							shapeIdsFromWithinQuery.push(eachObj["id"]);
						}),
					);
					//console.log("ShapeIds from within query :",shapeIdsFromWithinQuery);
				}
				// append with code here to find the shapes from the withinGridsArr
				// souvik
				// end of code block to handle shape search from found grids using shape name
				intersectionArray.push(_.flattenDeep(shapeIdsFromWithinQuery));
				// the line above pushes the array of shape ids found against the within query to intersection Array to handle intersecting each modular blocks for final end query
			}

			let finalIds = [];
			// The intersection Array is operated on to generate final list of shape ids from all the requests
			intersectionArray.forEach((eachArray, index) => {
				console.log("intersecting ", eachArray);
				if (index === 0) {
					finalIds = eachArray;
				} else {
					finalIds = _.intersection(finalIds, eachArray);
				}
				console.log("final ids after intersection", finalIds);
			});
			console.log("final ids length", finalIds.length);
			return finalIds;
		}
	}

	async getFilters(query) {
		let filters: any[] = [];
		if (query?.["keys"]?.length) {
			filters = await this.shapeIndexRepository
				.createQueryBuilder("shapeindex")
				.where(`"indexName" IN(:...keys)`, { keys: query["keys"] as string[] })
				.distinctOn(["shapeindex.indexName"])
				.getMany();
		} else {
			filters = await this.shapeIndexRepository
				.createQueryBuilder("shapeindex")
				.distinctOn(["shapeindex.indexName"])
				.getMany();
		}

		const maxMinValues = await Promise.all(
			filters.map(async (eachFilter) => {
				console.log(eachFilter.indexType);
				if (eachFilter.indexType === "number") {
					/*
        const maxMin = await getRepository(Shapeindex)
          .createQueryBuilder("shapeindex")
          .select('MAX(shapeindex."indexValue")', "max")
          .addSelect('MIN(shapeindex."indexValue")', "min")
          .where('shapeindex."indexName" = :column', { column: eachFilter["indexName"] })
          .getRawOne();
        */
					const MaxMin = { /* max: maxMin.max, min: maxMin.min ,*/ type: "range" };
					const tempObj = {};
					tempObj[eachFilter["indexName"]] = MaxMin;
					return tempObj;
				} else {
					const categoricalValues = await this.shapeIndexRepository
						.createQueryBuilder("shapeindex")
						.where('shapeindex."indexName" = :indexName', { indexName: eachFilter.indexName })
						.distinctOn(["shapeindex.categoricalValue"])
						.getMany();
					const tempObj = {};
					const maxMin = { type: "select" };
					console.log(categoricalValues);
					const sortedCategoricalValues = _.sortBy(categoricalValues, "indexValue");
					maxMin["values"] = await sortedCategoricalValues.map((eachCategory) => {
						return eachCategory["categoricalValue"];
					});
					tempObj[eachFilter["indexName"]] = maxMin;
					return tempObj;
				}
			}),
		);

		const returnFilters = {};
		maxMinValues.forEach((eachDict) => {
			returnFilters[Object.keys(eachDict)[0]] = eachDict[Object.keys(eachDict)[0]];
		});

		return returnFilters;
	}

	async getInfo(query) {
		const requiredKeys = [
			"HIG_%",
			"MIG_%",
			"LIG_%",
			"population",
			"economic_activity",
			"commercial_activity",
			"SME_loan_disbursment_category",
			"gold_loan_disbursment_category",
			"loan_delinquency_category",
			"loan_non_delinquency_category",
			"affluence_category",
			"brand_presence",
			"branded_area",
			"retail",
			"financial_institutions",
			"bank_count",
			"ATM_count",
			"digital_transaction_index",
			"digital_transaction_growth",
		];
		if (query["pincode"] == undefined) {
			throw new HttpException("pincode missing!", HttpStatus.BAD_REQUEST);
		}
		const response = {};
		const shape = await this.shapesRepository.findOne({ where: { name: query["pincode"], level: "Pincode" } });
		response["Pincode"] = shape.name;
		response["District"] = shape.District;
		response["State"] = shape.State;
		const shapeIndex = await this.shapeIndexRepository
			.createQueryBuilder("shapeindex")
			.where(`"shapeId" = :shapeId`, { shapeId: shape.id })
			.distinct(true)
			.getMany();
		console.log("Shape Index Length : ", shapeIndex.length);
		await Promise.all(
			shapeIndex.map((eachShapeIndex) => {
				if (requiredKeys.includes(eachShapeIndex["indexName"])) {
					if (eachShapeIndex["indexType"] == "number") {
						response[eachShapeIndex["indexName"]] = eachShapeIndex["indexValue"];
					} else {
						response[eachShapeIndex["indexName"]] = eachShapeIndex["categoricalValue"];
					}
				}
			}),
		);
		return response;
	}
}
