import { Test, TestingModule } from "@nestjs/testing";
import { IndexMasterController } from "./index-master.controller";

describe("IndexMaster Controller", () => {
	let controller: IndexMasterController;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			controllers: [IndexMasterController]
		}).compile();

		controller = module.get<IndexMasterController>(IndexMasterController);
	});

	it("should be defined", () => {
		expect(controller).toBeDefined();
	});
});
