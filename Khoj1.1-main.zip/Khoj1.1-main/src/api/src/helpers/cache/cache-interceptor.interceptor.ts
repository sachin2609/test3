import { CallHandler, ExecutionContext, Injectable, NestInterceptor, Inject } from "@nestjs/common";
import { CACHE_MANAGER } from "@nestjs/cache-manager";
import { Observable } from "rxjs";
import { Reflector } from "@nestjs/core";
import { Cache } from "cache-manager";
import { tap } from "rxjs/operators";
import { Request } from "express-serve-static-core";

@Injectable()
export class CacheInterceptorInterceptor implements NestInterceptor {
	constructor(@Inject(CACHE_MANAGER) private cacheManager: Cache, private reflector: Reflector) {}

	async intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>> {
		const ctx = context.switchToHttp();
		const request: Request = ctx.getRequest();
		let key = this.reflector.get("cache-key", context.getHandler());
		if (key == undefined) {
			key = request.url;
		}
		let cacheTime = this.reflector.get("cache-time", context.getHandler());
		if (!cacheTime) cacheTime = 600000000;
		if (process.env.ENABLE_DATA_CACHING == "false") {
			const notAllowedKeys = [
				"/grid/search", // Infinite Cache
				"/poi/filter", // Infinite Cache
				"/shape/level-search", // Infinite Cache
				"/poi-shape/filter", // Infinite Cache
				"/monitor/user-activity",
				"/monitor/leads-category-count",
				"/monitor/leads-category-gst-count",
				"/monitor/top-reasons",
				"/monitor/lead-conversion-timeline",
				"/monitor/user-activity",
				"/monitor/team-activity",
				"/monitor/in-progress-ageing",
				"/monitor/lead-report",
				"/monitor/lead-report-historical",
				"/monitor/upcoming-reminder",
				"/monitor/lead-report-paginated",
			];
			if (notAllowedKeys.includes(key)) {
				return next.handle();
			}
		}
		if (request.body != undefined) {
			const body = JSON.stringify(request.body);
			key = key + "-body-" + body;
		}
		if (request.query != undefined) {
			const query = JSON.stringify(request.query);
			key = key + "-query-" + query;
		}
		console.log("Cache Interceptor Logs");
		console.log("KEY:", key);
		const cached: string = await this.cacheManager.get(key);
		if (cached) {
			console.log("Cache Hit");
			const response = JSON.parse(cached);
			return new Observable((observer) => {
				observer.next(response);
				observer.complete();
			});
			//return next.handle().pipe(
			//	tap(async (res) => {
			//		res = response;
			//	}),
			//);
		}
		console.log("Cache Miss");
		return next.handle().pipe(
			tap(async (res) => {
				const response = JSON.stringify(res);
				await this.cacheManager.set(key, response, { ttl: Number(cacheTime) });
			}),
		);
	}
}
