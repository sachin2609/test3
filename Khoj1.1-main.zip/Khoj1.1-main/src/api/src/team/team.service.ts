import { HttpException, HttpStatus, Inject, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { User, UserDTO } from "src/users/users.entity";
import { In, Repository } from "typeorm";
import { Team, TeamDTO } from "./team.entity";
import { isBoolean, uniq } from "lodash";
import { JwtService } from "@nestjs/jwt";
import { Role } from "src/helpers/roles-guard/roles-guard.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { getInvitationEmailTemplate } from "src/helpers/email-templates/registration-email-template";
import { MailerService } from "@nestjs-modules/mailer";
import { CentralServerService } from "src/auth/central-server.service";
import { UserCredits } from "src/user-history/user-credits.entity";
import * as _ from "lodash";
import { CACHE_MANAGER } from "@nestjs/cache-manager";
import { Cache } from "cache-manager";
import * as fs from "fs";
import * as csvParser from "csv-parser";

@Injectable()
export class TeamService {
	constructor(
		@InjectRepository(Team)
		private teamRepos: Repository<Team>,
		@InjectRepository(UserCredits) private userCreditsRepository: Repository<UserCredits>,
		@InjectRepository(User)
		private userRepos: Repository<User>,
		@Inject(CACHE_MANAGER) private cacheManager: Cache,
		private jwtService: JwtService,
		private keyCloakService: KeyCloakService,
		private centralServerService: CentralServerService,
		private readonly mailerService: MailerService,
	) {}

	// Decode Token Function should be ideally kept in Auth Module - Service File

	async validateBlacklist(token: string): Promise<void> {
		const exist = await this.cacheManager.get<boolean>(token);
		if (exist) {
			throw new HttpException("Token Expired!", HttpStatus.UNAUTHORIZED);
		}
	}

	async decodeUserJWT(token: string): Promise<Partial<User>> {
		if (!token.length) throw new HttpException("Token is required!", HttpStatus.UNAUTHORIZED);
		try {
			await this.jwtService.verifyAsync(token);
		} catch (err) {
			console.error(err);
			throw new HttpException("Token Invalid!", HttpStatus.UNAUTHORIZED);
		}

		// Checking for blacklisted token
		await this.validateBlacklist(token);

		const user = this.jwtService.decode(token) as User;
		if (!user.email && !user.phoneNumber) throw new HttpException("Unauthorized", HttpStatus.UNAUTHORIZED);
		const { email, phoneNumber } = user;
		const query = email && phoneNumber ? { email, phoneNumber } : email ? { email } : { phoneNumber };
		const userInDB = await this.userRepos.findOne({
			where: { ...query },
		});
		if (!userInDB) throw new HttpException("No Account Found!", HttpStatus.UNAUTHORIZED);
		if (!userInDB.isAuthorized) throw new HttpException("Account Not Authorized Yet!", HttpStatus.UNAUTHORIZED);
		const { password, googleAccessToken, createdAt, updatedAt, createdBy, updatedBy, ...tempUser } = userInDB;
		tempUser["type"] = "token";
		return tempUser;
	}

	generateRandomPassword(length) {
		const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		let password = "";

		for (let i = 0; i < length; i++) {
			const randomIndex = Math.floor(Math.random() * charset.length);
			password += charset[randomIndex];
		}

		return password;
	}

	async processCsv(file, item: "team" | "user"): Promise<Partial<User>[] | Team[]> {
		const requiredFields = (() => {
			if (item == "team") return ["name", "description", "credits", "ownerId"];
			if (item == "user")
				return ["firstName", "lastName", "email", "phoneNumber", "teamId", "designation", "roles"];
		})();
		const results: Partial<User>[] = [];
		return new Promise((resolve, reject) => {
			const filePath = "temp.csv"; // Specify the path where you want to save the uploaded file temporarily

			// Write the uploaded file to the local file system
			fs.writeFileSync(filePath, file.buffer);

			const readableStream = fs.createReadStream(filePath).pipe(csvParser());

			readableStream
				.on("data", (row: Partial<User>) => {
					// Check if all required fields are present in the CSV row
					const missingFields = requiredFields.filter((field) => !(field in row));
					if (missingFields.length > 0) {
						return reject({
							error: `Missing required fields: ${missingFields.join(", ")}`,
						});
					}
					if (row?.roles) {
						row.roles = (row.roles as unknown as string).split(";");
					}
					if (row.password != undefined) {
						if (!row.password.length) row.password = this.generateRandomPassword(10);
					}
					row.isAuthorized = true;
					// Add the CSV row to the results array
					results.push(row);
				})
				.on("end", () => {
					// CSV file has been fully processed
					// You can add additional processing here if needed
					resolve(results);

					// Remove the temporary file after processing
					fs.unlinkSync(filePath);
				})
				.on("error", (error) => {
					// Remove the temporary file after processing
					fs.unlinkSync(filePath);
					reject(error);
				});
		});
	}

	//------------------------------- User Operations -------------------------------//

	async getUsers(
		userIDs?: number[],
		teamIDs?: number[],
		ownerIDs?: number[],
		email?: string,
		phoneNumber?: string,
	): Promise<User[]> {
		const ownerTeams = ownerIDs ? await this.getTeams(null, ownerIDs) : [];
		const ownerTeamIDs = ownerTeams?.map((team) => team?.id);
		const collatedTeamIDs = uniq([...(teamIDs ?? []), ...(ownerTeamIDs ?? [])]);
		try {
			const users = await this.userRepos.find({
				where: {
					id: userIDs?.length ? In(userIDs) : undefined,
					teamId: collatedTeamIDs?.length ? In(collatedTeamIDs) : undefined,
					email: email ?? undefined,
					phoneNumber: phoneNumber ?? undefined,
				},
			});
			return users;
		} catch (err) {
			throw new HttpException("Cannot Get Users - " + err, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async createUser(user: Partial<User>, userID?: number): Promise<void> {
		if (!(user.email || user.phoneNumber) || !user.firstName) {
			throw new HttpException("Please enter email or phone number and first name!", HttpStatus.BAD_REQUEST);
		}
		const existingUser = await this.getUsers(null, null, null, user?.email, user?.phoneNumber);
		if (existingUser?.length)
			throw new HttpException("User with provided Email or Phone Number Already Exists!", HttpStatus.BAD_REQUEST);
		if (user.teamId) {
			const team = await this.getTeams([user.teamId]);
			if (!team) {
				throw new HttpException("Provided Team ID Not Found!", HttpStatus.BAD_REQUEST);
			}
		} else {
			user.isAuthorized = false;
		}
		if (user.roles?.includes(Role.MAPS_USER)) await this.centralServerService.addUserToCentralServer(user);
		if (process.env.ENABLE_KEYCLOAK === "true") await this.keyCloakService.createKCUser(user);
		try {
			const newUser: Partial<User> = {
				firstName: user.firstName,
				lastName: user.lastName,
				email: user.email,
				phoneNumber: user.phoneNumber,
				roles: user.roles,
				designation: user.designation,
				teamId: user.teamId,
				isAuthorized: user.isAuthorized,
				password: user.password,
				createdBy: userID ?? null,
				updatedBy: userID ?? null,
			};
			if (user.roles?.length)
				user.roles = uniq(user.roles).filter(
					(role) => ![Role.ADMIN, Role.CLIENT_ADMIN]?.includes(role as Role),
				);
			else user.roles = [Role.BASIC];
			const createdUser = await this.userRepos.save(newUser);
			if (!userID) {
				const updatedBody = { createdBy: createdUser.id, updatedBy: createdUser.id };
				await this.userRepos.update(updatedBody, { id: createdUser.id });
			}
		} catch (error) {
			throw new HttpException("Cannot Create User - " + error.message, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async createUserWithPass(user: Partial<User>, userID?: number): Promise<void> {
		if (!(user.email || user.phoneNumber) || !user.firstName) {
			throw new HttpException("Please enter email or phone number and first name!", HttpStatus.BAD_REQUEST);
		}
		const existingUser = await this.getUsers(null, null, null, user?.email, user?.phoneNumber);
		if (existingUser?.length)
			throw new HttpException("User with provided Email or Phone Number Already Exists!", HttpStatus.BAD_REQUEST);
		if (user.teamId) {
			const team = await this.getTeams([user.teamId]);
			if (!team) {
				throw new HttpException("Provided Team ID Not Found!", HttpStatus.BAD_REQUEST);
			}
		} else {
			user.isAuthorized = false;
		}
		if (user.roles?.includes(Role.MAPS_USER)) await this.centralServerService.addUserToCentralServer(user);
		if (process.env.ENABLE_KEYCLOAK === "true") await this.keyCloakService.createKCUserWithPass(user);
		try {
			const newUser: Partial<User> = {
				firstName: user.firstName,
				lastName: user.lastName,
				email: user.email,
				phoneNumber: user.phoneNumber,
				roles: user.roles,
				designation: user.designation,
				teamId: user.teamId,
				isAuthorized: user.isAuthorized,
				password: user.password,
				createdBy: userID ?? null,
				updatedBy: userID ?? null,
			};
			if (user.roles?.length)
				user.roles = uniq(user.roles).filter(
					(role) => ![Role.ADMIN, Role.CLIENT_ADMIN]?.includes(role as Role),
				);
			else user.roles = [Role.BASIC];
			const createdUser = await this.userRepos.save(newUser);
			if (!userID) {
				const updatedBody = { createdBy: createdUser.id, updatedBy: createdUser.id };
				await this.userRepos.update(updatedBody, { id: createdUser.id });
			}
		} catch (error) {
			throw new HttpException("Cannot Create User - " + error.message, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async createMultipleUser(
		users: Array<Partial<User>>,
		userID: number,
	): Promise<Array<{ email: string; phoneNumber: string; error: string }>> {
		if (!users.length) {
			throw new HttpException("Please Provide Users to Create!", HttpStatus.BAD_REQUEST);
		}
		const usersNotAdded = [];
		for (const user of users) {
			try {
				await this.createUser(user, userID);
			} catch (err) {
				usersNotAdded.push({
					email: user?.email,
					phoneNumber: user?.phoneNumber,
					error: err.response,
				});
			}
		}
		return usersNotAdded;
	}

	async createMultipleTeams(
		teams: Array<Partial<Team>>,
		userID: number,
	): Promise<Array<{ email: string; phoneNumber: string; error: string }>> {
		if (!teams.length) {
			throw new HttpException("Please Provide Teams to Create!", HttpStatus.BAD_REQUEST);
		}
		const teamNotAdded = [];
		for (const team of teams) {
			try {
				await this.createTeam(team, userID);
			} catch (err) {
				teamNotAdded.push({
					name: team?.name,
					ownerId: team?.ownerId,
					error: err.response,
				});
			}
		}
		return teamNotAdded;
	}

	async createMultipleUserWithPass(
		users: Array<Partial<User>>,
		userID: number,
	): Promise<Array<{ email: string; phoneNumber: string; error: string }>> {
		if (!users.length) {
			throw new HttpException("Please Provide Users to Create!", HttpStatus.BAD_REQUEST);
		}
		const usersNotAdded = [];
		for (const user of users) {
			try {
				await this.createUserWithPass(user, userID);
			} catch (err) {
				usersNotAdded.push({
					email: user?.email,
					phoneNumber: user?.phoneNumber,
					error: err.response,
				});
			}
		}
		return usersNotAdded;
	}

	async updateUser(user: Partial<User>, userID: number): Promise<void> {
		if (!user?.id) {
			throw new HttpException("User ID is Required!", HttpStatus.BAD_REQUEST);
		}
		const existingUser = await this.getUsers([user.id]);
		if (!existingUser?.length) {
			throw new HttpException("User with provided ID Not Found!", HttpStatus.BAD_REQUEST);
		}
		if (user.teamId) {
			const team = await this.getTeams([user.teamId]);
			if (!team) {
				throw new HttpException("Provided Team ID Not Found!", HttpStatus.BAD_REQUEST);
			}
		}
		if (Object.keys(user).length <= 1) {
			throw new HttpException("Please Provide Data to Update!", HttpStatus.BAD_REQUEST);
		}
		const existingManagementRoles = existingUser[0].roles?.filter((role) =>
			[Role.ADMIN, Role.CLIENT_ADMIN].includes(role as Role),
		);
		if (user.roles)
			user.roles = uniq([
				Role.BASIC,
				...existingManagementRoles,
				...user.roles.filter((role) => ![Role.ADMIN, Role.CLIENT_ADMIN].includes(role as Role)),
			]);
		console.log("EXisting Roles", user.roles);
		const updatedUser: Partial<User> = {
			id: user.id,
			firstName: user.firstName && user.firstName != existingUser[0].firstName ? user.firstName : undefined,
			lastName: user.lastName && user.lastName != existingUser[0].lastName ? user.lastName : undefined,
			roles: user.roles,
			designation: user.designation,
			teamId: user.teamId,
			isAuthorized: user.isAuthorized,
			password: user.password,
			updatedBy: userID,
		};
		await this.keyCloakService.updateKCUser(existingUser[0].email || existingUser[0].phoneNumber, updatedUser);
		try {
			await this.userRepos.update(user.id, updatedUser);
		} catch (error) {
			throw new HttpException("Cannot Update User - " + error.message, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async updateMultipleUser(
		users: Array<Partial<User>>,
		userID: number,
	): Promise<Array<{ id: number; error: string }>> {
		if (!users.length) {
			throw new HttpException("Please Provide Users to Create!", HttpStatus.BAD_REQUEST);
		}
		const userNotUpdated = [];
		for (const user of users) {
			try {
				await this.updateUser(user, userID);
			} catch (err) {
				userNotUpdated.push({
					id: user.id,
					error: err.message,
				});
			}
		}
		return userNotUpdated;
	}

	async deleteUser(id: number): Promise<void> {
		if (!id) {
			throw new HttpException("User ID is Required!", HttpStatus.BAD_REQUEST);
		}
		const existingUser = (await this.getUsers([id]))?.[0];
		if (!existingUser) {
			throw new HttpException("User with provided ID Not Found!", HttpStatus.BAD_REQUEST);
		}
		const ownedTeams = await this.getTeams(null, [id]);
		if (ownedTeams?.length) {
			throw new HttpException("User is Owner of a Team!", HttpStatus.BAD_REQUEST);
		}
		if (existingUser?.roles?.includes(Role.MAPS_USER))
			await this.centralServerService.deleteUserFromCentralServer(existingUser);
		try {
			await this.keyCloakService.delteKCUser(existingUser);
		} catch (error) {}
		try {
			await this.userRepos.delete(id);
		} catch (error) {
			throw new HttpException("Cannot Delete User - " + error.message, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async deleteMultipleUser(ids: Array<number>): Promise<Array<{ id: number; error: string }>> {
		if (!ids?.length) {
			throw new HttpException("Please Provide User IDs to Delete!", HttpStatus.BAD_REQUEST);
		}
		const usersNotDeleted = [];
		for (const id of ids) {
			try {
				await this.deleteUser(id);
			} catch (err) {
				usersNotDeleted.push({
					id: id,
					error: err.message,
				});
			}
		}
		return usersNotDeleted;
	}

	async userToUserDTOs(
		users: Array<User>,
		teams?: Array<Team>,
		ownedTeams?: Array<TeamDTO>,
	): Promise<Array<Partial<UserDTO>>> {
		if (!users.length) return [];
		const userTeams = teams ? teams : await this.getTeams(users.map((user) => user.teamId));
		const userOwnedTeams = ownedTeams
			? ownedTeams
			: await this.getTeams(
					null,
					users.map((user) => user.id),
			  );
		const teamMembers = await this.getUsers(
			null,
			uniq([...userTeams.map((team) => team.id), ...userOwnedTeams.map((team) => team.id)]),
		);
		const userDTOs = users.map((user) => {
			const {
				googleAccessToken,
				organisationId,
				teamId,
				password,
				createdAt,
				updatedAt,
				createdBy,
				updatedBy,
				...tempUser
			} = user;
			const team = userTeams.find((team) => team.id === teamId);
			const tempTeam = team ? { id: team.id, name: team.name } : null;
			const ownedTeams = userOwnedTeams
				.filter((team) => team.ownerId === user.id)
				.map((team) => {
					return {
						id: team.id,
						name: team.name,
						teamSize: teamMembers.filter((member) => member?.teamId === team?.id)?.length ?? 0,
					};
				});
			return {
				...tempUser,
				team: tempTeam,
				ownedTeams: ownedTeams,
			};
		});
		return userDTOs;
	}

	async inviteUsers(query: { ids: number[] }) {
		if (!query?.ids) throw new HttpException(`'ids' missing!`, HttpStatus.BAD_REQUEST);
		const users = await this.getUsers(query.ids);
		if (!users.length) return { response: "No users found to invite!" };
		const dsInsightUsers = users.filter((u) => u.roles.includes(Role.INSIGHTS_USER) && Boolean(u.isAuthorized));
		const dsMapsUsers = users.filter((u) => u.roles.includes(Role.MAPS_USER) && Boolean(u.isAuthorized));
		if (!dsInsightUsers.length && !dsMapsUsers.length)
			throw new HttpException("No users found to invite!", HttpStatus.BAD_REQUEST);
		try {
			if (dsInsightUsers?.length) await this.sendEmailInvite(dsInsightUsers);
			if (dsMapsUsers?.length) await this.centralServerService.sendSMSInvite(dsMapsUsers);
		} catch (error) {
			console.error(error);
			throw new HttpException("Error sending invites!", HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async sendEmailInvite(query: Array<User>) {
		for (const user of query) {
			const html = getInvitationEmailTemplate(user.firstName, user.lastName, "DS Insights");
			await this.mailerService
				.sendMail({
					to: user.email, // list of receivers
					from: process.env.MAILDEV_INCOMING_USER, // sender address
					subject: "Data Sutram Insights | Invitation", // Subject line
					text: "Verify :", // plaintext body
					html: html, // HTML body content
				})
				.then(() => {
					console.log("Email Sent!");
				})
				.catch((err) => {
					console.log("Error in sending mail", err);
				});
		}
	}

	//------------------------------- Team Operations -------------------------------//

	async getAllTeams(): Promise<Array<Partial<TeamDTO>>> {
		const teams = await this.getTeams();
		if (!teams) return [];
		return await this.teamToTeamDTOs(teams);
	}

	async createTeam(team: Partial<Team>, userID: number): Promise<void> {
		if (!team.name) {
			throw new HttpException("Team Name is Required!", HttpStatus.BAD_REQUEST);
		}
		const existingTeam = await this.getTeams(null, null, team.name);
		if (existingTeam?.length) {
			throw new HttpException("Team with provided Name Already Exists!", HttpStatus.BAD_REQUEST);
		}
		if (team.ownerId) {
			const owner = await this.getUsers([team.ownerId]);
			if (!owner?.length) {
				throw new HttpException("Owner ID is Invalid!", HttpStatus.BAD_REQUEST);
			}
		} else {
			team.isAuthorized = false;
		}
		if (team?.coOwnerIds?.length) {
			const coOwners = await (async () => {
				try {
					return await this.userRepos.find({ where: { id: In(team.coOwnerIds) } });
				} catch (error) {
					console.error(error);
				}
			})();
			const teamsWithCoOwnerIds = await (async () => {
				try {
					return this.teamRepos
						.createQueryBuilder(`team`)
						.where(`ARRAY[:...ids]::integer[] && "coOwnerIds"`, {
							ids: team.coOwnerIds,
						})
						.getMany();
				} catch (error) {
					console.error(error);
					return [];
				}
			})();
			if (team.coOwnerIds.length != coOwners.length) {
				throw new HttpException(
					`Invalid coOwnerIds : ${team.coOwnerIds.filter(
						(id) => !coOwners.map((co) => co.id).includes(id),
					)} !`,
					HttpStatus.BAD_REQUEST,
				);
			}
			if (teamsWithCoOwnerIds?.length) {
				throw new HttpException(`"coOwnerIds" Conflict!`, HttpStatus.BAD_REQUEST);
			}
		}
		if (process.env.SET_ONBOARDED_STATIC_COUNT == "true") {
			if (isNaN(team?.onboardedCount)) {
				throw new HttpException(`onboardedCount is not a number!`, HttpStatus.BAD_REQUEST);
			}
			if (Number(team?.onboardedCount) < 0) {
				throw new HttpException(`onboardedCount cannot be a negative number!`, HttpStatus.BAD_REQUEST);
			}
		}
		const newTeam: Partial<Team> = {
			name: team.name,
			description: team.description,
			credits: team.credits,
			isAuthorized: team.isAuthorized,
			ownerId: team.ownerId,
			coOwnerIds: team.coOwnerIds,
			createdBy: userID,
			updatedBy: userID,
			onboardedCount: String(team?.onboardedCount) ? Number(team?.onboardedCount) : undefined,
		};
		try {
			await this.teamRepos.save(newTeam);
		} catch (error) {
			throw new HttpException("Cannot Create Team - " + error.message, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async updateTeam(team: Partial<Team>, userID: number): Promise<void> {
		if (!team?.id) {
			throw new HttpException("Team ID is Required!", HttpStatus.BAD_REQUEST);
		}
		if (Object.keys(team).length <= 1) {
			throw new HttpException("No Data Provided to Update!", HttpStatus.BAD_REQUEST);
		}
		const existingTeam = (await this.getTeams([team.id], null, null))?.[0];
		if (!existingTeam) {
			throw new HttpException("Team with provided ID Does Not Exist!", HttpStatus.BAD_REQUEST);
		}
		if (team?.name && team?.name !== existingTeam.name) {
			const existingTeamWithName = await this.getTeams(null, null, team.name);
			if (existingTeamWithName?.length) {
				throw new HttpException("Team with provided Name Already Exists!", HttpStatus.BAD_REQUEST);
			}
		}
		if (team.ownerId) {
			const owner = await this.getUsers([team.ownerId]);
			if (!owner) {
				throw new HttpException("Owner ID is Invalid!", HttpStatus.BAD_REQUEST);
			}
		}
		if (isBoolean(team.isAuthorized) && !team.ownerId && !existingTeam.ownerId) {
			throw new HttpException(
				"Cannot Update Team Authorization for a Team without Owner!",
				HttpStatus.BAD_REQUEST,
			);
		}
		if (team?.coOwnerIds?.length) {
			const coOwners = await (async () => {
				try {
					return await this.userRepos.find({ where: { id: In(team.coOwnerIds) } });
				} catch (error) {
					console.error(error);
				}
			})();
			const teamsWithCoOwnerIds = await (async () => {
				try {
					return this.teamRepos
						.createQueryBuilder(`team`)
						.where(`ARRAY[:...ids]::integer[] && "coOwnerIds"`, {
							ids: team.coOwnerIds,
						})
						.andWhere(`id != :id`, { id: team.id })
						.getMany();
				} catch (error) {
					console.error(error);
					return [];
				}
			})();
			if (team.coOwnerIds.length != coOwners.length) {
				throw new HttpException(
					`Invalid coOwnerIds : ${team.coOwnerIds.filter(
						(id) => !coOwners.map((co) => co.id).includes(id),
					)} !`,
					HttpStatus.BAD_REQUEST,
				);
			}
			if (teamsWithCoOwnerIds?.length) {
				throw new HttpException(`"coOwnerIds" Conflict!`, HttpStatus.BAD_REQUEST);
			}
		}
		if (process.env.SET_ONBOARDED_STATIC_COUNT == "true") {
			if (isNaN(team?.onboardedCount)) {
				throw new HttpException(`onboardedCount is not a number!`, HttpStatus.BAD_REQUEST);
			}
			if (Number(team?.onboardedCount) < 0) {
				throw new HttpException(`onboardedCount cannot be a negative number!`, HttpStatus.BAD_REQUEST);
			}
		}
		const updatedTeam: Partial<Team> = {
			name: team.name,
			description: team.description,
			credits: team.credits,
			isAuthorized: team.isAuthorized,
			ownerId: team.ownerId,
			coOwnerIds: team.coOwnerIds,
			updatedBy: userID,
			onboardedCount: String(team?.onboardedCount) ? Number(team?.onboardedCount) : undefined,
		};
		try {
			team.updatedBy = userID;
			await this.teamRepos.update(team.id, updatedTeam);
		} catch (error) {
			throw new HttpException("Cannot Update Team - " + error.message, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async deleteTeam(id: number): Promise<void> {
		if (!id) {
			throw new HttpException("Team ID is Required!", HttpStatus.BAD_REQUEST);
		}
		const existingTeam = await this.getTeams([id]);
		if (!existingTeam?.length)
			throw new HttpException("Team with provided ID Does Not Exist!", HttpStatus.BAD_REQUEST);
		const teamUsers = await this.getUsers(null, [id]);
		if (teamUsers?.length) {
			throw new HttpException("Cannot Delete Team with Users!", HttpStatus.BAD_REQUEST);
		}
		try {
			await this.teamRepos.delete(id);
		} catch (error) {
			throw new HttpException("Cannot Delete Team - " + error.message, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async getTeams(IDs?: number[], ownerIDs?: number[], name?: string): Promise<Team[]> {
		const res = [];
		const coOwnedTeamsOwnerId = await (async () => {
			try {
				if (ownerIDs?.length) {
					return (
						await this.teamRepos
							.createQueryBuilder(`team`)
							.where(`ARRAY[${ownerIDs.join(",")}]::integer[] && team."coOwnerIds"`)
							.getMany()
					).map((t) => Number(t.ownerId));
				} else {
					return [];
				}
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		if (ownerIDs?.length) ownerIDs = [...ownerIDs, ...coOwnedTeamsOwnerId];
		const teams = await (async () => {
			try {
				return await this.teamRepos.find({
					where: {
						id: IDs ? In(IDs) : undefined,
						ownerId: ownerIDs ? In(ownerIDs) : undefined,
						name: name ?? undefined,
					},
				});
			} catch (error) {
				throw new HttpException("Cannot Get Team - " + error.message, HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		const usersWithinTeams = await (async () => {
			try {
				return await this.userRepos.find();
			} catch (error) {
				console.error(error);
			}
		})();
		const userWithCredits = await (async () => {
			try {
				return await this.userCreditsRepository.find();
			} catch (error) {
				console.error(error);
			}
		})();
		teams.forEach((team) => {
			const usersWithinGivenTeam = usersWithinTeams.filter((user) => user.teamId === team.id);
			const totalCreditsUsed = usersWithinGivenTeam.reduce((sum, userWithinGivenTeam) => {
				const userCredit = userWithCredits.find(
					(userWithCredit) => userWithCredit.userId === userWithinGivenTeam.id,
				);
				return sum + (userCredit?.creditsUsed || 0);
			}, 0);
			res.push({
				...team,
				creditsUsed: totalCreditsUsed,
			});
		});
		return res as Team[];
	}

	async teamToTeamDTOs(teams: Array<Team>): Promise<Array<Partial<TeamDTO>>> {
		const members = await this.getUsers(
			null,
			teams.map((team) => team.id),
		);
		const ownerIDs = uniq(teams.map((team) => team.ownerId));
		const allCoOwnerIds = uniq(
			_.flattenDeep(
				teams.map((t) => {
					return t?.coOwnerIds?.length ? t.coOwnerIds : [];
				}),
			),
		);
		const allcoOwners = await (async () => {
			try {
				return await this.getUsers(allCoOwnerIds);
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const owners = ownerIDs.length ? await this.getUsers(ownerIDs) : [];
		const tempTeams = teams.map((team) => {
			const { createdAt, updatedAt, createdBy, updatedBy, ownerId, coOwnerIds, ...tempTeam } = team;
			const teamSize = members.filter((member) => member.teamId === team.id).length;
			const owner = owners.find((owner) => owner.id === ownerId);
			const coOwners = coOwnerIds?.length
				? _.compact(
						allcoOwners.map((owner) => {
							if (coOwnerIds.includes(owner.id)) return owner;
						}),
				  )
				: [];
			return {
				...tempTeam,
				teamSize,
				ownerId,
				coOwnerIds,
				owner: owner
					? {
							id: owner?.id,
							firstName: owner?.firstName,
							lastName: owner?.lastName,
					  }
					: undefined,
				coOwners: coOwners?.length
					? coOwners.map((co) => {
							return { id: co?.id, firstName: co?.firstName, lastName: co?.lastName };
					  })
					: undefined,
			};
		});
		return tempTeams;
	}
}
