import {
	Controller,
	Get,
	Body,
	Post,
	Query,
	Patch,
	Delete,
	Headers,
	UseInterceptors,
	UploadedFile,
} from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { User } from "./users.entity";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { TeamService } from "src/team/team.service";
import { UsersService } from "./users.service";
import { FileInterceptor } from "@nestjs/platform-express";
import * as _ from "lodash";
@ApiTags("users")
@Controller("users")
export class UsersController {
	constructor(private teamService: TeamService, private usersService: UsersService) {}

	//--------------------------------------------User CRUD EPs--------------------------------------------

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN)
	@Get("all")
	async getAllUsers(@Query("allstatus") allstatus: string) {
		const users = await this.teamService.getUsers();
		if (allstatus === "true") {
			await this.usersService.addUserCreditsAndApiUsage(users);
		}
		const userDTOs = await this.teamService.userToUserDTOs(users, null, null);

		return {
			count: userDTOs.length,
			data: userDTOs,
		};
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN, Role.TEAM_ADMIN)
	@Get()
	async getUsers(@Headers() headers, @Query("teamId") teamId: number, @Query("allstatus") allstatus: string) {
		let users: User[];
		if (teamId) users = await this.teamService.getUsers(null, [teamId]);
		else {
			const user = await this.teamService.decodeUserJWT(headers["token"]);
			users = await this.teamService.getUsers(null, null, [user.id]);
		}
		if (allstatus === "true") {
			await this.usersService.addUserCreditsAndApiUsage(users);
		}
		const userDTOs = await this.teamService.userToUserDTOs(users, null, null);
		return {
			count: userDTOs.length,
			data: userDTOs,
		};
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN)
	@Post("create")
	async createUser(@Body() body: Array<Partial<User>>, @Headers() headers) {
		const user = await this.teamService.decodeUserJWT(headers["token"]);
		const usersNotAdded = await this.teamService.createMultipleUser(body, user.id);
		if (usersNotAdded.length === body.length) {
			return {
				message: "No Users Added!",
				data: usersNotAdded,
			};
		} else if (usersNotAdded.length === 0) {
			return {
				message: "All Users Added!",
			};
		} else {
			return {
				message: "Some Users Added!",
				data: usersNotAdded,
			};
		}
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN)
	@Patch("update")
	async updateUser(@Body() body: Array<Partial<User>>, @Headers() headers) {
		const user = await this.teamService.decodeUserJWT(headers["token"]);
		const usersNotUpdated = await this.teamService.updateMultipleUser(body, user.id);
		if (usersNotUpdated.length === body.length) {
			return {
				message: "No Users Updated!",
				data: usersNotUpdated,
			};
		} else if (usersNotUpdated.length === 0) {
			return {
				message: "All Users Updated!",
			};
		} else {
			return {
				message: "Some Users Updated!",
				data: usersNotUpdated,
			};
		}
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN)
	@Delete("delete")
	async deleteUser(@Body() body: Array<number>) {
		const usersNotDeleted = await this.teamService.deleteMultipleUser(body);
		if (usersNotDeleted.length === body.length) {
			return {
				message: "No Users Deleted!",
				data: usersNotDeleted,
			};
		} else if (usersNotDeleted.length === 0) {
			return {
				message: "All Users Deleted!",
			};
		} else {
			return {
				message: "Some Users Deleted!",
				data: usersNotDeleted,
			};
		}
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN, Role.TEAM_ADMIN)
	@Post("invite")
	async inviteUsers(@Body() body: { ids: number[] }) {
		await this.teamService.inviteUsers(body);
		return { message: "Invitation Sent!" };
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN, Role.TEAM_ADMIN)
	@Post("upload")
	@UseInterceptors(FileInterceptor("file"))
	async addUsers(@UploadedFile() file, @Headers() headers) {
		try {
			const user = await this.teamService.decodeUserJWT(headers["token"]);
			const users: Partial<User>[] = await this.teamService.processCsv(file, "user");
			const usersNotAdded = await this.teamService.createMultipleUser(users, user.id);
			if (usersNotAdded.length === users.length) {
				return {
					message: "No Users Added!",
					err_data: usersNotAdded,
					input_data: users,
				};
			} else if (usersNotAdded.length === 0) {
				return {
					message: "All Users Added!",
					data: await this.usersService.findUsers({
						phoneNumbers: _.compact(
							users.map((u) => {
								if (u?.phoneNumber?.length) return u.phoneNumber;
							}),
						),
						emails: _.compact(
							users.map((u) => {
								if (u?.email?.length) return u?.email;
							}),
						),
					}),
					input_data: users,
				};
			} else {
				return {
					message: "Some Users Added!",
					err_data: usersNotAdded,
					data: await this.usersService.findUsers({
						phoneNumbers: _.compact(
							users
								.filter((u) => !usersNotAdded.map((us) => us?.phoneNumber).includes(u?.phoneNumber))
								.map((u) => u?.phoneNumber),
						),
						emails: _.compact(
							users
								.filter((u) => !usersNotAdded.map((us) => us?.email).includes(u?.email))
								.map((u) => u?.email),
						),
					}),
					input_data: users,
				};
			}
		} catch (error) {
			throw error;
		}
	}
}
