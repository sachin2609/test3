import { Test, TestingModule } from '@nestjs/testing';
import { ApiKeyUsersController } from './api-key-users.controller';

describe('ApiKeyUsersController', () => {
  let controller: ApiKeyUsersController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ApiKeyUsersController],
    }).compile();

    controller = module.get<ApiKeyUsersController>(ApiKeyUsersController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
