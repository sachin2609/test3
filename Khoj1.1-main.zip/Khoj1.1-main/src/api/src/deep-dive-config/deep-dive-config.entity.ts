import { Entity, PrimaryColumn, Column, PrimaryGeneratedColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

export interface SomeInterface {
	index: string;
	poi: string;
}

@Entity()
export class DeepDiveConfig {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	layerName: string;

	@ApiProperty()
	@Column()
	layerSet: string;

	@ApiProperty()
	@Column()
	value: string;

	@ApiProperty()
	@Column({default:true})
	default: boolean;

	@ApiProperty()
	@Column()
	userId: number;
}
