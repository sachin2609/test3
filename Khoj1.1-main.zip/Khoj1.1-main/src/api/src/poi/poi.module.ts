import { Module } from "@nestjs/common";
import { CacheModule } from "@nestjs/cache-manager";
import { HttpModule } from "@nestjs/axios";
import { PoiController } from "./poi.controller";
import { PoiService } from "./poi.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Poi } from "./poi.entity";
import { GridService } from "../grid/grid.service";
import { Grid } from "../grid/grids.entity";
import { PoiGrid } from "../relations/poi-grid/poi-grid.entity";
import { PoiGridService } from "../relations/poi-grid/poi-grid.service";
import { Property } from "../property/property.entity";
import { User } from "../users/users.entity";
import { PropertyService } from "../property/property.service";
import { PropertyGrid } from "../relations/property-grid/property-grid.entity";
import { UserGrid } from "../relations/user-grid/user-grid.entity";
import { PropertyGridService } from "../relations/property-grid/property-grid.service";
import { WorkItemService } from "../work-item/work-item.service";
import { PropertyDetailService } from "../property-detail/property-detail.service";
import { PropertyDetail } from "src/property-detail/property-detail.entity";
import { WorkItem } from "../work-item/work-item.entity";
import { Indexmaster } from "../index-master/index-master.entity";
import { JwtModule } from "@nestjs/jwt";
import { Answer } from "src/answer/answer.entity";
import { Question } from "src/question/question.entity";
import { PoiDetail } from "../poi-details/poi-details.entity";
import { Poiexported } from "./poisExported.entity";
import { TargetDetail } from "src/target-details/target-details.entity";
import { CsvUploadedFiles } from "../csv-processor/csv-upload.entity";
import { CsvModule, CsvParser } from "nest-csv-parser";
import { GlobalServiceService } from "src/helpers/global-service/global-service.service";
import { MongooseModule } from "@nestjs/mongoose";
import { DemoShapesDBSchema } from "src/shape/shape.schema";
import { Shape } from "src/shape/shape.entity";
import * as redisStore from "cache-manager-redis-store";
import { RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { Organisation } from "src/organisations/organisations.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { ShapeService } from "src/shape/shape.service";
import { UserMerchant } from "src/merchant/user-merchant.entity";
import { ApiKeyUserMerchant } from "src/merchant/api-key-user-merchant.entity";
import { Team } from "src/team/team.entity";
import { POIFilter, POIFilterUserTeam } from "src/poi-filter/poi-filter.entity";
import { TeamService } from "src/team/team.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		HttpModule,
		TypeOrmModule.forFeature([
			WorkItem,
			Poi,
			Grid,
			PoiGrid,
			Property,
			User,
			Team,
			PropertyGrid,
			UserGrid,
			PropertyDetail,
			Indexmaster,
			Answer,
			Question,
			PoiDetail,
			Poiexported,
			TargetDetail,
			CsvUploadedFiles,
			Shape,
			Organisation,
			UserApiUsageHistory,
			UserCredits,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyUserApiUsageHistory,
			ApiKeyUserCredits,
			ApiKeyIp,
			UserIdIp,
			Shapeindex,
			ShapeDetail,
			UserMerchant,
			ApiKeyUserMerchant,
			POIFilter,
			POIFilterUserTeam,
		]),
		CsvModule,
		MongooseModule.forFeature([{ name: "DemoShapesDB", schema: DemoShapesDBSchema }]),
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
		HttpModule.register({
			timeout: 100000,
			maxRedirects: 100,
		}),
		MongoDatabaseModule,
	],
	controllers: [PoiController],
	providers: [
		PoiService,
		GridService,
		PoiGridService,
		PropertyService,
		PropertyGridService,
		WorkItemService,
		PropertyDetailService,
		GlobalServiceService,
		RolesGuardService,
		ShapeService,
		TeamService,
		KeyCloakService,
		CentralServerService,
	],
})
export class PoiModule {}
