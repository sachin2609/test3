import { Body, Controller, Get, Headers, HttpException, HttpStatus, Post, Query } from "@nestjs/common";
import { ApiBody, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { RealIP } from "nestjs-real-ip";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Roles, RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { Header } from "src/interfaces/header";
import { Org, UpdateCreditsBody, UpdateCreditsRequest } from "src/interfaces/organisation";
import { ApiKeyOrganisation } from "./api-key-organisations.entity";
import { ApiKeyOrganisationsService, OrgWithCreditsSpent } from "./api-key-organisations.service";
import { TeamService } from "src/team/team.service";

@Controller("api-key-organisations")
export class ApiKeyOrganisationsController {
	constructor(
		private _apiKeyOrganisationsService: ApiKeyOrganisationsService,
		private _rolesGuardService: RolesGuardService,
		private teamService: TeamService,
	) {}

	@Get("getorganisationagainstuser")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Get all Organisational Users for a User using the user-token" })
	async getOrg(@Headers() headers: Header): Promise<ApiKeyOrganisation> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		return await this._apiKeyOrganisationsService.findOrgAgainstUser(user.email, user.id);
	}

	@Roles("basic")
	@Get("getallorganisations")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Get all Organisations" })
	async getAllOrgs(@Headers() headers): Promise<OrgWithCreditsSpent[]> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		return await this._apiKeyOrganisationsService.getOrgs(user["id"] as number, user["roles"] as string[]);
	}

	@Roles("admin")
	@Post("addorganisations")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Add Multiple Organisations" })
	async addOrgs(@Body() body: Org[]): Promise<ApiKeyOrganisation[]> {
		return await this._apiKeyOrganisationsService.addOrgs(body);
	}

	@Roles("admin")
	@Post("updateorganisation")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Update an Organisation" })
	async updateOrg(@Body() body: ApiKeyOrganisation): Promise<ApiKeyOrganisation> {
		return await this._apiKeyOrganisationsService.updateOrg(body);
	}

	@Roles("admin")
	@Post("deleteorganisation")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Delete an Organisation" })
	async deleteOrg(@Body() body: { id: number }) {
		return await this._apiKeyOrganisationsService.deleteOrg(body.id);
	}

	@Roles("admin")
	@Post("updateuser")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: ApiKeyUser })
	@ApiResponse({ description: "Update an User" })
	async updateUser(@Body() body: ApiKeyUser): Promise<ApiKeyUser> {
		return await this._apiKeyOrganisationsService.updateUser(body);
	}

	@Roles("admin")
	@Post("addusers")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: ApiKeyUser })
	@ApiResponse({ description: "Add Users to Organisations" })
	async addUsers(@Body() body: ApiKeyUser[]): Promise<unknown> {
		return await this._apiKeyOrganisationsService.addUsers(body);
	}

	@Roles("admin")
	@Post("deleteuser")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Delete User" })
	async deleteUser(@Body() body: { id: number }): Promise<unknown> {
		return await this._apiKeyOrganisationsService.deleteUser(body.id);
	}

	@Post("getusers")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Get Users Against Organisations" })
	async getUsersAginstOrganisation(@Body() body): Promise<ApiKeyUser[]> {
		try {
			return await this._apiKeyOrganisationsService.getUsersAginstOrganisation(body);
		} catch (error) {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: "BAD REQUEST",
				},
				HttpStatus.BAD_REQUEST,
			);
		}
	}

	@Roles("basic")
	@Get("getallusers")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Get All Users" })
	async getAllUsers(@Query("allstatus") allstatus: string, @Headers() headers): Promise<ApiKeyUser[]> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		try {
			return allstatus === "true"
				? await this._apiKeyOrganisationsService.getAllUsers(
						user["id"] as number,
						user["roles"] as string[],
						true,
				  )
				: await this._apiKeyOrganisationsService.getAllUsers(user["id"] as number, user["roles"] as string[]);
		} catch (error) {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: "BAD REQUEST",
				},
				HttpStatus.BAD_REQUEST,
			);
		}
	}

	@Roles("admin")
	@Post("update-credits")
	async updateCredits(@Body() body: UpdateCreditsBody, @Headers() headers) {
		return await this._apiKeyOrganisationsService.updateCredits(body, headers);
	}

	@Roles("externalapi")
	@Post("updatecreds")
	async updateCreds(
		@Headers() header: Header,
		@Body() body: UpdateCreditsRequest,
		@RealIP() ip: string,
	): Promise<boolean> {
		return await this._rolesGuardService.updateCreds(
			body.user_token,
			body.credits,
			"/api-key-organisations/updatecreds",
			ip,
			JSON.stringify(body),
		);
	}
}
