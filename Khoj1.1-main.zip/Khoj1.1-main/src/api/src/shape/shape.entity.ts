import { Entity, Column, PrimaryGeneratedColumn, OneToMany, JoinColumn, Index } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
import { Shapeindex } from "./shapeIndex.entity";

@Entity()
export class Shape {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	name: string;
	
	@ApiProperty()
	@Column()
	level: string;
	
	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	State: string;

	@ApiProperty()
	@Index()
	@Column()
	City: string;
	
	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	Pincode: string;

	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	Cluster: string;
	
	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	District: string;

	@ApiProperty()
	@Column({ nullable: true })
	Taluka: string;
	
	@ApiProperty()
	@Index()
	@Column({ default: 'india' })
	Country: string;
	
	@ApiProperty()
	@Column()
	objectId: string;
	
	@ApiProperty()
	@OneToMany(
		() => Shapeindex,
		shapeindex => shapeindex.shape,
		{ cascade: true }
	)
	@JoinColumn()
	shapeindex: Shapeindex[];

}

