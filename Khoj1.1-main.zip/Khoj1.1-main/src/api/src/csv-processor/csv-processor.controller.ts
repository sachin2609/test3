import { Body, Controller, Post, Res, UploadedFiles, UseInterceptors, Headers } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { FilesInterceptor } from '@nestjs/platform-express';
import { ApiHeader, ApiResponse, ApiTags } from '@nestjs/swagger';
import { InjectRepository } from '@nestjs/typeorm';
import { Grid } from 'src/grid/grids.entity';
import { CsvUploadedFiles } from 'src/csv-processor/csv-upload.entity';
import { editFileName, csvFileFilter } from 'src/poi/filefilter';
import { PoiService } from 'src/poi/poi.service';
import { Property } from 'src/property/property.entity';
import { Roles } from 'src/helpers/roles-guard/roles-guard.service';
import { Repository } from 'typeorm';
import { diskStorage } from "multer";
import { CsvProcessorService } from './csv-processor.service';

@ApiTags("CsvProcessor")
@Controller('csv-processor')
export class CsvProcessorController {
	constructor(
		private _poiService: PoiService,
		@InjectRepository(Property) private propertyRepository: Repository<Property>,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		private _jwtService: JwtService,
		private _csvProcessorService: CsvProcessorService
	) {}

	@Roles("basic")
	@Post("/uploadCsv")
	@ApiHeader({ name: "header" })
	@ApiResponse({ description: "Upload" })
	@UseInterceptors(
		FilesInterceptor("file", 20, {
			storage: diskStorage({
				destination: "./public",
				filename: editFileName
			}),
			fileFilter: csvFileFilter
		})
	)
	async uploadCsv(@UploadedFiles() files: File[], @Headers() header: JSON, @Body() body): Promise<CsvUploadedFiles[] | CsvUploadedFiles> {
		const fileNames = [];
		const user = this._jwtService.decode(header["token"]);
		console.log(files);
		files.forEach(file => {
			fileNames.push(file["filename"]);
		});
		console.log("File names: ",files);
		console.log(body["description"]);
		return await this._csvProcessorService.uploadCsv(user["id"],files, body);
	}

	@Roles("basic")
	@ApiHeader({ name: "header" })
	@ApiResponse({ description: "Get Uploads" })
	@Post("getUploadCsv")
	async getUploadCsv(@Headers() header: JSON, @Body() body): Promise<CsvUploadedFiles[] | CsvUploadedFiles> {
		const user = this._jwtService.decode(header["token"]);
		return await this._csvProcessorService.getUploadCsv(user["id"], body);
	}

	@Roles("basic")
	@ApiHeader({ name: "header" })
	@ApiResponse({ description: "Delete Uploads" })
	@Post("deleteUploadedCsv")
	async deleteUploadCsv(@Headers() header: JSON, @Body() body): Promise<void> {
		const user = this._jwtService.decode(header["token"]);
		await this._csvProcessorService.deleteUploadCsv(user["id"],body);
	}

	@Roles("basic")
	@ApiHeader({ name: "header" })
	@ApiResponse({ description: "Read Uploads" })
	@Post("readUploadCsv")
	async readUploadCsv(@Headers() header: JSON, @Body() body, @Res() res): Promise<unknown> {
		//const res = [];
		console.log("inside read upload csv");
		const user = this._jwtService.decode(header["token"]);
		console.log("user is ", user);
		try {
			return await this._csvProcessorService.readUploadCsv(user["id"],body, res);
			/*const result = await this._poiService.readUploadCsv(user["id"],body, res);
			return await this._poiService.calcUploadCsv(body,res);*/
		} catch(error) {
			console.log(error);
			return [];
		}
	}

}
