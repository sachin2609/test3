import { Module, NestModule, MiddlewareConsumer } from "@nestjs/common";
import { AuthService } from "./auth.service";
import { AuthServiceV2 } from "./auth.service.v2";
import { AuthController } from "./auth.controller";
import { GoogleStrategy } from "./google.strategy";
import { UsersService } from "../users/users.service";
import { User } from "../users/users.entity";
import { TypeOrmModule } from "@nestjs/typeorm";
import { JwtModule } from "@nestjs/jwt";
import * as dotenv from "dotenv";
import { PassportModule } from "@nestjs/passport";
import { UserHistory } from "src/user-history/user-history.entity";
import { UserHistoryService } from "src/user-history/user-history.service";
import { Organisation } from "src/organisations/organisations.entity";
import { UserOtp } from "src/users/user-otp.entity";
import { MailerModule } from "@nestjs-modules/mailer";
import * as path from "path";
import { HandlebarsAdapter } from "@nestjs-modules/mailer/dist/adapters/handlebars.adapter";
import { UserCredits } from "../user-history/user-credits.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyIp } from "./apiKey-ip.entity";
import { UserIdIp } from "./userId-ip.entity";
import { ApiKeyUsersService } from "src/api-key-users/api-key-users.service";
import { AppVersionController } from "./app-version.controller";
import { TeamService } from "src/team/team.service";
import { Team } from "src/team/team.entity";
import { KeyCloakService } from "./keycloak.service";
import { CentralServerService } from "./central-server.service";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { Kpi } from "src/kpi/kpi.entity";
import { SecurityService } from "src/security/security.service";
import { HttpModule } from "@nestjs/axios";
import { CacheModule } from "@nestjs/cache-manager";
import * as redisStore from "cache-manager-redis-store";

dotenv.config();
@Module({
	imports: [
		TypeOrmModule.forFeature([
			User,
			UserHistory,
			Organisation,
			Team,
			UserOtp,
			UserCredits,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyUserCredits,
			ApiKeyIp,
			UserIdIp,
			Kpi,
			UserApiUsageHistory
		]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		PassportModule.register({ defaultStrategy: "bearer" }),
		MailerModule.forRoot({
			transport: {
				host: "smtp.gmail.com",
				port: 587,
				ignoreTLS: true,
				secure: false,
				service: "gmail",
				auth: {
					user: process.env.MAILDEV_INCOMING_USER,
					pass: process.env.MAILDEV_INCOMING_PASS,
				},
				tls: { rejectUnauthorized: false },
			},
			defaults: {
				from: "datasutram01@wellnessforever.in",
			},
			template: {
				dir: path.join(process.env.PWD, "templates/pages"),
				adapter: new HandlebarsAdapter(),
				options: {
					strict: false,
				},
			},
			options: {
				partials: {
					dir: path.join(process.env.PWD, "templates/partials"),
					options: {
						strict: true,
					},
				},
			},
		}),
		HttpModule.register({
			timeout: 100000,
			maxRedirects: 100,
		}),
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
	],
	providers: [
		AuthService,
		GoogleStrategy,
		UsersService,
		UserHistoryService,
		ApiKeyUsersService,
		TeamService,
		AuthServiceV2,
		KeyCloakService,
		CentralServerService,
		SecurityService
	],
	controllers: [AuthController, AppVersionController],
})
export class AuthModule implements NestModule {
	public configure(consumer: MiddlewareConsumer): void {
		//consumer
		//	.apply(
		//		passport.authenticate("google", {
		//			accessType: "offline",
		//			prompt: "consent",
		//			session: false,
		//		}),
		//	)
		//	.forRoutes("auth/login");
	}
}
