import { Controller, Get, Headers } from "@nestjs/common";
import { AuthService } from "./auth.service";
import * as dotenv from "dotenv";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
dotenv.config();

@Controller("appVersion")
export class AppVersionController {
	constructor(private _authService: AuthService) {}

	@Roles("basic")
	@Get()
	async getAppVersion(@Headers() headers) {
		return await this._authService.getAppVersion(headers);
	}
}
