export class PincodeAnalysisBody {
    pincode: string;
}

export class CoordinateAnalysisBody {
    lat: number;
    lng: number;
}