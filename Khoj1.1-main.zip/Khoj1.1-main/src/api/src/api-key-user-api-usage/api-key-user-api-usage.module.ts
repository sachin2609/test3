import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyUserApiUsageController } from "./api-key-user-api-usage.controller";
import { ApiKeyUserApiUsageHistory } from "./api-key-user-api-usage.entity";
import { ApiKeyUserApiUsageService } from "./api-key-user-api-usage.service";
import { TeamService } from "src/team/team.service";
import { Team } from "src/team/team.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { User } from "src/users/users.entity";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";

@Module({
	imports: [
		TypeOrmModule.forFeature([ApiKeyUserApiUsageHistory, ApiKeyUser, ApiKeyOrganisation, Team, UserCredits, User]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
	],
	controllers: [ApiKeyUserApiUsageController],
	providers: [ApiKeyUserApiUsageService, TeamService, KeyCloakService, CentralServerService],
})
export class ApiKeyUserApiUsageModule {}
