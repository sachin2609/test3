import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class Question {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	question: string;

	@ApiProperty()
	@Column()
	type: string;

	@ApiProperty()
	@Column({ nullable: true })
	category: string;

	@ApiProperty()
	@Column("simple-array", { nullable: true })
	options: string[];

	@ApiProperty()
	@Column("simple-array", { nullable: true })
	optionsType: string[];

	@ApiProperty()
	@Column({ default: false })
	remark: boolean;

	@ApiProperty()
	@Column()
	required: boolean;

	@ApiProperty()
	@Column("simple-array", { nullable: true })
	placeholder: string[];
}
