import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { KeycloakTokenResponse, KeycloakUserInfo } from "src/interfaces/keycloak";
import axios from "axios";
import { User } from "src/users/users.entity";
import { JwtService } from "@nestjs/jwt";

@Injectable()
export class KeyCloakService {
	kcAccessToken: string;
	kcIdToken: string;

	constructor(private jwtService: JwtService) {}

	async axiosReq(
		url: string,
		method: "get" | "post" | "put" | "delete",
		bearerToken?: string,
		data?: string,
		contentType?: "json" | "urlencoded",
	): Promise<any> {
		const config = {
			method,
			maxBodyLength: Infinity,
			url,
			headers: {
				"Content-Type": contentType
					? contentType === "json" ?? "application/x-www-form-urlencoded"
					: "application/json",
				Authorization: bearerToken ? `Bearer ${bearerToken}` : undefined,
				Accept: "*/*",
			},
			data: data,
		};
		return axios(config);
	}

	async getKCAccessTokenFromAuthorizationCode(authorizationCode: string): Promise<KeycloakTokenResponse> {
		try {
			const options = {
				method: "POST",
				url: `${process.env.KC_AUTH_SERVER}/realms/${process.env.KC_REALM}/protocol/openid-connect/token`,
				headers: {
					"content-type": "application/x-www-form-urlencoded",
				},
				data: {
					grant_type: "authorization_code",
					client_id: process.env.KC_CLIENT_ID,
					client_secret: process.env.KC_CLIENT_SECRET,
					code: authorizationCode,
					redirect_uri: String(process.env.BASE_URL) + "/auth/redirect",
				},
			};
			const req = await axios.request(options);
			return await req.data;
		} catch (e) {
			console.error("Error Getting Access Token using KC Auth Code", e);
			throw new HttpException((e as Error).message, HttpStatus.UNAUTHORIZED);
		}
	}

	async createKCAdminAccessToken(): Promise<void> {
		const data = {
			client_id: process.env.KC_CLIENT_ID,
			client_secret: process.env.KC_CLIENT_SECRET,
			username: process.env.KC_ADMIN_USERNAME,
			password: process.env.KC_ADMIN_PASSWORD,
			grant_type: "password",
		};
		const config = {
			method: "post",
			maxBodyLength: Infinity,
			url: `${process.env.KC_AUTH_SERVER}/realms/${process.env.KC_REALM}/protocol/openid-connect/token`,
			headers: {
				"Content-Type": "application/x-www-form-urlencoded",
				Accept: "*/*",
			},
			data: data,
		};
		try {
			const response = await axios(config);
			this.kcAccessToken = response.data.access_token;
			console.log("Generated New KC Access Token!");
		} catch (err) {
			console.error("Cannot Generate KeyCloak Access Token", err);
		}
	}

	async createKCAdminIdToken(): Promise<string> {
		const data = {
			client_id: process.env.KC_CLIENT_ID,
			client_secret: process.env.KC_CLIENT_SECRET,
			username: process.env.KC_ADMIN_USERNAME,
			password: process.env.KC_ADMIN_PASSWORD,
			grant_type: "client_credentials",
			scope: "openid",
		};
		const config = {
			method: "post",
			maxBodyLength: Infinity,
			url: `${process.env.KC_AUTH_SERVER}/realms/${process.env.KC_REALM}/protocol/openid-connect/token`,
			headers: {
				"Content-Type": "application/x-www-form-urlencoded",
				Accept: "*/*",
			},
			data: data,
		};
		try {
			const response = await axios(config);
			this.kcIdToken = response.data?.id_token;
			console.log("Generated New KC ID Token!");
			return response.data.id_token;
		} catch (err) {
			console.error("Cannot Generate KeyCloak ID Token", err);
		}
	}

	async getKCUserInfo(access_token: string): Promise<KeycloakUserInfo> {
		try {
			const userInfo = await this.axiosReq(
				`${process.env.KC_AUTH_SERVER}/realms/${process.env.KC_REALM}/protocol/openid-connect/userinfo`,
				"get",
				access_token,
				null,
			);
			return await userInfo.data;
		} catch (e) {
			console.error("Error Getting User Info using KC Access Token", e);
			throw new HttpException((e as Error).message, HttpStatus.UNAUTHORIZED);
		}
	}

	async checkKCAccessToken(): Promise<void> {
		if (this.kcAccessToken?.length) {
			const decoded = this.jwtService.decode(this.kcAccessToken);
			const currentTime = Math.floor(Date.now() / 1000);
			if (currentTime >= decoded["exp"]) await this.createKCAdminAccessToken();
		} else await this.createKCAdminAccessToken();
	}

	async createKCUser(user: Partial<User>): Promise<void> {
		await this.checkKCAccessToken();
		const { email, phoneNumber, firstName, lastName } = user;
		const data = JSON.stringify({
			username: email || phoneNumber,
			enabled: true,
			firstName,
			lastName,
			email: email || phoneNumber,
			credentials: [
				{
					type: "password",
					value: process.env.KC_USER_DEFAULT_PASSWORD,
					temporary: true,
				},
			],
		});
		try {
			await this.axiosReq(
				`${process.env.KC_AUTH_SERVER}/admin/realms/${process.env.KC_REALM}/users`,
				"post",
				this.kcAccessToken,
				data,
			);
		} catch (err) {
			console.error("Cannot Create KeyCloak User", err);
			throw new HttpException("Cannot Create KC User!", HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async createKCUserWithPass(user: Partial<User>): Promise<void> {
		await this.checkKCAccessToken();
		const { email, phoneNumber, firstName, lastName, password } = user;
		const data = JSON.stringify({
			username: email || phoneNumber,
			enabled: true,
			firstName,
			lastName,
			email: email || phoneNumber,
			credentials: [
				{
					type: "password",
					value: password,
					temporary: false,
				},
			],
		});
		try {
			await this.axiosReq(
				`${process.env.KC_AUTH_SERVER}/admin/realms/${process.env.KC_REALM}/users`,
				"post",
				this.kcAccessToken,
				data,
			);
		} catch (err) {
			console.error("Cannot Create KeyCloak User", err);
			throw new HttpException("Cannot Create KC User!", HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async getKCUserByUserName(userName: string): Promise<KeycloakUserInfo> {
		await this.checkKCAccessToken();
		try {
			const response = await this.axiosReq(
				`${process.env.KC_AUTH_SERVER}/admin/realms/${process.env.KC_REALM}/users?search=${userName}`,
				"get",
				this.kcAccessToken,
				null,
			);
			return response.data;
		} catch (err) {
			console.error("Cannot Get KeyCloak User", err);
		}
	}

	async updateKCUser(username: string, user: Partial<User>): Promise<KeycloakUserInfo> {
		await this.checkKCAccessToken();
		const { firstName, lastName } = user;
		if (!firstName?.length && !lastName?.length) return;
		try {
			const existingKCUser = await this.getKCUserByUserName(username);
			const KCUserID = existingKCUser[0].id;
			const data = JSON.stringify({ firstName, lastName });
			const response = await this.axiosReq(
				`${process.env.KC_AUTH_SERVER}/admin/realms/${process.env.KC_REALM}/users/${KCUserID}`,
				"put",
				this.kcAccessToken,
				data,
			);
			return response.data.access_token;
		} catch (err) {
			console.error("Cannot Update KeyCloak User", err);
			throw new HttpException("Cannot Update KC User!", HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async delteKCUser(user: Partial<User>): Promise<KeycloakUserInfo> {
		await this.checkKCAccessToken();
		try {
			const existingKCUser = (await this.getKCUserByUserName(user?.email || user?.phoneNumber))?.[0];
			if (!existingKCUser) {
				throw new HttpException("KC User Not Found!", HttpStatus.BAD_REQUEST);
			}
			const response = await this.axiosReq(
				`${process.env.KC_AUTH_SERVER}/admin/realms/${process.env.KC_REALM}/users/${existingKCUser.id}`,
				"delete",
				this.kcAccessToken,
				null,
			);
			return response.data.access_token;
		} catch (err) {
			console.error("Cannot Delete KeyCloak User", err);
			throw new HttpException("Cannot Delete KC User!", HttpStatus.SERVICE_UNAVAILABLE);
		}
	}
}
