import { Controller, Post, Get, Body, Query } from "@nestjs/common";
import { PoiDetailsService } from "./poi-details.service";
import { PoiDetail } from "./poi-details.entity";
@Controller("poi-details")
export class PoiDetailsController {
	constructor(private _poiDetailsService: PoiDetailsService) {}

	@Post()
	async create(@Body() poiDetailObjects: PoiDetail[]): Promise<PoiDetail[]> {
		return await this._poiDetailsService.create(poiDetailObjects);
	}

	@Get()
	async list(@Query() query: PoiDetail): Promise<PoiDetail[]> {
		return await this._poiDetailsService.list(query.poiId ? query.poiId : null);
	}
}
