import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Organisation } from "src/organisations/organisations.entity";
import { User } from "src/users/users.entity";
import { UserApiUsageHistoryController } from "./user-api-usage-history.controller";
import { UserApiUsageHistory } from "./user-api-usage-history.entity";
import { UserApiUsageHistoryService } from "./user-api-usage-history.service";
import { Team } from "src/team/team.entity";
import { TeamService } from "src/team/team.service";
import { UserCredits } from "src/user-history/user-credits.entity";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";

@Module({
	imports: [
		TypeOrmModule.forFeature([UserApiUsageHistory, User, Organisation, Team, UserCredits]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
	],
	controllers: [UserApiUsageHistoryController],
	providers: [UserApiUsageHistoryService, TeamService, KeyCloakService, CentralServerService],
})
export class UserApiUsageHistoryModule {}
