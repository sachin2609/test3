import { Body, Controller, Headers, HttpStatus, Patch, Post, Req } from "@nestjs/common";
import { RemindersService } from "./reminders.service";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { Reminder } from "./reminders.entity";
import { ReminderQuery } from "src/interfaces/reminders";

import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { TeamService } from "src/team/team.service";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";
import { Request } from "express";
import { RealIP } from "nestjs-real-ip";

@Controller("reminders")
export class RemindersController {
	constructor(
		private readonly _remindersService: RemindersService,
		private teamService: TeamService,
		private _syslogService: SyslogService,
	) {}

	async getUser(headers: any): Promise<{ tokenUser: Partial<User>; apiKeyUser: Partial<ApiKeyUser> }> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		const tokenUser = user["type"] === "token" ? (user as User) : undefined;
		const apiKeyUser = user["type"] === "apikey" ? (user as ApiKeyUser) : undefined;
		if (!tokenUser && !apiKeyUser) {
			throw new Error("Invalid token");
		}
		return { tokenUser, apiKeyUser };
	}

	@Roles(Role.BASIC)
	@Post("create")
	async addReminder(
		@Headers() headers,
		@Body() body: Partial<Reminder> & { updatedFields?: string[] },
		@Req() req: Request,
		@RealIP() ip,
	) {
		try {
			const { tokenUser, apiKeyUser } = await this.getUser(headers);
			if (tokenUser?.id) {
				body.tokenUserId = tokenUser?.id;
			}

			if (apiKeyUser?.id) {
				body.apiKeyUserId = apiKeyUser?.id;
			}
			const res = await this._remindersService.createReminder(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("fetch")
	async fetchReminder(@Headers() headers, @Body() body: Partial<ReminderQuery>, @Req() req: Request, @RealIP() ip) {
		try {
			const { tokenUser, apiKeyUser } = await this.getUser(headers);
			if (!body?.userId?.length) {
				body.userId = [apiKeyUser?.id ?? tokenUser?.id];
			}
			const res = await this._remindersService.fetchReminderswithPoiDetails(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Patch("update")
	async updateReminder(
		@Body() body: Partial<Reminder> & { updatedFields: string[] },
		@Req() req: Request,
		@RealIP() ip,
	) {
		try {
			const res = await this._remindersService.editReminder(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Patch("done")
	async markAsDone(@Body() body: Partial<Reminder> & { updatedFields: string[] }, @Req() req: Request, @RealIP() ip) {
		try {
			const res = await this._remindersService.editReminder(
				{ id: body.id, updatedFields: ["done"], isActive: false },
				true,
			);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("delete")
	async deleteReminder(@Body() body: Partial<Reminder>, @Req() req: Request, @RealIP() ip) {
		try {
			const res = await this._remindersService.deleteReminder(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}
}
