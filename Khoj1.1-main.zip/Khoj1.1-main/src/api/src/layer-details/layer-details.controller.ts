import { Controller } from '@nestjs/common';

@Controller('layer-details')
export class LayerDetailsController {}
