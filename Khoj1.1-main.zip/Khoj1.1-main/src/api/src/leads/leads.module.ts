import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { LeadController } from "./leads.controller";
import { LeadsService } from "./leads.service";
import { Lead, LeadStatusUpdates, LostLead } from "./leads.entity";
import { JwtModule } from "@nestjs/jwt";
import { Poi } from "src/poi/poi.entity";
import { Grid } from "src/grid/grids.entity";
import { PoiGrid } from "src/relations/poi-grid/poi-grid.entity";
import { MerchantService } from "src/merchant/merchant.service";
import { HttpModule } from "@nestjs/axios";
import { MongooseModule } from "@nestjs/mongoose";
import { CsvModule } from "nest-csv-parser";
import { Answer } from "src/answer/answer.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { CsvUploadedFiles } from "src/csv-processor/csv-upload.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
import { Indexmaster } from "src/index-master/index-master.entity";
import { ApiKeyUserMerchant } from "src/merchant/api-key-user-merchant.entity";
import { UserMerchant } from "src/merchant/user-merchant.entity";
import { Organisation } from "src/organisations/organisations.entity";
import { PoiDetail } from "src/poi-details/poi-details.entity";
import { Poiexported } from "src/poi/poisExported.entity";
import { PropertyDetail } from "src/property-detail/property-detail.entity";
import { Property } from "src/property/property.entity";
import { Question } from "src/question/question.entity";
import { PropertyGrid } from "src/relations/property-grid/property-grid.entity";
import { UserGrid } from "src/relations/user-grid/user-grid.entity";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { Shape } from "src/shape/shape.entity";
import { DemoShapesDBSchema } from "src/shape/shape.schema";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { TargetDetail } from "src/target-details/target-details.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { User } from "src/users/users.entity";
import { WorkItem } from "src/work-item/work-item.entity";
import { GridService } from "src/grid/grid.service";
import { PoiService } from "src/poi/poi.service";
import { ShapeService } from "src/shape/shape.service";
import { TeamService } from "src/team/team.service";
import { Team } from "src/team/team.entity";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
import { RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { Kpi } from "src/kpi/kpi.entity";
import { Reminder, ReminderUpdate } from "src/reminders/reminders.entity";
import { Note } from "src/notes/notes.entity";
import { RemindersService } from "src/reminders/reminders.service";
import { POIFilter, POIFilterUserTeam } from "src/poi-filter/poi-filter.entity";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";

@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		HttpModule.register({
			timeout: 100000,
			maxRedirects: 100,
		}),
		TypeOrmModule.forFeature([
			WorkItem,
			Poi,
			Grid,
			PoiGrid,
			Property,
			User,
			Team,
			PropertyGrid,
			UserGrid,
			PropertyDetail,
			Indexmaster,
			Answer,
			Question,
			PoiDetail,
			Poiexported,
			TargetDetail,
			CsvUploadedFiles,
			Shape,
			Organisation,
			UserApiUsageHistory,
			UserCredits,
			ShapeDetail,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyUserCredits,
			ApiKeyUserApiUsageHistory,
			UserMerchant,
			ApiKeyIp,
			UserIdIp,
			Shapeindex,
			ShapeDetail,
			ApiKeyUserMerchant,
			Lead,
			LeadStatusUpdates,
			LostLead,
			Kpi,
			ReminderUpdate,
			Reminder,
			Note,
			POIFilter,
			POIFilterUserTeam,
		]),
		CsvModule,
		MongooseModule.forFeature([{ name: "DemoShapesDB", schema: DemoShapesDBSchema }]),
		MongoDatabaseModule,
	],
	controllers: [LeadController],
	providers: [
		LeadsService,
		MerchantService,
		GridService,
		PoiService,
		RolesGuardService,
		ShapeService,
		TeamService,
		KeyCloakService,
		CentralServerService,
		RemindersService,
		SyslogService,
	],
})
export class LeadsModule {}
