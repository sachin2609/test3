import { Controller } from '@nestjs/common';

@Controller('shape-details')
export class ShapeDetailsController {}
