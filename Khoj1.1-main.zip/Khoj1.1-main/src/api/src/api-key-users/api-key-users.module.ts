import { Module } from '@nestjs/common';
import { ApiKeyUsersController } from './api-key-users.controller';
import { ApiKeyUsersService } from './api-key-users.service';
import { TypeOrmModule } from "@nestjs/typeorm";
import { ApiKeyUser } from './api-key-users.entity';
import { ApiKeyUserCredits } from './api-key-users-credits.entity';

@Module({
    imports: [TypeOrmModule.forFeature([ApiKeyUser,ApiKeyUserCredits])],
    controllers: [ApiKeyUsersController],
    providers: [ApiKeyUsersService]
})
export class ApiKeyUsersModule {}
