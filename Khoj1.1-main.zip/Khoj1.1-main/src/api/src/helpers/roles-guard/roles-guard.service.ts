import {
	Injectable,
	CanActivate,
	ExecutionContext,
	SetMetadata,
	CustomDecorator,
	HttpException,
	HttpStatus,
} from "@nestjs/common";
import { UserCredits } from "../../user-history/user-credits.entity";
import { Reflector } from "@nestjs/core";
import { JwtService } from "@nestjs/jwt";
import { Repository, DataSource } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { User } from "../../users/users.entity";
import * as _ from "lodash";
import { UserApiUsageHistory } from "../../user-api-usage-history/user-api-usage-history.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { Shape } from "src/shape/shape.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { Team } from "src/team/team.entity";

@Injectable()
export class RolesGuardService implements CanActivate {
	constructor(
		private reflector: Reflector,
		private _jwtService: JwtService,
		private connection: DataSource,
		@InjectRepository(User) private usersRepository: Repository<User>,
		@InjectRepository(Team) private teamRepository: Repository<Team>,
		@InjectRepository(UserApiUsageHistory) private userApiUsageHistoryRepository: Repository<UserApiUsageHistory>,
		@InjectRepository(UserCredits) private userCreditsRepository: Repository<UserCredits>,
		@InjectRepository(ApiKeyUser) private apiKeyUsersRepository: Repository<ApiKeyUser>,
		@InjectRepository(ApiKeyOrganisation) private apiKeyOrganisationRepository: Repository<ApiKeyOrganisation>,
		@InjectRepository(ApiKeyUserApiUsageHistory)
		private apiKeyUserApiUsageHistoryRepository: Repository<ApiKeyUserApiUsageHistory>,
		@InjectRepository(ApiKeyUserCredits) private apiKeyUserCreditsRepository: Repository<ApiKeyUserCredits>,
		@InjectRepository(ApiKeyIp) private apiKeyIpRepository: Repository<ApiKeyIp>,
		@InjectRepository(Shape) private shapeRepository: Repository<Shape>,
		@InjectRepository(UserIdIp) private userIdIpRepository: Repository<UserIdIp>,
	) {}

	async canActivate(context: ExecutionContext): Promise<boolean> {
		const request = context.switchToHttp().getRequest();
		const ip = request.headers["x-real-ip"] ? request.headers["x-real-ip"] : null;
		const requestParams = {
			route: request?.url ?? undefined,
			method: JSON.stringify(request?.method ?? undefined),
			body: JSON.stringify(request?.body ?? undefined),
			query: JSON.stringify(request?.query ?? undefined),
			params: JSON.stringify(request?.params ?? undefined),
			headers: JSON.stringify(request?.headers ?? undefined),
			ipAddress: JSON.stringify(ip ?? undefined),
		};
		console.log("Request Params: ", requestParams);
		const roles = this.reflector.get<string[]>("roles", context.getHandler());
		console.log("API Required Roles are", roles);
		if (!roles) {
			return true;
		}
		const token = request?.headers?.token;
		const apikey = request?.headers?.apikey || request?.headers?.apiKey || request?.headers?.["api-key"];
		if (!apikey && !token) {
			throw new HttpException("No API Key or Token Provided!", HttpStatus.FORBIDDEN);
		}
		const { tokenUser, apiKeyUser } = await this.getUserInDB(token, apikey);
		const tokenUserApiHistoryObject: Partial<UserApiUsageHistory> = { userId: tokenUser?.id, ...requestParams };
		const apiKeyUserApiUsageHistory: Partial<ApiKeyUserApiUsageHistory> = {
			userId: apiKeyUser?.id,
			...requestParams,
		};
		if (process.env.TWO_FACTOR_AUTH === "true") this.checkClientIP(tokenUser, apikey, ip);
		await this.checkUserRoles(roles, tokenUser, apiKeyUser);
		if (tokenUser) {
			const { route, ipAddress, body, query, params } = tokenUserApiHistoryObject;
			const creditsUpdated = await this.updateCreds(token, 0, route, ipAddress, body, query, params);
			console.log("Token User Credits Updated: ", creditsUpdated);
			return creditsUpdated;
		}
		if (apiKeyUser) {
			const { route, ipAddress, body, query, params } = apiKeyUserApiUsageHistory;
			const creditsUpadted = await this.apiKeyUpdateCreds(apikey, 0, route, ipAddress, body, query, params);
			console.log("API Key User Credits Updated: ", creditsUpadted);
			return creditsUpadted;
		}
	}

	async getUserInDB(token?: string, apiKey?: string): Promise<{ tokenUser: User; apiKeyUser: ApiKeyUser }> {
		const decodedUser = await (async () => {
			try {
				return await this._jwtService.verifyAsync(token ? token : apiKey);
			} catch (err) {
				console.error("JWT Decode Error", err);
				throw new HttpException(`Invalid ${token ? "Token" : "API Key"}`, HttpStatus.FORBIDDEN);
			}
		})();
		if (!decodedUser) throw new HttpException("No User found!", HttpStatus.FORBIDDEN);
		const { id, email, phoneNumber } = decodedUser;
		const tokenUser = token
			? await (async () => {
					try {
						return await this.usersRepository.findOne({ where: { id, email, phoneNumber } });
					} catch (err) {
						console.log(err);
						throw new HttpException("No User against token found!", HttpStatus.FORBIDDEN);
					}
			  })()
			: null;
		const apiKeyUser = apiKey
			? await (async () => {
					try {
						return await this.apiKeyUsersRepository.findOne({ where: { id, email } });
					} catch (err) {
						console.log(err);
						throw new HttpException("No User against API Key found!", HttpStatus.FORBIDDEN);
					}
			  })()
			: null;
		if (!tokenUser && !apiKeyUser) throw new HttpException("No User found!", HttpStatus.FORBIDDEN);
		return { tokenUser, apiKeyUser };
	}

	async checkClientIP(tokenUser: User, apiKey: string, ip: string): Promise<void> {
		if (tokenUser) {
			if (tokenUser.password?.length) {
				const userIdIp = await this.userIdIpRepository.findOne({ where: { userId: tokenUser.id } });
				if (userIdIp.ip != ip) {
					throw new HttpException("Login attempt from new device detected!", HttpStatus.CONFLICT);
				}
			}
		} else {
			const apiKeyIP = await (async () => {
				try {
					return await this.apiKeyIpRepository.findOne({ where: { apiKey } });
				} catch (err) {
					console.log(err);
					throw new HttpException("Cannot Get API Key IP!", HttpStatus.SERVICE_UNAVAILABLE);
				}
			})();
			if (!apiKeyIP)
				throw new HttpException("IP not registered. Please try loginng in again!", HttpStatus.FORBIDDEN);
			if (apiKeyIP.ip != ip) {
				await this.apiKeyIpRepository.delete({ apiKey: apiKey });
				throw new HttpException("Login attempt from a new device detected!", HttpStatus.CONFLICT);
			}
		}
	}

	async checkUserRoles(roles: string[], tokenUser?: User, apiKeyRoles?: ApiKeyUser): Promise<void> {
		const userRoles = tokenUser ? tokenUser.roles : apiKeyRoles.roles;
		const intersectingRoles = _.intersection(roles, userRoles);
		if (!intersectingRoles.length) {
			console.error("No matching roles found");
			throw new HttpException("No matching roles found!", HttpStatus.FORBIDDEN);
		}
	}

	async updateCreds(
		token: string,
		value: number,
		route: string,
		ipAddress: string,
		body?: string,
		query?: string,
		params?: string,
	): Promise<boolean> {
		const { tokenUser } = await this.getUserInDB(token);
		if (!tokenUser?.teamId && value)
			throw new HttpException("User Not associated with a Team!", HttpStatus.UNAUTHORIZED);
		const team = await (async () => {
			try {
				return await this.teamRepository.findOne({ where: { id: tokenUser.teamId } });
			} catch (err) {
				console.error(err);
				throw new HttpException("Cannot Get Team!", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		if (!team && value) throw new HttpException("User associated Team Not Found!", HttpStatus.UNAUTHORIZED);
		const creditsLeft = Number(team?.credits) - value;
		if (value && !isNaN(creditsLeft) && creditsLeft <= 0) {
			console.log("No Team Credits Left!");
			throw new HttpException("No Team Credits Left!", HttpStatus.FORBIDDEN);
		}
		const userCredits = await (async () => {
			try {
				return await this.userCreditsRepository.findOne({
					where: {
						userId: tokenUser.id,
					},
				});
			} catch (err) {
				console.error(err);
				throw new HttpException("Cannot Get User Credits", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		if (!userCredits) this.userCreditsRepository.save({ userId: tokenUser.id, credits: 0 });
		console.log("Credits for User's Team before processing request - ", team?.credits);
		const geoDetails = body?.length ? await this.getGeographyDetails(body, route) : undefined;
		const userAPIUsageHistory: Partial<UserApiUsageHistory> = {
			userId: tokenUser.id,
			route,
			ipAddress,
			body,
			query,
			params,
			creditsUsed: value,
			Pincode: geoDetails?.Pincode,
			City: geoDetails?.City,
			Taluka: geoDetails?.Taluka,
			District: geoDetails?.District,
			State: geoDetails?.State,
			Country: geoDetails?.Country,
			layer: geoDetails?.layer,
			layerType: geoDetails?.layerType,
		};
		const queryRunner = this.connection.createQueryRunner();
		await queryRunner.connect();
		await queryRunner.startTransaction();
		try {
			if (process.env.ENABLE_DB_LOGS == "true") {
				await queryRunner.manager.save(
					UserApiUsageHistory,
					queryRunner.manager.create(UserApiUsageHistory, userAPIUsageHistory),
				);
			}
			if (value) {
				await queryRunner.manager.update(
					UserCredits,
					{ id: userCredits.id },
					{ creditsUsed: Number(userCredits.creditsUsed) + value },
				);
				await queryRunner.manager.update(Team, { id: team.id }, { credits: Number(team?.credits) - value });
			}
			await queryRunner.commitTransaction();
		} catch (error) {
			console.error(error);
			await queryRunner.rollbackTransaction();
			throw new HttpException("Cannot Update User Credits", HttpStatus.SERVICE_UNAVAILABLE);
		} finally {
			await queryRunner.release();
			return true;
		}
	}

	async apiKeyUpdateCreds(
		apiKey: string,
		value: number,
		route: string,
		ipAddress: string,
		body?: string,
		query?: string,
		params?: string,
	): Promise<boolean> {
		const { apiKeyUser } = await this.getUserInDB(null, apiKey);
		const team = await this.apiKeyOrganisationRepository.findOne({ where: { id: apiKeyUser.organisationId } });
		const creditsLeft = Number(team.credits) - value;
		if (!isNaN(creditsLeft) && creditsLeft <= 0) {
			console.log("No API Key Organisation Credits Left!");
			throw new HttpException("No API Key Organisation Credits Left!", HttpStatus.FORBIDDEN);
		}
		const userCredits = await (async () => {
			try {
				return await this.apiKeyUserCreditsRepository.findOne({
					where: {
						userId: apiKeyUser.id,
					},
				});
			} catch (err) {
				console.error(err);
				throw new HttpException("Cannot Get User Credits", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		if (!userCredits) await this.apiKeyUserCreditsRepository.save({ userId: apiKeyUser.id, credits: 0 });
		console.log("Credits for API Key User before processing request - ", userCredits?.creditsUsed);
		const { Pincode, City, Taluka, District, State, Country, layer, layerType } = await this.getGeographyDetails(
			body,
			route,
		);
		const userAPIUsageHistory: Partial<ApiKeyUserApiUsageHistory> = {
			userId: apiKeyUser.id,
			route,
			ipAddress,
			body,
			query,
			params,
			creditsUsed: value,
			Pincode,
			City,
			Taluka,
			District,
			State,
			Country,
			layer,
			layerType,
		};
		const queryRunner = this.connection.createQueryRunner();
		await queryRunner.connect();
		await queryRunner.startTransaction();
		try {
			if (process.env.ENABLE_DB_LOGS) {
				await queryRunner.manager.save(
					ApiKeyUserApiUsageHistory,
					queryRunner.manager.create(ApiKeyUserApiUsageHistory, userAPIUsageHistory),
				);
			}
			if (value) {
				await queryRunner.manager.update(
					ApiKeyUserCredits,
					{ userId: Number(apiKeyUser.id) },
					{ creditsUsed: Number(userCredits.creditsUsed) + value },
				);
				await queryRunner.manager.update(
					ApiKeyOrganisation,
					{ id: team.id },
					{ credits: Number(team?.credits) - value },
				);
			}
			await queryRunner.commitTransaction();
		} catch (error) {
			console.error(error);
			await queryRunner.rollbackTransaction();
			throw new HttpException("Cannot Update APIKEY User Credits", HttpStatus.SERVICE_UNAVAILABLE);
		} finally {
			await queryRunner.release();
			return true;
		}
	}

	async getGeographyDetails(
		body: string,
		route: string,
	): Promise<{
		Pincode: string;
		City: string;
		Taluka: string;
		District: string;
		State: string;
		Country: string;
		layer: string;
		layerType: string[];
	}> {
		const jsonLocation = JSON.parse(body);
		const shape = await (async () => {
			if (jsonLocation?.["location"]?.[0]) {
				try {
					return await this.shapeRepository.findOne({
						where: {
							level: Object.keys(jsonLocation?.["location"])?.[0],
							name: jsonLocation?.["location"]?.[Object.keys(jsonLocation["location"])[0]],
						},
					});
				} catch (err) {
					console.error(err);
				}
			} else return undefined;
		})();
		let layer = route.substring(route.indexOf("/") + 1, route.lastIndexOf("/"));
		if (layer == "acquisition" || layer == "scorecard") {
			layer = "poi";
		}
		const obj = {
			Pincode: shape?.Pincode ?? "",
			City: shape?.City ?? "",
			Taluka: shape?.Taluka ?? "",
			District: shape?.District ?? "",
			State: shape?.State ?? "",
			Country: shape?.Country ?? "",
			layer: layer ?? "",
			layerType: (jsonLocation?.["types"] || [jsonLocation?.["childLevel"]]) ?? [],
		};
		return obj;
	}

	async deductCredits(header, count: number): Promise<boolean> {
		if (header["apikey"] || header["api-key"] || header["apiKey"]) {
			const user = this._jwtService.decode(header["apikey"] || header["api-key"] || header["apiKey"]);
			const apiKeyUser = await this.apiKeyUsersRepository.findOne({ where: { id: Number(user["id"]) } });
			const apiKeyUserCredits = await this.apiKeyUserCreditsRepository.findOne({
				where: { id: Number(user["id"]) },
			});
			const apiKeyOrganisation = await this.apiKeyOrganisationRepository.findOne({
				where: { id: Number(apiKeyUser.organisationId) },
			});
			if (Number(apiKeyOrganisation.credits) >= count) {
				apiKeyUserCredits.creditsUsed = apiKeyUserCredits.creditsUsed + count;
				apiKeyOrganisation.credits = apiKeyOrganisation.credits - count;
				await this.apiKeyUserCreditsRepository.save(apiKeyUserCredits);
				await this.apiKeyOrganisationRepository.save(apiKeyOrganisation);
				return true;
			} else {
				return false;
			}
		} else {
			const user = this._jwtService.decode(header["token"]);
			const tokenUser = await this.usersRepository.findOne({ where: { id: Number(user["id"]) } });
			const userCredits = await this.userCreditsRepository.findOne({ where: { userId: Number(tokenUser.id) } });
			const team = await this.teamRepository.findOne({
				where: { id: Number(tokenUser.teamId) },
			});
			if (Number(team.credits) >= count) {
				userCredits.creditsUsed = userCredits.creditsUsed + count;
				team.credits = team.credits - count;
				await this.userCreditsRepository.save(userCredits);
				await this.teamRepository.save(team);
				return true;
			} else {
				return false;
			}
		}
	}
}

export enum Role {
	BASIC = "basic",
	MAPS_USER = "maps_user",
	INSIGHTS_USER = "insights_user",
	TEAM_ADMIN = "team_admin",
	CLIENT_ADMIN = "client_admin",
	ADMIN = "admin",
}

export const Roles = (...roles: string[]): CustomDecorator<string> => {
	console.log("roles are", roles);
	return SetMetadata("roles", roles);
};
