export class NotesQuery{
    userId?: string[];
	poiId?: string[];
	startDate?: Date;
	endDate?: Date;
}