import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import * as csv from "csv-parser";
import { Repository, In, getRepository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { Poi, PoiStatus } from "../poi/poi.entity";
import { GridService } from "../grid/grid.service";
import { PoiGrid } from "../relations/poi-grid/poi-grid.entity";
import * as fs from "fs";
import { Property } from "../property/property.entity";
import * as tf from "@turf/turf";
import * as geohash from "ngeohash";
import { Grid } from "../grid/grids.entity";
import { PropertyService } from "../property/property.service";
import { LatLng, Catchment, PoiQuery, PoiPaginationDto, PoiStatusUpdate, LatLong } from "../interfaces/poi";
import * as excel from "exceljs";
import { PropertyQuery } from "../interfaces/property";
import * as _ from "lodash";
import { POI } from "../interfaces/newPOI";
import { PoiDetail } from "../poi-details/poi-details.entity";
import { Poiexported } from "../poi/poisExported.entity";
import { Indexmaster } from "src/index-master/index-master.entity";
import * as stats from "stats-lite";
import { CsvUploadedFiles } from "./csv-upload.entity";
import { CsvParser } from "nest-csv-parser";
import { Response } from 'express';

@Injectable()
export class CsvProcessorService {
	[ x: string ]: any;
	constructor(
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(PoiGrid) private poiGridRepository: Repository<PoiGrid>,
		@InjectRepository(Property) private propertyRepository: Repository<Property>,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		@InjectRepository(PoiDetail) private poiDetailRepository: Repository<PoiDetail>,
		@InjectRepository(Poiexported) private poiexportedRepository: Repository<Poiexported>,
		@InjectRepository(Indexmaster) private indexMasterRepository: Repository<Indexmaster>,
		@InjectRepository(CsvUploadedFiles) private csvUploadedFilesRepository: Repository<CsvUploadedFiles>,
		private _gridService: GridService,
		private _propertyService: PropertyService,
		private readonly csvParser: CsvParser
	) {}


	async uploadCsv(userId: number, files: File[], body) {
		const response = [];
		await Promise.all(files.map(async file => {
			const alreadyExist = await this.csvUploadedFilesRepository.findOne({ where: {name: file["originalname"], userId: userId }});
			if(alreadyExist) {
				//const errResp = {"err":"File with similar filename :"+file["originalname"]+"already exist.Failed to upload this file"};
				fs.unlink(file["path"],(err) => {
					if(err) {
						console.log(err);
					}
					if(!err) {
						console.log("File with similar filename was found");
						console.log("File Deleted");
					}
				});
				//response.push(errResp);
				throw new HttpException({
					status: HttpStatus.FORBIDDEN,
					error: "File with similar filename : "+file["originalname"]+"  already exist.Failed to upload this file",
				}, HttpStatus.FORBIDDEN);
			} else {
				const tempObject = {"name": file["originalname"], "path": file["path"], "userId": userId, "description":body["description"]};
				const tempRes = await this.csvUploadedFilesRepository.save(tempObject);
				response.push(tempRes);
			}
		}));
		return response;
	}

	async getUploadCsv(userId: number, query):Promise<CsvUploadedFiles[] | CsvUploadedFiles> {
		if(query["name"]) {
			return await this.csvUploadedFilesRepository.findOne({ where: {userId: userId, name: query["name"] }});
		} else {
			return await this.csvUploadedFilesRepository.find({ where: {userId: userId }});
		}
	}

	async deleteUploadCsv(userId: number, query): Promise<void> {
		const uploadCsv = await this.csvUploadedFilesRepository.findOne({ where: {userId: userId, name: query["name"] }});
		const path = uploadCsv.path;
		fs.unlink(path,(err) => {
			console.log(err);
		});
		await this.csvUploadedFilesRepository.delete({userId: userId , name: query["name"]});
	}

	
	async readUploadCsv(userId: number, query, res: Response): Promise<unknown> {
		const file = await this.csvUploadedFilesRepository.findOne({ where: {userId: userId, name:query["name"] }});
		const path = file.path;
		let result = [];
		const response = [];/*
		const garbage = await Promise.resolve(fs.createReadStream( path )
			.pipe( csv() )
			.on( "data", ( data ) => {
				result.push( data );
				//console.log("data : ",data)
			} )
			.on( "end", () => {
				console.log( result );
				console.log( "CSV reading finished" );
				// resp = result;
			}));*/
		let readStream = fs.createReadStream( path ).pipe( csv() );
		readStream.on( "data", ( data ) => {
				result.push( data );
				//console.log("data : ",data)
			} );
		const resp = readStream.on( "end", async () => {
				console.log( result.length );
				console.log( "CSV reading finished" );
				const sampleObj = result[0];
				//console.log(result);
				//res.send(result);
				if(query["keys"]) {
					await Promise.all(Object.keys(query["keys"]).map(async eachKey => {
						const values = [];
						if(isNaN(sampleObj[eachKey])) {
							const tempRes = { "key": eachKey , "answer": "Not a Number" };
							response.push(tempRes);
						} else {
							console.log("Number Key found: ",eachKey);
							await Promise.all(result.map(eachObj => {
								values.push(Number(eachObj[eachKey]));
							}));
							if(query["keys"][eachKey] == "sum") {
								const sum = stats.sum(values);
								const tempRes = {"key":eachKey , "sum": sum};
								response.push(tempRes);
							}
							if(query["keys"][eachKey] == "mean") {
								const mean = stats.mean(values);
								const tempres = {"key": eachKey , "mean": mean};
								response.push(tempres);
							}
							if(query["keys"][eachKey] == "median") {
								const median = stats.median(values);
								const tempRes = {"key": eachKey , "mean": median};
								response.push(tempRes);
							}
							if(query["keys"][eachKey] == "mode") {
								let mode; 
								mode = stats.mode(values);
								if (typeof mode != "number"){
										mode = Array.from(mode);
								}
								console.log("Mode is :",mode);
								const tempRes = {"key":eachKey,"mode": mode};
								response.push(tempRes);
							}
						}
					}));
				}
				res.send(response);
			});
		return res;
		/*let variable;
		variable = "11651.16511";
		console.log(isNaN(variable));*/
		//await this.createReadStream(path , result);
		//const entities = await this.csvParser.parse(stream, Entity);
		//console.log(stream);
		//return res;
		//const sampleObj = result[0];/*
		
	}

	async createReadStream(path,response) {
		const result = [];
		fs.createReadStream( path )
			.pipe( csv() )
			.on( "data", ( data ) => {
				result.push( data );
				//console.log("data : ",data)
			} )
			.on( "end", () => {
				response = result;
				console.log( result );
				console.log( "CSV reading finished" );
			} );
		
		return response;
	}

	async calcUploadCsv(query,res) {
		const result = res;
		const response = [];
		const sampleObj = result[0];/*
		Promise.all(Object.keys(smapleObj).map(eachKey => {
			if(isNaN(smapleObj[eachKey])) {
				const tempResponse = {"key": eachKey , "value": "Cant be computed"};
			}
		}));*/
		if(query["keys"]) {
			Promise.all(Object.keys(query["keys"]).map(async eachKey => {
				const values = [];
				if(isNaN(sampleObj[eachKey])) {
					const tempRes = { "key": eachKey , "answer": "Not a Number" };
					response.push(tempRes);
				} else {
					await Promise.all(result.map(eachObj => {
						values.push(Number(eachObj[eachKey]));
					}));
					if(query["keys"][eachKey] == "sum") {
						const sum = stats.sum(values);
						const tempRes = {"key":eachKey , "sum": sum};
						response.push(tempRes);
					}
					if(query["keys"][eachKey] == "mean") {
						const mean = stats.mean(values);
						const tempres = {"key": eachKey , "mean": mean};
						response.push(tempres);
					}
					if(query["keys"][eachKey] == "median") {
						const median = stats.median(values);
						const tempRes = {"key": eachKey , "mean": median};
						response.push(tempRes);
					}
					if(query["keys"][eachKey] == "mode") {
						let mode; 
						mode = stats.mode(values);
						if (typeof mode != "number"){
								mode = Array.from(mode);
						}
						console.log(mode);
						const tempRes = {"key":eachKey,"mode": mode};
						response.push(tempRes);
					}
				}
			}))
		}
		res.send(response);
	}
}
