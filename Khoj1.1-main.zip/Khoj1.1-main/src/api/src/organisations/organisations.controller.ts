import { Body, Controller, Get, Post, Headers, HttpException, HttpStatus, Query } from "@nestjs/common";
import { ApiBody, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Org, UpdateCreditsBody, UpdateCreditsRequest } from "src/interfaces/organisation";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { Organisation } from "./organisations.entity";
import { OrganisationsService, OrgWithCreditsSpent } from "./organisations.service";
import { Header } from "../interfaces/header";
import { User } from "../users/users.entity";
import { RolesGuardService } from "../helpers/roles-guard/roles-guard.service";
import { RealIP } from "nestjs-real-ip";
import { TeamService } from "src/team/team.service";

@Controller("organisations")
export class OrganisationsController {
	constructor(
		private _OrganisationsService: OrganisationsService,
		private teamService: TeamService,
		private _rolesGuardService: RolesGuardService,
	) {}

	@Get("getorganisationagainstuser")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Get all Organisational Users for a User using the user-token" })
	async getOrg(@Headers() headers: Header): Promise<Organisation> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		return await this._OrganisationsService.findOrgAgainstUser(user.email, user.id);
	}

	@Roles("basic")
	@Get("getallorganisations")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Get all Organisations" })
	async getAllOrgs(@Headers() headers): Promise<OrgWithCreditsSpent[]> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		return await this._OrganisationsService.getOrgs(user["id"] as number, user["roles"] as string[]);
	}

	@Roles("admin")
	@Post("addorganisations")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Add Multiple Organisations" })
	async addOrgs(@Body() body: Org[]): Promise<Organisation[]> {
		return await this._OrganisationsService.addOrgs(body);
	}

	@Roles("admin")
	@Post("updateorganisation")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Update an Organisation" })
	async updateOrg(@Body() body: Organisation): Promise<Organisation> {
		return await this._OrganisationsService.updateOrg(body);
	}

	@Roles("admin")
	@Post("deleteorganisation")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Delete an Organisation" })
	async deleteOrg(@Body() body: { id: number }) {
		return await this._OrganisationsService.deleteOrg(body.id);
	}

	@Roles("admin")
	@Post("updateuser")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: User })
	@ApiResponse({ description: "Update an User" })
	async updateUser(@Body() body: User): Promise<User> {
		return await this._OrganisationsService.updateUser(body);
	}

	@Roles("admin")
	@Post("addusers")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: User })
	@ApiResponse({ description: "Add Users to Organisations" })
	async addUsers(@Body() body: User[]): Promise<unknown> {
		return await this._OrganisationsService.addUsers(body);
	}

	@Roles("admin")
	@Post("deleteuser")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Delete User" })
	async deleteUser(@Body() body: { id: number }): Promise<unknown> {
		return await this._OrganisationsService.deleteUser(body.id);
	}

	@Post("getusers")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Get Users Against Organisations" })
	async getUsersAginstOrganisation(@Body() body): Promise<User[]> {
		try {
			return await this._OrganisationsService.getUsersAginstOrganisation(body);
		} catch (error) {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: "BAD REQUEST",
				},
				HttpStatus.BAD_REQUEST,
			);
		}
	}

	@Roles("basic")
	@Get("getallusers")
	@ApiHeader({ name: "Header" })
	@ApiBody({ type: Org })
	@ApiResponse({ description: "Get All Users" })
	async getAllUsers(@Query("allstatus") allstatus: string, @Headers() headers): Promise<User[]> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		try {
			return allstatus === "true"
				? await this._OrganisationsService.getAllUsers(user.id, user.roles, true)
				: await this._OrganisationsService.getAllUsers(user.id, user.roles);
		} catch (error) {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: "BAD REQUEST",
				},
				HttpStatus.BAD_REQUEST,
			);
		}
	}

	@Roles("admin")
	@Post("update-credits")
	async updateCredits(@Body() body: UpdateCreditsBody, @Headers() headers) {
		return await this._OrganisationsService.updateCredits(body, headers);
	}

	@Roles("externalapi")
	@Post("updatecreds")
	async updateCreds(
		@Headers() header: Header,
		@Body() body: UpdateCreditsRequest,
		@RealIP() ip: string,
	): Promise<boolean> {
		if (body.user_token) {
			return await this._rolesGuardService.updateCreds(
				body.user_token,
				body.credits,
				"/organisations/updatecreds",
				ip,
				JSON.stringify(body),
			);
		}
		if (body.user_apikey) {
			return await this._rolesGuardService.apiKeyUpdateCreds(
				body.user_apikey,
				body.credits,
				"/organisations/updatecreds",
				ip,
				JSON.stringify(body),
			);
		}
	}
}
