import { Controller, Get, Headers, Inject } from "@nestjs/common";
import { CACHE_MANAGER } from "@nestjs/cache-manager";
import { HttpService } from "@nestjs/axios";
import { Cache } from "cache-manager";
import { ApiTags } from "@nestjs/swagger";
import { Role, Roles } from "../roles-guard/roles-guard.service";
import { CacheService } from "./cache.service";

@ApiTags("cache")
@Controller("cache")
export class CacheController {

    constructor(
        private httpService: HttpService,
        @Inject(CACHE_MANAGER) private cacheManager: Cache,
        private _cacheService: CacheService
    ) {}

    @Roles(Role.ADMIN)
    @Get("delete")
    async deleteCache() {
        try {
			await this.cacheManager.reset();
			return { response: "Deleted!" };
		}
		catch(err) {
			throw err;
		}
    }

}