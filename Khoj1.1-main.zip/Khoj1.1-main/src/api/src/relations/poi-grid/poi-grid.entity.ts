import { Entity, PrimaryColumn, Column, Index } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

@Entity()
export class PoiGrid {
	@ApiProperty()
	@PrimaryColumn()
	poiId: number;

	@ApiProperty()
	@Index("poi_grid_grid_id_index")
	@Column()
	gridId: number;
}
