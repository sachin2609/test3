import { Test, TestingModule } from '@nestjs/testing';
import { ShapeDetailsController } from './shape-details.controller';

describe('ShapeDetailsController', () => {
  let controller: ShapeDetailsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ShapeDetailsController],
    }).compile();

    controller = module.get<ShapeDetailsController>(ShapeDetailsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
