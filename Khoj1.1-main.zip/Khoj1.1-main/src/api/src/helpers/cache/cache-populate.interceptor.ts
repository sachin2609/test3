import { CallHandler, ExecutionContext, Injectable, NestInterceptor, Inject } from '@nestjs/common';
import { Observable } from 'rxjs';
import { Reflector } from '@nestjs/core';
import { Cache } from "cache-manager";
import { CACHE_MANAGER } from "@nestjs/cache-manager";
import { tap } from "rxjs/operators";
import { Request } from 'express-serve-static-core';


@Injectable()
export class CachePopulateInterceptor implements NestInterceptor {
    constructor(
        @Inject(CACHE_MANAGER) private cacheManager: Cache,
        private reflector: Reflector
    ){}

    async intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>> {
        const ctx = context.switchToHttp();
        const request: Request = ctx.getRequest();
        let key = this.reflector.get("cache-key",context.getHandler());
        if(key == undefined) {
            key = request.url;
        }
        let cacheTime = this.reflector.get("cache-time", context.getHandler());
        if (!cacheTime) cacheTime = 60000000;
        if(process.env.ENABLE_DATA_CACHING == "false") {
            const notAllowedKeys = ["grid-search","poi-filter","shape-level-search","poi-shape-filter"];
            if(notAllowedKeys.includes(key)) {
                return next.handle();
            }
        }
        if(request.body != undefined) {
            const body = JSON.stringify(request.body);
            key = key + "-body-" + body;
        }
        if(request.query != undefined) {
            const query = JSON.stringify(request.query);
            key = key + "-query-" + query;
        }
        console.log("KEY:",key);
        const cached: string = await this.cacheManager.get(key);
        console.log("From Query Engine");
        return next.handle().pipe(
            tap(async res => {
                const response = JSON.stringify(res);
                if(cached) {
                    await this.cacheManager.del(key);
                    console.log("Previous Cache found....Deleted.");
                }
                await this.cacheManager.set(key,response,{ ttl: Number(cacheTime) });
            })
        );
    }
}
