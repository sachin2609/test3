import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { Organisation } from "src/organisations/organisations.entity";
import { Shape } from "src/shape/shape.entity";
import { UpdateCreditsLogs } from "src/update-credits-logs/update-credits-logs.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { User } from "src/users/users.entity";
import { ApiKeyOrganisationsController } from "./api-key-organisations.controller";
import { ApiKeyOrganisation } from "./api-key-organisations.entity";
import { ApiKeyOrganisationsService } from "./api-key-organisations.service";
import { Team } from "src/team/team.entity";
import { TeamService } from "src/team/team.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";

@Module({
	imports: [
		TypeOrmModule.forFeature([
			ApiKeyOrganisation,
			ApiKeyUser,
			ApiKeyUserCredits,
			ApiKeyUserApiUsageHistory,
			ApiKeyIp,
			User,
			Team,
			UserIdIp,
			UserCredits,
			UserApiUsageHistory,
			Organisation,
			Shape,
			UpdateCreditsLogs,
		]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
	],
	controllers: [ApiKeyOrganisationsController],
	providers: [ApiKeyOrganisationsService, RolesGuardService, TeamService, KeyCloakService, CentralServerService],
})
export class ApiKeyOrganisationsModule {}
