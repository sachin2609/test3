import { Body, Controller, Headers, HttpStatus, Post, Req } from "@nestjs/common";
import { Role, Roles } from "../helpers/roles-guard/roles-guard.service";
import { Note } from "./notes.entity";
import { NoteService } from "./notes.service";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { NotesQuery } from "src/interfaces/notes";
import { TeamService } from "src/team/team.service";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";
import { Request } from "express";
import { RealIP } from "nestjs-real-ip";

@Controller("note")
export class NoteController {
	constructor(
		private readonly _noteService: NoteService,
		private teamService: TeamService,
		private _syslogService: SyslogService,
	) {}

	async getUser(headers: any): Promise<{ tokenUser: Partial<User>; apiKeyUser: Partial<ApiKeyUser> }> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		const tokenUser = user["type"] === "token" ? (user as User) : undefined;
		const apiKeyUser = user["type"] === "apikey" ? (user as ApiKeyUser) : undefined;
		if (!tokenUser && !apiKeyUser) {
			throw new Error("Invalid token");
		}
		return { tokenUser, apiKeyUser };
	}

	@Roles(Role.BASIC)
	@Post("create")
	async addReminder(@Headers() headers, @Body() body: Partial<Note>, @Req() req: Request, @RealIP() ip) {
		try {
			const { tokenUser, apiKeyUser } = await this.getUser(headers);
			if (tokenUser?.id) {
				body.tokenUserId = tokenUser?.id;
			}

			if (apiKeyUser?.id) {
				body.apiKeyUserId = apiKeyUser?.id;
			}
			const res = await this._noteService.createNote(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("fetch")
	async fetchNotes(@Headers() headers, @Body() body: Partial<NotesQuery>, @Req() req: Request, @RealIP() ip) {
		try {
			if (!body.userId || body?.userId?.length <= 0) {
				const { tokenUser, apiKeyUser } = await this.getUser(headers);
				if (tokenUser?.id) {
					body.userId = [JSON.stringify(tokenUser?.id)];
				}

				if (apiKeyUser?.id) {
					body.userId = [JSON.stringify(apiKeyUser?.id)];
				}
			}

			const res = await this._noteService.fetchNote(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("delete")
	async deleteReminder(@Body() body: Partial<Note>, @Req() req: Request, @RealIP() ip) {
		try {
			const res = await this._noteService.deleteNote(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}
}
