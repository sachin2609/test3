import { Body, Controller, Get, Headers, HttpStatus, Param, Post, Req, UsePipes, ValidationPipe } from "@nestjs/common";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { AddLeadDto } from "src/interfaces/status-updates";
import { LeadsService } from "./leads.service";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { LeadQuery, TimeLineQuery } from "src/interfaces/leads";
import { TeamService } from "src/team/team.service";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";
import { RealIP } from "nestjs-real-ip";
import { Request } from "express";

@Controller("leads")
export class LeadController {
	constructor(
		private readonly _leadsService: LeadsService,
		private teamService: TeamService,
		private _syslogService: SyslogService,
	) {}

	async getUser(headers: any): Promise<{ tokenUser: Partial<User>; apiKeyUser: Partial<ApiKeyUser> }> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		const tokenUser = user["type"] === "token" ? (user as User) : undefined;
		const apiKeyUser = user["type"] === "apikey" ? (user as ApiKeyUser) : undefined;
		if (!tokenUser && !apiKeyUser) {
			throw new Error("Invalid token");
		}
		return { tokenUser, apiKeyUser };
	}

	@Roles(Role.BASIC)
	@Post("update-status")
	@UsePipes(new ValidationPipe())
	async addStatusUpdate(@Headers() headers, @Body() body: AddLeadDto, @Req() req: Request, @RealIP() ip) {
		try {
			const { tokenUser, apiKeyUser } = await this.getUser(headers);
			await this._leadsService.addLead(body, tokenUser?.id, apiKeyUser?.id);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return { message: "Lead Status updated successfully!" };
		} catch (error) {
			console.log(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("fetch")
	async fetchMerchants(@Req() req: Request, @Headers() headers, @Body() body: LeadQuery, @RealIP() ip) {
		try {
			const { tokenUser, apiKeyUser } = await this.getUser(headers);
			const leads = await this._leadsService.fetchLeads(body, tokenUser?.id, apiKeyUser?.id);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return {
				count: leads.length,
				data: leads,
			};
		} catch (error) {
			console.error(error.status);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			return { count: 0, data: [] };
		}
	}

	@Roles(Role.BASIC)
	@Get("count")
	async fetchCounts(@Headers() headers, @Req() req: Request, @RealIP() ip) {
		try {
			const { tokenUser, apiKeyUser } = await this.getUser(headers);
			const res = await this._leadsService.getLeadCounts(tokenUser?.id, apiKeyUser?.id);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Get("history/:id")
	async getHistory(@Param() param: { id: number }, @Req() req: Request, @RealIP() ip) {
		try {
			const statusUpdates = await this._leadsService.getLeadStatusHistory(param.id);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return {
				count: statusUpdates?.length,
				data: statusUpdates,
			};
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("timeline")
	async getTimeline(@Headers() headers, @Body() body: TimeLineQuery, @Req() req: Request, @RealIP() ip) {
		try {
			const { tokenUser, apiKeyUser } = await this.getUser(headers);
			body.userId = apiKeyUser?.id ?? tokenUser?.id;
			const res = await this._leadsService.getTimelinewithPoi(body, tokenUser as User, apiKeyUser as User);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}
}
