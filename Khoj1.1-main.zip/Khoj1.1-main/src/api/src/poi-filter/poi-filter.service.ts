import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { POIFilter, POIFilterDTO, POIFilterPayload, POIFilterUserTeam } from "./poi-filter.entity";
import { DataSource, In, Repository } from "typeorm";
import { User } from "src/users/users.entity";
import { uniq, chain } from "lodash";
import { TeamService } from "src/team/team.service";

@Injectable()
export class PoiFilterService {
	constructor(
		@InjectRepository(POIFilter) private POIFilterRepository: Repository<POIFilter>,
		@InjectRepository(POIFilterUserTeam) private POIFilterUserTeamRepository: Repository<POIFilterUserTeam>,
		private teamService: TeamService,
		private connection: DataSource,
	) {}

	async getPOIFilters(
		IDs?: number[],
		createdByIDs?: number[],
		userIDs?: number[],
		teamIDs?: number[],
	): Promise<POIFilter[]> {
		const POIFilters: POIFilter[] = await (async () => {
			try {
				const userTeamPOIFilters =
					userIDs?.length || teamIDs?.length
						? await this.POIFilterUserTeamRepository.find({
								where: {
									UserId: userIDs?.length ? In(userIDs) : undefined,
									TeamId: teamIDs?.length ? In(teamIDs) : undefined,
								},
						  })
						: [];
				const allIDs = uniq([...(userTeamPOIFilters?.map((x) => x.POIFilterId) ?? []), ...(IDs ?? [])]);
				return await this.POIFilterRepository.find({
					where: {
						createdBy: createdByIDs?.length ? In(createdByIDs) : undefined,
						id: allIDs?.length ? In(allIDs) : undefined,
					},
				});
			} catch (err) {
				console.error(err);
				throw new HttpException("Error getting POI Filters", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		return POIFilters;
	}

	async getPOIFilterUserTeams(
		POIFilterIDs?: number[],
		userId?: number[],
		teamId?: number[],
	): Promise<POIFilterUserTeam[]> {
		const POIFilterUserTeams: POIFilterUserTeam[] = await (async () => {
			try {
				return await this.POIFilterUserTeamRepository.find({
					where: {
						POIFilterId: POIFilterIDs?.length ? In(POIFilterIDs) : undefined,
						TeamId: teamId?.length ? In(teamId) : undefined,
						UserId: userId?.length ? In(userId) : undefined,
					},
				});
			} catch (err) {
				console.error(err);
				throw new HttpException("Error getting POI Filter User Teams", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		return POIFilterUserTeams;
	}

	async createPOIFilter(poiFilter: Partial<POIFilterPayload>, createdByUser: Partial<User>) {
		const { userIds, teamIds, name, description, value, isActivated } = poiFilter;
		const filter = { name, description, value, isActivated };

		if (isActivated) {
			if (await this.activePassCheck(userIds, teamIds, null))
				throw new HttpException(
					"Active Poi-Filter for the given user ID and Team ID already exists",
					HttpStatus.BAD_REQUEST,
				);
		}
		Object.assign(filter, { createdBy: createdByUser.id });
		const queryRunner = this.connection.createQueryRunner();
		await queryRunner.connect();
		await queryRunner.startTransaction();
		try {
			const poiFilterQuery = queryRunner.manager.create(POIFilter, filter);
			const savedFilter = await queryRunner.manager.save<Partial<POIFilter>>(poiFilterQuery);
			if (userIds?.length || teamIds?.length) {
				const POIFilterUsers =
					userIds?.map((UserId) => {
						return { POIFilterId: savedFilter.id, UserId };
					}) ?? [];
				const POIFilterTeams =
					teamIds?.map((TeamId) => {
						return { POIFilterId: savedFilter.id, TeamId };
					}) ?? [];
				const userQueries = POIFilterUsers?.map((x) => queryRunner.manager.create(POIFilterUserTeam, x)) ?? [];
				const teamQueries = POIFilterTeams?.map((x) => queryRunner.manager.create(POIFilterUserTeam, x)) ?? [];
				await queryRunner.manager.save([...userQueries, ...teamQueries]);
				await queryRunner.commitTransaction();
			}
		} catch (err) {
			await queryRunner.rollbackTransaction();
			console.error(err);
			throw new HttpException("Error creating POI Filter", HttpStatus.SERVICE_UNAVAILABLE);
		} finally {
			await queryRunner.release();
		}
	}

	async activePassCheck(userIds: number[], teamIds: number[], poiFilterId?: number): Promise<boolean> {
		if (!userIds?.length && !teamIds?.length) return false;
		const POIFilterUserTeams: POIFilterUserTeam[] = await (async () => {
			try {
				return await this.POIFilterUserTeamRepository.find({
					where: [
						{
							UserId: userIds?.length ? In(userIds) : undefined,
						},
						{
							TeamId: teamIds?.length ? In(teamIds) : undefined,
						},
					],
				});
			} catch (err) {
				console.error(err);
				throw new HttpException("Error getting POI Filter User Teams", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		const poiFiltersIds = POIFilterUserTeams.map((poiFilter) => poiFilter.POIFilterId).filter(
			(poiFilter) => poiFilterId && poiFilter !== poiFilterId,
		);
		if (!poiFiltersIds.length) return false;
		const POIFiltersIsActive: POIFilter[] = await (async () => {
			try {
				return await this.POIFilterRepository.find({
					where: {
						isActivated: true,
						id: In(poiFiltersIds),
					},
				});
			} catch (err) {
				console.error(err);
			}
		})();
		return POIFiltersIsActive?.length > 0;
	}

	async updatePOIFilter(POIFilter: Partial<POIFilterPayload>, updatedByUser: Partial<User>) {
		const { userIds, teamIds, name, description, value, isActivated, id } = POIFilter;
		const filter = { name, description, value, isActivated, id };
		if (!filter.id) {
			throw new HttpException("No POI Filter ID provided", HttpStatus.BAD_REQUEST);
		}
		if (!userIds?.length && !teamIds?.length && Object.keys(filter).length <= 1) {
			throw new HttpException("No updates provided", HttpStatus.BAD_REQUEST);
		}
		const existingPOIFilter = await this.getPOIFilters([filter.id]);
		if (!existingPOIFilter?.length) {
			throw new HttpException("POI Filter does not exist", HttpStatus.BAD_REQUEST);
		}
		if (isActivated) {
			if (await this.activePassCheck(userIds, teamIds, id)) {
				throw new HttpException(
					"Active Poi-Filter for the given User ID and Team ID already exists",
					HttpStatus.BAD_REQUEST,
				);
			}
		}
		const existingPOIFilterUsersTeams = await this.getPOIFilterUserTeams([filter.id]);
		const existingPOIFilterUsers = existingPOIFilterUsersTeams.filter((x) => x.UserId).map((x) => x.UserId);
		const existingPOIFilterTeams = existingPOIFilterUsersTeams.filter((x) => x.TeamId).map((x) => x.TeamId);
		if (Object.keys(filter).length > 1) {
			try {
				Object.assign(filter, { updatedBy: updatedByUser.id });
				this.POIFilterRepository.save(filter);
			} catch (err) {
				console.error(err);
				throw new HttpException("Error updating POI Filter", HttpStatus.SERVICE_UNAVAILABLE);
			}
		}
		if (userIds && existingPOIFilterUsers.sort() !== userIds.sort()) {
			try {
				this.POIFilterUserTeamRepository.delete({
					POIFilterId: filter.id,
					UserId: In(existingPOIFilterUsers),
				}).then(() => {
					if (userIds.length) {
						const POIFilterUsers = userIds.map((UserId) => {
							return { POIFilterId: filter.id, UserId };
						});
						this.POIFilterUserTeamRepository.save(POIFilterUsers);
					}
				});
			} catch (err) {
				console.error(err);
				throw new HttpException("Error updating Users for POI Filter", HttpStatus.SERVICE_UNAVAILABLE);
			}
		}
		if (teamIds && existingPOIFilterTeams.sort() !== teamIds.sort()) {
			try {
				this.POIFilterUserTeamRepository.delete({
					POIFilterId: filter.id,
					TeamId: In(existingPOIFilterTeams),
				}).then(() => {
					if (teamIds.length) {
						const POIFilterTeams = teamIds.map((TeamId) => {
							return { POIFilterId: filter.id, TeamId };
						});
						this.POIFilterUserTeamRepository.save(POIFilterTeams);
					}
				});
			} catch (err) {
				console.error(err);
				throw new HttpException("Error updating Teams for POI Filter", HttpStatus.SERVICE_UNAVAILABLE);
			}
		}
	}

	async deletePOIFilter(id: number) {
		if (!id) {
			throw new HttpException("No POI Filter ID provided", HttpStatus.BAD_REQUEST);
		}
		const existingPOIFilter = await this.getPOIFilters([id]);
		if (!existingPOIFilter?.length) {
			throw new HttpException("POI Filter does not exist", HttpStatus.BAD_REQUEST);
		}
		const userTeams = await (async () => {
			try {
				return await this.POIFilterUserTeamRepository.find({ where: { POIFilterId: id } });
			} catch (err) {
				console.error(err);
				throw new HttpException(
					"Error finding Users / Teams associated with POI Filter",
					HttpStatus.SERVICE_UNAVAILABLE,
				);
			}
		})();
		if (userTeams?.length) {
			const userIDs = userTeams.filter((x) => x.UserId).map((x) => x.UserId);
			const teamIDs = userTeams.filter((x) => !x.UserId).map((x) => x.TeamId);
			throw new HttpException(
				`Cannot delete a POI Filter is in use. ${userIDs?.length ? "Users - " + userIDs.join(", ") : ""}
				${teamIDs?.length ? " & Teams - " + userIDs.join(", ") : ""}`,
				HttpStatus.BAD_REQUEST,
			);
		}
		try {
			await this.POIFilterRepository.delete(id);
		} catch (err) {
			console.error(err);
			throw new HttpException("Error deleting POI Filter", HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	async POIFilterToPOIFilterDTO(POIFilters: POIFilter[]): Promise<POIFilterDTO[]> {
		if (!POIFilters?.length) return [];
		const allUserTeams = await this.getPOIFilterUserTeams(POIFilters.map((x) => x.id));
		let allUserIDs = [];
		let allTeamIDs = [];
		allUserTeams.forEach((x) => {
			if (x.UserId) allUserIDs.push(x.UserId);
			if (x.TeamId) allTeamIDs.push(x.TeamId);
		});
		allUserIDs = chain([...allUserIDs, ...POIFilters.map((x) => x.createdBy)])
			.sortBy()
			.uniq()
			.value();
		allTeamIDs = chain(allTeamIDs).sortBy().uniq().value();
		const allUsers = await this.teamService.getUsers(allUserIDs);
		const allTeams = await this.teamService.getTeams(allTeamIDs);
		return POIFilters.map((POIFilter) => {
			const createdByUser = allUsers
				.filter((x) => x.id === POIFilter.createdBy)
				.map((x) => {
					const { id, firstName, lastName } = x;
					return { id, firstName, lastName };
				})[0];
			const assignedUserIDs: number[] = [];
			const assignedTeamIDs: number[] = [];
			allUserTeams.forEach((x) => {
				if (x.POIFilterId === POIFilter.id) {
					if (x.UserId) assignedUserIDs.push(x.UserId);
					if (x.TeamId) assignedTeamIDs.push(x.TeamId);
				}
			});
			const assignedUsers = allUsers
				.filter((x) => assignedUserIDs.includes(x.id))
				.map((x) => {
					const { id, firstName, lastName } = x;
					return { id, firstName, lastName };
				});
			const assignedTeams = allTeams
				.filter((x) => assignedTeamIDs.includes(x.id))
				.map((x) => {
					const { id, name } = x;
					return { id, name };
				});
			const { createdBy, updatedBy, createdAt, updatedAt, ...tempPOIFilter } = POIFilter;
			const POIFilterDTO: POIFilterDTO = {
				...tempPOIFilter,
				createdBy: createdByUser,
				assignedUsers,
				assignedTeams,
			};
			return POIFilterDTO;
		});
	}
}
