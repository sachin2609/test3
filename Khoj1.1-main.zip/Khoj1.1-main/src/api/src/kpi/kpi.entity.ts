import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from "typeorm";

@Entity()
export class Kpi {
	@PrimaryGeneratedColumn()
	id: number;

	@Column({ nullable: true })
	poiType?: string;

	@Column()
	action: string;

	@Column({ nullable: true, type: "integer" })
	tokenUserId?: number;

	@Column({ nullable: true, type: "integer" })
	apiKeyUserId?: number;

	@Column({ nullable: true })
	faId?: string;

	@Column({ type: "integer", nullable: true })
	poiId?: number;

	@Column({ type: "decimal" })
	latitude: number;

	@Column({ type: "decimal" })
	longitude: number;

	@CreateDateColumn()
	createdAt?: Date;
}
