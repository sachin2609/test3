import { Body, Controller, Headers, Post } from "@nestjs/common";
import { ApiHeader, ApiResponse } from "@nestjs/swagger";
import { PoiPaginationDto } from "src/interfaces/poi";
import { Poi } from "src/poi/poi.entity";
import { PoiService } from "src/poi/poi.service";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { MerchantService } from "src/merchant/merchant.service";
import { RolesGuardService } from "../helpers/roles-guard/roles-guard.service";
import { Header } from "../interfaces/header";
import { MultilevelShapesQuery } from "src/interfaces/shapes";
import { ShapeService } from "src/shape/shape.service";
import { RealIP } from "nestjs-real-ip";
import { PlacesQuery } from "src/interfaces/places";

@Controller("scorecard")
export class ScorecardController {
	constructor(
		private _merchantService: MerchantService,
		private _poiService: PoiService,
		private _rolesGuardService: RolesGuardService,
		private _shapeService: ShapeService,
	) {}

	@Roles("merchant_scorecard")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("merchant-v1")
	async scorecard(
		@Body() body,
		@Headers() header: Header,
		@RealIP() ip: string,
	): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			const resp = await this._merchantService.scorecard(body);
			//await this._rolesGuardService.updateCreds(header.token, resp['count'] - 1);
			//let credsResp;
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					resp["count"] - 1,
					"/scorecard/merchant-v1",
					ip,
					JSON.stringify(body),
				);
			} else {
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp["count"] - 1,
					"/scorecard/merchant-v1",
					ip,
					JSON.stringify(body),
				);
			}
			return resp;
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("merchant_scorecard")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("merchant-v2")
	async scorecardNewNew(@Body() body): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			return await this._merchantService.scorecardNewNew(body);
		} catch (error) {
			if (error.status == 400) {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("merchant_scorecard")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("merchant-v3")
	async merchantScorecard(@Body() body, @Headers() header): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			return await this._merchantService.merchantScorecard(body, header["token"]);
		} catch (error) {
			if (error.status == 400 || error.status == 204 || error.status == 424) {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("merchant_scorecard")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("personal")
	async personalScorecard(@Body() body, @Headers() header): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			return await this._merchantService.personalScorecard(body, header["token"]);
		} catch (error) {
			if (error.status == 400 || error.status == 204 || error.status == 424) {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("merchant_acquisition")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("location")
	async multilevelSearchNew(
		@Body() body: MultilevelShapesQuery,
		@Headers() header: Header,
		@RealIP() ip: string,
	): Promise<unknown> {
		try {
			const resp = await this._shapeService.multilevelShapesScorecard(body);
			//await this._rolesGuardService.updateCreds(header.token, resp['count'] - 1);
			let credsResp;
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					resp["count"] - 1,
					"/scorecard/location",
					ip,
					JSON.stringify(body),
				);
			} else {
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp["count"] - 1,
					"/scorecard/location",
					ip,
					JSON.stringify(body),
				);
			}
			await Promise.all(
				resp["data"].map((eachObj) => {
					delete eachObj["index"];
				}),
			);
			return resp;
		} catch (error) {
			console.log(error);
			return {
				count: 0,
				data: [],
			};
		}
	}

	@Roles("basic")
	@Post("places")
	async places(@Body() body: PlacesQuery, @Headers() header, @RealIP() ip: string) {
		try {
			const resp = await this._merchantService.places(body, header["token"]);
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					resp["count"] - 1,
					"/custom/places",
					ip,
					JSON.stringify(body),
				);
			} else {
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp["count"] - 1,
					"/custom/places",
					ip,
					JSON.stringify(body),
				);
			}
			return resp;
		} catch (error) {
			if (error.status == 400 || error.status == 204 || error.status == 424) {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("basic")
	@Post("rent")
	async rent(@Body() body: PlacesQuery, @Headers() header, @RealIP() ip: string) {
		try {
			const resp = await this._merchantService.rent(body, header["token"]);
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					resp["financial_institutions"].count - 1,
					"/custom/rent",
					ip,
					JSON.stringify(body),
				);
			} else {
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp["financial_institutions"].count - 1,
					"/custom/rent",
					ip,
					JSON.stringify(body),
				);
			}
			return resp;
		} catch (error) {
			if (error.status == 400 || error.status == 204 || error.status == 424) {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("merchant_acquisition")
	@ApiHeader({ name: "Token" })
	@Post("pincode")
	async pincodeScorecard(@Body() body, @Headers() header, @RealIP() ip: string) {
		try {
			const resp = await this._merchantService.pincodeScorecard(body);
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					1,
					"/scorecard/location",
					ip,
					JSON.stringify(body),
				);
			} else {
				console.log("body is ", body);
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					1,
					"/scorecard/location",
					ip,
					JSON.stringify(body),
				);
			}
			return resp;
		} catch (err) {
			console.log(err);
			return {
				count: 0,
				data: [],
			};
		}
	}

	@Roles("merchant_scorecard")
	@ApiHeader({ name: "Token" })
	@Post("address")
	async addressScorecard(@Body() body, @Headers() header, @RealIP() ip: string) {
		const resp = await this._merchantService.addressAndLatLngScorecard(body);
		if (header.token) {
			await this._rolesGuardService.updateCreds(header.token, 1, "/scorecard/address", ip, JSON.stringify(body));
		} else {
			await this._rolesGuardService.apiKeyUpdateCreds(
				header["apikey"],
				1,
				"/scorecard/address",
				ip,
				JSON.stringify(body),
			);
		}
		return resp;
	}

	@Roles("merchant_scorecard")
	@ApiHeader({ name: "Token" })
	@Post("coordinate")
	async latLngScorecard(@Body() body, @Headers() header, @RealIP() ip: string) {
		const resp = await this._merchantService.addressAndLatLngScorecard(body);
		if (resp) {
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					1,
					"/scorecard/coordinate",
					ip,
					JSON.stringify(body),
				);
			} else {
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					1,
					"/scorecard/coordinate",
					ip,
					JSON.stringify(body),
				);
			}
		}
		return resp;
	}

	@Roles("merchant_scorecard")
	@ApiHeader({ name: "Token" })
	@Post("geohash7")
	async geoHash7(@Body() body, @Headers() header, @RealIP() ip: string) {
		const resp = await this._merchantService.geoHash7Scorecard(body);
		if (resp) {
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					1,
					"/scorecard/geohash7",
					ip,
					JSON.stringify(body),
				);
			} else {
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					1,
					"/scorecard/geohash7",
					ip,
					JSON.stringify(body),
				);
			}
		}
		return resp;
	}

	@Roles("merchant_scorecard")
	@ApiHeader({ name: "Token" })
	@Post("multi-geohash7")
	async multiGeoHash7(@Body() body, @Headers() header, @RealIP() ip: string) {
		const resp = await this._merchantService.multiGeoHash7Scorecard(body);
		if (resp) {
			if (header.token) {
				await this._rolesGuardService.updateCreds(
					header.token,
					resp.count_to_decuct,
					"/scorecard/multi-geohash7",
					ip,
					JSON.stringify(body),
				);
			} else {
				await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp.count_to_decuct,
					"/scorecard/multi-geohash7",
					ip,
					JSON.stringify(body),
				);
			}
		}
		return resp.data;
	}
}
