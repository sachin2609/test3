import { Module } from "@nestjs/common";
import { PromptLogController } from "./prompt-log.controller";
import { PromptLogService } from "./prompt-log.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { PromptLog } from "./prompt-log.entity";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { JwtModule } from "@nestjs/jwt";
import { Poi } from "src/poi/poi.entity";
import { TeamService } from "src/team/team.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
import { Team } from "src/team/team.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";

@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		TypeOrmModule.forFeature([PromptLog, User, Team, ApiKeyUser, Poi, UserCredits]),
	],
	controllers: [PromptLogController],
	providers: [PromptLogService, TeamService, KeyCloakService, CentralServerService, SyslogService],
})
export class PromptLogModule {}
