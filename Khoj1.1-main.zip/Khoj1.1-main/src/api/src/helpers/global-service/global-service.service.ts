import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { each } from 'lodash';
import { User } from 'src/users/users.entity';
import { Repository } from 'typeorm';
const csv = require('csv-parser');
const fs = require('fs');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

@Injectable()
export class GlobalServiceService {
	constructor(
		private _jwtService: JwtService,
		@InjectRepository(User) private userRepository: Repository<User>
	) {}

	async decode(token) {
		const user = await this._jwtService.decode(token);
		console.log(user);
		console.log("User Email found from token: ",user["email"]);
		const userFromDb = await this.userRepository.findOne(user["id"]);
		console.log("User Email found from DB: ",userFromDb["email"]);
		if(user["email"] == userFromDb["email"]) {
			return user;
		}
		else {
			throw new HttpException('Forbidden', HttpStatus.FORBIDDEN);
		}
	}

	async exportCsv(resArr : any[],userId: number, type: string) {
		let fileName = type+"(userId:"+userId+").csv";
		const path = './public/'+fileName;
		console.log("Path :",path);
		const keys : any[] = Object.keys(resArr[0]);
		const header = [];
		await Promise.all(keys.map(eachKey => {
			if(resArr[0][eachKey] == Object) {

			}
			let tempObj = {"id":eachKey , "title":eachKey};
			header.push(tempObj);
		}));
		console.log(header);
		const csvWriter = createCsvWriter({
			path: path,
			header: header
		});
		await csvWriter.writeRecords(resArr).then(() => {
    	    console.log('...Done');
    	});
		const url = "https://api.staging.datasutram.com/public/"+fileName;
		return {"url": url};
	}
}
