import { Entity, PrimaryColumn, Column, Index } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

@Entity()
export class PoiShape {
	@ApiProperty()
	@PrimaryColumn()
	@Index()
	poiId: number;

	@ApiProperty()
	@PrimaryColumn()
	@Index("poi_shape_index")
	shapeId: number;
}

