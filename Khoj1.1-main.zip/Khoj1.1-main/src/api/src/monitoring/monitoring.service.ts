import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Kpi } from "src/kpi/kpi.entity";
import { LeadStatusUpdates, LostLead } from "src/leads/leads.entity";
import { Lead } from "src/leads/leads.entity";
import { Team } from "src/team/team.entity";
import { User } from "src/users/users.entity";
import { Between, DataSource, In, LessThanOrEqual, MoreThanOrEqual, Not, Repository } from "typeorm";
import * as _ from "lodash";
import * as moment from "moment";
import {
	LeadConversionQuery,
	LeadQueryRes,
	LostOpportunityQuery,
	MonitoringQuery,
	UpcomingRemindersQuery,
} from "src/interfaces/monitoring";
import { Poi } from "src/poi/poi.entity";
import { PoiDetail } from "src/poi-details/poi-details.entity";
import { Note } from "src/notes/notes.entity";
import { Reminder, ReminderUpdate } from "src/reminders/reminders.entity";
import { MerchantService } from "src/merchant/merchant.service";
import { PromptLog } from "src/prompt-log/prompt-log.entity";

@Injectable()
export class MonitoringService {
	constructor(
		@InjectRepository(Kpi) private kpiRepository: Repository<Kpi>,
		@InjectRepository(User) private usersRepository: Repository<User>,
		@InjectRepository(Team) private teamRepository: Repository<Team>,
		@InjectRepository(Lead) private leadRepository: Repository<Lead>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(PoiDetail) private poiDetailRepository: Repository<PoiDetail>,
		@InjectRepository(LeadStatusUpdates) private leadStatusUpdatesRepository: Repository<LeadStatusUpdates>,
		@InjectRepository(LostLead) private lostLeadRepository: Repository<LostLead>,
		@InjectRepository(Reminder) private reminderRepository: Repository<Reminder>,
		@InjectRepository(Note) private noteRepository: Repository<Note>,
		private _merchantService: MerchantService,
		@InjectRepository(ReminderUpdate) private reminderUpdateRepository: Repository<ReminderUpdate>,
		@InjectRepository(PromptLog) private promptLogRepository: Repository<PromptLog>,
		@InjectRepository(LostLead) private lostLeadsRepository: Repository<LostLead>,
		private connection: DataSource,
	) {}

	successful_call_nodes = _.isArray(JSON.parse(String(process.env.SUCCESSFUL_CALL_NODES)))
		? (JSON.parse(String(process.env.SUCCESSFUL_CALL_NODES)) as number[][][])
		: [];

	async getUserActivity(query: MonitoringQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.allFosData) {
			const allFosIds = await (async () => {
				try {
					return (
						await this.usersRepository
							.createQueryBuilder("user")
							.where(`ARRAY['maps_user']::character varying[] && roles`)
							.andWhere(`designation = 'Feet On Street'`)
							.andWhere(`"user".id IN (:...ids)`, {
								ids: await this.getUsersUnderHirerchy(query?.userIds),
							})
							.getMany()
					).map((u) => u.id);
				} catch (error) {
					console.error(error);
					return [];
				}
			})();
			query.userIds = allFosIds;
		}
		const userGroups: Map<number, number[]> = new Map();
		const teamGroup: Map<number, number[]> = new Map();
		const cascadedUsers = await Promise.all(
			query.userIds.map(async (id) => (query?.cascade ? await this.getUsersUnderHirerchy([id]) : [id])),
		);
		const cascadedTeams = await Promise.all(query.userIds.map(async (id) => await this.getTeamsUnderHirerchy(id)));
		if (!cascadedUsers?.length) return [];
		query.userIds.forEach((id, idx) => {
			userGroups.set(id, cascadedUsers[idx]);
			teamGroup.set(id, cascadedTeams[idx]);
		});
		const leadStatusGroupedByUserIDs = await (async () => {
			try {
				const res: { count: number; status: string; tokenUserId: number }[] = await this.leadRepository
					.createQueryBuilder(`lead`)
					.select([`status`, `"tokenUserId"`, `COUNT(*)`])
					.where(`"tokenUserId" IN (:...ids)`, { ids: cascadedUsers.flat() })
					.andWhere(
						() => {
							if (query.startTime && query.endTime) return `"updatedAt" between :startTime and :endTime`;
							else if (query.startTime) return `"updatedAt" >= :startTime`;
							else if (query.endTime) return `"updatedAt" <= :endTime`;
							else return `1=1`;
						},
						{
							startTime: query.startTime,
							endTime: query.endTime,
						},
					)
					.groupBy(`status`)
					.addGroupBy(`"tokenUserId"`)
					.getRawMany();
				return _.groupBy(res, "tokenUserId");
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const staticOnboarded: _.Dictionary<{ tokenUserId: number; status: string; count: number }> =
			await (async () => {
				try {
					if (String(process.env.SET_ONBOARDED_STATIC_COUNT) == "true") {
						const res = {};
						const teams = await this.teamRepository.find({ where: { id: In(cascadedTeams.flat()) } });
						query.userIds.forEach((uid) => {
							const filteredTeams = teams.filter((t) => teamGroup.get(uid).includes(t.id));
							if (filteredTeams.length) {
								const tempObj = { tokenUserId: Number(uid), status: "onboarded", count: 0 };
								tempObj.count = filteredTeams.reduce((acc, obj) => acc + obj.onboardedCount, 0);
								res[uid] = tempObj;
							}
						});
						return res;
					} else {
						return {};
					}
				} catch (error) {
					console.error(error);
					return {};
				}
			})();
		const kpiActivitesGroupedByUserIDs = await (async () => {
			try {
				const kpis: { count: string; status: string; tokenUserId: number }[] = await this.kpiRepository
					.createQueryBuilder(`kpi`)
					.select([`"tokenUserId"`, `COUNT(*)`])
					.addSelect(`action`, `status`)
					.where(`"tokenUserId" IN (:...ids)`, { ids: cascadedUsers.flat() })
					.andWhere(
						() => {
							if (query.startTime && query.endTime) return `"createdAt" between :startTime and :endTime`;
							else if (query.startTime) return `"createdAt" >= :startTime`;
							else if (query.endTime) return `"createdAt" <= :endTime`;
							else return `1=1`;
						},
						{
							startTime: query.startTime,
							endTime: query.endTime,
						},
					)
					.andWhere(`action in ('Merchant Call','Merchant Navigate')`)
					.groupBy(`status`)
					.addGroupBy(`"tokenUserId"`)
					.getRawMany();
				return _.groupBy(kpis, "tokenUserId");
			} catch (error) {
				console.error(error);
			}
		})();
		const successfulCallsMade = await (async () => {
			try {
				const promptLogs: { tokenUserId: number; node: number; count: number }[] =
					await this.promptLogRepository
						.createQueryBuilder(`prompt_logs`)
						.select([`"id", "tokenUserId"`, "node"])
						.where(`"tokenUserId" IN (:...ids)`, { ids: cascadedUsers.flat() })
						.andWhere(
							() => {
								if (query.startTime && query.endTime)
									return `"createdAt" between :startTime and :endTime`;
								else if (query.startTime) return `"createdAt" >= :startTime`;
								else if (query.endTime) return `"createdAt" <= :endTime`;
								else return `1=1`;
							},
							{
								startTime: query.startTime,
								endTime: query.endTime,
							},
						)
						.andWhere(
							() => {
								if (this.successful_call_nodes.length) return `node IN (:...nodeIds)`;
								else return `1=1`;
							},
							{ nodeIds: _.flattenDeep(this.successful_call_nodes) },
						)
						.orderBy("id")
						.getRawMany();
				return _.groupBy(promptLogs, "tokenUserId");
			} catch (error) {
				console.error(error);
			}
		})();
		const visitedLeads = await (async () => {
			try {
				const leads = await this.leadRepository
					.createQueryBuilder(`lead`)
					.select([`"tokenUserId"`, `COUNT(*)`])
					.where(`"tokenUserId" IN (:...ids)`, { ids: cascadedUsers.flat() })
					.andWhere(`visited = true`)
					.andWhere(
						() => {
							if (query.startTime && query.endTime) return `"updatedAt" between :startTime and :endTime`;
							else if (query.startTime) return `"updatedAt" >= :startTime`;
							else if (query.endTime) return `"updatedAt" <= :endTime`;
							else return `1=1`;
						},
						{
							startTime: query.startTime,
							endTime: query.endTime,
						},
					)
					.groupBy(`"tokenUserId"`)
					.getRawMany();
				return _.groupBy(leads, "tokenUserId");
			} catch (error) {
				console.error(error);
			}
		})();
		const hotLeads = await (async () => {
			try {
				const leadsWithNoTags = await this.leadRepository
					.createQueryBuilder(`lead`)
					.select([`"tokenUserId"`, `COUNT(*)`])
					.where(`"tokenUserId" IN (:...ids)`, { ids: cascadedUsers.flat() })
					.andWhere(
						() => {
							if (query.startTime && query.endTime) return `"updatedAt" between :startTime and :endTime`;
							else if (query.startTime) return `"updatedAt" >= :startTime`;
							else if (query.endTime) return `"updatedAt" <= :endTime`;
							else return `1=1`;
						},
						{
							startTime: query.startTime,
							endTime: query.endTime,
						},
					)
					.andWhere(`status = :status`, { status: "in_progress" })
					.andWhere(`tags = '{}'`)
					.groupBy(`"tokenUserId"`)
					.getRawMany();
				return _.groupBy(leadsWithNoTags, "tokenUserId");
			} catch (error) {
				console.error(error);
			}
		})();
		const reminders = await (async () => {
			try {
				const reminders: { tokenUserId: number; count: number }[] = await this.reminderRepository
					.createQueryBuilder(`reminder`)
					.select([`"tokenUserId"`, `COUNT(*)`])
					.where(`"tokenUserId" IN (:...ids)`, { ids: cascadedUsers.flat() })
					.andWhere(
						() => {
							if (query.startTime && query.endTime)
								return `"createdAt" between :startTime and :endTime OR "updatedAt" between :startTime and :endTime`;
							else if (query.startTime) return `"createdAt" >= :startTime OR "updatedAt" >= :startTime`;
							else if (query.endTime) return `"createdAt" <= :endTime OR "updatedAt" <= :endTime`;
							else return `1=1`;
						},
						{
							startTime: query.startTime,
							endTime: query.endTime,
						},
					)
					.andWhere(`"isDeleted" = false`)
					.andWhere(`"isActive" = true`)
					.groupBy(`"tokenUserId"`)
					.getRawMany();
				return _.groupBy(reminders, "tokenUserId");
			} catch (error) {
				console.error(error);
			}
		})();
		const userDetailsArr: User[] = await (async () => {
			try {
				return await this.connection.manager.query(
					`WITH owners AS (select "user".id , "user"."firstName", "user"."lastName", team.id team_id from team join "user" on "user".id = team."ownerId")
					SELECT "user".id, "user"."firstName", "user"."lastName", "user".email, "user"."phoneNumber", team.id team_id, team.name team_name, MAX(kpi."createdAt") last_active, owners.id owner_id, owners."firstName" owner_first_name, owners."lastName" owner_last_name
					FROM "user" LEFT JOIN kpi on "user".id = kpi."tokenUserId" LEFT JOIN team on team."id" = "user"."teamId" LEFT JOIN owners on team.id = owners.team_id
					WHERE "user".id IN (${query.userIds.join(",")})
					GROUP BY "user".id, "user"."firstName", "user"."lastName", "user".email, "user"."phoneNumber", team.id, team.name, owners.id, owners."firstName", owners."lastName"`,
				);
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const uniqueLeadStatuses = (() => {
			const statuses = Object.entries(leadStatusGroupedByUserIDs)
				.map(([key, value]) => value.map((v) => v?.status))
				.filter((v) => v);
			return _.uniq(statuses.flat());
		})();
		const userActivities = userDetailsArr.map((user) => {
			const filteredStatusCounts = userGroups
				.get(user.id)
				?.map((id) => leadStatusGroupedByUserIDs?.[id] ?? [])
				.flat();
			const filteredKpiCounts = userGroups
				.get(user.id)
				?.map((id) => kpiActivitesGroupedByUserIDs?.[id] ?? [])
				.flat();
			uniqueLeadStatuses.forEach((status) => {
				const count = filteredStatusCounts
					.filter((v) => v?.status === status)
					.reduce((a, b) => a + parseInt(b?.count ?? "0"), 0);
				user[status] = count;
			});
			if (String(process.env.SET_ONBOARDED_STATIC_COUNT) == "true" && staticOnboarded[user.id]) {
				user["onboarded"] = Number(staticOnboarded[user.id].count);
			}
			const filteredSuccessCallsCounts = userGroups
				.get(user.id)
				?.map((id) => successfulCallsMade?.[id] ?? [])
				.flat();
			const filteredSuccessVisitCounts = userGroups
				.get(user.id)
				?.map((id) => visitedLeads?.[id] ?? [])
				.flat();
			const filteredHotLeadsCounts = userGroups
				.get(user.id)
				?.map((id) => hotLeads?.[id] ?? [])
				.flat();
			const filteredRemindersCounts = userGroups
				.get(user.id)
				?.map((id) => reminders?.[id] ?? [])
				.flat();
			user["navigations_made"] = filteredKpiCounts
				.filter((v) => v.status === "Merchant Navigate")
				.reduce((a, b) => a + parseInt(b?.count ?? "0"), 0);
			user["calls_made"] = filteredKpiCounts
				.filter((v) => v.status === "Merchant Call")
				.reduce((a, b) => a + parseInt(b?.count ?? "0"), 0);
			user["successful_calls"] = (() => {
				let total_succ_calls = 0;
				filteredSuccessCallsCounts.forEach((currentPrompt, index) => {
					const nextPrompt = filteredSuccessCallsCounts[index + 1];
					if (nextPrompt) {
						const nodeSet = this.successful_call_nodes.find((nodeSet) =>
							nodeSet[0].includes(Number(currentPrompt.node)),
						);
						if (nodeSet) {
							if (nodeSet[1].includes(Number(nextPrompt.node))) {
								total_succ_calls++;
							}
						}
					}
				});
				return total_succ_calls;
			})();
			user["successful_visits"] = filteredSuccessVisitCounts.reduce((a, b) => a + Number(b?.count ?? 0), 0);
			user["hot_leads"] = filteredHotLeadsCounts.reduce((a, b) => a + Number(b?.count ?? 0), 0);
			user["reminders"] = filteredRemindersCounts.reduce((a, b) => a + Number(b?.count ?? 0), 0);
			return user;
		});
		return userActivities;
	}

	async getTopReasons(query: MonitoringQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);
		const resFromLeadsHistory: { status: string; reason: string; count: number }[] = await (async () => {
			try {
				return await this.leadStatusUpdatesRepository
					.createQueryBuilder(`lead_status_updates`)
					.select([`status`, `COUNT(*)`])
					.addSelect(`remarks`, `reason`)
					.where(`"tokenUserId" IN (:...ids)`, { ids: query.userIds })
					.andWhere(
						() => {
							if (query.startTime && query.endTime) return `"createdAt" between :startTime and :endTime`;
							else if (query.startTime) return `"createdAt" >= :startTime`;
							else if (query.endTime) return `"createdAt" <= :endTime`;
							else return `1=1`;
						},
						{
							startTime: query.startTime,
							endTime: query.endTime,
						},
					)
					.groupBy(`status`)
					.addGroupBy(`remarks`)
					.orderBy(`"count"`, "DESC")
					.getRawMany();
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		resFromLeadsHistory.forEach((e) => {
			e.count = Number(e.count);
		});
		return this.getResFromArr(resFromLeadsHistory, query?.limit ?? 5);
	}

	getResFromArr(
		arr: {
			status: string;
			reason: string;
			count: number;
		}[],
		reasonCount: number,
	) {
		try {
			const groupedByStatus = _.groupBy(arr, "status");
			const result = {};
			_.forEach(groupedByStatus, (reasons, status) => {
				const sortedReasons = _.sortBy(reasons, "count").reverse();
				const topReasons = sortedReasons.slice(0, reasonCount).map(({ reason, count }) => ({ reason, count }));
				const restCount = sortedReasons.slice(reasonCount).reduce((acc, curr) => acc + curr.count, 0);
				const restReason = { reason: "Rest", count: restCount };
				if (sortedReasons.length > reasonCount) topReasons.push(restReason);
				result[status] = topReasons;
			});
			return result;
		} catch (error) {
			return {};
		}
	}

	async getUsersUnderHirerchy(userIds: number[]): Promise<number[]> {
		const ids: { id: number }[] = await (async () => {
			try {
				return await this.connection.manager.query(`
				WITH RECURSIVE subordinates AS (
					SELECT "user".id, "teamId", team.id owned_team_id
					FROM "user" left join team on team."ownerId" = "user".id
					WHERE "user".id IN (${userIds.join(",")})
					UNION
					SELECT u.id, u."teamId", t.id owned_team_id
					FROM "user" u 
					JOIN subordinates s ON u."teamId" = s.owned_team_id left join team t on t."ownerId" = u.id
				)
				select DISTINCT(id) from "user" where id IN(
					SELECT DISTINCT(id) FROM subordinates
				) and "isAuthorized" = true;
				`);
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const idsByCoOwnership: { id: number }[] = await (async () => {
			try {
				return await this.connection.manager.query(`
				WITH RECURSIVE subordinates AS (
					SELECT "user".id, "teamId", team.id owned_team_id
					FROM "user" left join team on team."ownerId" = "user".id
					WHERE "user".id IN (SELECT "ownerId" from team where ARRAY[${userIds.join(",")}]::integer[] && team."coOwnerIds")
					UNION
					SELECT u.id, u."teamId", t.id owned_team_id
					FROM "user" u 
					JOIN subordinates s ON u."teamId" = s.owned_team_id left join team t on t."ownerId" = u.id
				)
				select DISTINCT(id) from "user" where id IN(
					SELECT DISTINCT(id) FROM subordinates
				) and "isAuthorized" = true;
				`);
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const finalIds = [...ids, ...idsByCoOwnership];
		if (finalIds.length) return _.sortBy(finalIds?.map((e) => Number(e?.id)));
		return [];
	}

	async getTeamsUnderHirerchy(userId: number): Promise<number[]> {
		const ids: { id: number }[] = await (async () => {
			try {
				return await this.connection.manager.query(`
				WITH RECURSIVE TeamHierarchy AS (
  					SELECT team.id, name, "ownerId", "user".id user_id
  					FROM team
  					left join "user" on "user"."teamId" = team.id 
  					WHERE "ownerId" = ${userId}
  					UNION 
  					SELECT t.id, t.name, t."ownerId", u.id user_id
  					FROM team t
  					JOIN TeamHierarchy th ON th.user_id = t."ownerId" left join "user" u on t.id = u."teamId"
				)
				SELECT DISTINCT(id)
				FROM TeamHierarchy;
			`);
			} catch (error) {
				console.error(error);
			}
		})();
		const idsByCoOwnership: { id: number }[] = await (async () => {
			try {
				return await this.connection.manager.query(`
					SELECT id FROM team WHERE ARRAY[${Number(userId)}]::integer[] && team."coOwnerIds"
				`);
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		const finalIds = [...ids, ...idsByCoOwnership];
		if (finalIds.length) return _.sortBy(finalIds?.map((e) => Number(e?.id)));
		return [];
	}

	async getStats(user: Partial<User | ApiKeyUser>): Promise<_.Dictionary<Lead[]>> {
		const leads = await (async () => {
			try {
				const query = {
					tokenUserId: user?.["type"] == "token" ? Number(user.id) : undefined,
					apiKeyUserId: user?.["type"] == "apikey" ? Number(user.id) : undefined,
				};
				return await this.leadRepository.find({ where: query });
			} catch (error) {
				console.error(error);
			}
		})();
		const lostLeads = await (async () => {
			try {
				return await this.leadStatusUpdatesRepository
					.createQueryBuilder(`lead_status_updates`)
					.where(
						`"poiId" in (select "poiId" from lost_lead where ${
							user?.["type"] == "token" ? '"tokenUserId"' : '"apiKeyUserId"'
						} = ${Number(user.id)})`,
					)
					.andWhere(`${user?.["type"] == "token" ? '"tokenUserId"' : '"apiKeyUserId"'} = ${Number(user.id)}`)
					.andWhere(`status = 'lost'`)
					.getMany();
			} catch (error) {
				console.error(error);
			}
		})();
		const allLeads = [...(leads || []), ...(lostLeads.map(({ id, ...rest }) => rest) || [])];
		if (!allLeads?.length) return [] as unknown as _.Dictionary<Lead[]>;
		return _.groupBy(allLeads, "status") as _.Dictionary<Lead[]>;
	}

	async getTopCategories(query: MonitoringQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);
		const res: _.Dictionary<LeadQueryRes[]> = await (async () => {
			try {
				const res: LeadQueryRes[] = await this.leadRepository
					.createQueryBuilder(`lead`)
					.select([`lead.*`, `p.type`])
					.leftJoin(Poi, `p`, `p.id = lead."poiId"`)
					.where(`lead."tokenUserId" in (:...ids)`, { ids: query.userIds })
					.andWhere(
						() => {
							if (query.startTime && query.endTime) return `"updatedAt" between :startTime and :endTime`;
							else if (query.startTime) return `"updatedAt" >= :startTime`;
							else if (query.endTime) return `"updatedAt" <= :endTime`;
							else return `1=1`;
						},
						{
							startTime: query.startTime,
							endTime: query.endTime,
						},
					)
					.getRawMany();
				return _.groupBy(res, "status");
			} catch (error) {
				console.error(error);
				return {};
			}
		})();
		const finalResponse = {};
		try {
			_(res).forEach((value, key) => {
				finalResponse[key] = _.countBy(value, "p_type");
			});
			const limit = query?.limit || 10;
			_(finalResponse).forEach((value, key) => {
				const categories = Object.entries(value).sort((a, b) => (b[1] as number) - (a[1] as number));
				const topCategories = categories.slice(0, limit);
				const restCount = categories?.slice(limit)?.reduce((acc, curr) => acc + (curr?.[1] as number), 0);
				if (restCount) topCategories.push(["rest", restCount]);
				finalResponse[key] = Object.fromEntries(topCategories);
			});
		} catch (error) {
			console.error(error);
		}
		return finalResponse;
	}

	async getTopCategoriesGST(query: MonitoringQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);
		const statusGroups = await (async () => {
			try {
				const res = await this.leadRepository
					.createQueryBuilder(`lead`)
					.select([`lead.*`, `p.type`, `pd.value`, `pd.unit`])
					.leftJoin(Poi, `p`, `p.id = lead."poiId"`)
					.leftJoin(PoiDetail, `pd`, `pd."poiId" = p.id and pd."key" = 'turn_over_slab'`)
					.where(`lead."tokenUserId" in (:...ids)`, { ids: query.userIds })
					.andWhere(
						() => {
							if (query.startTime && query.endTime) return `"updatedAt" between :startTime and :endTime`;
							else if (query.startTime) return `"updatedAt" >= :startTime`;
							else if (query.endTime) return `"updatedAt" <= :endTime`;
							else return `1=1`;
						},
						{
							startTime: query.startTime,
							endTime: query.endTime,
						},
					)
					.getRawMany();
				return _.groupBy(res, "status");
			} catch (error) {
				console.error(error);
				return {};
			}
		})();
		const gstCategories = await (async () => {
			try {
				const res = await this.connection.manager.query(
					`select distinct("value"), unit from poi_detail where "key" = 'turn_over_slab' order by unit`,
				);
				return res;
			} catch (error) {
				console.error(error);
				return [];
			}
		})();

		const limit = query?.limit || 10;
		_(statusGroups).forEach((value, key) => {
			statusGroups[key] = _.groupBy(value, "p_type") as any;
			const categories = Object.entries(statusGroups[key]).sort((a, b) => b[1].length - a[1].length);
			const topCategories = categories.slice(0, limit);
			const rest = categories.slice(limit);
			if (rest?.length) topCategories.push(["rest", rest.map((i) => i[1]).flat()]);
			statusGroups[key] = Object.fromEntries(topCategories) as any;
			_(statusGroups[key]).forEach((value, category) => {
				if (gstCategories?.length) {
					const gstCategoriesCount = _.countBy(value, "pd_value") as any;
					statusGroups[key][category] = {};
					gstCategories.forEach((i) => {
						statusGroups[key][category][i.value] = gstCategoriesCount[i.value] || 0;
					});
				} else statusGroups[key][category] = _.countBy(value, "pd_value") as any;
			});
		});
		return statusGroups;
	}

	generateTimeFilterQuery(query: LeadConversionQuery) {
		if (query.startTime && query.endTime) return `"createdAt" between '${query.startTime}' and '${query.endTime}'`;
		else if (query.startTime) return `"createdAt" >= '${query.startTime}'`;
		else if (query.endTime) return `"createdAt" <= '${query.endTime}'`;
		else return `1=1`;
	}

	async getStatusConversionDistribution(query: LeadConversionQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);
		if (!query?.userIds?.length) return [];
		const uniqueLeadStatuses = ["in_progress", "onboarded", "rejected"];
		const statusUpdatesDict: _.Dictionary<{ status: string; time: Date; date: Date; poiId: number }[]> =
			await (async () => {
				try {
					const res: { status: string; time: Date; date: Date; poiId: number }[] =
						await this.connection.manager.query(
							`SELECT "poiId", "createdAt" AS time, DATE_TRUNC('day', "createdAt") AS date, status
							FROM
							public.lead_status_updates
							WHERE "tokenUserId" IN (${query.userIds.join(",")})
							AND ${this.generateTimeFilterQuery(query)}
							AND status IN ('${uniqueLeadStatuses.join("','")}')
							ORDER BY
							date;`,
						);
					return _.groupBy(res, "date");
				} catch (error) {
					console.error(error);
					throw new HttpException("Cannot get Lead Status Updates", HttpStatus.SERVICE_UNAVAILABLE);
				}
			})();

		const getLastObjectPerId = (
			array: { status: string; time: Date; date: Date; poiId: number }[],
		): { status: string; time: Date; date: Date; poiId: number }[] => {
			const result = array.reduce((acc, item) => {
				acc[item.poiId] = item;
				// if (!acc[item.poiId] || moment(acc[item.poiId].time).isBefore(moment(item.time))) {
				// 	acc[item.poiId] = item;
				// }
				return acc;
			}, {});
			return Object.values(result);
		};
		const statusUpdateArr = Object.entries(statusUpdatesDict).map(([key, value]) => {
			return { date: key, status: value };
		});
		const response = [];
		try {
			for (const [index, dayStatus] of statusUpdateArr.entries()) {
				const resp = { time: this.getTimePhrase(dayStatus.date as any, dayStatus.date as any) };
				const allCurrentStatusHistory = statusUpdateArr
					.slice(0, index + 1)
					.map((d) => d.status)
					.flat();
				const allCurrentLatestStatus = getLastObjectPerId(allCurrentStatusHistory);
				for (const status of uniqueLeadStatuses) {
					const statuses = allCurrentLatestStatus.filter((s) => s["status"] === status);
					resp[status] = statuses.length || 0;
				}
				response.push(resp);
			}

			// TO FIX START
			const latestStatusCount = await (async () => {
				try {
					const res = await this.connection.manager.query(
						`SELECT "status", count(*)
						FROM
						public.lead
						WHERE "tokenUserId" IN (${query.userIds.join(",")})
						AND ${this.generateTimeFilterQuery(query)}
						AND status IN ('${uniqueLeadStatuses.join("','")}')
						GROUP BY
						status;`,
					);
					return res;
				} catch (error) {
					console.error(error);
					throw new HttpException("Cannot get Lead Status Updates", HttpStatus.SERVICE_UNAVAILABLE);
				}
			})();
			for (const status of uniqueLeadStatuses) {
				const statuses = latestStatusCount.find((s) => s["status"] === status);
				response[response.length - 1][status] = parseInt(statuses.count ?? 0) || 0;
			}
			// TO FIX END
		} catch (error) {
			console.error(error);
		} finally {
			return response;
		}
	}

	async getStatusConversionDistributionOld(query: LeadConversionQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);
		const statusUpdates = await (async () => {
			try {
				return await this.leadStatusUpdatesRepository.find({
					where: {
						tokenUserId: In(query.userIds),
						createdAt:
							query.startTime && query.endTime ? Between(query.startTime, query.endTime) : undefined,
					},
				});
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot get Lead Status Updates", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();

		const groupedRes = _.groupBy(statusUpdates, "status");

		let brackets = query.brackets ?? 5;
		let startBracket =
			new Date(statusUpdates[0]?.createdAt) > new Date(query.startTime)
				? new Date(query.startTime)
				: new Date(statusUpdates[0]?.createdAt);
		const endBracket =
			new Date(statusUpdates[statusUpdates.length - 1]?.createdAt) < new Date(query.endTime)
				? new Date(query.endTime)
				: new Date(statusUpdates[statusUpdates.length - 1]?.createdAt);
		const diffDays = moment(endBracket).diff(moment(startBracket), "days");
		brackets = brackets > diffDays ? diffDays + 1 : brackets;
		const bracketSizeMs = Math.round((endBracket.getTime() - startBracket.getTime()) / (brackets ?? 1));
		const result = [];
		for (let i = 0; i < brackets; i++) {
			const bracketStart = startBracket;
			const endTimestamp = new Date(bracketStart.getTime() + bracketSizeMs);
			const bracketEnd =
				i === brackets - 1
					? endBracket
					: new Date(endTimestamp.getFullYear(), endTimestamp.getMonth(), endTimestamp.getDate() + 1);
			const resObjs = {};
			_(groupedRes).forEach((value, key) => {
				const resObj = value.filter((e) => {
					const date = new Date(e.createdAt);
					return date >= new Date(bracketStart) && date <= new Date(bracketEnd);
				});
				resObjs[key] = resObj.length;
			});
			result.push({ bracketStart, bracketEnd, time: this.getTimePhrase(bracketStart, bracketEnd), ...resObjs });
			startBracket = bracketEnd;
		}
		return result;
	}

	getTimePhrase(startDate: Date, endDate: Date): string {
		const start = moment(startDate);
		const end = moment(endDate);

		const diffHours = end.diff(start, "hours");
		if (diffHours > 24) {
			if (start.isSame(end, "month")) {
				const formattedStartDate = start.format("D");
				const formattedEndDate = end.format("D MMM'YY");
				return `${formattedStartDate}-${formattedEndDate}`;
			} else if (start.isSame(end, "year")) {
				const formattedStartDate = start.format("D MMM");
				const formattedEndDate = end.format("D MMM'YY");
				return `${formattedStartDate}-${formattedEndDate}`;
			} else {
				const formattedStartDate = start.format("D MMM'YY");
				const formattedEndDate = end.format("D MMM'YY");
				return `${formattedStartDate}-${formattedEndDate}`;
			}
		} else return start.format("D MMM'YY");
	}

	async getTeamsStatsDistribution(query: MonitoringQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userId && !query?.teamId) query.userId = user?.["type"] == "token" ? Number(user.id) : undefined;
		query.cascade = true;
		query.userIds = await (async () => {
			try {
				if (query?.userId) {
					const ids: { id: number }[] = await this.connection.manager.query(`
					select id from "user" where "teamId" IN (select id from team where "ownerId" IN (SELECT id from "user" where "teamId" in (select id from team where "ownerId" = ${Number(
						query.userId,
					)}))) 
					`);
					return ids.map((e) => e.id);
				} else {
					const ids: { id: number }[] = await this.connection.manager.query(`
					select id from "user" where "teamId" IN (select id from team where "ownerId" IN (SELECT id from "user" where "teamId" = ${Number(
						query.teamId,
					)})) 
					`);
					return ids.map((e) => e.id);
				}
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
		return await (async () => {
			try {
				const teamWise = _.groupBy(await this.getUserActivity(query, user), "team_id");
				const teamIds = Object.keys(teamWise).map((id) => Number(id));
				const teamSizeDict = await (async () => {
					try {
						const tobj = {};
						const teamRes: { id: number; count: number }[] = await this.connection.manager.query(
							`select team.id, count("user".*) from team join "user" on "user"."teamId" = team.id where team.id in (${teamIds.join(
								",",
							)}) group by team.id`,
						);
						teamRes.map((o) => {
							tobj[o.id] = Number(o.count);
						});
						return tobj;
					} catch (error) {
						console.error(error);
						return {};
					}
				})();
				const resp = [];
				Object.keys(teamWise).map((tid) => {
					try {
						const tempObj = {
							id: Number(tid),
							name: teamWise[tid][0]?.["team_name"],
							teamSize: teamSizeDict[tid],
							owner: {
								id: Number(teamWise[tid][0]?.["owner_id"]),
								firstname: teamWise[tid][0]?.["owner_first_name"],
								lastName: teamWise[tid][0]?.["owner_last_name"],
							},
							status_counts: {
								in_progress: 0,
								onboarded: 0,
								rejected: 0,
							},
							activities: {
								calls_made: 0,
								navigations_made: 0,
							},
						};
						teamWise[tid].map((u) => {
							tempObj.status_counts.in_progress =
								Number(tempObj.status_counts.in_progress) +
								(() => {
									return u?.["in_progress"] ? Number(u["in_progress"]) : 0;
								})();
							tempObj.status_counts.onboarded =
								Number(tempObj.status_counts.onboarded) +
								(() => {
									return u?.["onboarded"] ? Number(u["onboarded"]) : 0;
								})();
							tempObj.status_counts.rejected =
								Number(tempObj.status_counts.rejected) +
								(() => {
									return u?.["rejected"] ? Number(u["rejected"]) : 0;
								})();
							tempObj.activities.calls_made =
								Number(tempObj.activities.calls_made) +
								(() => {
									return u?.["calls_made"] ? Number(u["calls_made"]) : 0;
								})();
							tempObj.activities.navigations_made =
								Number(tempObj.activities.navigations_made) +
								(() => {
									return u?.["navigations_made"] ? Number(u["navigations_made"]) : 0;
								})();
						});
						resp.push(tempObj);
					} catch (error) {
						console.error(error);
					}
				});
				return resp;
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
	}

	async getCurrentInProgressLeadsAgeing(query: LeadConversionQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);
		const currentInProgressLeads = await (async () => {
			try {
				const records = await this.leadRepository.find({
					where: {
						tokenUserId: In(query.userIds),
						status: "in_progress",
						updatedAt: (() => {
							if (query.startTime && query.endTime) return Between(query.startTime, query.endTime);
							else if (query.startTime) return MoreThanOrEqual(query.startTime);
							else if (query.endTime) return LessThanOrEqual(query.endTime);
							else return undefined;
						})(),
					},
				});
				return records;
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot get Lead Status Updates", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		const leadAge: { id: number; age: number; updatedAt: Date }[] = currentInProgressLeads.map((lead) => {
			return {
				id: lead.poiId,
				age: moment(new Date()).diff(moment(lead.updatedAt), "days"),
				updatedAt: lead.updatedAt,
			};
		});
		const ages: number[] = _.sortBy(leadAge.map((l) => l.age));
		const [minAge, maxAge] = [ages[0], ages[ages.length - 1]];

		const calcAge = (selectedAges: number[], start: number, end: number) => {
			if (start) {
				if (selectedAges[0] === selectedAges[selectedAges.length - 1]) return `${selectedAges[0]}`;
				else return `${start} to ${end}`;
			} else return `Less than ${end}`;
		};

		const brackets = query.brackets ?? 5;
		const ranges = _.range(minAge, maxAge, Math.round((maxAge - minAge) / brackets));
		const rangeBrackets = _.map(ranges, (value, index) => {
			const start = value;
			const end = ranges[index + 1] ?? maxAge;
			const selectedAges =
				end != maxAge
					? _.filter(ages, (e) => e >= start && e < end)
					: _.filter(ages, (e) => e >= start && e <= end);
			if (selectedAges?.length)
				return {
					age: calcAge(selectedAges, start, end),
					count: selectedAges.length,
				};
		}).filter((e) => e);
		return rangeBrackets;
	}

	async getInProgressAgeing(query: LeadConversionQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);
		const leadsWithInProgressRecords = await (async () => {
			try {
				const records = await this.leadRepository.find({
					where: {
						tokenUserId: In(query.userIds),
						status: "in_progress",
						updatedAt: (() => {
							if (query.startTime && query.endTime) return Between(query.startTime, query.endTime);
							else if (query.startTime) return MoreThanOrEqual(query.startTime);
							else if (query.endTime) return LessThanOrEqual(query.endTime);
							else return undefined;
						})(),
					},
				});
				return _.keyBy(records, "poiId");
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot get Lead Status Updates", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		const inProgressLeadsCurrentStatus = await (async () => {
			try {
				const records = await this.leadRepository.find({
					where: {
						poiId: In(Object.keys(leadsWithInProgressRecords)),
						status: Not("in_progress"),
					},
				});
				return _.keyBy(records, "poiId");
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot get Lead Current Status", HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		const leadRecords = {};
		_.forEach(leadsWithInProgressRecords, (value, key) => {
			const currentStatus = inProgressLeadsCurrentStatus[key];
			const endTime = currentStatus?.updatedAt ?? new Date();
			const age = Math.round((endTime.getTime() - new Date(value.createdAt).getTime()) / (1000 * 60 * 60 * 24));
			leadRecords[key] = { startTime: value.createdAt, endTime, endStatus: currentStatus?.status, age };
		});
		const ages = _.map(leadRecords, (value) => Number(value["age"]));
		const [minAge, maxAge] = [_.min(ages), _.max(ages)];

		const brackets = query.brackets ?? 5;
		const ranges = _.range(minAge, maxAge, Math.round((maxAge - minAge) / brackets));
		const rangeBrackets = _.map(ranges, (value, index) => {
			const start = value;
			const end = ranges[index + 1] ?? maxAge;
			const count =
				end != maxAge
					? _.filter(ages, (e) => e >= start && e < end).length
					: _.filter(ages, (e) => e >= start && e <= end).length;
			return {
				age: (start ? `${start} to` : "Less than ") + ` ${end}`,
				count,
			};
		});
		return rangeBrackets;
	}

	async merchantWiseReportHistory(
		query: MonitoringQuery,
		user: Partial<User | ApiKeyUser>,
		withHistory?: boolean,
		paginate?: boolean,
	) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);

		//Get the leads
		const leads = await (async () => {
			try {
				const leadsRes = await this.leadRepository.find({
					where: {
						tokenUserId: In(query.userIds),
						updatedAt: (() => {
							if (query.startTime && query.endTime) return Between(query.startTime, query.endTime);
							else if (query.startTime) return MoreThanOrEqual(query.startTime);
							else if (query.endTime) return LessThanOrEqual(query.endTime);
							else return undefined;
						})(),
					},
				});
				return leadsRes;
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot fetch Leads!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		})();
		if (!leads.length) return [];
		const leadsDict = _.keyBy(leads, "poiId");

		//error handling for pagination
		if (paginate) {
			if (!query?.limit || !query?.page)
				throw new HttpException(`'limit' OR 'page' missing!`, HttpStatus.BAD_REQUEST);
			if (Number(query.limit) <= 0) throw new HttpException(`Invalid limit!`, HttpStatus.BAD_REQUEST);
			if (Number(query.page) < 1) throw new HttpException(`Invalid page!`, HttpStatus.BAD_REQUEST);
			if (Number(query.page) > Math.ceil(Object.keys(leadsDict).length / Number(query.limit)))
				throw new HttpException(`page number out of bound!`, HttpStatus.BAD_REQUEST);
		}

		//For sorting
		let leadIds: number[] = [];
		if (query?.sortBy) {
			if (!query?.sortType) throw new HttpException(`'sortType' is missing!`, HttpStatus.BAD_REQUEST);

			if (!["id", "name", "address", "type"].includes(query.sortBy))
				throw new HttpException(`Invalid sorting option!`, HttpStatus.BAD_REQUEST);
			if (!["asc", "desc"].includes(query?.sortType))
				throw new HttpException(`'sortType' can only be 'asc' or 'desc'`, HttpStatus.BAD_REQUEST);
			await (async () => {
				try {
					const pois = await this.poiRepository.find({
						where: { id: In(Object.keys(leadsDict)) },
						order: { [query.sortBy]: query.sortType },
					});
					leadIds = pois.map((p) => Number(p.id));
				} catch (error) {
					console.log(error);
				}
			})();
		} else {
			leadIds = Object.keys(leadsDict).map((key) => Number(key));
		}

		const poiIDs = paginate
			? leadIds.slice((Number(query.page) - 1) * Number(query.limit), Number(query.page) * Number(query.limit))
			: leadIds.sort((a, b) => a - b);
		const userIDs = _.uniq(leads.map((l) => l.tokenUserId));

		//Get the pois
		const poiDict = await (async () => {
			try {
				const pois = await this.poiRepository.find({ where: { id: In(poiIDs) } });
				return _.keyBy(pois, "id");
			} catch (err) {
				console.error(err);
				throw new HttpException("Cannot fetch POIs!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		})();

		//Get the poi_details
		const poiDetailsDict = await (async () => {
			try {
				const poiDetails = await this.poiDetailRepository.find({ where: { poiId: In(poiIDs) } });
				return _.groupBy(poiDetails, "poiId");
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot fetch POI Details!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		})();

		//Get the users
		const userDict = await (async () => {
			try {
				if (!userIDs.length) return {};
				const usrRes: { id: number; firstName: string; lastName: string; team_id: number; name: string }[] =
					await this.connection.manager.query(`
						select "user".id, "user"."firstName","user"."lastName" , team.id team_id, team.name 
						from "user" join team on team.id = "user"."teamId" 
						where "user".id IN (${userIDs.join(",")})
						group by "user".id, "user"."firstName","user"."lastName" , team.id, team.name;
					`);
				return _.keyBy(usrRes, "id");
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot fetch Users!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		})();

		//Get the lead_status_updates
		const leadUpdatesDict = await (async () => {
			try {
				const leadStatusUpdates = await this.leadStatusUpdatesRepository.find({
					where: {
						poiId: In(poiIDs),
						tokenUserId: In(query.userIds),
					},
				});
				return _.groupBy(leadStatusUpdates, "poiId");
			} catch (error) {
				console.error(error);
			}
		})();

		const kpiDict = await (async () => {
			try {
				const kpis = await this.kpiRepository.find({
					where: {
						poiId: In(poiIDs),
						action: In(["Merchant Call", "Merchant Navigate"]),
						tokenUserId: In(query.userIds),
					},
				});
				return _.groupBy(kpis, "poiId");
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot fetch KPIs!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		})();

		const noteDict = await (async () => {
			try {
				const notes = await this.noteRepository.find({
					where: { poiId: In(poiIDs), tokenUserId: In(query.userIds) },
				});
				return _.groupBy(notes, "poiId");
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot fetch Notes!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		})();

		const remindeUpdatesDict = await (async () => {
			try {
				const reminders = await this.reminderRepository.find({
					where: { poiId: In(poiIDs), tokenUserId: In(query.userIds) },
				});
				const remindersDict = _.keyBy(reminders, "id");
				let reminderUpdates = await this.reminderUpdateRepository.find({
					where: { reminderId: In(Object.keys(remindersDict)) },
				});
				reminderUpdates = reminderUpdates.map((ru) => {
					// console.log(ru);
					const poiId = remindersDict[ru.reminderId].poiId;
					return { ...ru, poiId };
				});
				return _.groupBy(reminderUpdates, "poiId");
			} catch (error) {
				console.error(error);
				throw new HttpException("Cannot fetch Reminders!", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		})();

		const successFullCallsDict = await this.getSuccessfulCallsDict(poiIDs, userIDs);
		const leadHistories = [];
		for (const poiID of poiIDs) {
			if (!poiDict[poiID]) continue;
			const poi = (() => {
				const { id, name, address, type, latitude, longitude } = poiDict[poiID];
				return {
					id,
					name,
					address,
					type,
					geometry: {
						type: "Point",
						coordinates: [Number(longitude), Number(latitude)],
					},
				};
			})();

			const poi_details = (() => {
				const detailDict = {};
				for (const pd of poiDetailsDict[poiID]) {
					detailDict[pd.key] = pd.dataType === "number" ? Number(pd.unit) : pd.value;
				}
				return detailDict;
			})();

			const user = (() => {
				if (userDict[leadsDict[poiID].tokenUserId]) {
					const { id, firstName, lastName, team_id, name } = userDict[leadsDict[poiID].tokenUserId];
					return { id, firstName, lastName, teamId: Number(team_id), teamName: name };
				}
			})();
			const lead_details = (() => {
				const { status, visited, tags, remarks, comment, updatedAt } = leadsDict[poiID];
				const last_visit_confirmed_on = this.getFormattedActivity(
					leadUpdatesDict[poiID],
					kpiDict[poiID],
					noteDict[poiID],
					remindeUpdatesDict[poiID],
				)
					.activities.slice()
					.reverse()
					.find((activity) => activity.title === "Marked as Visited")?.timeStamp;
				const activities = withHistory
					? this.getFormattedActivity(
							leadUpdatesDict[poiID],
							kpiDict[poiID],
							noteDict[poiID],
							remindeUpdatesDict[poiID],
					  )
					: undefined;
				const activity = !withHistory
					? this.getFormattedActivity(
							leadUpdatesDict[poiID],
							kpiDict[poiID],
							noteDict[poiID],
							remindeUpdatesDict[poiID],
							successFullCallsDict[poiID],
							true,
					  )
					: undefined;
				return {
					status,
					visited: visited ? "Yes" : "No",
					tags,
					remarks,
					comment,
					updatedAt,
					last_visit_confirmed_on,
					...activities,
					...activity,
				};
			})();
			const leadHistoryObj = {
				...poi,
				poi_details,
				user,
				lead_details,
			};
			leadHistories.push(leadHistoryObj);
		}
		if (paginate) {
			return {
				count: Number(leadHistories.length),
				totalCount: Object.keys(leadsDict).length,
				page: Number(query.page),
				totalPages: Math.ceil(Object.keys(leadsDict).length / Number(query.limit)),
				data: leadHistories,
			};
		} else {
			return leadHistories;
		}
	}

	async getUpcomingReminders(query: UpcomingRemindersQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);
		const reminderForUsers = await (async () => {
			try {
				return await this.reminderRepository.find({
					where: {
						tokenUserId: In(query.userIds),
						isActive: true,
						isDeleted: false,
						createdAt: (() => {
							if (query.startTime && query.endTime) return Between(query.startTime, query.endTime);
							else if (query.startTime) return MoreThanOrEqual(query.startTime);
							else if (query.endTime) return LessThanOrEqual(query.endTime);
							else return undefined;
						})(),
						updatedAt: (() => {
							if (query.startTime && query.endTime) return Between(query.startTime, query.endTime);
							else if (query.startTime) return MoreThanOrEqual(query.startTime);
							else if (query.endTime) return LessThanOrEqual(query.endTime);
							else return undefined;
						})(),
					},
				});
			} catch (err) {
				throw new HttpException(
					"Could not fetch reminders for the specified userIds",
					HttpStatus.SERVICE_UNAVAILABLE,
				);
			}
		})();

		if (reminderForUsers.length === 0) {
			return [{ count: 0, time: "" }];
		}

		const sortedData = _.orderBy(
			reminderForUsers.map((r) => r.remindAt),
			function (date) {
				return moment(date);
			},
			"desc",
		);
		let brackets = query.brackets ?? 4;
		const startBracket = new Date(sortedData[sortedData.length - 1]);
		const endBracket = new Date(sortedData[0]);

		const diffDays = moment(endBracket).diff(moment(startBracket), "days");

		brackets = brackets > diffDays ? diffDays + 1 : brackets;
		const results = [];

		function divideDateRange(startDate, endDate, intervals) {
			const intervalDuration = Math.floor(moment(endDate).diff(moment(startDate)) / intervals);

			const dateIntervals = [];

			for (let i = 0; i <= intervals; i++) {
				const intervalStart = moment(startDate)
					.add(i * intervalDuration, "milliseconds")
					.toDate();
				const intervalEnd = moment(startDate)
					.add((i + 1) * intervalDuration, "milliseconds")
					.toDate();
				dateIntervals.push({ start: intervalStart, end: intervalEnd });
			}

			// Adjust the last interval end to match the actual end date
			dateIntervals[intervals - 1].end = endDate;

			return dateIntervals;
		}

		const timeRange = divideDateRange(startBracket, endBracket, brackets);
		for (let i = 0; i < brackets; i++) {
			const bracketStart = timeRange[i].start;
			const bracketEnd = timeRange[i].end;
			const resObjs = { count: 0, time: "" };
			const resObj = reminderForUsers.filter((reminder) => {
				const date = new Date(reminder.remindAt);
				return date >= new Date(bracketStart) && date <= new Date(bracketEnd);
			}).length;
			resObjs.count = resObj;
			resObjs.time = this.getTimePhrase(bracketStart, bracketEnd);
			results.push(resObjs);
		}

		return results;
	}

	async fetchLostOpportunities(query: LostOpportunityQuery, user: Partial<User | ApiKeyUser>) {
		if (!query?.userIds?.length) query.userIds = [Number(user.id)];
		if (query?.cascade) query.userIds = await this.getUsersUnderHirerchy(query.userIds);
		const lostLeadsForUsers = await (async () => {
			return await this.leadStatusUpdatesRepository.find({
				where: [
					{
						tokenUserId: In(query.userIds),
						status: "lost",
						createdAt: (() => {
							if (query.startTime && query.endTime) return Between(query.startTime, query.endTime);
							else if (query.startTime) return MoreThanOrEqual(query.startTime);
							else if (query.endTime) return LessThanOrEqual(query.endTime);
							else return undefined;
						})(),
					},
				],
			});
		})();
		const users = await (async () => {
			return await this.usersRepository.find({
				where: [
					{
						id: In(query.userIds),
					},
				],
			});
		})();
		if (!lostLeadsForUsers) return [];
		const lostLeadsDict = _.keyBy(lostLeadsForUsers, "poiId");
		const pois = await this._merchantService.getPOIDetailsByIDs(
			lostLeadsForUsers.map((lostLead) => lostLead.poiId),
		);

		const usersDict = _.keyBy(users, "id");

		const lostLeadDTOs = pois.map((poi) => {
			const { tokenUserId, id, poiId, remarks, comment, createdAt } = lostLeadsDict[poi.id];
			const lostDetails = { tokenUserId, id, poiId, remarks, comment, timestamp: createdAt };
			const userForThisLead = usersDict[tokenUserId];
			const userForThisLeadObj = {
				id: userForThisLead.id,
				firstname: userForThisLead.firstName,
				lastname: userForThisLead.lastName,
			};
			return { ...poi, lostDetails, userDetails: userForThisLeadObj };
		});

		return lostLeadDTOs;
	}

	getFormattedActivity(
		leadStatusUpdates: LeadStatusUpdates[],
		kpis: Kpi[],
		notes: Note[],
		reminderUpdates: ReminderUpdate[],
		successfullCalls?: number,
		onlyFirstAndLast?: boolean,
	) {
		enum ActivityType {
			leadStatusUpdate = "leadStatusUpdate",
			kpi = "kpi",
			note = "note",
			reminderUpdate = "reminderUpdate",
		}
		leadStatusUpdates = leadStatusUpdates?.map((lu) => {
			return {
				...lu,
				activityType: ActivityType.leadStatusUpdate,
			};
		});
		kpis = kpis?.map((kpi) => {
			return {
				...kpi,
				activityType: ActivityType.kpi,
			};
		});
		notes = notes?.map((note) => {
			return {
				...note,
				activityType: ActivityType.note,
			};
		});
		reminderUpdates = reminderUpdates?.map((reminderUpdate) => {
			return {
				...reminderUpdate,
				activityType: ActivityType.reminderUpdate,
			};
		});
		let rawActivities = _.orderBy(
			[...(leadStatusUpdates ?? []), ...(kpis ?? []), ...(notes ?? []), ...(reminderUpdates ?? [])],
			"createdAt",
			"asc",
		);

		if (onlyFirstAndLast) rawActivities = [rawActivities[0], rawActivities[rawActivities.length - 1]];
		let latestStatusUpdate: LeadStatusUpdates;
		let activities: {
			title: string;
			activity_number: number;
			timeStamp: Date;
			status: string;
			remarks: string;
			comment: string;
			remindAt?: Date;
		}[] = rawActivities.map((act, index) => {
			const activityType = act?.["activityType"];
			if (activityType === ActivityType.leadStatusUpdate) {
				latestStatusUpdate = act as LeadStatusUpdates;
				latestStatusUpdate.status = latestStatusUpdate.status
					?.split("_")
					?.map((s) => s.charAt(0).toUpperCase() + s.slice(1))
					?.join(" ");
				const title = (() => {
					const { status, visited } = latestStatusUpdate;
					if (status === "Reserved") return "Took Action";
					else if (visited) return "Marked as Visited";
					else if (visited == false) return "Marked as Not Visited";
					else return `Moved to ${status}`;
				})();
				return {
					title,
					activity_number: index + 1,
					timeStamp: latestStatusUpdate.createdAt,
					status: latestStatusUpdate.status?.length ? latestStatusUpdate.status : undefined,
					remarks: latestStatusUpdate.remarks?.length ? latestStatusUpdate.remarks : "--",
					comment: latestStatusUpdate.comment?.length ? latestStatusUpdate.comment : "--",
				};
			} else if (activityType === ActivityType.kpi) {
				const activity = act as Kpi;
				return {
					title: activity.action === "Merchant Call" ? "Called" : "Navigated",
					activity_number: index + 1,
					timeStamp: activity.createdAt,
					status: latestStatusUpdate?.status,
					remarks: "--",
					comment: "--",
				};
			} else if (activityType === ActivityType.reminderUpdate) {
				const activity = act as ReminderUpdate;
				const title = (() => {
					if (activity.updatedFields.includes("deleted")) return "Deleted Reminder";
					else if (activity.updatedFields.includes("reminder_created")) return "Created Reminder";
					else if (activity.updatedFields.includes("done")) return "Marked Reminder as Done";
					else if (activity.updatedFields.includes("date") || activity.updatedFields.includes("message"))
						return "Updated Reminder";
				})();
				return {
					title,
					activity_number: index + 1,
					timeStamp: activity.createdAt,
					status: latestStatusUpdate?.status,
					remarks: "--",
					comment: activity.message,
					remindAt: activity.remindAt,
				};
			} else if (activityType === ActivityType.note) {
				const activity = act as Note;
				return {
					title: "Added Note",
					activity_number: index + 1,
					timeStamp: activity.createdAt,
					status: latestStatusUpdate?.status,
					remarks: "--",
					comment: activity.note,
				};
			}
		});

		let handleVisitResponse = [];
		// Ommit repetitive records for "Visit Confirmed" after "Navigated Event"
		activities.forEach((r) => {
			const secondLastRecord = handleVisitResponse[handleVisitResponse.length - 2];
			const lastRecord = handleVisitResponse[handleVisitResponse.length - 1];
			if (
				secondLastRecord?.title === "Navigated" &&
				["Marked as Visited", "Marked as Not Visited"].includes(lastRecord?.title)
			) {
				if (r.title === "Marked as Not Visited") {
					handleVisitResponse.pop();
				} else if (r.title === "Marked as Visited") {
					handleVisitResponse[handleVisitResponse.length - 1] = r;
				} else handleVisitResponse.push(r);
			} else {
				handleVisitResponse.push(r);
			}
		});
		handleVisitResponse = handleVisitResponse.filter((f) => f?.eventDetails?.["visited"] !== false);

		activities = handleVisitResponse
			.filter((o) => o?.title != "Marked as Not Visited")
			.map((o, i) => {
				return { ...o, activity_number: i + 1 };
			});

		const total_calls = kpis?.filter((kpi) => kpi.action === "Merchant Call")?.length ?? 0;
		const total_navigations = kpis?.filter((kpi) => kpi.action === "Merchant Navigation")?.length ?? 0;
		const successful_calls_made = successfullCalls ?? 0;
		if (onlyFirstAndLast) {
			activities?.forEach((activity) => {
				delete activity?.activity_number;
			});
			return {
				total_calls,
				total_navigations,
				successful_calls_made,
				first_activity: activities[0],
				last_activity: activities[1],
			};
		} else
			return { total_calls, total_navigations, successful_calls_made, activities, first_activity: activities[0] };
	}

	async getSuccessfulCallsDict(poiIDs: number[], userIDs: number[]) {
		const successful_calls_dict = {};
		//Get prompt_logs
		const successfulCallsMade = await (async () => {
			try {
				const promptLogs: { poiId: number; node: number; count: number }[] = await this.promptLogRepository
					.createQueryBuilder(`prompt_logs`)
					.select([`"id", "poiId"`, "node"])
					.where(`"tokenUserId" IN (:...ids)`, { ids: userIDs })
					.andWhere(`"poiId" in (:...poiIds)`, { poiIds: poiIDs })
					.andWhere(
						() => {
							if (this.successful_call_nodes.length) return `node IN (:...nodeIds)`;
							else return `1=1`;
						},
						{ nodeIds: _.flattenDeep(this.successful_call_nodes) },
					)
					.orderBy("id")
					.getRawMany();
				return _.groupBy(promptLogs, "poiId");
			} catch (error) {
				console.error(error);
			}
		})();
		Object.keys(successfulCallsMade).forEach((poiId) => {
			const filteredSuccessCallsNodes = successfulCallsMade[poiId];
			let total_succ_calls = 0;
			filteredSuccessCallsNodes.forEach((currentPrompt, index) => {
				const nextPrompt = filteredSuccessCallsNodes[index + 1];
				if (nextPrompt) {
					const nodeSet = this.successful_call_nodes.find((nodeSet) =>
						nodeSet[0].includes(Number(currentPrompt.node)),
					);
					if (nodeSet) {
						if (nodeSet[1].includes(Number(nextPrompt.node))) {
							total_succ_calls++;
						}
					}
				}
			});
			successful_calls_dict[poiId] = Number(total_succ_calls);
		});
		return successful_calls_dict;
	}
}
