import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class ApiKeyUserCredits {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	userId: number;

	@ApiProperty()
	@Column({ default: 0 })
	creditsUsed: number;
}