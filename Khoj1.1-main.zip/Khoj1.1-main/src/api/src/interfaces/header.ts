import { ApiProperty } from "@nestjs/swagger";

export class Header {
	@ApiProperty()
	token: string;
}
