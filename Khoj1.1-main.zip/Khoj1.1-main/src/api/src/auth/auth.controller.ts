import { Controller, Get, Redirect, Query, Headers, HttpException, HttpStatus, Post, Body, Res } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { AuthService } from "./auth.service";
import { JwtService } from "@nestjs/jwt";
import * as moment from "moment";
import * as dotenv from "dotenv";
import { Header } from "../interfaces/header";
import { UserHistoryClass } from "src/interfaces/userHistory";
import { UserHistoryService } from "src/user-history/user-history.service";
import { RealIP } from "nestjs-real-ip";
import { ApiKeyUsersService } from "src/api-key-users/api-key-users.service";
import { AuthServiceV2 } from "./auth.service.v2";
import { User } from "src/users/users.entity";
import { TeamService } from "src/team/team.service";
import { Response } from "express";
import { error } from "console";
import { KeyCloakService } from "./keycloak.service";
import { SecurityService } from "src/security/security.service";

dotenv.config();

@ApiTags("auth")
@Controller("auth")
export class AuthController {
	constructor(
		private _authService: AuthService,
		private _jwtService: JwtService,
		private _userHistoryService: UserHistoryService,
		private authService: AuthService,
		private authServiceV2: AuthServiceV2,
		private teamService: TeamService,
		private keyCloakService: KeyCloakService,
		private securityService: SecurityService,
	) {}

	@Get("login")
	async Login(@Res({ passthrough: true }) res: Response) {
		const redirect_uri = encodeURIComponent(String(process.env.BASE_URL) + "/auth/redirect");
		const keyCloakRedirect = `${process.env.KC_AUTH_SERVER}/realms/${process.env.KC_REALM}/protocol/openid-connect/auth?client_id=${process.env.KC_CLIENT_ID}&redirect_uri=${redirect_uri}&response_type=code&scope=openid`;
		res.redirect(keyCloakRedirect);
	}

	@Get("redirect")
	@Redirect(process.env.FRONTEND_LOGIN_URL, 302)
	async keycloakAuthRedirect(@Query() query: { redirect_uri: string }) {
		const code = query["code"];
		try {
			const KCAccessToken = await this.keyCloakService.getKCAccessTokenFromAuthorizationCode(code);
			const KCUserInfo = await this.keyCloakService.getKCUserInfo(KCAccessToken.access_token);
			const existingUser = (await this.teamService.getUsers(null, null, null, KCUserInfo.email))[0];
			if (!existingUser || !existingUser.isAuthorized) throw error;
			const token = await this.authServiceV2.generateUserJWT(existingUser);
			const userHistory: UserHistoryClass = {
				userId: existingUser.id,
				loginTime: moment().toISOString(),
			};
			await this._userHistoryService.createOrUpdateUserHistory(userHistory);
			return { url: process.env.FRONTEND_LOGIN_URL + "?token=" + encodeURI(token) };
		} catch (err) {
			console.error("KC Redirect Error", JSON.stringify(err));
			return { url: process.env.FRONTEND_LOGIN_URL + "?token=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" };
		}
	}

	@Get("logout")
	async keycloakLogout(@Res({ passthrough: false }) res: Response) {
		const KCIdToken = await this.keyCloakService.createKCAdminIdToken();
		res.redirect(
			`${process.env.KC_AUTH_SERVER}/realms/${
				process.env.KC_REALM
			}/protocol/openid-connect/logout?id_token_hint=${KCIdToken}&post_logout_redirect_uri=${encodeURIComponent(
				process.env.FRONTEND_LOGIN_URL + "/auth/login",
			)}`,
		);
	}

	/*
	@Get("login")
	@UseGuards(AuthGuard("google"))
	async googleAuth(): Promise<void> {
		return null;
	}
	@Get("redirect")
	@UseGuards(AuthGuard("google"))
	@Redirect(process.env.FRONTEND_LOGIN_URL, 302)
	async googleAuthRedirect(@Req() req: JSON): Promise<RedirectObject> {
		const userObject = this._authService.googleLogin(req);
		const tempUser = {};
		const userHistory = new UserHistoryClass();
		const user = await this._userService.findOrCreateUser(userObject);
		if (user.status) {
			console.log(user);
			tempUser["id"] = user.id;
			tempUser["firstName"] = user.firstName;
			tempUser["lastName"] = user.lastName;
			tempUser["email"] = user.email;
			tempUser["roles"] = user.roles;
			tempUser["type"] = "token";
			tempUser["googleAuthToken"] = user.googleAccessToken;
			tempUser["picture"] = userObject.picture;
			tempUser["googleExp"] = moment().add(3599, "s").format("X");
			const time = new Date().getTime();
			console.log("Created Time: ", time);
			tempUser["createdTime"] = time;
			const token = this._jwtService.sign(tempUser);
			userHistory.userId = user.id;
			userHistory.loginTime = moment().toISOString();
			await this._authService.updateOrganisation(user);
			await this._userHistoryService.createOrUpdateUserHistory(userHistory);
			return { url: process.env.FRONTEND_LOGIN_URL + "?token=" + encodeURI(token) };
		} else {
			return { url: process.env.FRONTEND_LOGIN_URL + "?token=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" };
		}
	}
	*/

	@Get("ping")
	async ping(@Headers() header: Header) {
		await this.authService.ping(header?.["token"]);
		return { message: "Ping Registered Successfully!" };
	}

	@Post("signin/api-key")
	async generateApiKey(@Body() body, @RealIP() ip: string) {
		//const ip = req.connection.remoteAddress;
		console.log("Real Ip : ", ip);
		const user = await this._authService.generateApiKey(body);
		const { status, password, ...tempUser } = user;
		Object.assign(tempUser, {
			type: "apikey",
		});
		const token = this._jwtService.sign(tempUser, { expiresIn: "365d" });
		// await this._authService.updateApiKeyIp(token, ip);
		const response = { apikey: token };
		return response;
	}

	@Post("signup/api-key")
	async signUpNewApiKeyUser(@Body() body) {
		const user = await this._authService.signUpNewApiKeyUser(body);
		const tempUser = {};
		tempUser["id"] = user.id;
		tempUser["firstName"] = user.firstName;
		tempUser["lastName"] = user.lastName;
		tempUser["email"] = user.email;
		tempUser["roles"] = user.roles;
		const time = new Date().getTime();
		console.log("Created Time: ", time);
		tempUser["createdTime"] = time;
		const token = this._jwtService.sign(tempUser);
		const response = {};
		response["response"] = "Your Account will be authorized soon";
		return response;
	}

	// -------------------------------------------- Auth APIs Start --------------------------------------------
	@Post("signup")
	async signup(@Body() body: Partial<User>) {
		const message = await this.authServiceV2.userSignUp(body);
		return { message: "Sign Up Successful! " + message };
	}

	@Post("signin")
	async signin(@Body() body: Partial<User>) {
		const token = await this.authServiceV2.userSignIn(body.email, body.phoneNumber, body.password);
		return { token };
	}

	@Post("send-otp")
	async sendOtp(@Body() body: { email: string; phoneNumber: string }) {
		const message = await this.authServiceV2.sendUserVerificationOTP(body.email, body.phoneNumber);
		return { message: message };
	}

	@Post("verify-otp")
	async verifyOtp(@Body() body: { email: string; phoneNumber: string; otp: number }) {
		await this.authServiceV2.verifyUserOTP(body.email, body.phoneNumber, body.otp);
		return { message: "OTP Verification Successful!" };
	}

	@Post("reset-password")
	async resetPassword(@Body() body: { email: string; phoneNumber: string; password: string; otp: number }) {
		await this.authServiceV2.resetUserPassword(body.email, body.phoneNumber, body.password, body.otp);
		return { message: "Reset Password Successful!" };
	}

	@Get("decode")
	async decodeJwt(@Query() query: JSON): Promise<JSON> {
		if (query?.["token"]) {
			const user = await this.teamService.decodeUserJWT(query["token"]);
			return user as JSON;
		}

		return this.authService.decodeApiKeyUsers(query);
	}

	@Post("decode")
	async decodeJwtWithPost(@Body() body: JSON): Promise<JSON> {
		if (body?.["token"]) {
			const user = await this.teamService.decodeUserJWT(body["token"]);
			return user as JSON;
		}

		return this.authService.decodeApiKeyUsers(body);
	}

	@Post("app-login")
	async appLogin(@Body() body: { phoneNumber: string; code: string }) {
		const token = await this.authServiceV2.appLogin(body);
		return { token };
	}

	@Post("pwa-login")
	async pwaLogin(@Body() body: { data: string }) {
		const decryptedBody = this.securityService.decrypt<{ phoneNumber: string }>(body.data);
		const token = await this.authServiceV2.pwaLogin(decryptedBody);
		return { token };
	}

	@Get("app-logout")
	async logout(@Headers() headers) {
		const token = headers["token"];
		if (!token) throw new HttpException("Token Invalid!", HttpStatus.UNAUTHORIZED);
		await this.authService.blacklistToken(token);
		return { success: true };
	}
}
