import { ValidationArguments, ValidatorConstraint, ValidatorConstraintInterface } from "class-validator";

@ValidatorConstraint({ name: "string-or-number", async: false })
export class IsNumberOrString implements ValidatorConstraintInterface {
	validate(text: any) {
		if (typeof text !== "number" && typeof text !== "string") return false;

		const num = Number(text);
		if (Number.isNaN(num)) return false;
		return num > 0;
	}

	defaultMessage(args: ValidationArguments) {
		return args.property + " must be number or string";
	}
}
