import { Test, TestingModule } from '@nestjs/testing';
import { PoiRoutesController } from './poi-routes.controller';

describe('PoiRoutesController', () => {
  let controller: PoiRoutesController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PoiRoutesController],
    }).compile();

    controller = module.get<PoiRoutesController>(PoiRoutesController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
