import { Module } from '@nestjs/common';
import { HttpModule } from "@nestjs/axios";
import { JwtModule } from '@nestjs/jwt';
import { MongooseModule } from '@nestjs/mongoose';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CsvModule } from 'nest-csv-parser';
import { Answer } from 'src/answer/answer.entity';
import { ApiKeyOrganisation } from 'src/api-key-organisations/api-key-organisations.entity';
import { ApiKeyUserApiUsageHistory } from 'src/api-key-user-api-usage/api-key-user-api-usage.entity';
import { ApiKeyUserCredits } from 'src/api-key-users/api-key-users-credits.entity';
import { ApiKeyUser } from 'src/api-key-users/api-key-users.entity';
import { CsvUploadedFiles } from 'src/csv-processor/csv-upload.entity';
import { GlobalServiceService } from 'src/helpers/global-service/global-service.service';
import { GridService } from 'src/grid/grid.service';
import { Grid } from 'src/grid/grids.entity';
import { Indexmaster } from 'src/index-master/index-master.entity';
import { MerchantController } from 'src/merchant/merchant.controller';
import { MerchantService } from 'src/merchant/merchant.service';
import { MongoDatabaseModule } from 'src/helpers/mongo-database/mongo-database.module';
import { Organisation } from 'src/organisations/organisations.entity';
import { PoiDetail } from 'src/poi-details/poi-details.entity';
import { Poi } from 'src/poi/poi.entity';
import { PoiService } from 'src/poi/poi.service';
import { Poiexported } from 'src/poi/poisExported.entity';
import { PropertyDetail } from 'src/property-detail/property-detail.entity';
import { PropertyDetailService } from 'src/property-detail/property-detail.service';
import { Property } from 'src/property/property.entity';
import { PropertyService } from 'src/property/property.service';
import { Question } from 'src/question/question.entity';
import { PoiGrid } from 'src/relations/poi-grid/poi-grid.entity';
import { PoiGridService } from 'src/relations/poi-grid/poi-grid.service';
import { PropertyGrid } from 'src/relations/property-grid/property-grid.entity';
import { PropertyGridService } from 'src/relations/property-grid/property-grid.service';
import { UserGrid } from 'src/relations/user-grid/user-grid.entity';
import { RolesGuardService } from 'src/helpers/roles-guard/roles-guard.service';
import { ShapeDetail } from 'src/shape-details/shape-details.entity';
import { Shape } from 'src/shape/shape.entity';
import { DemoShapesDBSchema } from 'src/shape/shape.schema';
import { ShapeService } from 'src/shape/shape.service';
import { Shapeindex } from 'src/shape/shapeIndex.entity';
import { TargetDetail } from 'src/target-details/target-details.entity';
import { UserApiUsageHistory } from 'src/user-api-usage-history/user-api-usage-history.entity';
import { UserCredits } from 'src/user-history/user-credits.entity';
import { User } from 'src/users/users.entity';
import { WorkItem } from 'src/work-item/work-item.entity';
import { WorkItemService } from 'src/work-item/work-item.service';
import { ScorecardController } from './scorecard.controller';
import { UserMerchant } from 'src/merchant/user-merchant.entity';
import { ApiKeyIp } from 'src/auth/apiKey-ip.entity';
import { UserIdIp } from 'src/auth/userId-ip.entity';
import { CustomController } from './custom.controller';
import { ApiKeyUserMerchant } from 'src/merchant/api-key-user-merchant.entity';
import { Team } from 'src/team/team.entity';
import { Lead } from 'src/leads/leads.entity';
import { POIFilter, POIFilterUserTeam } from 'src/poi-filter/poi-filter.entity';

@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		}),
		HttpModule.register({
			timeout: 100000,
			maxRedirects: 100
		}),
		TypeOrmModule.forFeature([
			WorkItem,
			Poi,
			Grid,
			PoiGrid,
			Property,
			User,
			Team,
			PropertyGrid,
			UserGrid,
			PropertyDetail,
			Indexmaster,
			Answer,
			Question,
			PoiDetail,
			Poiexported,
			TargetDetail,
			CsvUploadedFiles,
			Shape,
			Organisation,
			UserApiUsageHistory,
			UserCredits,
			Shapeindex,
			ShapeDetail,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyUserCredits,
			ApiKeyUserApiUsageHistory,
			UserMerchant,
			ApiKeyUserMerchant,
			ApiKeyIp,
			UserIdIp,
			Lead,
			POIFilter,
			POIFilterUserTeam,
		]),
		CsvModule,
		MongooseModule.forFeature([{ name: 'DemoShapesDB', schema: DemoShapesDBSchema }]),
		MongoDatabaseModule,
	],
	controllers: [ScorecardController, CustomController],
	providers: [
		MerchantService,
		PoiService,
		GridService,
		PoiGridService,
		PropertyService,
		PropertyGridService,
		WorkItemService,
		PropertyDetailService,
		GlobalServiceService,
		RolesGuardService,
		ShapeService,
	],
})
export class ScorecardModule {}
