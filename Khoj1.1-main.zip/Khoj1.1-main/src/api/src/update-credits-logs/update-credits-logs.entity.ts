import { ApiProperty } from "@nestjs/swagger";
import { Operation } from "src/interfaces/organisation";
import { Entity, Column, PrimaryGeneratedColumn, PrimaryColumn, CreateDateColumn } from "typeorm";

@Entity()
export class UpdateCreditsLogs {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column({type: "integer"})
	organisationId: number;

	@ApiProperty()
    @Column()
    organisationType: OrganisationType;

    @ApiProperty()
    @Column({type:"decimal"})
    oldCredits: number;

    @ApiProperty()
    @Column({type: "decimal"})
    credits: number;

    @ApiProperty()
    @Column()
    operation: Operation;

    @ApiProperty()
    @Column({type: "integer"})
    userId: number;

    @ApiProperty()
    @Column()
    userType: string;

    @ApiProperty()
    @CreateDateColumn()
    createdAt: Date;
}

export enum OrganisationType {
    token = "token",
    apikey = "apikey"
}
