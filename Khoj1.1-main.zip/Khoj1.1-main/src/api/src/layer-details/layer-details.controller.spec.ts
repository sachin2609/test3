import { Test, TestingModule } from '@nestjs/testing';
import { LayerDetailsController } from './layer-details.controller';

describe('LayerDetailsController', () => {
  let controller: LayerDetailsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [LayerDetailsController],
    }).compile();

    controller = module.get<LayerDetailsController>(LayerDetailsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
