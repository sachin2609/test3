export class PlacesQuery {
    address?: string;
    radius: number;
    lat?:number;
    lng?:number;
}