import { Controller, Get, Body, Post, Param, Query } from "@nestjs/common";
import { ApiBody, ApiHeader, ApiParam, ApiProperty, ApiQuery, ApiResponse } from "@nestjs/swagger";
import { ApiKeyUsersService } from "./api-key-users.service";
import { ApiKeyUser } from "./api-key-users.entity";
import { UsersQuery } from "../interfaces/users";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
class UserUpdate {
	@ApiProperty()
	id: number;

	@ApiProperty()
	roles: string[];
}

@Controller('api-key-users')
export class ApiKeyUsersController {
	constructor(
		private _apiKeyUsersService: ApiKeyUsersService
	) {}

	//@Roles("basic")
	@Post()
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Save multiple Users" })
	@ApiBody({ type: ApiKeyUser })
	async create(@Body() body: ApiKeyUser[]): Promise<ApiKeyUser[]> {
		return await this._apiKeyUsersService.saveAll(body);
	}

	@Roles("basic")
	@Get()
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "find multiple users" })
	@ApiQuery({ name: "query", type: UsersQuery })
	async list(@Query() query: UsersQuery): Promise<ApiKeyUser[]> {
		// find by code | category | category class
		return await this._apiKeyUsersService.queryUsers(query);
	}

	@Roles("basic")
	@Get(":id")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "find user by Id" })
	@ApiParam({ type: UserUpdate, name: "parameter" })
	async get(@Param() params: UserUpdate): Promise<ApiKeyUser[]> {
		return await this._apiKeyUsersService.queryUsers({
			id: params.id
		} as UsersQuery);
	}

	@Roles("basic")
	@Post("update")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Update User" })
	@ApiBody({ type: UsersQuery })
	async update(@Body() body: UsersQuery[]): Promise<ApiKeyUser[]> {
		return await Promise.all(
			body.map(async eachUser => {
				return await this._apiKeyUsersService.findOrCreateUser(eachUser);
			})
		);
	}

}
