import { Injectable } from "@nestjs/common";
import { Repository, In } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { InsightGrid } from "./insight-grid.entity";
import { Insight } from "../../insight/insight.entity";
import { GridService } from "../../grid/grid.service";
import { Property } from "../../property/property.entity";
import { Grid } from "../../grid/grids.entity";
import * as geohash from "ngeohash";
import * as tf from "@turf/turf";
import { PoiGrid } from "../poi-grid/poi-grid.entity";
import { Poi } from "../../poi/poi.entity";
import { AggregateQuery, AggregateType } from "../../interfaces/insightGrid";
import { Indexmaster } from '../../index-master/index-master.entity';
@Injectable()
export class InsghtGridService {
	constructor(
		@InjectRepository(InsightGrid) private insightGridRepository: Repository<InsightGrid>,
		@InjectRepository(Insight) private insightRepository: Repository<Insight>,
		@InjectRepository(Property) private propertyRepository: Repository<Property>,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		@InjectRepository(PoiGrid) private poiGridRepository: Repository<PoiGrid>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(Indexmaster) private indexMasterRepository: Repository<Indexmaster>,
		private _gridService: GridService
	) {}

	async populate(): Promise<void> {
		const insights = await this.insightRepository.find();
		for await (const eachInsight of insights) {
			console.log("lat", eachInsight.latitude);
			console.log("lon", eachInsight.longitude);
			const grid = await this._gridService.nearestGrid(eachInsight.latitude, eachInsight.longitude);
			const tempInsightGrid = new InsightGrid();
			tempInsightGrid.gridId = grid["id"];
			tempInsightGrid.insightId = eachInsight.id;
			if (grid["value"] > 0.9) {
				console.log("yes");
				await this.insightGridRepository.save(tempInsightGrid);
			}
		}
	}

	async search(latitude: number, longitude: number): Promise<Insight[]> {
		const point = tf.point([latitude, longitude]);
		console.log("point is", point);
		const distance = 0.5;
		const topLeft = tf.destination(point, distance, -160);
		console.log("distance is", distance);
		const bottomRight = tf.destination(point, distance, 30);
		console.log("topleft", topLeft);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		console.log(
			"latlongs are",
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1]
		);
		try {
			const tempGrid = await this.gridRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.select("grid.id")
				.getMany();

			const tempGridIds = tempGrid.map(eachGrid => {
				return eachGrid.id;
			});
			const insightGridsReltions = await this.insightGridRepository.find({
				where: {
					gridId: In(tempGridIds)
				}
			});
			const insightGridsReltionsIds = insightGridsReltions.map(eachRelation => {
				return eachRelation.insightId;
			});
			console.log("grids are");
			return await this.insightRepository.find({
				where: {
					id: In(insightGridsReltionsIds)
				}
			});
		} catch (error) {
			return [];
		}
	}

	async aggregate(query: AggregateQuery): Promise<unknown> {
		let eachTarget;
		if (query.propertyId) {
			eachTarget = await this.propertyRepository.findOne({ where: { id: query.propertyId }});
		} else if (query.gridId) {
			eachTarget = await this.gridRepository.findOne({ where: { id: query.gridId }});
		}
		const point = tf.point([eachTarget.latitude, eachTarget.longitude]);
		console.log("point is", point);
		const distance = 0.5;
		const topLeft = tf.destination(point, distance, -160);
		console.log("distance is", distance);
		const bottomRight = tf.destination(point, distance, 30);
		console.log("topleft", topLeft);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		console.log(
			"latlongs are",
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1]
		);
		try {
			const tempGrid = await this.gridRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.select("grid.id")
				.getMany();

			const tempGridIds = tempGrid.map(eachGrid => {
				return eachGrid.id;
			});
			const insightGridsReltions = await this.insightGridRepository.find({
				where: {
					gridId: In(tempGridIds)
				}
			});
			const insightGridsReltionsIds = insightGridsReltions.map(eachRelation => {
				return Number(eachRelation.insightId);
			});
			const responseObject = {};
			if (query.type === AggregateType.categorise) {
				const resp = await this.insightRepository
					.createQueryBuilder("insight")
					.select("insight." + query.category)
					.distinct(true)
					.getRawMany();
				await Promise.all(
					resp.map(async eachObj => {
						const category = eachObj[Object.keys(eachObj)[0]];

						const categoryCount = await this.insightRepository
							.createQueryBuilder("insight")
							.where("insight.id IN (:...ids)", { ids: insightGridsReltionsIds })
							.andWhere("insight." + query.category + " = :category", { category: category })
							.getCount();
						const respObj = {};
						respObj[category] = categoryCount;
						responseObject[category] = categoryCount;
						return respObj;
					})
				);
				console.log("returning with ", responseObject);
				return responseObject;
			}
			if (query.type === AggregateType.count) {
				const categoryCount = await this.insightRepository
					.createQueryBuilder("insight")
					.where("insight.id IN (:...ids)", { ids: insightGridsReltionsIds })
					.select("SUM(insight." + query.category + ")", "sum")
					.getRawOne();
				console.log("category count is ", categoryCount);
				return categoryCount;
			}
			if (query.type === AggregateType.average) {
				const categoryCount = await this.insightRepository
					.createQueryBuilder("insight")
					.where("insight.id IN (:...ids)", { ids: insightGridsReltionsIds })
					.select("AVG(insight." + query.category + ")", "avg")
					.getRawOne();
				console.log("category count is ", categoryCount);
				return categoryCount;
			}
		} catch (error) {
			console.log("error is", error);
			return [];
		}
	}

	async getSocietyCountAgainstAffluenceClass(query: AggregateQuery): Promise<unknown> {
		let eachTarget;
		if (query.propertyId) {
			eachTarget = await this.propertyRepository.findOne({ where: { id: query.propertyId }});
		} else if (query.gridId) {
			eachTarget = await this.gridRepository.findOne({ where: { id: query.gridId }});
		}
		const point = tf.point([eachTarget.latitude, eachTarget.longitude]);
		console.log("point is", point);
		const distance = 0.5;
		const topLeft = tf.destination(point, distance, -160);
		console.log("distance is", distance);
		const bottomRight = tf.destination(point, distance, 30);
		console.log("topleft", topLeft);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		console.log(
			"latlongs are",
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1]
		);
		try {
			const tempGrid = await this.gridRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.select("grid.id")
				.getMany();

			const tempGridIds = tempGrid.map(eachGrid => {
				return eachGrid.id;
			});
			const poiGridsRelations = await this.poiGridRepository.find({
				where: {
					gridId: In(tempGridIds)
				}
			});
			const poiGridsRelationIds = poiGridsRelations.map(eachPoi => {
				return eachPoi.poiId;
			});
			const poiGridRelationDict = {};
			poiGridsRelations.forEach(eachRelation => {
				poiGridRelationDict[eachRelation.poiId] = eachRelation.gridId;
			});
			const pois = await this.poiRepository.find({
				where: {
					id: In(poiGridsRelationIds),
					type: "society"
				}
			});
			console.log("total societies", pois.length);
			const response = {};
			await Promise.all(
				pois.map(async eachPoi => {
					try {
						const insightGridRltn = await this.insightGridRepository.findOne({ where: {
							gridId: poiGridRelationDict[eachPoi.id]
					}});
						const insight = await this.insightRepository.findOne({ where: {
							id: insightGridRltn.insightId
					}});
						if (!response[insight.affluenceCategory]) {
							response[insight.affluenceCategory] = 1;
						} else {
							response[insight.affluenceCategory] += 1;
						}
						console.log(insight.affluenceCategory);
					} catch (error) {
						console.log(error);
						if (!response["0.0"]) {
							response["0.0"] = 1;
						} else {
							response["0.0"] += 1;
						}
					}
				})
			);
			return response;
		} catch (error) {
			console.log(error);
		}
	}
	async getSocietyCountAgainstAffluenceClassLatLng(
		latitude: number,
		longitude: number
	): Promise<unknown> {
		const point = tf.point([latitude, longitude]);
		console.log("point is", point);
		const distance = 0.5;
		const topLeft = tf.destination(point, distance, -160);
		console.log("distance is", distance);
		const bottomRight = tf.destination(point, distance, 30);
		console.log("topleft", topLeft);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		console.log(
			"latlongs are",
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1]
		);
		try {
			const tempGrid = await this.gridRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.select("grid.id")
				.getMany();

			const tempGridIds = tempGrid.map(eachGrid => {
				return eachGrid.id;
			});
			const poiGridsRelations = await this.poiGridRepository.find({
				where: {
					gridId: In(tempGridIds)
				}
			});
			const poiGridsRelationIds = poiGridsRelations.map(eachPoi => {
				return eachPoi.poiId;
			});
			const poiGridRelationDict = {};
			poiGridsRelations.forEach(eachRelation => {
				poiGridRelationDict[eachRelation.poiId] = eachRelation.gridId;
			});
			const pois = await this.poiRepository.find({
				where: {
					id: In(poiGridsRelationIds),
					type: "society"
				}
			});
			console.log("total societies", pois.length);
			const response = {};
			await Promise.all(
				pois.map(async eachPoi => {
					try {
						const insightGridRltn = await this.insightGridRepository.findOne({ where: {
							gridId: poiGridRelationDict[eachPoi.id]
					}});
						const insight = await this.insightRepository.findOne({ where: {
							id: insightGridRltn.insightId
					}});
						if (!response[insight.affluenceCategory]) {
							response[insight.affluenceCategory] = 1;
						} else {
							response[insight.affluenceCategory] += 1;
						}
						console.log(insight.affluenceCategory);
					} catch (error) {
						console.log(error);
						if (!response["0.0"]) {
							response["0.0"] = 1;
						} else {
							response["0.0"] += 1;
						}
					}
				})
			);
			return response;
		} catch (error) {
			console.log(error);
		}
	}

async aggregateLatLon(query: AggregateQuery): Promise<unknown> {
		const point = tf.point([query.latitude, query.longitude]);
		console.log("point is", point);
		const distance = query.radius ? query.radius / 2 : 0.5;
		const topLeft = tf.destination(point, distance, -160);
		console.log("distance is", distance);
		const bottomRight = tf.destination(point, distance, 30);
		console.log("topleft", topLeft);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		console.log(
			"latlongs are",
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1]
		);
		try {
			const tempGrid = await this.gridRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.select("grid.id")
				.getMany();

			const tempGridIds = tempGrid.map(eachGrid => {
				return eachGrid.id;
			});
			const insightGridsReltions = await this.insightGridRepository.find({
				where: {
					gridId: In(tempGridIds)
				}
			});
			const insightGridsReltionsIds = insightGridsReltions.map(eachRelation => {
				return Number(eachRelation.insightId);
			});
			const responseObject = {};
			responseObject['0 - 0.2'] = 0;
			responseObject['0.2 - 0.4'] = 0;
			responseObject['0.4 - 0.6'] = 0;
			responseObject['0.6 - 0.8'] = 0;
			responseObject['0.8 - 1'] = 0;
			if (query.type === AggregateType.categorise) {
				let poiGrids;
				if (query.poiType) {
					const poiObjects = await this.poiRepository.find({ where: {
						type: query.poiType
				}});
					const poiIds = poiObjects.map(eachPoiObject => {
						return eachPoiObject.id
					});
					poiGrids = await this.poiGridRepository.find({ where: {
						gridId: In(tempGridIds),
						poiId: In(poiIds)
				}});
				} else {
					poiGrids = await this.poiGridRepository.find({ where: {
						gridId: In(tempGridIds)
				}});
				}
				await Promise.all(
					poiGrids.map(async eachPoiGridRelation => {
						const indexes = await this.indexMasterRepository.find({
							where: {
								grid: eachPoiGridRelation.gridId,
								indexName: query.category
							}
						});
						const percentile = indexes[0].percentile;
						if (0 < percentile && percentile < 0.2) {
							responseObject['0 - 0.2'] += 1;
						} else if (0.2 < percentile && percentile < 0.4) {
							responseObject['0.2 - 0.4'] += 1;
						} else if (0.4 < percentile && percentile < 0.6) {
							responseObject['0.4 - 0.6'] += 1;
						} else if (0.6 < percentile && percentile < 0.8) {
							responseObject['0.6 - 0.8'] += 1;
						} else if (0.8 < percentile && percentile < 1) {
							responseObject['0.8 - 1'] += 1;
						}	
					})
				);
				return responseObject;
			}
			if (query.type === AggregateType.count) {
				const categoryCountIndex = await this.indexMasterRepository
					.createQueryBuilder("indexmaster")
					.where("indexmaster.grid In (:...ids)", { ids: tempGridIds })
					.andWhere('indexmaster."indexName" = :category', { category: query.category })
					.select("SUM(indexmaster.indexValue)", "sum")
					.getRawOne();
				return categoryCountIndex;
			}
			if (query.type === AggregateType.average) {
				const categoryCount = await this.indexMasterRepository
					.createQueryBuilder("indexmaster")
					.where("indexmaster.grid In (:...ids)", { ids: tempGridIds })
					.andWhere('indexmaster."indexName" = :category', { category: query.category })
					.select("AVG(indexmaster.indexValue)", "avg")
				console.log("category count is ", categoryCount);
				return categoryCount;
			}
		} catch (error) {
			console.log("error is", error);
			return [];
		}
	}
}
