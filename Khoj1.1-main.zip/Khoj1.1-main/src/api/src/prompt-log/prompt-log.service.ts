import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { PromptLog } from "./prompt-log.entity";
import { Repository } from "typeorm";
import { AddPromptLogDto, FetchPromptLogDto } from "src/interfaces/prompt-log";
import { Poi } from "src/poi/poi.entity";
import { isArray } from "lodash";
import moment = require("moment");

@Injectable()
export class PromptLogService {
	constructor(
		@InjectRepository(PromptLog) private promptLogRepository: Repository<PromptLog>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
	) {}

	async createPromptLog(query: AddPromptLogDto) {
		if (!query.poiId) throw new HttpException("Please provide a poiId", HttpStatus.BAD_REQUEST);

		// Check if given POI exists
		const existingPoi = await (async () => {
			try {
				return await this.poiRepository.findOne({ where: { id: query.poiId } });
			} catch (error) {
				console.log(error);
			}
		})();
		if (!existingPoi) throw new HttpException(`POI with id : ${query.poiId} doesnt exist!`, HttpStatus.BAD_REQUEST);

		try {
			await this.promptLogRepository.save(query);
		} catch (err) {
			console.error(err);
			throw new HttpException("Cannot create a prompt log", HttpStatus.SERVICE_UNAVAILABLE);
		} finally {
			return {
				message: "Prompt logged successfully",
			};
		}
	}
	async fetchPromptLog(query: FetchPromptLogDto) {
		if (!query.poiId || !isArray(query.poiId) || query?.poiId?.length < 1)
			throw new HttpException("poiId is missing", HttpStatus.BAD_REQUEST);
		const promptLogQuery = this.promptLogRepository.createQueryBuilder("prompt_log");

		if (query?.startDate) {
			promptLogQuery.andWhere("prompt_log.createdAt >= :startDate", {
				startDate: moment(query.startDate).format(),
			});
		}

		if (query?.endDate) {
			promptLogQuery.andWhere("prompt_log.createdAt <= :endDate", {
				endDate: moment(query.endDate).format(),
			});
		}

		if (query?.poiId) {
			promptLogQuery.andWhere("prompt_log.poiId IN (:...poiId)", { poiId: query?.poiId });
		}

		promptLogQuery.andWhere("prompt_log.tokenUserId IN (:...userId) OR prompt_log.apiKeyUserId IN (:...userId)", {
			userId: query?.userId,
		});

		return await promptLogQuery.getMany();
	}
}
