import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Reminder } from "./reminders.entity";
import { ReminderQuery } from "src/interfaces/reminders";
import { DataSource, Repository } from "typeorm";
import { Poi } from "src/poi/poi.entity";
import * as _ from "lodash";
import { ReminderUpdate } from "src/reminders/reminders.entity";
import moment = require("moment");
import { MerchantService } from "src/merchant/merchant.service";

@Injectable()
export class RemindersService {
	constructor(
		@InjectRepository(Reminder) private remindersRepository: Repository<Reminder>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(ReminderUpdate) private reminderUpdateRepository: Repository<ReminderUpdate>,
		private _merchantService: MerchantService,
		private connection: DataSource,
	) {}

	async fetchReminder(query: ReminderQuery) {
		let reminders = [];
		const { startDate, endDate, userId, poiId } = query;
		try {
			const formattedStartDate = startDate ? new Date(startDate).toISOString().split("T")[0] : null;
			const formattedEndDate = endDate ? new Date(endDate).toISOString().split("T")[0] : null;
			const remindersQuery = this.remindersRepository.createQueryBuilder("reminder");

			remindersQuery.where(`reminder."isDeleted" = false`);

			remindersQuery.andWhere(`reminder."isActive" = true`);

			if (startDate) {
				remindersQuery.andWhere(`reminder."createdAt" >= TO_TIMESTAMP(:startDate, 'YYYY-MM-DD')`, {
					startDate: formattedStartDate,
				});
			}

			if (endDate) {
				remindersQuery.andWhere(`reminder."updatedAt" <= TO_TIMESTAMP(:endDate, 'YYYY-MM-DD')`, {
					endDate: formattedEndDate,
				});
			}

			if (poiId) {
				remindersQuery.andWhere(`reminder."poiId" IN (:...poiId)`, { poiId });
			}

			remindersQuery.andWhere(
				`reminder."tokenUserId" IN (:...userId) OR reminder."apiKeyUserId" IN (:...userId)`,
				{
					userId,
				},
			);

			reminders = await remindersQuery.getMany();
			if (!reminders.length) return [];
			const lastContacedDict = await (async () => {
				try {
					const resFromKpi: { action: string; poiId: number; createdAt: string }[] = await this.connection
						.query(`
						WITH ranked_actions AS (
  							SELECT "poiId", action, "createdAt", ROW_NUMBER() OVER (PARTITION BY "poiId" ORDER BY "createdAt" DESC) AS row_num
  							FROM kpi
  							WHERE "poiId" IN (${reminders.map((r) => Number(r.poiId)).join(",")})
  							AND action IN ('Merchant Call', 'Merchant Navigate')
						)				
						SELECT "poiId", action, "createdAt"
						FROM ranked_actions
						WHERE row_num = 1;
					`);
					return _.groupBy(resFromKpi, "poiId");
				} catch (error) {
					console.error(error);
					return {};
				}
			})();
			reminders.forEach((r) => {
				try {
					const lastContactRecord = lastContacedDict?.[r?.poiId]?.[0];
					if (lastContactRecord) {
						const lastCallRecord = lastContactRecord.action == "Merchant Call";
						const diff = moment(Date.now()).diff(lastContactRecord.createdAt, "days");
						const diffString = diff > 0 ? `${diff} days ago` : "today";
						r["lastContacted"] = `${lastCallRecord ? "Called" : "Navigated"} ${diffString}`;
					} else {
						r["lastContacted"] = `Not contacted yet!`;
					}
				} catch (error) {
					console.error(error);
				}
			});
		} catch (err) {
			console.error(err);
			throw new HttpException(`Could not fetch reminders`, HttpStatus.SERVICE_UNAVAILABLE);
		} finally {
			return reminders;
		}
	}

	isDateFormatValid(dateString: Date): boolean {
		const format = "YYYY-MM-DD";
		const date = moment(dateString, format, true); // The 'true' argument enables strict parsing

		return date.isValid();
	}

	async fetchReminderswithPoiDetails(query: ReminderQuery) {
		const reminders = await this.fetchReminder(query);
		const reminderDict = _.keyBy(reminders, "poiId");
		const pois = await this._merchantService.getPOIDetailsByIDs(reminders.map((reminder) => reminder.poiId));
		const reminderDTOs = pois.map((poi) => {
			const { id, isActive, remindAt, message, tokenUserId, apiKeyUserId, createdAt, updatedAt, lastContacted } =
				reminderDict[poi.id];
			const reminderDetails = {
				id,
				isActive,
				remindAt,
				message,
				tokenUserId,
				apiKeyUserId,
				createdAt,
				updatedAt,
				lastContacted,
			};
			return { ...poi, reminderDetails };
		});

		return { count: reminderDTOs.length, data: reminderDTOs };
	}

	async createReminder(query: Partial<Reminder> & { updatedFields?: string[] }) {
		if (!query.tokenUserId && !query.apiKeyUserId)
			throw new HttpException(`'tokenUserId' or 'apiKeyUserId' is needed!`, HttpStatus.BAD_REQUEST);
		if (!query.message) throw new HttpException(`'message' missing!`, HttpStatus.BAD_REQUEST);
		if (!query.poiId) throw new HttpException(`'poiId' missing!`, HttpStatus.BAD_REQUEST);
		if (!this.isDateFormatValid(query.remindAt))
			throw new HttpException("Date string format not applicable", HttpStatus.BAD_REQUEST);
		if (typeof query.remindAt !== "string")
			throw new HttpException("Format of remindAt time not correct", HttpStatus.BAD_REQUEST);
		const existingPoi = await (async () => {
			try {
				return await this.poiRepository.findOne({ where: { id: Number(query.poiId) } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (!existingPoi) throw new HttpException(`Invalid 'poiId'!`, HttpStatus.BAD_REQUEST);

		const queryRunner = this.connection.createQueryRunner();
		await queryRunner.connect();
		await queryRunner.startTransaction();

		const existingReminders: Reminder[] = await (async () => {
			try {
				return await this.remindersRepository.find({ where: { poiId: query.poiId } });
			} catch (err) {
				console.error(err);
			}
		})();

		if (
			existingReminders?.find(
				(existingReminder) => existingReminder?.isDeleted === false && existingReminder?.isActive === true,
			)
		) {
			throw new HttpException("Reminder for this poiId already exists", HttpStatus.FORBIDDEN);
		}

		try {
			const reminderObj: Reminder = queryRunner.manager.create(Reminder, {
				...query,
				isDeleted: false,
				isActive: true,
			});
			const reminder = await queryRunner.manager.save<Reminder>(reminderObj);
			const reminderUpdateObject: ReminderUpdate = {
				reminderId: reminder.id,
				updatedFields: !query.updatedFields ? ["reminder_created"] : query.updatedFields,
				message: reminder.message,
				isActive: reminder.isActive,
				remindAt: reminder.remindAt,
			};
			const reminderUpdate = queryRunner.manager.create(ReminderUpdate, reminderUpdateObject);

			await queryRunner.manager.save<ReminderUpdate>(reminderUpdate);
			await queryRunner.commitTransaction();
		} catch (error) {
			console.error(error);
			await queryRunner.rollbackTransaction();
			return { response: `Failed !` };
		} finally {
			await queryRunner.release();
			return { response: `Reminder Created Successfully!` };
		}
	}

	async editReminder(query: Partial<Reminder> & { updatedFields: string[] }, updateActive?: boolean) {
		if (!query.id) throw new HttpException(`'id' missing!`, HttpStatus.BAD_REQUEST);
		if (typeof query.id !== "number")
			throw new HttpException("reminderid should be number", HttpStatus.BAD_REQUEST);
		if (query.remindAt) {
			if (!this.isDateFormatValid(query?.remindAt))
				throw new HttpException("Date not formatted properly", HttpStatus.BAD_REQUEST);
		}
		const existingReminder = await (async () => {
			try {
				return await this.remindersRepository.findOne({ where: { id: Number(query.id) } });
			} catch (error) {
				console.error(error);
			}
		})();
		if (!existingReminder || existingReminder.isDeleted)
			throw new HttpException(`Invalid id!`, HttpStatus.BAD_REQUEST);
		const queryRunner = this.connection.createQueryRunner();
		await queryRunner.connect();
		await queryRunner.startTransaction();
		try {
			const newRem = _.merge({}, existingReminder, query);
			delete newRem.createdAt;
			delete newRem.updatedAt;
			const updatedRemider = queryRunner.manager.create(Reminder, newRem);
			const reminderUpdateObject: ReminderUpdate = {
				reminderId: updatedRemider.id,
				updatedFields: query.updatedFields,
				message: updatedRemider.message,
				isActive: updatedRemider.isActive,
				remindAt: updatedRemider.remindAt,
			};

			const reminderUpdate = queryRunner.manager.create(ReminderUpdate, reminderUpdateObject);
			await queryRunner.manager.save<Reminder>(updatedRemider);
			await queryRunner.manager.save<ReminderUpdate>(reminderUpdate);
			await queryRunner.commitTransaction();
		} catch (error) {
			console.error(error);
			await queryRunner.rollbackTransaction();
			return { response: `Failed!` };
		} finally {
			await queryRunner.release();
			return {
				response: updateActive ? `Reminder Marked as done Successfully!` : `Reminder Updated Successfully`,
			};
		}
	}

	async deleteReminder(query: Partial<Reminder>) {
		if (!query.id && !query.poiId)
			throw new HttpException(`Please provide either poiId or reminder id`, HttpStatus.BAD_REQUEST);
		const existingReminder = await (async () => {
			try {
				const poiId = !isNaN(query?.poiId) && query.poiId > 0 ? query.poiId : undefined;
				const id = isNaN(poiId) ? query.id : undefined;
				return await this.remindersRepository.findOne({
					where: { id, poiId, isDeleted: false, isActive: true },
				});
			} catch (error) {
				console.error(error);
			}
		})();
		if (!existingReminder) throw new HttpException(`Invalid id!`, HttpStatus.BAD_REQUEST);
		const queryRunner = this.connection.createQueryRunner();
		await queryRunner.connect();
		await queryRunner.startTransaction();
		try {
			existingReminder.isDeleted = true;
			const deletedReminder = queryRunner.manager.create(Reminder, existingReminder);
			const updateReminderObject: ReminderUpdate = {
				reminderId: Number(existingReminder.id),
				updatedFields: ["deleted"],
				isActive: false,
				message: existingReminder.message,
				remindAt: existingReminder.remindAt,
			};
			const reminderUpdate = queryRunner.manager.create(ReminderUpdate, updateReminderObject);
			await queryRunner.manager.save<Reminder>(deletedReminder);
			await queryRunner.manager.save<ReminderUpdate>(reminderUpdate);
			await queryRunner.commitTransaction();
		} catch (error) {
			await queryRunner.rollbackTransaction();
			console.error(error);
			return { response: `Failed!` };
		} finally {
			await queryRunner.release();
			return { response: `Reminder Deleted Successfully!` };
		}
	}
}
