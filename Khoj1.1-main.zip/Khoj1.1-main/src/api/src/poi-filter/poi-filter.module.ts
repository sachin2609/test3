import { Module } from "@nestjs/common";
import { PoiFilterController } from "./poi-filter.controller";
import { PoiFilterService } from "./poi-filter.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { User } from "src/users/users.entity";
import { POIFilter, POIFilterUserTeam } from "./poi-filter.entity";
import { TeamService } from "src/team/team.service";
import { Team } from "src/team/team.entity";
import { JwtModule } from "@nestjs/jwt";
import { RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { Shape } from "src/shape/shape.entity";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";

@Module({
	imports: [
		TypeOrmModule.forFeature([
			POIFilter,
			POIFilterUserTeam,
			User,
			Team,
			Shape,
			UserApiUsageHistory,
			UserCredits,
			UserIdIp,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyUserApiUsageHistory,
			ApiKeyUserCredits,
			ApiKeyIp,
		]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
	],
	controllers: [PoiFilterController],
	providers: [PoiFilterService, TeamService, RolesGuardService, KeyCloakService, CentralServerService],
})
export class PoiFilterModule {}
