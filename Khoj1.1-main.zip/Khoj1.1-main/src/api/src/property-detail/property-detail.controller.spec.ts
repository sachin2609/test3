import { Test, TestingModule } from "@nestjs/testing";
import { PropertyDetailController } from "./property-detail.controller";

describe("PropertyDetailController", () => {
	let controller: PropertyDetailController;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			controllers: [PropertyDetailController]
		}).compile();

		controller = module.get<PropertyDetailController>(PropertyDetailController);
	});

	it("should be defined", () => {
		expect(controller).toBeDefined();
	});
});
