import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, Index } from "typeorm";
import { Shape } from './shape.entity';
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class Shapeindex {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	indexName: string;

	@ApiProperty()
	@Index()
	@Column({ default: 'number' })
	indexType: string;

	@ApiProperty()
	@Index()
	@Column("decimal", { default: 0 })
	indexValue: number;

	@ApiProperty()
	@Column("decimal", { default: 0, nullable: true })
	percentile: number;

	@ApiProperty()
	@Index()
	@ManyToOne(
		() => Shape,
		shape => shape.shapeindex
	)
	shape: Shape;
	
	@Column({nullable: true})
	metrics: string;
	
	@ApiProperty()
	@Column({ nullable: true })
	categoricalValue: string;
}

