import { ApiProperty } from "@nestjs/swagger";
import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class AppConfigs {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	name: string;

	@ApiProperty()
	@Column()
	config: string;

	@ApiProperty()
	@Column({ default: false })
	isActive: boolean;

	@ApiProperty()
	@Column({ nullable: true, array: true, type: "integer" })
	teamIds?: number[];
}
