import { Test, TestingModule } from '@nestjs/testing';
import { LayerSetService } from './layer-set.service';

describe('LayerSetService', () => {
  let service: LayerSetService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [LayerSetService],
    }).compile();

    service = module.get<LayerSetService>(LayerSetService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
