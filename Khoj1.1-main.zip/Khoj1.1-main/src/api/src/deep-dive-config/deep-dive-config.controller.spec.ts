import { Test, TestingModule } from '@nestjs/testing';
import { DeepDiveConfigController } from './deep-dive-config.controller';

describe('DeepDiveConfigController', () => {
  let controller: DeepDiveConfigController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [DeepDiveConfigController],
    }).compile();

    controller = module.get<DeepDiveConfigController>(DeepDiveConfigController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
