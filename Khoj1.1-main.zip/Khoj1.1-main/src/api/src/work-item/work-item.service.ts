import { HttpException, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { WorkItem, WorkItemStage, WorkItemStatus } from "./work-item.entity";
import { Repository } from "typeorm";
import {
	WorkItemPaginationDto,
	WorkItemQuery,
	WorkItemRequest,
	WorkItemResponse
} from "src/interfaces/work-item";
import { Property } from "src/property/property.entity";
import { PropertyGrid } from "src/relations/property-grid/property-grid.entity";
import { Role, UserGrid } from "src/relations/user-grid/user-grid.entity";
import { User } from "../users/users.entity";
import { WorkItemUsers } from "../interfaces/work-item";
@Injectable()
export class WorkItemService {
	constructor(
		@InjectRepository(WorkItem) private workItemRepository: Repository<WorkItem>,
		@InjectRepository(Property) private propertyRepository: Repository<Property>,
		@InjectRepository(PropertyGrid) private propertyGridRepository: Repository<PropertyGrid>,
		@InjectRepository(UserGrid) private userGridRepository: Repository<UserGrid>,
		@InjectRepository(User) private userRepository: Repository<User>
	) {}

	async create(workItemRequests: WorkItemRequest[], userId?: number): Promise<WorkItem[]> {
		let workItems = [];
		if (userId) {
			workItems = await Promise.all(
				workItemRequests.map(workItemRequest => {
					const workItem = {
						propertyId: workItemRequest.propertyId,
						userId: userId,
						stage: workItemRequest.stage
					};
					return workItem;
				})
			);
		} else {
			workItems = workItemRequests;
		}
		return await this.workItemRepository.save(workItems);
	}

	async save(workItems: WorkItem[]): Promise<WorkItem[]> {
		return await this.workItemRepository.save(workItems);
	}

	async list(
		query: WorkItemQuery,
		userId: number
	): Promise<WorkItemResponse[] | WorkItemPaginationDto> {
		const limit: number = query.limit as number;
		const page: number = query.page as number;
		const offset: number = (page - 1) * limit;
		const filterQuery = {};
		if (query.status) {
			filterQuery["status"] = query.status;
		}
		filterQuery["userId"] = userId;
		delete query.limit;
		delete query.page;
		const workItems = await this.workItemRepository.find({
			where: filterQuery,
			skip: offset,
			take: limit
		});
		const workItemResponses = await Promise.all(
			workItems.map(async workItem => {
				const property = await this.propertyRepository.findOne({where: {id: workItem.propertyId}});
				const workItemResponse: WorkItemResponse = {
					id: workItem.id,
					propertyId: workItem.propertyId,
					propertyName: property.name,
					stage: workItem.stage,
					status: workItem.status
				};
				workItem["property"] = property;
				return workItemResponse;
			})
		);
		const totalPages = await this.workItemRepository.count({ where: filterQuery });
		const workItemPaginationDto: WorkItemPaginationDto = {
			limit: limit,
			page: page,
			totalPages:
				totalPages % limit ? Math.floor(totalPages / limit) + 1 : Math.floor(totalPages / limit),
			data: workItemResponses
		};
		return workItemPaginationDto;
	}

	async close(workItemId: number, status: string): Promise<WorkItem[]> {
		let userGrid = null;
		const workItem = await this.workItemRepository.findOne({where: { id: workItemId }});
		const tempProperty = await this.propertyRepository.findOne({ where: { id: workItem.propertyId }});
		tempProperty.status = status;
		await this.propertyRepository.save(tempProperty);
		if (workItem.status == WorkItemStatus.close) {
			return [workItem];
		} else if (workItem.stage == WorkItemStage.approver) {
			workItem.status = WorkItemStatus.close;
			return await this.workItemRepository.save([workItem]);
		} else {
			const workItemRequest: WorkItemRequest = {
				propertyId: workItem.propertyId,
				userId: null,
				stage: null,
				assignedBy: null
			};
			const propertyGrid = await this.propertyGridRepository.findOne({ where: {
				propertyId: workItem.propertyId
		}});
			if (!propertyGrid) {
				throw new HttpException("Property not mapped properly or outside the allowed area", 404);
			}
			if (workItem.stage == WorkItemStage.analyzer) {
				userGrid = await this.userGridRepository.findOne({
					where: {
						gridId: propertyGrid.gridId,
						role: Role.verifier
					}
				});
				workItemRequest.stage = WorkItemStage.verifier;
				workItemRequest.userId = userGrid.userId;
			} else if (workItem.stage == WorkItemStage.verifier) {
				userGrid = await this.userGridRepository.findOne({
					where: {
						gridId: propertyGrid.gridId,
						role: Role.approver
					}
				});
				workItemRequest.stage = WorkItemStage.approver;
				workItemRequest.userId = userGrid.userId;
			}
			if (!userGrid) {
				throw new HttpException("No User against zone found", 404);
			}
			workItem.status = WorkItemStatus.close;
			await this.workItemRepository.save(workItem);
			return await this.create([workItemRequest]);
		}
	}

	async queryWorkItem(query: WorkItem): Promise<WorkItem[]> {
		console.log("query", query);
		return await this.workItemRepository.find({where: query});
	}

	async getUsers(workItems: WorkItem[]): Promise<WorkItemUsers[]> {
		const response = [];
		for await (const workItem of workItems) {
			const tempWorkItems = await this.workItemRepository.find({ where: {
				propertyId: workItem.propertyId
		}});
			console.log(tempWorkItems);
			const tempWorkItemUser = {};
			tempWorkItemUser["propertyId"] = tempWorkItems[0].propertyId;
			for await (const workItemsFound of tempWorkItems) {
				if (workItemsFound.stage === WorkItemStage.analyzer) {
					const analyzer = await this.userRepository.findOne({ where: {
						id: workItemsFound.userId
				}});
					tempWorkItemUser["analyzer"] = analyzer.firstName + " " + analyzer.lastName;
				}
				if (workItemsFound.stage === WorkItemStage.verifier) {
					const verifier = await this.userRepository.findOne({ where: {
						id: workItemsFound.userId
				}});
					tempWorkItemUser["verifier"] = verifier.firstName + " " + verifier.lastName;
				}
				if (workItemsFound.stage === WorkItemStage.approver) {
					const approver = await this.userRepository.findOne({ where: {
						id: workItemsFound.userId
				}});
					tempWorkItemUser["approver"] = approver.firstName + " " + approver.lastName;
				}
			}
			response.push(tempWorkItemUser as WorkItemUsers);
		}
		return response;
	}
}
