import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { GridService } from "src/grid/grid.service";
import { Grid } from "src/grid/grids.entity";
import { Repository, UpdateResult } from "typeorm";
import { Indexmaster } from "./index-master.entity";
import * as fs from "fs";
import * as csv from "csv-parser";
import * as _ from "lodash";
@Injectable()
export class IndexMasterService {
	constructor(
		@InjectRepository(Indexmaster) private indexMasterRepository: Repository<Indexmaster>,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		private _gridService: GridService
	) {}

	async create(): Promise<Indexmaster[]> {
		const keys = [
			"population_cat",
			"affluence_cat",
			"footfall_cat",
			"JF_cat",
			"SU_cat",
			"doctors_cat",
			"commercial_cat",
			"educational_cat",
			"entertainment_cat",
			"financial_cat",
			"medical_cat",
			"income__cat"
		];
		const results = [];
		fs.createReadStream("./src/files/Location_data.csv")
			.pipe(csv())
			.on("data", async data => {
				results.push(data);
			})
			.on("end", async () => {
				for await (const data of results) {
					const val = await this._gridService.nearestGrid(data.Latitude, data.Longitude);
					const nearestGrid = await this.gridRepository.findOne({ where: { id: val["id"] }});
					console.log(data);
					const indexTempArr = [];
					keys.forEach(eachKey => {
						const indexTemp = new Indexmaster();
						indexTemp.indexName = eachKey.slice(0, eachKey.length - 4);
						indexTemp.indexValue = data[eachKey];
						indexTemp.indexType = "basic";

						indexTemp.grid = nearestGrid;
						indexTempArr.push(indexTemp);
					});
					try {
						await this.indexMasterRepository.save(indexTempArr);
					} catch (error) {
						console.log(error);
					}
					//console.log(indexTempArr);
				}
			});
		//const indexes = await Promise.all(
		//indexMasters.map(async indexMaster => {
		//const val = this._gridService.nearestGrid(indexMaster['lat'], indexMaster['lng']);
		//delete indexMaster['lat'];
		//delete indexMaster['lng'];
		//const grid = await this.gridRepository.findOne(val['id']);
		//indexMaster.grid = grid;
		//return indexMaster;
		//})
		//);
		//return this.indexMasterRepository.save(indexes);
		return null;
	}
	async populateBusinessPotential(): Promise<void> {
		const grids = await this.gridRepository.find({ where: {
			State: "Maharashtra"
	}});
		for await (const eachGrid of grids) {
			console.log();
			const index = new Indexmaster();
			index.indexName = "BP";
			index.indexType = "basic";
			index.indexValue = _.random(1, 3);
			index.grid = eachGrid;
			const indexSaved = await this.indexMasterRepository.save(index);
			console.log("saved index", indexSaved);
		}
	}
	async update(indexes: Indexmaster[]): Promise<UpdateResult[]> {
		let values;
		if (indexes.length > 1) {
			values = await Promise.all(
				indexes.map(async index => {
					const update = {};
					const fixedKeys = ["id", "indexName", "indexType"];
					Object.keys(index).forEach(key => {
						if (fixedKeys.includes(key) == false) update[key] = index[key];
					});
					return await this.indexMasterRepository.update({ id: index.id }, update);
				})
			);
		} else {
			values = [];
			indexes = [];
			fs.createReadStream("src/files/indexmaster.csv")
				.pipe(csv())
				.on("data", async data => {
					indexes.push(data);
				})
				.on("end", async () => {
					console.log(indexes.length);
					values = await Promise.all(
						indexes.map(async index => {
							return await this.indexMasterRepository.update(
								{ id: index.id },
								{ percentile: index.percentile }
							);
						})
					);
				});
		}
		return values;
		// return await this.indexMasterRepository.save(indexes);
	}
}
