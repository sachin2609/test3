import { MailerService } from "@nestjs-modules/mailer";
import { HttpService } from "@nestjs/axios";
import { Injectable } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { InjectRepository } from "@nestjs/typeorm";
import { keys } from "lodash";
import { firstValueFrom } from "rxjs";
import { FilterIssue, Issue } from "src/interfaces/jira";
import { Organisation } from "src/organisations/organisations.entity";
import { User } from "src/users/users.entity";
import { Repository } from "typeorm";

const reqFields = [
	"Location/ Geography","Layers","Layer Items","Raised Issue Type","Client User Description","Client User ID",
	"Client User Email","Client User Name","Functional Specifications","Technical Specifications","Environment"
];

@Injectable()
export class JiraService {
    constructor(
        private httpService: HttpService,
        @InjectRepository(Organisation) private organisationsRepository: Repository<Organisation>,
        @InjectRepository(User) private usersRepository: Repository<User>,
        private readonly mailerService: MailerService,
		private readonly jwtService: JwtService
    ) {}

    requestConfig = {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Basic ${process.env.JIRA_BASE64_TOKEN}`,
        },
    };

    async getAllProjects() {
        try {
            const url = process.env.JIRA_DOMAIN + '/rest/api/2/project';
            return (await firstValueFrom(this.httpService.get(url,this.requestConfig))).data;
        } catch(err) {
            throw err;
        }
    }

    async getAllIssues() {
        try {
            const url = process.env.JIRA_DOMAIN + '/rest/api/2/search';
            const jql: string = 'project = ' + process.env.JIRA_PROJECT_ID + ' ORDER BY created ASC'; 
            let body = { jql: jql , startAt: 0 , maxResults: 1000000 };
            let total = 1;
            let maxResults = 0;
            let startAt = 0;
            const issues = [];
            //let data = (await firstValueFrom(this.httpService.post(url,body,this.requestConfig))).data;
            while(total > ( maxResults + startAt ) ) {
                let data = (await firstValueFrom(this.httpService.post(url,body,this.requestConfig))).data;
                total = Number(data?.["total"]);
                maxResults = Number(data?.["maxResults"]);
                startAt = Number(data?.["startAt"]);
                data?.["issues"].forEach(i => { issues.push(i) });
                body.startAt = ( maxResults + startAt ) - 1;
            }
            return issues;
        } catch(err) {
            console.log(err);
            throw err;
        }
    }

    async findAllIssues(jql: string) {
        try {
            const url = process.env.JIRA_DOMAIN + '/rest/api/2/search';
            //const jql: string = 'project = ' + process.env.JIRA_PROJECT_ID + ' ORDER BY created ASC'; 
            let body = { jql: jql , startAt: 0 , maxResults: 1000000 };
            let total = 1;
            let maxResults = 0;
            let startAt = 0;
            const issues = [];
            //let data = (await firstValueFrom(this.httpService.post(url,body,this.requestConfig))).data;
            while(total > ( maxResults + startAt ) ) {
                let data = (await firstValueFrom(this.httpService.post(url,body,this.requestConfig))).data;
                total = Number(data?.["total"]);
                maxResults = Number(data?.["maxResults"]);
                startAt = Number(data?.["startAt"]);
                data?.["issues"].forEach(i => {
					if(i?.["fields"]?.["parent"]?.["key"] == String(process.env.JIRA_PARENT_ID)) {
						issues.push(i);
					} 
				});
                body.startAt = ( maxResults + startAt ) - 1;
            }
            return issues;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    async findCustomFieldId(query) {
        const names = query["keys"] as string[];
        const url = process.env.JIRA_DOMAIN + '/rest/api/2/field';
        try {
            const res = await firstValueFrom(this.httpService.get(url, this.requestConfig));
            const data = res.data as any[];
            //console.log(data);
            let response = {};
            data.forEach(obj => {
                if(String(process.env.JIRA_PROJECT_TYPE) == "CM") {
                    if(obj["scope"]) {
                        
                    } else {
                        const name = String(obj["name"]);
                        if(names.includes(name)) {
                            response[name] = obj["id"];
                        } else {}
                    }
                } else {
                    if(obj["scope"]) {
                        if(obj["scope"]["type"] == "PROJECT") {
                            if(obj["scope"]["project"]["id"] == String(process.env.JIRA_PROJECT_ID)) {
                                const name = String(obj["name"]);
                                if(names.includes(name)) {
                                    response[name] = obj["id"];
                                } else {}
                            }
                        } else {}
                        
                    } else {}
                }
            });
            return response;
        } catch(err) {
            throw err;
        }
    }

    async findIssueTypeId(query) {
        const names = query["issueTypes"] as string[];
        const url = process.env.JIRA_DOMAIN + '/rest/api/2/project/' + process.env.JIRA_PROJECT_ID;
        try {
            const res = await firstValueFrom(this.httpService.get(url,this.requestConfig));
            const data = res.data["issueTypes"] as any[];
            let response = {};
            data.forEach(obj => {
                const name = String(obj["name"]);
                if(names.includes(name)) {
                    response[name] = obj["id"];
                } else {}
            });
            return response;
        } catch(err) {
            throw err;
        }
    }

    async createIssue(query: Issue,user: JSON) {
        const url = process.env.JIRA_DOMAIN + '/rest/api/2/issue';
        try {
            let issue : Issue = {
                summary: query.summary,
                description: query.description,
                project: { id: String(process.env.JIRA_PROJECT_ID) },
                issuetype: { 
                    id: String( ( await this.findIssueTypeId({ issueTypes : [String(process.env.JIRA_DEFAULT_ISSUE_TYPE)] }) )[String(process.env.JIRA_DEFAULT_ISSUE_TYPE)] ) 
                }
            };
			//Check if default issueType is the flow
			if(String(process.env.JIRA_DEFAULT_ISSUE) == "false") {
				issue.issuetype.id = String( ( await this.findIssueTypeId({ issueTypes : [ String(query.issueType) ] }) )[String(query.issueType)] );
			}
			//
            const dbUser = await this.usersRepository.findOne({ where: {id: user["id"],email: user["email"] }});
            const organistion = await this.organisationsRepository.findOne({ where: {id: dbUser?.organisationId }});
            const usr = { 
                userId: user["id"], 
                firstName: user["firstName"], 
                lastName: user["lastName"], 
                email: user["email"], 
                roles: user["roles"] , 
                organisationId: organistion?.id,
                organistion: organistion?.organisation,
                credits: organistion?.credits,
            };
            query[reqFields[4]] = JSON.stringify(usr);
            query[reqFields[5]] = Number(user["id"]);
            query[reqFields[7]] = String(user["firstName"]) + ' ' + String(user["lastName"]);
            query[reqFields[6]] = dbUser.email;
            query["Acceptance Criteria"] = "Must be populated appropriately when issue is assigned.";
            //query["Story Points"] = 2;
			if(query["Location"] != undefined) {
				query[reqFields[0]] = query["Location"];
				delete query["Location"];
			}
            delete query.summary;
            delete query.description;
            delete query?.issueType;
            const allKeys = Object.keys(query);
            const customFieldIds = await this.findCustomFieldId({ keys : allKeys });
            allKeys.forEach(key => {
                issue[customFieldIds[key]] = query[key]; 
            });
            issue["parent"] = { key: String(process.env.JIRA_PARENT_ID) };
            let data = {fields: issue};
            console.log(JSON.stringify(data));
            return (await firstValueFrom(this.httpService.post(url,JSON.stringify(data),this.requestConfig))).data;
        } catch(err) {
            //console.log(err);
            throw err;
        }
    }

    async editIssue(query: Issue, user: JSON) {
        const url = process.env.JIRA_DOMAIN + '/rest/api/2/issue/' + query["issueKey"];
        try {
            let issue = {};

        } catch(err) {
            throw err;
        }
    }

    async getRaisedIssue(query: FilterIssue, headers) {
		//Check Roles.Then send if roles have `client-admin` send all issues.
		let user;
        if(headers?.["token"]) {
            user = await this.jwtService.decode(headers["token"]) as JSON;
        } else {
            let apiKey;
			if(headers["apikey"]) {
				apiKey = headers["apikey"];
			}
			if(headers["api-key"]) {
				apiKey = headers["api-key"];
			}
			if(headers["apiKey"]) {
				apiKey = headers["apiKey"];
			}
            user = await this.jwtService.decode(apiKey) as JSON;
        }
		const thisUserId: number = Number(user["id"]);
		const roles: string[] = user["roles"] as string[];
		if(roles.includes("client-admin")) {
			delete query.userIds;
		} else {
			query.userIds = [thisUserId];
		}
		//Check roles ends here.
		
        const url = process.env.JIRA_DOMAIN + '/rest/api/2/search';
        let jql: string;
        if(query?.startDate && query?.endDate) {
            jql = 'project = ' + process.env.JIRA_PROJECT_ID + ' AND created >= ' + query.startDate + ' AND created <= ' + query.endDate + ' ORDER BY created ASC';
        } else {
            jql = 'project = ' + process.env.JIRA_PROJECT_ID + ' ORDER BY created ASC';
        }
        //const body = { jql: jql , startAt: 0 , maxResults: 1000000 };
        //const data = (await firstValueFrom(this.httpService.post(url,body,this.requestConfig))).data;
        const issues: any[] = await this.findAllIssues(jql);
        const customFieldIds = await this.findCustomFieldId({keys: reqFields});
        const responseIssues = [];
        issues.forEach(issue => {
            if(query?.userIds) {
                if(query.userIds.includes(Number( issue["fields"][ customFieldIds[ reqFields[5] ] ] ))) {
                    let tempIssue = {};
					tempIssue["id"] = issue?.["id"];
					tempIssue["key"] = issue?.["key"];
					tempIssue["Raised Issue Type"] = issue?.["fields"]?.["issuetype"]?.["name"]; 
                    tempIssue["Summary"] = issue?.["fields"]?.["summary"];
                    tempIssue["Description"] = issue?.["fields"]?.["description"];
                    tempIssue["Created At"] = issue?.["fields"]?.["created"];
                    tempIssue["Priority"] = issue?.["fields"]?.["priority"]?.["name"];
					tempIssue["Status"] = issue?.["fields"]?.["status"]?.["name"];
                    reqFields.forEach(field => {
						if( (issue["fields"][ customFieldIds[field] ] != null) && (issue["fields"][ customFieldIds[field] ] != undefined) ) {
							tempIssue[field] = issue["fields"][ customFieldIds[field] ];
						}
                    });
                    responseIssues.push(tempIssue); 
                }
            } else {
                let tempIssue = {};
				tempIssue["id"] = issue?.["id"];
				tempIssue["key"] = issue?.["key"];
				tempIssue["Raised Issue Type"] = issue?.["fields"]?.["issuetype"]?.["name"];
                tempIssue["Summary"] = issue["fields"]?.["summary"];
                tempIssue["Description"] = issue["fields"]?.["description"];
                tempIssue["Created At"] = issue["fields"]?.["created"];
				tempIssue["Priority"] = issue?.["fields"]?.["priority"]?.["name"];
				tempIssue["Status"] = issue?.["fields"]?.["status"]?.["name"];
                reqFields.forEach(field => {
					if( (issue["fields"][ customFieldIds[field] ] != null) && (issue["fields"][ customFieldIds[field] ] != undefined) ) {
						tempIssue[field] = issue["fields"][ customFieldIds[field] ];
					}
                });
                responseIssues.push(tempIssue);    
            }
        });
		await Promise.all(responseIssues?.map(async issue => {
			const key = String(issue["key"]);
			const url = process.env.JIRA_DOMAIN + '/rest/api/2/issue/' + key + '/changelog';
			const data = (await firstValueFrom(this.httpService.get(url,this.requestConfig))).data;
			const changeLogs: any[] = data["values"];
			issue["changeLogs"] = [];
			changeLogs.forEach(changelog => {
				const items : any[] = changelog?.["items"];
				items.forEach(item => {
					if(item?.["field"] == "status") {
						issue["changeLogs"].push(
							{
								created : changelog["created"],
								field: "status",
								from: item?.["fromString"],
								to: item?.["toString"]
							}
						);
					} else {}
				});
				/* 
				if(changelog?.["items"]?.[0]?.["field"] == "status") {
					issue["changeLogs"].push(
						{
							created : changelog["created"],
							field: "status",
							from: changelog?.["items"]?.[0]?.["fromString"],
							to: changelog?.["items"]?.[0]?.["toString"]
						}
					);
				} else {
					//console.log("Failed");
				}
				*/
			});
		}));
        return responseIssues;
    }

    async overview(query: FilterIssue, user) {
        const url = process.env.JIRA_DOMAIN + '/rest/api/2/search';
        let jql: string;
        if(query?.startDate && query?.endDate) {
            jql = 'project = ' + process.env.JIRA_PROJECT_ID + ' AND created >= ' + query.startDate + ' AND created <= ' + query.endDate + ' ORDER BY created ASC';
        } else {
            jql = 'project = ' + process.env.JIRA_PROJECT_ID + ' ORDER BY created ASC';
        }
        const issues: any[] = await this.findAllIssues(jql);
        const customFieldIds = await this.findCustomFieldId({ keys: reqFields });
		class Res {
			id: number;
			name: string;
			raisedTicketCount: number;
			inProgressTicketCount: number;
			doneTicketCount: number;
		};
		let response = [];
		let responseObj = {};
		issues.forEach(issue => {
			const userId = Number(issue["fields"][ customFieldIds[ reqFields[5] ] ]);
			const name = String(issue["fields"][ customFieldIds[ reqFields[7] ] ]);
			if(Object.keys(responseObj).includes(String(userId))) {
				responseObj[ String(userId) ].raisedTicketCount = responseObj[ String(userId) ].raisedTicketCount + 1;
				responseObj[ String(userId) ].inProgressTicketCount = ( issue["fields"]["status"]["name"] == "In Progress" )?(responseObj[ String(userId) ].inProgressTicketCount + 1):responseObj[ String(userId) ].inProgressTicketCount;
				responseObj[ String(userId) ].inProgressTicketCount = ( issue["fields"]["status"]["name"] == "Done" )?(responseObj[ String(userId) ].doneTicketCount + 1):responseObj[ String(userId) ].doneTicketCount;
			} else {
				if(name != "null") {
					let tempObj : Res = {
						id: userId,
						name: name,
						raisedTicketCount : 1,
						inProgressTicketCount: ( issue["fields"]["status"]["name"] == "In Progress" )?1:0,
						doneTicketCount: ( issue["fields"]["status"]["name"] == "Done" )?1:0
					};
					responseObj[ String(issue["fields"][ customFieldIds[ reqFields[5] ] ]) ] = tempObj;
				}
			}
		});
		Object.keys(responseObj).forEach(key => { response.push(responseObj[key]) });
		/*
		issues.forEach(issue => {
			if(userIds.includes(Number(issue["fields"][ customFieldIds[ reqFields[5] ] ]))) {
				response.forEach((res : Res) => {
					if(res.id == Number( issue["fields"][ customFieldIds[ reqFields[5] ] ] )) {
						res.raisedTicketCount = res.raisedTicketCount + 1;
						res.inProgressTicketCount = ( issue["fields"]["status"]["name"] == "In Progress" )?(res.inProgressTicketCount + 1):res.inProgressTicketCount,
						res.doneTicketCount = ( issue["fields"]["status"]["name"] == "Done" )?(res.doneTicketCount + 1):res.doneTicketCount
					}
				});
			} else {
				userIds.push(Number(issue["fields"][ customFieldIds[ reqFields[5] ] ]));
				let tempObj : Res = {
					id: Number(issue["fields"][ customFieldIds[ reqFields[5] ] ]),
					name: String(issue["fields"][ customFieldIds[ reqFields[7] ] ]),
					raisedTicketCount : 1,
					inProgressTicketCount: ( issue["fields"]["status"]["name"] == "In Progress" )?1:0,
					doneTicketCount: ( issue["fields"]["status"]["name"] == "Done" )?1:0
				};
				response.push(tempObj);
			}
		});
		*/
		/*    
		let response = { 
            id: user["id"], 
            name: String(user["firstName"]) + ' ' + String(user["lastName"]),
            raisedTicketCount: 0,
            inProgressTicketCount: 0,
            doneTicketCount: 0
        };
        issues.forEach(issue => {
            if(issue["fields"][ customFieldId[ reqFields[5] ] ] == user["id"]) {
                response.raisedTicketCount = response.raisedTicketCount + 1;
                if(issue["fields"]["status"]["name"] == "In Progress") {
                    response.inProgressTicketCount = response.inProgressTicketCount + 1;
                }
                if(issue["fields"]["status"]["name"] == "Done") {
                    response.doneTicketCount = response.doneTicketCount + 1;
                }
            }
        })*/
        return response;
    }

    async issueTransitioned(query) {
        query = JSON.stringify(query);
        const newQuery = JSON.parse(query);
        const issue = newQuery?.["issue"];
        const customFieldIds = await this.findCustomFieldId({ keys: reqFields });
        const email = issue?.["fields"]?.[ customFieldIds[ reqFields[6] ] ];
        const userName = issue?.["fields"]?.[ customFieldIds[ reqFields[7] ] ];
        const summary = issue?.["fields"]?.["summary"];
        //const description = issue?.["fields"]?.["description"];
        const issueType = issue?.["fields"]?.[ customFieldIds[ reqFields[3] ] ];
		const key = issue?.["key"];
		const location = issue?.["fields"]?.[ customFieldIds[ reqFields[0] ] ];
        console.log(email);
        const status = issue?.["fields"]?.["status"]["name"];
        if(status == "Done") {
			const subject = "Datasutram Platform | Issue Resolved | " + String(key);

			let htmlForUser = `
				<!DOCTYPE html>
				<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">
				<head>
				  <meta charset="UTF-8">
				  <meta name="viewport" content="width=device-width,initial-scale=1">
				  <meta name="x-apple-disable-message-reformatting">
				  <meta http-equiv="Content-Type" content="text/html charset=UTF-8" />
				  <title></title>
				  <style>
					table, td, div, h1, p {font-family: Arial, sans-serif;}
				  </style>
				</head>
				<body style="margin:0;padding:0;">
				  <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;background:rgb(237, 237, 237);">
					<tr>
					  <td align="center" style="padding:0;">
						<table role="presentation" style="width:602px;border-collapse:collapse;border-spacing:0;text-align:left;">
						  <tr>
							<td align="center" style="padding:40px 0 30px 0;">
							  <a href="https://datasutram.com" target="blank" style="box-sizing: border-box;color: #0d6efd;text-decoration: underline;">
								<img src="https://datasutram.com/assets/images/common/ds_logo_b.png" style="max-width: 100%;width: 300px;vertical-align: middle;margin-top: 1.5rem!important;margin-bottom: 1.5rem!important;" alt="">
							  </a>
							</td>
						  </tr>
						</table>
					  </td>
					</tr>
				  </table>
				  <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;background:rgb(237, 237, 237);">
					<tr>
					  <td align="center" style="padding-bottom:50px;">
						<table role="presentation" style="width:602px;border-collapse:collapse;border:1px solid #cccccc;border-spacing:0;text-align:left;background: #ffffff;">
						  <tr>
							<td style="padding:36px 30px 42px 30px;">
							  <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;">
								<tr>
								  <td align="center">
									<h1 style="font-size:24px;margin:0 0 20px 0;font-family:Arial,sans-serif;">Datasutram Platform | Issue Resolved</h1>
								  </td>
								</tr>
								<tr>
								  <td style="padding:0 0 36px 0;color:#153643;">
									<p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Dear ${userName}, The ticket you raised with following specifications has been resolved.</p>
									<li style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">ID : ${key}</li>
									<li style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Title: ${summary} </li>
									<li style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Location: ${location} </li>
									<li style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Issue Type: ${issueType} </li>
									<p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Thanks for your patience and feedback.</p>
									<p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Should you need any assistance or have a question, please write to us at <a href="https://mail.google.com/mail/u/0/?fs=1&to=hello@datasutram.com&su=Data%20Sutram&body=Your%20Comments%20on%20Datasutram%20Console%20here&tf=cm" target="blank">hello@datasutram.com</a></p>
	
									<p style="margin:20px 0 0 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Warm Regards,</p>
									<p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Team Datasutram</p>
								  </td>
								</tr>
							  </table>
							</td>
						  </tr>
						  <tr>
							<td style="padding:0 30px 30px 30px;">
							  <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;font-size:9px;font-family:Arial,sans-serif;">
								<tr>
								  <td style="padding:0;width:25%;" align="center">
									<table role="presentation" style="border-collapse:collapse;border:0;border-spacing:0;">
									  <tr>
										<td style="padding:0 0 0 10px;width:38px;">
										  <a href="https://www.linkedin.com/company/data-sutram" target="blank" class="icon linkedin" title="Linkedin" style="width: 38px;">
											<img src="https://cdn.exclaimer.com/Handbook%20Images/linkedin-icon_32x32.png?_ga=2.1038641.1612459600.1629015905-2070996887.1629015905" alt="">
										  </a>
										</td>
									  </tr>
									</table>
								  </td>
								  <td style="padding:0;width:25%;" align="center">
									<table role="presentation" style="border-collapse:collapse;border:0;border-spacing:0;">
									  <tr>
										<td style="padding:0 0 0 10px;width:38px;">
										  <a href="https://twitter.com/dsutram?lang=en" target="blank" class="icon twitter" title="Twitter" style="width: 38px;">
											<img src="https://cdn.exclaimer.com/Handbook%20Images/twitter-icon_32x32.png?_ga=2.39811107.1612459600.1629015905-2070996887.1629015905" alt="">
										  </a>
										</td>
									  </tr>
									</table>
								  </td>
								  <td style="padding:0;width:25%;" align="center">
									<table role="presentation" style="border-collapse:collapse;border:0;border-spacing:0;">
									  <tr>
										<td style="padding:0 0 0 10px;width:38px;">
										  <a href="https://www.facebook.com/datasutram/" target="blank" class="icon facebook" title="Facebook" style="width: 38px;">
											<img src="https://cdn.exclaimer.com/Handbook%20Images/facebook-icon_32x32.png?_ga=2.105871363.1612459600.1629015905-2070996887.1629015905" alt="">
										  </a>
										</td>
									  </tr>
									</table>
								  </td>
								  <td style="padding:0;width:25%;" align="center">
									<table role="presentation" style="border-collapse:collapse;border:0;border-spacing:0;">
									  <tr>
										<td style="padding:0 0 0 10px;width:38px;">
										  <a href="https://datasutram.medium.com/" target="blank" class="icon medium" title="Twitter" style="width: 38px;">
											<img src="https://cdn.exclaimer.com/Handbook%20Images/Medium_32.png?_ga=2.98997534.1612459600.1629015905-2070996887.1629015905" alt="">
										  </a>
										</td>
									  </tr>
									</table>
								  </td>
								</tr>
							  </table>
							</td>
						  </tr>
						  <tr>
							<td style="padding: 20px; text-align: center;">
							  <p style="margin:0 0 12px 0;font-size:10px;font-family:Arial,sans-serif;font-style: italic;">The information contained in this electronic message and any attachments to this message are intended for the exclusive use of the addressee(s) and may contain proprietary, confidential or privileged information. If you are not the intended recipient, you should not disseminate, distribute or copy this e-mail. Please notify the sender immediately and destroy all copies of this message and any attachments contained in it.</p>
							</td>
						  </tr>
						</table>
					  </td>
					</tr>
				  </table>
				</body>
				</html>
				`;


            await this.mailerService.sendMail({
                to: email, // list of receivers
				from: process.env.MAILDEV_INCOMING_USER, // sender address
				subject: subject, // Subject line
				text: "Issue Resolved :", // plaintext body
				html: htmlForUser // HTML body content
            }).then(() => {
                console.log("Email Sent!");
            })
            .catch(err => {
                console.log("Error in sending mail", err);
            });
        }
        return true;
    }

}
