import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { Repository, In } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Layer } from './layers.entity';
import * as geohash from 'ngeohash';
import { Grid } from '../grid/grids.entity';
import { PoiPaginationDto, LatLong } from '../interfaces/poi';
import * as _ from 'lodash';
import { LayerDetail } from '../layer-details/layer-details.entity';
import { LayerQuery } from '../interfaces/layerQuery';
import * as dotenv from "dotenv";
import {Indexmaster} from '../index-master/index-master.entity';
dotenv.config()
@Injectable()
export class LayersService {
  constructor(
    @InjectRepository(Layer) private layerRepository: Repository<Layer>,
    @InjectRepository(Grid) private gridRepository: Repository<Grid>,
    @InjectRepository(LayerDetail) private layerDetailRepository: Repository<LayerDetail>,
    @InjectRepository(Indexmaster) private indexMasterRepository: Repository<Indexmaster>
  ) {}
  async filter(query: LayerQuery): Promise<Layer[] | PoiPaginationDto | unknown> {
    let gridIds;
    if (!query['location']) {
      throw new HttpException(
        {
          status: HttpStatus.BAD_REQUEST,
          error: "Request body must contain 'location'",
        },
        HttpStatus.BAD_REQUEST
      );
    }
    if (!query.types) {
      query.types = ['store'];
    }
    const gridsSearchedArr = [];
    let poiIdsFromPoiDetails = [];
    if (query['grids'] || query['location'] || query['within'] || query['layerDetails']) {
      if (query['layerDetails']) {
        const poiDetails: any[] = query['layerDetails'];
        if (poiDetails.length == 0) {
          delete query['layerDetails'];
        }
      }
      if (query['grids']) {
        if (query['grids']['range']) {
          if (Object.keys(query['grids']['range']).length) {
          }
        }
        if (query['grids']['select']) {
          if (Object.keys(query['grids']['select']).length) {
            console.log('gridsSelectResponse', gridsSearchedArr);
          }
        }
      }
      if (query['location']) {
        const locationQueryObject = {};
        let locationQueryString = '';
        Object.keys(query['location']).forEach((location, index) => {
          if (index === 0) {
            locationQueryObject[location] = query['location'][location];
            locationQueryString += 'grid.' + location + ' = :' + location;
          } else {
            locationQueryObject[location] = query['location'][location];
            locationQueryString += ' AND grid.' + location + ' = :' + location;
          }
        });
        if (Object.keys(locationQueryObject).length) {
          try {
            const locationGrids = await this.gridRepository
              .createQueryBuilder('grid')
              .select('grid.id')
              .where(locationQueryString, locationQueryObject)
              .getMany();
            const locationGridIds = await locationGrids.map((eachGrid) => {
              return eachGrid.id;
            });
            gridsSearchedArr.push(locationGridIds);
          } catch (error) {
            return [];
            console.log(error);
          }
        }
      }
      if (query['within']) {
        let latLongs: LatLong[] = [];
        latLongs = query['within']['points'];
        let distance = query['within']['radius'];
        distance = distance;
        const withinGridsArr: number[][] = await Promise.all(
          query['within']['points'].map(async (eachLatLong) => {
            //const eachTarget = await this.propertyRepository.findOne({ id: eachId });
            //const point = tf.point([eachTarget.latitude, eachTarget.longitude]);
            const pi = Math.PI;
            const lat_increment = 1 / 110.574;
            const lng_increment = 1 / 111.32;
            const lat_max = eachLatLong.lat + distance * lat_increment;
            const lat_min = eachLatLong.lat - distance * lat_increment;
            const lng_max =
              eachLatLong.lng + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
            const lng_min =
              eachLatLong.lng - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
            const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
            try {
              const tempGrid = await this.gridRepository
                .createQueryBuilder('grid')
                .where('grid.hash IN (:...hashes)', { hashes: withinGrids })
                .select('grid.id')
                .getMany();

							const tempGridIds = tempGrid.map(eachGrid => {
								return eachGrid.id;
							});
							return tempGridIds;
						} catch (error) {
							return null;
						}
					})
				);
				const tempGrids = _.flattenDeep(withinGridsArr);
				gridsSearchedArr.push(tempGrids);
			}
			if(query["layerDetails"]) {
				const poiDetails :any[] = query["layerDetails"];
				if(poiDetails.length==0) {
					poiIdsFromPoiDetails = [];
				} else {
					await Promise.all(poiDetails.map(async (eachPoiDetail) => {
						if(eachPoiDetail.dataType == "string") {
							const tempPoiIdsFromString = [];
							const tempPoiIds = await this.layerDetailRepository
								.createQueryBuilder("layer_detail")
								.where('key = :key AND value IN(:...values)',{key: eachPoiDetail.key, values: eachPoiDetail.values})
								.select('"layerId"')
								.distinct(true)
								.getRawMany()
							await Promise.all(tempPoiIds.map(eachPoiId => {
								tempPoiIdsFromString.push(eachPoiId.layerId);
							}));
							poiIdsFromPoiDetails.push(tempPoiIdsFromString);
						}
						if(eachPoiDetail.dataType == "number") {
							const tempPoiIdsArray = [];
							const tempPoiDetails = await this.layerDetailRepository
								.createQueryBuilder("layer_detail")
								.where('key = :key',{key: eachPoiDetail.key})
								.andWhere('unit BETWEEN :min and :max', {min: eachPoiDetail["values"]["min"], max: eachPoiDetail["values"]["max"]})
								.select('"layerId"')
								.distinct(true)
								.getRawMany()

							await Promise.all(tempPoiDetails.map(eachPoiDetailHere => {
									tempPoiIdsArray.push(eachPoiDetailHere.layerId);
							}));
							poiIdsFromPoiDetails.push(tempPoiIdsArray);
						}
					}));
				}
			}
			let responseIds = [];
			gridsSearchedArr.forEach((eachArr, index) => {
				if (index === 0) {
					responseIds = eachArr;
				} else {
					responseIds = _.intersection(responseIds, eachArr);
				}
			});
			if (!responseIds) {
				responseIds = [];
			}
			if (responseIds.length > 0) {
				gridIds = responseIds;
				try {	
					// -- start -- layer set response
					let grids = await this.gridRepository.createQueryBuilder('grid')
						.where('grid.id IN (:...responseIds)', { responseIds: responseIds })
						.leftJoinAndSelect('grid.indexmaster', 'indexmaster')
						.getMany();
					let hashIndexDict = {};
					let hashArr = grids.map(eachGrid => {
						let tempDict = {};
						eachGrid.indexmaster.forEach(eachIndex => {
							if (eachIndex.indexType === 'string') {
								tempDict[eachIndex.indexName] = eachIndex.categoricalValue;
							} else {
								let tempObj = {};
								tempObj["value"] = eachIndex.indexValue;
								tempObj["unit"] = eachIndex.metrics;
								tempDict[eachIndex.indexName] = eachIndex.indexValue;
							}
						});
						hashIndexDict[eachGrid.hash] = tempDict;
						return eachGrid.hash;
					});
					let layers = [];
					if(query["layerDetails"]) {
						let poiIdsFromPoiDetailsIntersected = [];
						poiIdsFromPoiDetails.forEach((eachArr, index) => {
							if (index === 0) {
								poiIdsFromPoiDetailsIntersected = eachArr;
							} else {
								poiIdsFromPoiDetailsIntersected = _.intersection(poiIdsFromPoiDetailsIntersected, eachArr);
							}
						});
						layers = await this.layerRepository.find({ where: {
							id: In(poiIdsFromPoiDetailsIntersected),
							gridHash: In(hashArr),
							type: In(query.types)
					}});
					} else {
						layers = await this.layerRepository.find({ where: {
							gridHash: In(hashArr),
							type: In(query.types)
					}});
					}
					/*
					if(query["layerDetails"]) {
						let layersFromInternalDetails = await this.layerRepository.find({ where: {id:In(poiIdsFromPoiDetails)}});
						console.log("Layers length: ",layersFromInternalDetails.length);
						layers = _.intersection(layers,layersFromInternalDetails);
						console.log("new layers length :" ,layers.length);
					}*/
					let layerIds = layers.map(eachLayer => {
						eachLayer['index'] = hashIndexDict[eachLayer.gridHash];
						return eachLayer.id;
					});/*
					console.log("Old Length : ",layerIds.length);
					if(query["layerDetails"]) {
						layerIds = _.intersection(layerIds,poiIdsFromPoiDetails);
						console.log("New Length : ",layerIds.length);
					}*/
					let layerDetailsDict = {};
					if(layerIds.length == 0) {
						layerIds = [0];
					}
					let layerDetails = await this.layerDetailRepository.find({ where: {
						layerId: In(layerIds)
				}});
					layerDetails.forEach(eachDetail => {
						if (!layerDetailsDict[eachDetail.layerId]) {
							layerDetailsDict[eachDetail.layerId] = {};	
							layerDetailsDict[eachDetail.layerId][eachDetail.key] = eachDetail.value;
						} else {
							layerDetailsDict[eachDetail.layerId][eachDetail.key] = eachDetail.value;
						}
					});
					layers.forEach(eachLayer => {
						eachLayer['internalDetails'] = layerDetailsDict[eachLayer.id];
					});
					if(layers.length == 0) {
						layers = [];
					}
					//New Response------------
					let finalResponse = {};
					finalResponse["count"] = layers.length;
					finalResponse["data"] = layers;
					finalResponse["typeCount"] = {};
					await Promise.all(layers.map(poi => {
						const subTypes = Object.keys(finalResponse["typeCount"]);
						if(subTypes.includes(poi.type)) {
							//console.log("Type encounterd :",poi.type);
							finalResponse["typeCount"][poi.type] = finalResponse["typeCount"][poi.type] +1;
						} else {
							finalResponse["typeCount"][poi.type] = 1;
						}
						poi["geometry"] = {};
						poi["geometry"]["type"] = "Point";
						let coordinates: number[] = [];
						coordinates.push(Number(poi["longitude"]));
						coordinates.push(Number(poi["latitude"]));
						poi["geometry"]["coordinates"] = coordinates;
						delete poi.latitude;
						delete poi.longitude;
					}));
					return finalResponse;
					//return layers;
					// -- end -- layer set response 
				} catch (error) {
					//return [];
					console.log(error);
				}
			} else {return [];}
		}
	}
	async filterLayerDetails(query) {
		if(!query["types"]) {
			throw new HttpException({
				status: HttpStatus.BAD_REQUEST,
				error: "Request body must contain 'types'"
			},HttpStatus.BAD_REQUEST);
		}
		const types = query["types"] as string[];
		let requestedKeys = [];
		if(query?.["keys"]?.length) {
			requestedKeys = query["keys"] as string[];
		}

		let reqLayerDetail = [];
		if(query?.["keys"]?.length) {
			reqLayerDetail = await this.layerDetailRepository
				.createQueryBuilder("layer_detail")
				.select(["key",'"dataType"'])
				.distinct(true)
				.where(`"layerId" IN (SELECT id FROM layer WHERE type IN(:...types))`,{types : types})
				.andWhere(`key IN(:...keys)`,{keys: requestedKeys})
				.getRawMany();
		} else {
			reqLayerDetail = await this.layerDetailRepository
				.createQueryBuilder("poi_detail")
				.select(["key",'"dataType"'])
				.distinct(true)
				.where(`"layerId" IN (SELECT id FROM layer WHERE type IN(:...types))`,{types : types})
				.getRawMany();
		}
		console.log("KEYS :",reqLayerDetail);

		const reqKeys = [];

		await Promise.all(reqLayerDetail.map(eachlayerDetail => {
			const tempObj = {};
			tempObj["key"] = eachlayerDetail.key;
			tempObj["dataType"] = eachlayerDetail.dataType;
			reqKeys.push(tempObj);
			
		}));
		await Promise.all(reqKeys.map(async eachKey => {
			if(eachKey.dataType == "number") {
				console.log("Number type found");
			} else {
				const values = await this.layerDetailRepository
					.createQueryBuilder("layer_detail")
					.select(['value','unit'])
					.where('key = :key AND "layerId" IN (SELECT id FROM layer WHERE type IN(:...types))', { key: eachKey["key"] , types: types})
					.distinct(true)
					.getRawMany();
				const sortedValues = _.sortBy(values,"unit");
				if(sortedValues.length>Number(process.env.MINIMUM_LIMIT_FOR_FILTER)) {
					eachKey["values"] = "Not Filterable";
				}
				else{
					eachKey["values"] = sortedValues.map(eachValue => {
						return eachValue.value;
					});
				}
			}
		}));

		return reqKeys;
	}
	async filterQuery(layerIds: number[], key) {
		return await this.layerDetailRepository
				.createQueryBuilder("layer_detail")
				.where('key = :key AND "layerId" IN (:...layerIds)', { key: key, layerIds: layerIds })
				.select('unit')
				.distinct(true)
				.getRawMany();
	}


	async getAllLayerTypes(query) {
		if (query["category"]) {
			const layerNames = await this.layerRepository.createQueryBuilder("layer")
				.select("type")
				.where("layer.category = :category", {category: query["category"]})
				.distinct(true)
				.getRawMany();
			console.log("Total Number of Layer Types in DB :",layerNames.length);
			const response = [];
			await Promise.all(layerNames.map(eachLayerName => {
				response.push(eachLayerName["type"]);
			}));
			return response;	
		} else {
			const layerNames = await this.layerRepository.createQueryBuilder("layer")
				.select("type")
				.distinct(true)
				.getRawMany();
			console.log("Total Number of Types in DB :",layerNames.length);
			const response = [];
			await Promise.all(layerNames.map(eachLayerName => {
				response.push(eachLayerName["type"]);
			}));
			return response;	
		}
	}

}
