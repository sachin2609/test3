import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ApiKeyOrganisation } from 'src/api-key-organisations/api-key-organisations.entity';
import { ApiKeyUserApiUsageHistory } from 'src/api-key-user-api-usage/api-key-user-api-usage.entity';
import { ApiKeyUserCredits } from 'src/api-key-users/api-key-users-credits.entity';
import { ApiKeyUser } from 'src/api-key-users/api-key-users.entity';
import { ApiKeyIp } from 'src/auth/apiKey-ip.entity';
import { UserIdIp } from 'src/auth/userId-ip.entity';
import { RolesGuardService } from 'src/helpers/roles-guard/roles-guard.service';
import { Organisation } from 'src/organisations/organisations.entity';
import { Shape } from 'src/shape/shape.entity';
import { UserApiUsageHistory } from 'src/user-api-usage-history/user-api-usage-history.entity';
import { UserCredits } from 'src/user-history/user-credits.entity';
import { User } from 'src/users/users.entity';
import { ExportDataController } from './export-data.controller';
import { ExportData } from './export-data.entity';
import { ExportDataService } from './export-data.service';
import { Team } from 'src/team/team.entity';

@Module({
	imports:[
		TypeOrmModule.forFeature([
			ExportData,
			User,
			Team,
			Organisation,
			ApiKeyUser,
			ApiKeyOrganisation,
			UserIdIp,
			Shape,
			ApiKeyIp,
			ApiKeyUserCredits,
			ApiKeyUserApiUsageHistory,
			UserApiUsageHistory,
			UserCredits,
			ApiKeyUserCredits
		]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		})
	],
	controllers: [ExportDataController],
	providers: [ExportDataService,RolesGuardService]
})
export class ExportDataModule {}
