import { Body, Controller, Headers, Post } from "@nestjs/common";
import { ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Roles, RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { SecurityService } from "./security.service";
import { IPRiskBody, EncryptedBody } from "./security.entity";
import { RealIP } from "nestjs-real-ip";

@Controller("security")
export class SecurityController {
	constructor(private _securityService: SecurityService, private _rolesGuardService: RolesGuardService) {}

	@Roles("ip_risk_assessment")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/risk-assessment")
	async riskAssessment(
		@Body() body: EncryptedBody | IPRiskBody,
		@Headers() header,
		@RealIP() ip: string,
	): Promise<any> {
		try {
			const resp = await this._securityService.IPRiskAssessment(body);
			if (resp) {
				if (header.token) {
					await this._rolesGuardService.updateCreds(
						header.token,
						1,
						"/security/risk-assessment",
						ip,
						JSON.stringify(body),
					);
				} else {
					await this._rolesGuardService.apiKeyUpdateCreds(
						header["apikey"],
						1,
						"/security/risk-assessment",
						ip,
						JSON.stringify(body),
					);
				}
				return resp;
			}
		} catch (error) {
			console.error(error);
		}
	}
}
