import { Body, Controller, Get, Post , Headers, Delete} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ApiBody, ApiHeader, ApiResponse } from '@nestjs/swagger';
import { Roles } from 'src/helpers/roles-guard/roles-guard.service';
import { DeepDiveConfig } from './deep-dive-config.entity';
import { DeepDiveConfigService } from './deep-dive-config.service';

@Controller('deep-dive-config')
export class DeepDiveConfigController {
	constructor(
		private _deepDiveConfigService: DeepDiveConfigService, 
		private _jwtService: JwtService
	) {}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Header" })
	@ApiBody({type: DeepDiveConfig})
	@ApiResponse({ description: "Add DeepDiveConfig" })
	async addDeepDiveConfig(@Body() body: DeepDiveConfig,@Headers() header): Promise<DeepDiveConfig> {
		const user = await this._jwtService.decode(header.token);
		return await this._deepDiveConfigService.addDeepDiveConfig(body,user["id"]);
	}

	@Roles("basic")
	@Get()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "get DeepDiveConfig" })
	async getDeepDiveConfig(@Headers() header): Promise<DeepDiveConfig[]> {
		const user = await this._jwtService.decode(header.token);
		return await this._deepDiveConfigService.getDeepDiveConfig(user["id"]);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create POI" })
	@Delete()
	async delete(@Body() body,@Headers() header):Promise<unknown> {
		const user = await this._jwtService.decode(header.token);
		return await this._deepDiveConfigService.delete(body,user["id"]);
	}

	@Roles("basic")
	@Post("update")
	@ApiHeader({ name: "Header" })
	@ApiBody({type: DeepDiveConfig})
	@ApiResponse({ description: "Add DeepDiveConfig" })
	async updateDeepDiveConfig(@Body() body: DeepDiveConfig,@Headers() header): Promise<DeepDiveConfig> {
		const user = await this._jwtService.decode(header.token);
		return await this._deepDiveConfigService.updateDeepDiveConfig(body,user["id"]);
	}
}
