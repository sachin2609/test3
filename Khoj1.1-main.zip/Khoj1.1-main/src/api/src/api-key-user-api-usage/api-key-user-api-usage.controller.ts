import { Body, Controller, Post, Headers } from "@nestjs/common";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { ApiKeyUserApiUsageService } from "./api-key-user-api-usage.service";
import { TeamService } from "src/team/team.service";

@Controller("api-key-usage")
export class ApiKeyUserApiUsageController {
	constructor(
		private _apiKeyUserApiUsageHistoryService: ApiKeyUserApiUsageService,
		private teamService: TeamService,
	) {}

	@Roles("basic")
	@Post("credit-spent")
	async creditSpent(@Body() body, @Headers() headers) {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		return await this._apiKeyUserApiUsageHistoryService.creditSpent(body, user.id, user.roles);
	}
}
