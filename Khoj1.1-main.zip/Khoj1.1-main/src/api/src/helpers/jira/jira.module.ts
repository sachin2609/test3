import { MailerModule } from '@nestjs-modules/mailer';
import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Organisation } from 'src/organisations/organisations.entity';
import { User } from 'src/users/users.entity';
import { JiraController } from './jira.controller';
import { JiraService } from './jira.service';
import * as path from "path";
import { HandlebarsAdapter } from "@nestjs-modules/mailer/dist/adapters/handlebars.adapter";

@Module({
    imports: [
        HttpModule.register({
			timeout: 100000,
      		maxRedirects: 100
		}),
        JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		}),
        TypeOrmModule.forFeature([Organisation,User]),
        MailerModule.forRoot({
			transport: {
				host: "smtp.gmail.com",
				port: 587,
				ignoreTLS: true,
				secure: false,
				service: "gmail",
				auth: {
					user: process.env.MAILDEV_INCOMING_USER,
					pass: process.env.MAILDEV_INCOMING_PASS
				},
				tls: { rejectUnauthorized: false }
			},
			defaults: {
				from: "datasutram01@wellnessforever.in"
			},
			template: {
				dir: path.join(process.env.PWD, "templates/pages"),
				adapter: new HandlebarsAdapter(),
				options: {
					strict: false
				}
			},
			options: {
				partials: {
					dir: path.join(process.env.PWD, "templates/partials"),
					options: {
						strict: true
					}
				}
			}
		})
    ],
    controllers: [JiraController],
    providers: [JiraService]
})
export class JiraModule {}