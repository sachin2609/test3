import { ApiProperty } from "@nestjs/swagger";

export enum AggregateType {
	count = "count",
	average = "average",
	categorise = "categorise"
}
export class AggregateQuery {
	@ApiProperty()
	category: string;

	@ApiProperty()
	propertyId: number;

	@ApiProperty()
	gridId: number;

	@ApiProperty()
	type: AggregateType;

	@ApiProperty()
	latitude: number;

	@ApiProperty()
	longitude: number;

	@ApiProperty()
	radius: number;

	@ApiProperty()
	poiType: string;
}
