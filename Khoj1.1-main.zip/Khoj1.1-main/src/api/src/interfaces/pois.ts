import { ApiProperty } from "@nestjs/swagger";

export class PoisQuery {
	@ApiProperty()
	level: string;

	@ApiProperty()
	levelName: string;

	//@ApiProperty()
	type: string;
}