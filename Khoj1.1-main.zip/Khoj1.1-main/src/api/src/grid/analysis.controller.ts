import { Controller, Post, Body, Get, Param , Query, Headers, HttpException, HttpStatus, UseInterceptors, Request, Req } from "@nestjs/common";
import { GridService } from "./grid.service";
import { Grid } from "./grids.entity";
import { GridWithIndexRanges, GridWithIndexRangesNew, Indexquery } from "../interfaces/grid";
import { ApiTags, ApiBody, ApiParam, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { LatLng } from "../interfaces/poi";
import { Roles, RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { query, request } from "express";
import { GlobalServiceService } from "src/helpers/global-service/global-service.service";
import { JwtService } from "@nestjs/jwt";
import { CacheKey } from "src/helpers/cache/cache-key.decorator";
import { CacheInterceptorInterceptor } from "src/helpers/cache/cache-interceptor.interceptor";
import { RealIP } from 'nestjs-real-ip';
import { CachePopulateInterceptor } from "src/helpers/cache/cache-populate.interceptor";
import { CoordinateAnalysisBody, PincodeAnalysisBody } from "src/interfaces/analysis";

//import { Query } from "mongoose";
@ApiTags("analysis")
@Controller("analysis")
export class AnalysisController {
	constructor(
		private _gridService: GridService, 
		private _globalService : GlobalServiceService, 
		private _jwtService: JwtService,
		private _rolesGuardService: RolesGuardService
	) {}

	@Roles("basic")
    @Post("pincode")
    async pincodeAnalysis(@Body() body: PincodeAnalysisBody,@Headers() header, @RealIP() ip: string) {
        if(header.token) {
            await this._rolesGuardService.updateCreds(header.token, 1 ,"/grid/search" , ip , JSON.stringify(body));
        } else {
            await this._rolesGuardService.apiKeyUpdateCreds((header["apikey"] || header["apiKey"] || header["api-key"]), 1 ,"/analysis/pincode",ip,JSON.stringify(body));
        }
        return await this._gridService.pincodeAnalysis(body);
    }

    @Roles("basic")
    @Post("coordinates")
    async coordinatesAnalysis(@Body() body: CoordinateAnalysisBody,@Headers() header, @RealIP() ip: string) {
        if(header.token) {
            await this._rolesGuardService.updateCreds(header.token,1,"/grid/search",ip,JSON.stringify(body));
        } else {
            await this._rolesGuardService.apiKeyUpdateCreds((header["apikey"] || header["apiKey"] || header["api-key"]),1,"/analysis/coordinates",ip,JSON.stringify(body));
        }
        return await this._gridService.coordinatesAnalysis(body);
    }

}
