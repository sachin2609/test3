import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Answer } from "src/answer/answer.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Organisation } from "src/organisations/organisations.entity";
import { Poi } from "src/poi/poi.entity";
import { User } from "src/users/users.entity";
import { Kpi } from "src/kpi/kpi.entity";
import { MonitoringService } from "./monitoring.service";
import { MonitoringController } from "./monitoring.controller";
import { Team } from "src/team/team.entity";
import { Lead, LeadStatusUpdates, LostLead } from "src/leads/leads.entity";
import { TeamService } from "src/team/team.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
import { PoiDetail } from "src/poi-details/poi-details.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { Reminder, ReminderUpdate } from "src/reminders/reminders.entity";
import { MerchantService } from "src/merchant/merchant.service";
import { PoiGrid } from "src/relations/poi-grid/poi-grid.entity";
import { Grid } from "src/grid/grids.entity";
import { Indexmaster } from "src/index-master/index-master.entity";
import { Shape } from "src/shape/shape.entity";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { UserMerchant } from "src/merchant/user-merchant.entity";
import { ApiKeyUserMerchant } from "src/merchant/api-key-user-merchant.entity";
import { MongooseModule } from "@nestjs/mongoose";
import { DemoShapesDBSchema } from "src/shape/shape.schema";
import { GridService } from "src/grid/grid.service";
import { PoiService } from "src/poi/poi.service";
import { ShapeService } from "src/shape/shape.service";
import { HttpModule } from "@nestjs/axios";
import { PropertyGrid } from "src/relations/property-grid/property-grid.entity";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { Poiexported } from "src/poi/poisExported.entity";
import { POIFilter, POIFilterUserTeam } from "src/poi-filter/poi-filter.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
import { PromptLog } from "src/prompt-log/prompt-log.entity";
import { Note } from "src/notes/notes.entity";
import { CacheModule } from "@nestjs/cache-manager";
import * as redisStore from "cache-manager-redis-store";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";

@Module({
	imports: [
		HttpModule.register({
			timeout: 100000,
			maxRedirects: 100,
		}),
		TypeOrmModule.forFeature([
			Kpi,
			User,
			ApiKeyUser,
			Organisation,
			ApiKeyOrganisation,
			Answer,
			Poi,
			Team,
			Lead,
			UserCredits,
			LostLead,
			LeadStatusUpdates,
			Indexmaster,
			Shape,
			ShapeDetail,
			UserMerchant,
			ApiKeyUserMerchant,
			PoiDetail,
			Grid,
			PoiGrid,
			PropertyGrid,
			Shapeindex,
			MonitoringModule,
			Poiexported,
			POIFilter,
			POIFilterUserTeam,
			Reminder,
			Note,
			PoiDetail,
			PromptLog,
			ReminderUpdate,
			LostLead,
		]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		MongooseModule.forFeature([{ name: "DemoShapesDB", schema: DemoShapesDBSchema }]),
		MongoDatabaseModule,
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
	],
	controllers: [MonitoringController],
	providers: [
		MonitoringService,
		TeamService,
		KeyCloakService,
		CentralServerService,
		MerchantService,
		GridService,
		PoiService,
		ShapeService,
		SyslogService,
	],
})
export class MonitoringModule {}
