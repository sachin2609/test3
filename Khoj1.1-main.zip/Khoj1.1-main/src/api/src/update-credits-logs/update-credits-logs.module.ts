import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UpdateCreditsLogsController } from './update-credits-logs.controller';
import { UpdateCreditsLogs } from './update-credits-logs.entity';
import { UpdateCreditsLogsService } from './update-credits-logs.service';

@Module({
	imports: [
		TypeOrmModule.forFeature([UpdateCreditsLogs])
	],
	controllers: [UpdateCreditsLogsController],
	providers: [UpdateCreditsLogsService]
})
export class UpdateCreditsLogsModule {}
