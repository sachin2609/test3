import { Module } from "@nestjs/common";
import { CacheModule } from "@nestjs/cache-manager";
import { ShapeController } from "./shape.controller";
import { ShapeService } from "./shape.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { MongooseModule } from "@nestjs/mongoose";
import { DemoShapesDBSchema } from "./shape.schema";
import { Shape } from "./shape.entity";
import { Grid } from "../grid/grids.entity";
import { Shapeindex } from "./shapeIndex.entity";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { JwtModule } from "@nestjs/jwt";
import { GlobalServiceService } from "src/helpers/global-service/global-service.service";
import { User } from "src/users/users.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
import * as redisStore from "cache-manager-redis-store";
import { RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { Organisation } from "src/organisations/organisations.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { Team } from "src/team/team.entity";
@Module({
	imports: [
		MongooseModule.forFeature([{ name: "DemoShapesDB", schema: DemoShapesDBSchema }]),
		TypeOrmModule.forFeature([
			Shape,
			Grid,
			Shapeindex,
			ShapeDetail,
			User,
			Team,
			Organisation,
			UserApiUsageHistory,
			UserCredits,
			ApiKeyOrganisation,
			ApiKeyUser,
			ApiKeyUserApiUsageHistory,
			ApiKeyUserCredits,
			ApiKeyIp,
			UserIdIp,
		]),
		MongoDatabaseModule,
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
	],
	controllers: [ShapeController],
	providers: [ShapeService, GlobalServiceService, RolesGuardService],
})
export class ShapeModule {}
