import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { MongooseModule } from '@nestjs/mongoose';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GlobalServiceModule } from 'src/helpers/global-service/global-service.module';
import { GlobalServiceService } from 'src/helpers/global-service/global-service.service';
import { Grid } from 'src/grid/grids.entity';
import { Indexmaster } from 'src/index-master/index-master.entity';
import { MongoDatabaseModule } from 'src/helpers/mongo-database/mongo-database.module';
import { PoiDetail } from 'src/poi-details/poi-details.entity';
import { Poi } from 'src/poi/poi.entity';
import { Property } from 'src/property/property.entity';
import { PoiGrid } from 'src/relations/poi-grid/poi-grid.entity';
import { PoiShape } from 'src/relations/poi-shape/poi-shape.entity';
import { TargetShapeService } from 'src/relations/target-shape/target-shape.service';
import { ShapeDetail } from 'src/shape-details/shape-details.entity';
import { Shape } from 'src/shape/shape.entity';
import { DemoShapesDBSchema } from 'src/shape/shape.schema';
import { ShapeService } from 'src/shape/shape.service';
import { Shapeindex } from 'src/shape/shapeIndex.entity';
import { TargetDetail } from 'src/target-details/target-details.entity';
import { TargetService } from 'src/target/target.service';
import { User } from 'src/users/users.entity';
import { TargetGridShapeController } from './target-grid-shape.controller';

@Module({
	imports: [
		TypeOrmModule.forFeature([PoiGrid, Poi, Property, Grid, TargetDetail, User, PoiDetail, Indexmaster,PoiShape,Shapeindex,Shape,ShapeDetail]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		}),
		GlobalServiceModule,
        MongooseModule.forFeature([{ name: 'DemoShapesDB', schema: DemoShapesDBSchema }]),
        MongoDatabaseModule
	],
	controllers: [TargetGridShapeController],
	providers: [TargetService,GlobalServiceService,TargetShapeService, ShapeService]
})
export class TargetGridShapeModule {}
