import { PrimaryColumn, Entity, Column } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

export enum Role {
	analyzer = "analyzer",
	verifier = "verifier",
	approver = "approver"
}

@Entity()
export class UserGrid {
	@ApiProperty()
	@Column()
	userId: number;

	@ApiProperty()
	@PrimaryColumn()
	gridId: number;

	@ApiProperty()
	@PrimaryColumn()
	zone: string;

	@ApiProperty()
	@PrimaryColumn()
	role: Role;
}
