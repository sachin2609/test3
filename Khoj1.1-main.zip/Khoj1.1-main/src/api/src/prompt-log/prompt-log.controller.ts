import { Body, Controller, Headers, HttpStatus, Post, Req } from "@nestjs/common";
import { PromptLogService } from "./prompt-log.service";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { AddPromptLogDto, FetchPromptLogDto } from "src/interfaces/prompt-log";
import { TeamService } from "src/team/team.service";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";
import { Request } from "express";
import { RealIP } from "nestjs-real-ip";

@Controller("prompt-log")
export class PromptLogController {
	constructor(
		private readonly _promptLogService: PromptLogService,
		private teamService: TeamService,
		private _syslogService: SyslogService,
	) {}

	async getUser(headers: any): Promise<{ tokenUser: Partial<User>; apiKeyUser: Partial<ApiKeyUser> }> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		const tokenUser = user["type"] === "token" ? (user as User) : undefined;
		const apiKeyUser = user["type"] === "apikey" ? (user as ApiKeyUser) : undefined;
		if (!tokenUser && !apiKeyUser) {
			throw new Error("Invalid token");
		}
		return { tokenUser, apiKeyUser };
	}

	@Roles(Role.BASIC)
	@Post("create")
	async createPromptLog(@Headers() headers, @Body() body: AddPromptLogDto, @Req() req: Request, @RealIP() ip) {
		try {
			const { tokenUser, apiKeyUser } = await this.getUser(headers);
			body.tokenUserId = tokenUser?.id ?? undefined;
			body.apiKeyUserId = apiKeyUser?.id ?? undefined;
			const res = await this._promptLogService.createPromptLog(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("fetch")
	async fetchPromptLog(@Headers() headers, @Body() body: FetchPromptLogDto, @Req() req: Request, @RealIP() ip) {
		try {
			const { tokenUser, apiKeyUser } = await this.getUser(headers);
			if (!body.userId) body.userId = [apiKeyUser?.id ?? tokenUser?.id];
			const res = await this._promptLogService.fetchPromptLog(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.log(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}
}
