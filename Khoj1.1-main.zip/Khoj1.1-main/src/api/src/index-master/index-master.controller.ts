import { Controller, Post, Body } from "@nestjs/common";
import { IndexMasterService } from "./index-master.service";
import { Indexmaster } from "./index-master.entity";
import { ApiTags, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { UpdateResult } from "typeorm";
@ApiTags("index-master")
@Controller("index-master")
export class IndexMasterController {
	constructor(private _indexMasterService: IndexMasterService) {}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create Indexmaster" })
	async create(): Promise<Indexmaster[]> {
		return await this._indexMasterService.create();
	}

	@Roles("basic")
	@Post("populatebp")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Populate Business Potential" })
	async populateBP(): Promise<void> {
		return await this._indexMasterService.populateBusinessPotential();
	}

	@Roles("basic")
	@Post("update")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Update Index Master" })
	async update(@Body() body: Indexmaster[]): Promise<UpdateResult[]> {
		return await this._indexMasterService.update(body);
	}
}
