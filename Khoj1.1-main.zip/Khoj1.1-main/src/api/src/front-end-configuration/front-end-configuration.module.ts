import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FrontEndConfigurationController } from './front-end-configuration.controller';
import { FrontEndConfiguration } from './front-end-configuration.entity';
import { FrontEndConfigurationService } from './front-end-configuration.service';

@Module({
    imports: [
        TypeOrmModule.forFeature([
            FrontEndConfiguration
        ])
    ],
    controllers: [FrontEndConfigurationController],
    providers: [FrontEndConfigurationService]
})
export class FrontEndConfigurationModule {}
