export class Issue {
	issue: string;
	description: string;
	userId: number;
	phoneNumber: string;
	email: string;
	username: string;
	client: string;
	team: string;
	attachments?: string | string[];
	createdAt: Date;
}
