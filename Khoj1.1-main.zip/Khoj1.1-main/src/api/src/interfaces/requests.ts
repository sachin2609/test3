// this module is used as request and response class definitions for routing modules
import { ApiProperty } from "@nestjs/swagger";
import { PoiStatus } from "src/poi/poi.entity";
import { LatLong } from "./poi";
class Location {
	@ApiProperty({
		description: "Locality to search points for",
		default: "Airoli",
		example: "Colaba"
	})
	Locality: string;
	City: string;
	Pincode: string;
}

class MinMax {
	@ApiProperty({example:1})
	min: number;

	@ApiProperty({example:5})
	max: number;
}

class Grids {
	@ApiProperty()
	indexName: MinMax;
}

export class LatLngNew {
	@ApiProperty()
	lat: number;

	@ApiProperty()
	lng: number;
}

class Within {
	@ApiProperty({example: [{"lat":"18.9067","lng":"72.81470999999999"}]})
	points: LatLngNew[];

	@ApiProperty({example: 3})
	radius: number;
}

class PoiDetails {
	@ApiProperty()
	key: string;

	@ApiProperty()
	dataType: string;

	@ApiProperty()
	values: MinMax;
}

export class FilterQuery {

	@ApiProperty()
	location: Location;

	limit: number;

	page: number;

	@ApiProperty({
		description: "Type of the point to return (categorise further)",
		default: ["banks"]
	})
	types: string[];
	
	poiStatus: PoiStatus;

	@ApiProperty()
	category?: string;

	@ApiProperty()
	count?: number;

	@ApiProperty()
	gst?: string[];
}

export class FilterQueryRequest {

	@ApiProperty({
		description: "Use Either 'Locality' OR 'City' OR 'State' OR 'Pincode'"
	})
	location: Location;

	//@ApiProperty()
	grids: Grids;

	@ApiProperty()
	within: Within;

	@ApiProperty({example: [
		{"key":"income_group","dataType":"string","values":["HIG","MIG"]},
		{"key":"price","dataType":"number","values":{"min":0,"max":10000}}
	]})
	poiDetails: PoiDetails[];

	//@ApiProperty({example: 10})
	limit: number;

	//@ApiProperty({example: 2})
	page: number;

	@ApiProperty({
		description: "Type of the point to return (categorise further)",
		default: ["banks"],
		example:["banks","atm"]
	})
	types: string[];
	
	@ApiProperty({example:"approved"})
	poiStatus: PoiStatus;

	//@ApiProperty({example: "count"})
	responseType: string;
}
