import { Body, Controller, Get, Headers, Post, Put, Query } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { FilterIssue, Issue } from "src/interfaces/jira";
import { Roles } from "../roles-guard/roles-guard.service";
import { JiraService } from "./jira.service";

@Controller('jira')
export class JiraController {
    constructor(
        private jiraService: JiraService,
        private jwtService: JwtService
    ) {}

    @Roles("admin")
    @Get("projects")
    async getAllProjects() {
        return await this.jiraService.getAllProjects();
    }

    @Roles("admin")
    @Get('issues')
    async getIssues() {
        return await this.jiraService.getAllIssues();
    }

    @Roles("basic")
    @Post('custom-fields')
    async getCustomFields(@Body() body) {
        return await this.jiraService.findCustomFieldId(body);
    }

    @Roles("basic")
    @Post('issue-types')
    async getIssueTypesId(@Body() body) {
        return await this.jiraService.findIssueTypeId(body);
    }

    @Roles("basic")
    @Post("issue")
    async createIssue(@Body() body: Issue, @Headers() headers) {
        try {
            let user;
            if(headers?.["token"]) {
                user = await this.jwtService.decode(headers["token"]) as JSON;
            } else {
                let apiKey;
		    	if(headers["apikey"]) {
		    		apiKey = headers["apikey"];
		    	}
		    	if(headers["api-key"]) {
		    		apiKey = headers["api-key"];
		    	}
		    	if(headers["apiKey"]) {
		    		apiKey = headers["apiKey"];
		    	}
                user = await this.jwtService.decode(apiKey) as JSON;
            }
            return await this.jiraService.createIssue(body,user);
        } catch(err) {
            throw err;
        }
    }

    @Roles("basic")
    @Put("issue")
    async editIssue(@Body() body: Issue, @Headers() headers) {
        let user;
        if(headers?.["token"]) {
            user = await this.jwtService.decode(headers["token"]) as JSON;
        } else {
            let apiKey;
			if(headers["apikey"]) {
				apiKey = headers["apikey"];
			}
			if(headers["api-key"]) {
				apiKey = headers["api-key"];
			}
			if(headers["apiKey"]) {
				apiKey = headers["apiKey"];
			}
            user = await this.jwtService.decode(apiKey) as JSON;
        }
        return await this.jiraService.editIssue(body,user);
    }

    @Roles("basic")
    @Post("get-raised-issues")
    async getRaisedIssue(@Body() body: FilterIssue, @Headers() headers ) {
        return await this.jiraService.getRaisedIssue(body as FilterIssue, headers);
    }

    @Roles("basic")
    @Post("overview")
    async overview(@Body() body: FilterIssue, @Headers() headers) {
        let user;
        if(headers?.["token"]) {
            user = await this.jwtService.decode(headers["token"]) as JSON;
        } else {
            let apiKey;
			if(headers["apikey"]) {
				apiKey = headers["apikey"];
			}
			if(headers["api-key"]) {
				apiKey = headers["api-key"];
			}
			if(headers["apiKey"]) {
				apiKey = headers["apiKey"];
			}
            user = await this.jwtService.decode(apiKey) as JSON;
        }
        return await this.jiraService.overview(body as FilterIssue,user);
    }

    //@Roles("basic")
    @Post("issue-transitioned")
    async issueTransitioned(@Body() body) {
        await this.jiraService.issueTransitioned(body);
        return true;
    }
}
