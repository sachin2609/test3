export class FrontEndConfigurationId {
    id: number;
}

export class PostFrontEndConfigurationBody {
	name: string;
	configuration: string;
}

export class UpdateFrontEndConfigurationBody {
	id: number;
	name?: string;
	configuration?: string;
}
