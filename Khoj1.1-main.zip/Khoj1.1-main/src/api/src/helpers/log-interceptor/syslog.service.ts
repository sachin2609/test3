import { Injectable } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import * as dotenv from "dotenv";
import { logger } from "./logger";
import { LoggerPayload } from "../../interfaces/logs";
import { User } from "src/users/users.entity";
dotenv.config();

@Injectable()
export class SyslogService {
	constructor(private _jwtService: JwtService) {}
	async log(payload: LoggerPayload) {
		try {
			const { req, level = "info", message, statusCode, ip, creditsUsed } = payload;
			const tokenDecoded = this._jwtService.decode(
				(req.headers["token"] as string) ||
					(req.headers["apikey"] as string) ||
					(req.headers["api-key"] as string),
			) as User;
			const { path } = req;
			logger.log({
				ip: ip,
				route: path,
				level: level,
				message: message,
				statusCode: statusCode,
				creditsUsed: creditsUsed,
				userType: tokenDecoded?.["type"],
				email: tokenDecoded?.email ? tokenDecoded.email : undefined,
				phoneNumber: tokenDecoded?.phoneNumber ? tokenDecoded.phoneNumber : undefined,
			});
		} catch (error) {
			return { response: "Failure" };
		} finally {
			return { response: "Success!" };
		}
	}

	async error(payload: LoggerPayload) {
		try {
			const { req, level = "err", message, statusCode, ip, creditsUsed } = payload;
			const tokenDecoded = this._jwtService.decode(
				(req.headers["token"] as string) ||
					(req.headers["apikey"] as string) ||
					(req.headers["api-key"] as string),
			) as User;
			const { path } = req;
			logger.error({
				ip: ip,
				route: path,
				level: level,
				message: message,
				statusCode: statusCode,
				creditsUsed: creditsUsed,
				userType: tokenDecoded?.["type"],
				email: tokenDecoded?.email ? tokenDecoded.email : undefined,
				phoneNumber: tokenDecoded?.phoneNumber ? tokenDecoded.phoneNumber : undefined,
			});
		} catch (error) {
			return { response: "Failure" };
		} finally {
			return { response: "Success!" };
		}
	}

	async warning(payload: LoggerPayload) {
		try {
			const { req, level = "warn", message, statusCode, ip, creditsUsed } = payload;
			const tokenDecoded = this._jwtService.decode(
				(req.headers["token"] as string) ||
					(req.headers["apikey"] as string) ||
					(req.headers["api-key"] as string),
			) as User;
			const { path } = req;
			logger.warning({
				ip: ip,
				route: path,
				level: level,
				message: message,
				statusCode: statusCode,
				creditsUsed: creditsUsed,
				userType: tokenDecoded?.["type"],
				email: tokenDecoded?.email ? tokenDecoded.email : undefined,
				phoneNumber: tokenDecoded?.phoneNumber ? tokenDecoded.phoneNumber : undefined,
			});
		} catch (error) {
			return { response: "Failure" };
		} finally {
			return { response: "Success!" };
		}
	}
}
