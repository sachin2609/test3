import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DeepDiveConfigController } from './deep-dive-config.controller';
import { DeepDiveConfig } from './deep-dive-config.entity';
import { DeepDiveConfigService } from './deep-dive-config.service';

@Module({
	imports: [
		TypeOrmModule.forFeature([DeepDiveConfig]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		})
	],
  	controllers: [DeepDiveConfigController],
  	providers: [DeepDiveConfigService]
})
export class DeepDiveConfigModule {}
