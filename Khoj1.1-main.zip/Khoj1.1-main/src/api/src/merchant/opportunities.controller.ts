import { Body, Controller, Headers, Post, HttpException, HttpStatus, Get, Req } from "@nestjs/common";
import { ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { MerchantService } from "./merchant.service";
import { RolesGuardService } from "../helpers/roles-guard/roles-guard.service";
import { RealIP } from "nestjs-real-ip";
import { JwtService } from "@nestjs/jwt";
import { FetchMerchantsBodyDto } from "src/interfaces/merchant";
import { TeamService } from "src/team/team.service";
import { isArray } from "lodash";
import { Request } from "express";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";

@Controller("opportunities")
export class OpportunitiesController {
	constructor(
		private _merchantService: MerchantService,
		private _rolesGuardService: RolesGuardService,
		private _jwtService: JwtService,
		private teamService: TeamService,
		private _syslogService: SyslogService,
	) {}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("save-against-user")
	async saveMerchantsAgainstUser(@Body() body, @Headers() headers, @Req() req: Request, @RealIP() ip) {
		try {
			const user = this._jwtService.decode(
				headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"],
			);
			const res = await this._merchantService.saveMerchantsAgainstUser(user["id"] as number, body, user["type"]);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles("merchant_acquisition")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("get-merchants")
	async getMerchantsAgainstIds(@Body() body, @Headers() header, @RealIP() ip: string, @Req() req: Request) {
		try {
			const resp = await this._merchantService.getMerchantsAgainstIds(body);
			console.log("deducting ", resp["count"]);
			let credsResp;
			if (header.token) {
				credsResp = await this._rolesGuardService.updateCreds(
					header.token,
					resp["count"],
					"/merchant/get-merchants",
					ip,
					JSON.stringify(body),
				);
			} else {
				credsResp = await this._rolesGuardService.apiKeyUpdateCreds(
					header["apikey"],
					resp["count"],
					"/merchants/get-merchants",
					ip,
					JSON.stringify(body),
				);
			}
			console.log("response from creds deduction", credsResp);
			if (credsResp) {
				await this._syslogService.log({
					ip: ip,
					req: req,
					level: "info",
					message: "Success",
					statusCode: HttpStatus.OK,
					creditsUsed: resp.count,
				});
				return resp;
			} else {
				throw new HttpException(
					{
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left",
					},
					HttpStatus.FORBIDDEN,
				);
			}
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Get("get-merchantIds")
	async getMerchantIdsAgainstUser(@Headers() headers, @RealIP() ip: string, @Req() req: Request) {
		try {
			const user = this._jwtService.decode(
				headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"],
			);
			const res = await this._merchantService.getMerchantIdsAgainstUser(user["id"] as number, user["type"]);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("delete-against-user")
	async deleteMerchantsAgainstUser(@Body() body, @Headers() headers, @RealIP() ip: string, @Req() req: Request) {
		try {
			const user = await this._jwtService.decode(
				headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"],
			);
			const res = await this._merchantService.deleteMerchantsAgainstUser(
				user["id"] as number,
				body,
				user["type"],
			);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Get("fetch/count")
	async fetchCounts(@Headers() headers, @RealIP() ip: string, @Req() req: Request) {
		try {
			const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
			const user = await this.teamService.decodeUserJWT(tokenAPIKey);
			const resp = await this._merchantService.fetchCounts(user);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return resp;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("fetch")
	async fetchMerchants(
		@Headers() headers,
		@Body() body: FetchMerchantsBodyDto,
		@RealIP() ip: string,
		@Req() req: Request,
	) {
		try {
			const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
			const user = await this.teamService.decodeUserJWT(tokenAPIKey);
			if (!this._merchantService.validateOpportunityPayload(body)) {
				throw new HttpException(
					"Please provide neccessary requirements for fetching opportunities",
					HttpStatus.BAD_REQUEST,
				);
			}
			const resp = await (async () => {
				if (process.env.FETCH_OPPORTUNITY_NEAR_POI_TYPE === "true") {
					const types = JSON.parse(process.env.POI_TYPES_FOR_NEARBY_FETCH);
					if (isArray(types) && types?.length)
						return await this._merchantService.fetch_opp_close_to_poi_types(body, user);
					else throw new Error("POI Types is not a valid array");
				} else {
					return await this._merchantService.fetchOpportunities(body, user);
				}
			})();
			await this._rolesGuardService.updateCreds(
				tokenAPIKey,
				resp.count,
				"/opportunities/fetch",
				ip,
				JSON.stringify(body),
			);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: resp.count,
			});
			return resp;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.BASIC)
	@Post("fetch-overview")
	async fetchMerchantsOverview(
		@Headers() headers,
		@Body() body: FetchMerchantsBodyDto,
		@RealIP() ip: string,
		@Req() req: Request,
	) {
		try {
			const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
			const user = await this.teamService.decodeUserJWT(tokenAPIKey);
			if (!this._merchantService.validateOpportunityPayload(body)) {
				throw new HttpException(
					"Please provide neccessary requirements for fetching opportunities",
					HttpStatus.BAD_REQUEST,
				);
			}
			const resp = await (async () => {
				if (process.env.FETCH_OPPORTUNITY_NEAR_POI_TYPE === "true") {
					const types = JSON.parse(process.env.POI_TYPES_FOR_NEARBY_FETCH);
					if (isArray(types) && types?.length)
						return await this._merchantService.fetch_opp_close_to_poi_types_overview(body, user);
					else throw new Error("POI Types is not a valid array");
				} else {
					return await this._merchantService.fetchOpportunitiesOverview(body, user);
				}
			})();
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return resp;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}
}
