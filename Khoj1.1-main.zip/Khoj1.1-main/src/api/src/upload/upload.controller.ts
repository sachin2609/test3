import {
	Controller,
	Body,
	Post,
	Query,
	Headers,
	UploadedFiles,
	UseInterceptors
} from "@nestjs/common";
import { FilesInterceptor } from "@nestjs/platform-express";
import * as AWS from "aws-sdk";
import * as multerS3 from "multer-s3";
import { JwtService } from "@nestjs/jwt";
import { Answer } from "../answer/answer.entity";
import { UploadService } from "./upload.service";
import { Header } from "../interfaces/header";
import { ApiTags, ApiBody, ApiHeader, ApiQuery, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
const AWS_S3_BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME;
const s3 = new AWS.S3();
AWS.config.update({
	accessKeyId: process.env.AWS_ACCESS_KEY_ID,
	secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
});
@ApiTags("upload")
@Controller("upload")
export class UploadController {
	constructor(private _jwtService: JwtService, private _uploadService: UploadService) {}
	@Roles("basic")
	@Post()
	@ApiBody({ type: Answer })
	@ApiQuery({ name: "query" })
	@ApiHeader({ name: "header" })
	@ApiResponse({
		description: "PostWithSurveyAnswers"
	})
	@UseInterceptors(
		FilesInterceptor("file", 20, {
			storage: multerS3({
				s3: s3,
				bucket: AWS_S3_BUCKET_NAME,
				acl: "public-read",
				key: function(request, file, cb) {
					cb(null, "surveys/" + `${Date.now().toString()} - ${file.originalname}`);
				}
			})
		})
	)
	async postWithSurveyAnswers(
		@Query() query: JSON,
		@Headers() header: Header,
		@Body() body: Answer,
		@UploadedFiles() files: unknown
	): Promise<Answer> {
		const user = this._jwtService.decode(header.token);
		console.log(files);
		const answer = new Answer();
		answer.questionId = body.questionId;
		answer.uniqueId = body.uniqueId;
		answer.workItemId = body.workItemId;
		answer.answer = files[0]["location"];
		console.log(user);
		console.log(answer);
		answer.faId = user["id"];
		return await this._uploadService.createAnswer(answer);
	}
}
