import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import _ = require('lodash');
import { MultilevelShapesQuery } from 'src/interfaces/shapes';
import { PoiDetail } from 'src/poi-details/poi-details.entity';
import { Poi } from 'src/poi/poi.entity';
import { ShapeService } from 'src/shape/shape.service';
import { Shapeindex } from 'src/shape/shapeIndex.entity';
import { TargetDetail } from 'src/target-details/target-details.entity';
import { User } from 'src/users/users.entity';
import { createQueryBuilder, In, Repository } from 'typeorm';
import { PoiShape } from '../poi-shape/poi-shape.entity';

@Injectable()
export class TargetShapeService {
    constructor(
		@InjectRepository(PoiShape) private poiShapeRepository: Repository<PoiShape>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(Shapeindex) private shapeIndexRepository: Repository<Shapeindex>,
		@InjectRepository(PoiDetail) private poiDetailRepository: Repository<PoiDetail>,
        @InjectRepository(User) private userRepository: Repository<User>,
        @InjectRepository(TargetDetail) private targetDetailRepository: Repository<TargetDetail>,
		private _shapeService: ShapeService
	) {}

    async filter(userId:number, query: MultilevelShapesQuery) {
        const user = await this.userRepository.findOne({ where: {id: userId}});
		console.log(user);
		const organisationId = user.organisationId;
        const allowedTargetDetails = await this.targetDetailRepository
			.createQueryBuilder("target_detail")
			.select('"poiId"')
			.where(' :orgId = ANY("ownerIds")',{orgId: Number(organisationId)})
			.distinct(true)
			.getRawMany();
		//console.log(allowedTargetDetails);
		const allowedPoiIds = [];
		await Promise.all(allowedTargetDetails.map(eachobj => {
			allowedPoiIds.push(eachobj["poiId"]);
		}));
		console.log("Number of Allowed Pois for "+user.firstName+" "+user.lastName+" with OrgId: "+organisationId+" is :",allowedPoiIds.length);

        //From PoiShape...
        const shapeIds = await this._shapeService.returnShapeIdsmultilevelShapes(query);
		const poiShapeIndexDict = {};
		const shapeIndexDict = {};
		//console.log("shape ids inside poi filter", shapeIds);
		const shapeIndexes = await this.shapeIndexRepository.createQueryBuilder('shapeindex')
			.where('shapeindex."shapeId" IN (:...shapeIds)', { shapeIds: shapeIds })
			.select('"shapeId"')
			.addSelect('"indexName"')
			.addSelect('"indexValue"')
			.addSelect('"indexType"')
			.addSelect('"categoricalValue"')
			.getRawMany();
		shapeIndexes.forEach(eachIndex => {
			if (!shapeIndexDict[eachIndex['shapeId']]) {
				shapeIndexDict[eachIndex['shapeId']] = {};
				if (eachIndex.indexType === 'number') {
					shapeIndexDict[eachIndex['shapeId']][eachIndex.indexName] = eachIndex.indexValue;
				} else {
					shapeIndexDict[eachIndex['shapeId']][eachIndex.indexName] = eachIndex.categoricalValue;
				}
			} else {
				if (eachIndex.indexType === 'number') {
					shapeIndexDict[eachIndex['shapeId']][eachIndex.indexName] = eachIndex.indexValue;
				} else {
					shapeIndexDict[eachIndex['shapeId']][eachIndex.indexName] = eachIndex.categoricalValue;
				}
			}
		});
		const poiShapeRelations = await this.poiShapeRepository.find({ where: {
			shapeId: In(_.flattenDeep(shapeIds)) 
	}});
		let poiIds = poiShapeRelations.map(eachRelation => {
			poiShapeIndexDict[eachRelation.poiId] = shapeIndexDict[eachRelation.shapeId];
			return eachRelation.poiId;
		});
        //getting only targets....
        poiIds = _.intersection(poiIds,allowedPoiIds);
		console.log("Lenth of TargetIds found :",poiIds.length);
		let poiIdsFromPoiDetails = [];
		if(query["poiDetails"]) {
			let intersectionStatus = 0;
			const poiDetails :any[] = query["poiDetails"];
			if(poiDetails.length==0) {
				poiIdsFromPoiDetails = [];
			} else {
				await Promise.all(poiDetails.map(async (eachPoiDetail, index) => {
					if(eachPoiDetail.dataType == "string") {
						const tempPoiIdsFromString = [];
						const tempPoiIds = await this.poiDetailRepository
							.createQueryBuilder("poi_detail")
							.where('key = :key AND value IN(:...values)',{key: eachPoiDetail.key, values: eachPoiDetail.values})
							.select('"poiId"')
							.distinct(true)
							.getRawMany()
						await Promise.all(tempPoiIds.map(eachPoiId => {
							tempPoiIdsFromString.push(eachPoiId.poiId);
						}));
						poiIdsFromPoiDetails.push(tempPoiIdsFromString);
					}
					if(eachPoiDetail.dataType == "number") {
						//console.log("inside numbers query");
						const tempPoiIdsArray = [];
						console.log(eachPoiDetail);
						const tempPoiDetails = await this.poiDetailRepository
							.createQueryBuilder("poi_detail")
							.where('key = :key',{key: eachPoiDetail.key})
							.andWhere('unit BETWEEN :min and :max', {min: eachPoiDetail["values"]["min"], max: eachPoiDetail["values"]["max"]})
							.select('"poiId"')
							.distinct(true)
							.getRawMany()

						console.log("temp poi details", tempPoiDetails);
						await Promise.all(tempPoiDetails.map(eachPoiDetailHere => {
								tempPoiIdsArray.push(eachPoiDetailHere.poiId);
						}));
						poiIdsFromPoiDetails.push(tempPoiIdsArray);
					}
				}));
			}
			poiIdsFromPoiDetails = _.flattenDeep(poiIdsFromPoiDetails);
			//console.log("PoiIds length from poiDetails :",poiIdsFromPoiDetails.length);
			poiIds = _.intersection(poiIdsFromPoiDetails,poiIds);
			//console.log("Length of PoiIds after poiDetails Intersection:",poiIds.length);
		}
        let poiIdsFromTargetDetails = [];
		if(query["targetDetails"]) {
            let intersectionStatus = 0;
            const targetDetails :any[] = query["targetDetails"];
            if(targetDetails.length==0) {
                poiIdsFromTargetDetails = [];
            } else {
                await Promise.all(targetDetails.map(async (eachTargetDetail, index) => {
                    console.log("eachTargetDetail", eachTargetDetail);
                    if(eachTargetDetail.dataType == "string") {
                        const tempTargetIdsFromString = [];
                        const tempPoiIds = await this.targetDetailRepository
                            .createQueryBuilder("target_detail")
                            .where('key = :key AND value IN(:...values)',{key: eachTargetDetail.key, values: eachTargetDetail.values})
                            .select('"poiId"')
                            .distinct(true)
                            .getRawMany()
                        await Promise.all(tempPoiIds.map(eachPoiId => {
                            tempTargetIdsFromString.push(eachPoiId.poiId);
                        }));
                        poiIdsFromTargetDetails.push(_.flattenDeep(tempTargetIdsFromString));
                        //if(poiIdsFromTargetDetails.length == 0 && intersectionStatus == 0) {
                        //	poiIdsFromTargetDetails = tempTargetIdsFromString;
                        //}
                        //if(poiIdsFromTargetDetails.length == 0 && intersectionStatus == 1) {
                        //	poiIdsFromTargetDetails = [];
                        //}
                        //if(poiIdsFromTargetDetails.length > 0 && intersectionStatus == 0) {
                        //	poiIdsFromTargetDetails = _.intersection(poiIdsFromTargetDetails, tempTargetIdsFromString);
                        //	intersectionStatus = 1;
                        //}
                        //if(poiIdsFromTargetDetails.length > 0 && intersectionStatus == 1) {
                        //	poiIdsFromTargetDetails = _.intersection(poiIdsFromPoiDetails, tempTargetIdsFromString);
                        //	intersectionStatus = 1;
                        //}
                    }
                    if(eachTargetDetail.dataType == "number") {
                        const tempTargetIdsArray = [];
                        let tempTargetDetails = []; 
                        try {
                            tempTargetDetails = await this.targetDetailRepository
                                .createQueryBuilder("target_detail")
                                .where('key = :key',{key: eachTargetDetail.key})
                                .andWhere('unit BETWEEN :min and :max', {min: eachTargetDetail["values"]["min"], max: eachTargetDetail["values"]["max"]})
                                .select('"poiId"')
                                .distinct(true)
                                .getRawMany()
                        } catch(error) {console.log(error)}
                        await Promise.all(tempTargetDetails.map(eachTargetDetailHere => {
                                tempTargetIdsArray.push(eachTargetDetailHere.poiId);
                        }));
                        console.log("index in loop is", index);
                        poiIdsFromTargetDetails.push(_.flattenDeep(tempTargetIdsArray));
                        //if(poiIdsFromTargetDetails.length == 0 && intersectionStatus == 0) {
                        //	poiIdsFromTargetDetails = tempTargetIdsArray;
                        //}
                        //if(poiIdsFromTargetDetails.length == 0 && intersectionStatus == 1) {
                        //	poiIdsFromTargetDetails = [];
                        //}
                        //if(poiIdsFromTargetDetails.length > 0 && intersectionStatus == 0) {
                        //	poiIdsFromTargetDetails = _.intersection(poiIdsFromTargetDetails, tempTargetIdsArray);
                        //	intersectionStatus = 1;
                        //}
                        //if(poiIdsFromTargetDetails.length > 0 && intersectionStatus == 1) {
                        //	poiIdsFromTargetDetails = _.intersection(poiIdsFromPoiDetails, tempTargetIdsArray);
                        //	intersectionStatus = 1;
                        //}
                    }
                }));
            }
            poiIdsFromTargetDetails = _.flattenDeep(poiIdsFromTargetDetails);
            poiIds = _.intersection(poiIdsFromTargetDetails,poiIds);
        }
        if(poiIds.length == 0) {
            poiIds = [0];
        }
		let pois;
		if(poiIds.length > 40000) {
			const poiIdsArr = _.chunk(poiIds,40000);
			pois = await Promise.all(poiIdsArr.map(async eachPoiIds => {
				if (query.types) {
					return await this.poiRepository.find({ where: {
						id: In(eachPoiIds),
						type: In(query.types),
                        
				}});
				} else {
					return await this.poiRepository.find({ where: {
						id: In(eachPoiIds),
				}});
				}
			}));
			pois = _.flattenDeep(pois);
		} else {
			if (query.types) {
				pois = await this.poiRepository.find({ where: {
					id: In(poiIds),
					type: In(query.types)
			}});
			} else {
				pois = await this.poiRepository.find({ where: {
					id: In(poiIds),
			}});
			}
		}
		//Internal Details...
		let poiDetailDict = {};
		let poiDetails = [];
		if(poiIds.length > 40000) {
			const poiIdsArr = _.chunk(poiIds,40000);
			poiDetails = await Promise.all(poiIdsArr.map(async eachPoiIds => {
				return await this.targetDetailRepository
                    .createQueryBuilder("target_deatil")
                    .select(['"poiId"','key','value'])
                    .where('"poiId" IN(:...poiIds)',{poiIds : eachPoiIds})
                    .getRawMany();
			}));
			poiDetails = _.flattenDeep(poiDetails);
		} else {
			poiDetails = await this.targetDetailRepository
                .createQueryBuilder("target_detail")
                .select(['"poiId"','key','value'])
                .where('"poiId" IN(:...poiIds)',{poiIds: poiIds})
                .getRawMany();
		}
		console.log("PoiDetails Length :",poiDetails.length);
		await Promise.all(poiDetails.map(eachObj => {
			if(poiDetailDict[eachObj.poiId] != undefined) {
				poiDetailDict[eachObj.poiId][eachObj.key] = eachObj.value 
			} else {
				let tempObj = {};
				tempObj[eachObj.key] = eachObj.value;
				poiDetailDict[eachObj.poiId] = tempObj;
			}
		}));
		//InternalDetails Done...
		const response = await this.prepareResponse(pois, poiShapeIndexDict, poiDetailDict);
		return response;
    }

    async prepareResponse(pois: Poi[], poiShapeIndexDict: any , poiDetailDict: any) {
		//console.log(poiDetailDict);
		const subCountsDict = {};
		await Promise.all(pois.map(async eachPoi => {
			eachPoi["internalDetails"] = poiDetailDict[eachPoi.id];
			eachPoi['geometry'] = {};
			eachPoi['geometry']['type'] = 'point';
			const coordinates: number[] = [];
			coordinates.push(Number(eachPoi.longitude));
			coordinates.push(Number(eachPoi.latitude));
			eachPoi['geometry']['coordinates'] = coordinates;
			delete eachPoi.latitude;
			delete eachPoi.longitude;
			eachPoi['index'] = poiShapeIndexDict[eachPoi.id];
			if (subCountsDict[eachPoi.type]) {
				subCountsDict[eachPoi.type] += 1;
			} else {
				subCountsDict[eachPoi.type] = 1;
			}
		}));/*
		pois.forEach(async eachPoi => {
			
		});*/
		const responseDict = {};
		responseDict["count"] = pois.length;
		responseDict["subTypeCount"] = subCountsDict;
		responseDict['data'] = pois;
		return responseDict;
	}
}
