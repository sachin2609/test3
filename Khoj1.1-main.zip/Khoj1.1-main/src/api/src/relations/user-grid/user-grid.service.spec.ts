import { Test, TestingModule } from "@nestjs/testing";
import { UserGridService } from "./user-grid.service";

describe("UserGridService", () => {
	let service: UserGridService;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			providers: [UserGridService]
		}).compile();

		service = module.get<UserGridService>(UserGridService);
	});

	it("should be defined", () => {
		expect(service).toBeDefined();
	});
});
