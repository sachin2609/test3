import { Entity, PrimaryColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class InsightGrid {
	@ApiProperty()
	@PrimaryColumn()
	gridId: number;

	@ApiProperty()
	@PrimaryColumn()
	insightId: number;
}
