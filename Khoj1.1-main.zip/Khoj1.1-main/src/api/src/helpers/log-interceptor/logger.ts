import winston = require("winston");
import * as syslog from "winston-syslog";

const myFormat = winston.format.printf(
	({ level, message, label, statusCode, ip, route, userType, creditsUsed, email, phoneNumber }) => {
		return `${level} : ${label} ${ip} ${route} : ${userType} ${email ? email : ""} ${
			phoneNumber ? phoneNumber : ""
		} : [${statusCode}] ${message} : ${creditsUsed}`;
	},
);

let logger: winston.Logger;
try {
	logger = winston.createLogger({
		format: winston.format.combine(
			winston.format.label({ label: "DS_Find" }),
			winston.format.timestamp(),
			myFormat,
		),
		levels: winston.config.syslog.levels,
		transports: [
			new syslog.Syslog({
				host: "localhost", // Syslog server address
				port: 514, // Syslog server port
				protocol: "udp4", // Protocol to use (udp4 or udp6)
				path: "/dev/log", // Path to the Syslog socket (Linux specific)
			}),
			//new winston.transports.File({ filename: "logs.txt" }),
		],
	});
} catch (error) {
	console.error("Error creating logger:", error);
} finally {
	console.log("Successfully created logger");
}

export { logger };
