import { Controller, Get, Post, Body, Headers } from "@nestjs/common";
import { Answer } from "./answer.entity";
import { AnswerService } from "./answer.service";
import { AnswerSearch, AnswerBody } from "../interfaces/answer";
import { ApiTags, ApiBody, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { JwtService } from "@nestjs/jwt";
@ApiTags("answer")
@Controller("answer")
export class AnswerController {
	constructor(
		private _answerService: AnswerService
	) {}

	@Roles("basic")
	@Get()
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Get multiple Answers" })
	async list(): Promise<Answer[]> {
		return await this._answerService.list();
	}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create Answers" })
	@ApiBody({ type: Answer })
	async create(@Body() answers: Answer[],@Headers() headers): Promise<Answer[]> {
		return await this._answerService.create(answers,headers);
	}

	@Roles("basic")
	@Post("search")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Search Answers" })
	@ApiBody({ type: AnswerSearch })
	async search(@Body() body: AnswerSearch,@Headers() headers): Promise<Answer[]> {
		try {
			return await this._answerService.searchNew(body,headers);	
		} catch (error) {
			console.log(error);
			return [];
		}
	}

	@Roles("basic")
	@Post("submitanswers")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create Answers" })
	@ApiBody({ type: Answer })
	async submitAnswers(@Body() body: AnswerBody[]): Promise<Answer[]> {
		return await this._answerService.submitAnswers(body);
	}
}
