import { Test, TestingModule } from '@nestjs/testing';
import { LayerShapeService } from './layer-shape.service';

describe('LayerShapeService', () => {
  let service: LayerShapeService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [LayerShapeService],
    }).compile();

    service = module.get<LayerShapeService>(LayerShapeService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
