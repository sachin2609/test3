import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { PropertyDetail } from "./property-detail.entity";

@Injectable()
export class PropertyDetailService {
	constructor(
		@InjectRepository(PropertyDetail) private propertyDetailRepository: Repository<PropertyDetail>
	) {}

	async create(propertyDetails: PropertyDetail[]): Promise<PropertyDetail[]> {
		return this.propertyDetailRepository.save(propertyDetails);
	}
}
