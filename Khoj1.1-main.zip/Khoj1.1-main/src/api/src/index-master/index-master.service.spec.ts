import { Test, TestingModule } from "@nestjs/testing";
import { IndexMasterService } from "./index-master.service";

describe("IndexMasterService", () => {
	let service: IndexMasterService;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			providers: [IndexMasterService]
		}).compile();

		service = module.get<IndexMasterService>(IndexMasterService);
	});

	it("should be defined", () => {
		expect(service).toBeDefined();
	});
});
