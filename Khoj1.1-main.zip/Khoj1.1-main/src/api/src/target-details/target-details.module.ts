import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Poi } from 'src/poi/poi.entity';
import { TargetDetailsController } from './target-details.controller';
import { TargetDetail } from './target-details.entity';
import { TargetDetailsService } from './target-details.service';

@Module({
	imports: [
		TypeOrmModule.forFeature([TargetDetail,Poi]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		})
	],
  	controllers: [TargetDetailsController],
  	providers: [TargetDetailsService]
})
export class TargetDetailsModule {}
