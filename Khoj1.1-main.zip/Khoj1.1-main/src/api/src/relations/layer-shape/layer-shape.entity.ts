import { Entity, PrimaryColumn, Column, Index } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

@Entity()
export class LayerShape {
	@ApiProperty()
	@PrimaryColumn()
	@Index()
	layerId: number;

	@ApiProperty()
	@PrimaryColumn()
	@Index("layer_shape_index")
	shapeId: number;
}


