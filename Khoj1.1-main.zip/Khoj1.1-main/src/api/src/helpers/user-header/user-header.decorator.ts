/* 
This interceptor/decorator is utilized to include
the email/phoneNumber of the authenticated user in 
the header of the response. 
*/
import { Injectable, NestInterceptor, ExecutionContext, CallHandler, HttpException, HttpStatus } from "@nestjs/common";
import { Observable, tap } from "rxjs";
import { JwtService } from "@nestjs/jwt";
import { User } from "../../users/users.entity";

@Injectable()
export class SetUserHeaderInterceptor implements NestInterceptor {
	constructor(private readonly jwtService: JwtService) {}

	creditableRoutes = [
		"/opportunities/fetch",
		"/opportunities/get-merchants",
		"/poi/fetch-fresh-merchant",
		"/leads/fetch",
		"/poi/filter",
		"/grid/search",
		"/layers/filter",
		"/merchant/acquisition",
		"/merchant/acquisition-new",
		"/merchant/scorecard",
		"/merchant/get-merchants",
		"/poi-shape/filter",
		"/custom/places",
		"/custom/rent",
		"/scorecard/merchant-v1",
		"/scorecard/location",
		"/scorecard/places",
		"/scorecard/rent",
		"/scorecard/pincode",
		"/scorecard/address",
		"/scorecard/coordinate",
		"/scorecard/geohash7",
		"/scorecard/multi-geohash7",
		"/security/risk-assessment",
		"/shape/levelsearch-new",
		"/target/filter",
	];

	intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
		const request = context.switchToHttp().getRequest();
		const url = request?.url;
		try {
			const { headers } = request;
			const user: User = this.jwtService.decode(
				headers["token"] || headers["api-key"] || headers["apikey"] || headers["apiKey"],
			) as User;
			if (user?.email) request.res.set("X-User-Email", user.email);
			if (user?.phoneNumber) request.res.set("X-User-PhoneNumber", user.phoneNumber);
			if (user?.["type"]) request.res.set("X-User-Type", user["type"]);
			if (this.creditableRoutes.includes(url)) {
				return next.handle().pipe(
					tap(async (response) => {
						if (response?.count)
							context.switchToHttp().getResponse().header("X-User-Credits-Used", Number(response.count));
						else context.switchToHttp().getResponse().header("X-User-Credits-Used", 1);
					}),
				);
			} else {
				return next.handle();
			}
		} catch (e) {
			console.log(e);
			throw new HttpException("Unauthorized", HttpStatus.UNAUTHORIZED);
		}
	}
}
