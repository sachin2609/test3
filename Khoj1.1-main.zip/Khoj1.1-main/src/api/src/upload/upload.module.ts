import { Module } from "@nestjs/common";
import { UploadController } from "./upload.controller";
import { UploadService } from "./upload.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Answer } from "../answer/answer.entity";
import { JwtModule } from "@nestjs/jwt";
import * as dotenv from "dotenv";
dotenv.config();
@Module({
	imports: [
		TypeOrmModule.forFeature([Answer]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		})
	],
	controllers: [UploadController],
	providers: [UploadService]
})
export class UploadModule {}
