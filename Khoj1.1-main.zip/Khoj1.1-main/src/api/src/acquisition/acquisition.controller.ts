import { Body, Controller, Headers, Post, HttpException, HttpStatus } from '@nestjs/common';
import { ApiHeader, ApiResponse, ApiBody } from '@nestjs/swagger';
import { PoiPaginationDto } from 'src/interfaces/poi';
import { FilterQueryRequest, FilterQuery } from 'src/interfaces/requests';
import { Poi } from 'src/poi/poi.entity';
import { PoiService } from 'src/poi/poi.service';
import { Roles } from 'src/helpers/roles-guard/roles-guard.service';
import { MerchantService } from 'src/merchant/merchant.service';
import { RolesGuardService } from '../helpers/roles-guard/roles-guard.service';
import { Header } from '../interfaces/header';
import { MultilevelShapesQuery } from 'src/interfaces/shapes';
import { ShapeService } from 'src/shape/shape.service';
import { query } from 'express';
import * as _ from "lodash";
import { RealIP } from 'nestjs-real-ip';


@Controller('acquisition')
export class AcquisitionController {
    constructor(
		private _merchantService: MerchantService,
		private _poiService: PoiService,
		private _rolesGuardService: RolesGuardService,
        private _shapeService: ShapeService
	) {}

    @Roles("merchant_acquisition")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("merchant-v1")
	async acquisition(@Body() body, @Headers() header: Header, @RealIP() ip: string): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			const resp = await this._merchantService.acquisition(body);
			await this._rolesGuardService.updateCreds(header.token, resp['count'] - 1,"/acquisition/merchant-v1",ip,JSON.stringify(body));
			return resp;
		} catch(error) {
			console.log(error);
			return [];
		}
	}

	@Roles("merchant_acquisition")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("merchant-v2")
	async acquisitionNew(@Body() body,@Headers() header: Header, @RealIP() ip: string): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			if(body["without"]) {
				const totalres = await this._merchantService.acquisitionNew(body);
				const totalresCount = totalres["count"];
				console.log("TotalCount:",totalresCount);
				body["within"] = body["without"];
				const withinres = await this._merchantService.acquisitionNew(body);
				const withinCount = withinres["count"];
				console.log("WithinCount:",withinCount);
				let withoutRes = {};
				const data = totalres["data"].filter(ar => !withinres["data"].find(rm => (rm.id === ar.id) ))
				withoutRes["count"] = data.length;
				withoutRes["data"] = data;
				withoutRes["location"] = totalres["location"];
				let credsResp;
				if(header.token) {
					credsResp = await this._rolesGuardService.updateCreds(header.token, withoutRes['count'] - 1,"/acquisition/merchant-v2",ip,JSON.stringify(body));
				} else {
					credsResp = await this._rolesGuardService.apiKeyUpdateCreds(header["apikey"], withoutRes['count'] -1,"/acquisition/merchant-v2",JSON.stringify(body));
				}
				console.log("response from creds deduction", credsResp);
				if (credsResp) {
					return withoutRes;
				} else {
					throw new HttpException({
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left"
					}, HttpStatus.FORBIDDEN)
				}
			} else {
				const resp = await this._merchantService.acquisitionNew(body);
				console.log("deducting ", resp['count'])
				let credsResp;
				if(header.token) {
					credsResp = await this._rolesGuardService.updateCreds(header.token, resp['count'] - 1,"/acquisition/merchant-v2",ip,JSON.stringify(body));
				} else {
					credsResp = await this._rolesGuardService.apiKeyUpdateCreds(header["apikey"], resp['count'] -1,"/acquisition/merchant-v2",JSON.stringify(body));
				}
				console.log("response from creds deduction", credsResp);
				if (credsResp) {
					return resp;
				} else {
					throw new HttpException({
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left"
					}, HttpStatus.FORBIDDEN)
				}
			}
		} catch(error) {
			if (error.status == '403') {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("merchant_acquisition")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("merchant-v3")
	async acquisitionV3(@Body() body,@Headers() header: Header, @RealIP() ip: string): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		if(body["page"] == undefined) {
			body["page"] = 1;
		}
		try {
			if(body["without"]) {
				const totalres = await this._merchantService.acquisitionNew(body);
				const totalresCount = totalres["count"];
				console.log("TotalCount:",totalresCount);
				body["within"] = body["without"];
				const withinres = await this._merchantService.acquisitionNew(body);
				const withinCount = withinres["count"];
				console.log("WithinCount:",withinCount);
				let withoutRes = {};
				const data = totalres["data"].filter(ar => !withinres["data"].find(rm => (rm.id === ar.id) ))
				withoutRes["count"] = data.length;
				withoutRes["data"] = data;
				let credsResp;
				if(header.token) {
					credsResp = await this._rolesGuardService.updateCreds(header.token, withoutRes['count'] - 1,"/acquisition/merchant-v3",ip,JSON.stringify(body));
				} else {
					credsResp = await this._rolesGuardService.apiKeyUpdateCreds(header["apikey"], withoutRes['count'] -1,"/acquisition/merchant-v3",JSON.stringify(body));
				}
				console.log("response from creds deduction", credsResp);
				if (credsResp) {
					return withoutRes;
				} else {
					throw new HttpException({
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left"
					}, HttpStatus.FORBIDDEN)
				}
			} else {
				const resp = await this._merchantService.acquisitionV3(body);
				console.log("deducting ", resp['count'])
				let credsResp;
				if(header.token) {
					credsResp = await this._rolesGuardService.updateCreds(header.token, resp['count'] - 1,"/acquisition/merchant-v3",ip,JSON.stringify(body));
				} else {
					credsResp = await this._rolesGuardService.apiKeyUpdateCreds(header["apikey"], resp['count'] -1,"/acquisition/merchant-v3",JSON.stringify(body));
				}
				console.log("response from creds deduction", credsResp);
				if (credsResp) {
					return resp;
				} else {
					throw new HttpException({
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left"
					}, HttpStatus.FORBIDDEN)
				}
			}
		} catch(error) {
			if (error.status == '403' || error.status == '400') {
				throw error;
			} else {
				console.log(error);
				return [];
			}
		}
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("merchant/update")
	async update(@Body() body, @Headers() header: Header): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			return await this._merchantService.update(body);
		} catch(error) {
			throw error;
		}
	}
}
