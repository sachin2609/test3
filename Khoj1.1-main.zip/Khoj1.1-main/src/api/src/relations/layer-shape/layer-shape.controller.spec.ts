import { Test, TestingModule } from '@nestjs/testing';
import { LayerShapeController } from './layer-shape.controller';

describe('LayerShapeController', () => {
  let controller: LayerShapeController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [LayerShapeController],
    }).compile();

    controller = module.get<LayerShapeController>(LayerShapeController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
