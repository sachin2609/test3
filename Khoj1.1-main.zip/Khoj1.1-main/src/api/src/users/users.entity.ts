import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class User {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	firstName: string;

	@ApiProperty()
	@Column()
	lastName: string;

	@ApiProperty()
	@Column({ nullable: true })
	email: string;

	@ApiProperty()
	@Column({ nullable: true })
	phoneNumber: string;

	@ApiProperty()
	@Column({
		type: "varchar",
		array: true,
	})
	roles: string[];

	@ApiProperty()
	@Column({ nullable: true })
	designation: string;

	@ApiProperty()
	@Column({ nullable: true })
	googleAccessToken: string;

	@ApiProperty()
	@Column({ nullable: true })
	organisationId: number;

	@ApiProperty()
	@Column({ nullable: true })
	teamId: number;

	@ApiProperty()
	@Column({
		type: "boolean",
		default: true,
	})
	status: boolean;

	@ApiProperty()
	@Column({
		type: "boolean",
		default: false,
	})
	isAuthorized: boolean;

	@ApiProperty()
	@Column({
		type: "boolean",
		default: false,
	})
	isVerified: boolean;

	@ApiProperty()
	@Column({ nullable: true })
	password: string;

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt: Date;

	@ApiProperty()
	@UpdateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)", onUpdate: "CURRENT_TIMESTAMP(6)" })
	updatedAt: Date;

	@ApiProperty()
	@Column({ nullable: true })
	createdBy: number;

	@ApiProperty()
	@Column({ nullable: true })
	updatedBy: number;
}

export class UserDTO extends User {
	team: {
		id: number;
		name: string;
	};
	teamOwned: {
		id: number;
		name: string;
	};
}
