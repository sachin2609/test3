import { IsDefined, IsLatitude, IsLongitude, IsOptional, IsPositive, IsString, Validate } from "class-validator";
import { IsNumberOrString } from "src/helpers/validations/IsNumberOrString";

export class KpiDTO {
	@IsString()
	action: string;

	@IsOptional()
	@IsString()
	poiType?: string;

	@IsOptional()
	@IsPositive()
	tokenUserId?: number;

	@IsOptional()
	@IsPositive()
	apiKeyUserId?: number;

	@IsOptional()
	@IsString()
	faId?: string;

	@IsOptional()
	@IsDefined()
	@Validate(IsNumberOrString)
	poiId?: number;

	@IsLatitude()
	latitude: number;

	@IsLongitude()
	longitude: number;
}
