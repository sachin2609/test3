import { Body, Controller, Post, Headers } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { UserApiUsageHistoryService } from "./user-api-usage-history.service";
import { TeamService } from "src/team/team.service";

@ApiTags("usage")
@Controller("usage")
export class UserApiUsageHistoryController {
	constructor(private _userApiUsageHistoryService: UserApiUsageHistoryService, private teamService: TeamService) {}

	@Roles("basic")
	@Post("credit-spent")
	async creditSpent(@Body() body, @Headers() headers) {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		return await this._userApiUsageHistoryService.creditSpent(body, user.id, user.roles);
	}
}
