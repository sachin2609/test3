import { Module } from "@nestjs/common";
import { HttpModule } from "@nestjs/axios";
import { JwtModule } from "@nestjs/jwt";
import { MongooseModule } from "@nestjs/mongoose";
import { TypeOrmModule } from "@nestjs/typeorm";
import { CsvModule } from "nest-csv-parser";
import { Answer } from "src/answer/answer.entity";
import { CsvUploadedFiles } from "src/csv-processor/csv-upload.entity";
import { GlobalServiceService } from "src/helpers/global-service/global-service.service";
import { GridService } from "src/grid/grid.service";
import { Grid } from "src/grid/grids.entity";
import { Indexmaster } from "src/index-master/index-master.entity";
import { PoiDetail } from "src/poi-details/poi-details.entity";
import { Poi } from "src/poi/poi.entity";
import { PoiService } from "src/poi/poi.service";
import { Poiexported } from "src/poi/poisExported.entity";
import { PropertyDetail } from "src/property-detail/property-detail.entity";
import { PropertyDetailService } from "src/property-detail/property-detail.service";
import { Property } from "src/property/property.entity";
import { PropertyService } from "src/property/property.service";
import { Question } from "src/question/question.entity";
import { PoiGrid } from "src/relations/poi-grid/poi-grid.entity";
import { PoiGridService } from "src/relations/poi-grid/poi-grid.service";
import { PropertyGrid } from "src/relations/property-grid/property-grid.entity";
import { PropertyGridService } from "src/relations/property-grid/property-grid.service";
import { UserGrid } from "src/relations/user-grid/user-grid.entity";
import { Shape } from "src/shape/shape.entity";
import { DemoShapesDBSchema } from "src/shape/shape.schema";
import { ShapeService } from "src/shape/shape.service";
import { TargetDetail } from "src/target-details/target-details.entity";
import { User } from "src/users/users.entity";
import { WorkItem } from "src/work-item/work-item.entity";
import { WorkItemService } from "src/work-item/work-item.service";
import { MerchantController } from "./merchant.controller";
import { MerchantService } from "./merchant.service";
import { RolesGuardService } from "../helpers/roles-guard/roles-guard.service";
import { Organisation } from "../organisations/organisations.entity";
import { UserApiUsageHistory } from "../user-api-usage-history/user-api-usage-history.entity";
import { UserCredits } from "../user-history/user-credits.entity";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { UserMerchant } from "./user-merchant.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
import { ApiKeyUserMerchant } from "./api-key-user-merchant.entity";
import { Lead } from "src/leads/leads.entity";
import { OpportunitiesController } from "./opportunities.controller";
import { Team } from "src/team/team.entity";
import { POIFilter, POIFilterUserTeam } from "src/poi-filter/poi-filter.entity";
import { TeamService } from "src/team/team.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";

@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		HttpModule.register({
			timeout: 100000,
			maxRedirects: 100,
		}),
		TypeOrmModule.forFeature([
			WorkItem,
			Poi,
			Grid,
			PoiGrid,
			Property,
			User,
			Team,
			PropertyGrid,
			UserGrid,
			PropertyDetail,
			Indexmaster,
			Answer,
			Question,
			PoiDetail,
			Poiexported,
			TargetDetail,
			CsvUploadedFiles,
			Shape,
			Organisation,
			UserApiUsageHistory,
			UserCredits,
			ShapeDetail,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyUserCredits,
			ApiKeyUserApiUsageHistory,
			UserMerchant,
			ApiKeyIp,
			UserIdIp,
			Shapeindex,
			ShapeDetail,
			ApiKeyUserMerchant,
			Lead,
			POIFilter,
			POIFilterUserTeam,
		]),
		CsvModule,
		MongooseModule.forFeature([{ name: "DemoShapesDB", schema: DemoShapesDBSchema }]),
		MongoDatabaseModule,
	],
	controllers: [MerchantController, OpportunitiesController],
	providers: [
		MerchantService,
		PoiService,
		GridService,
		PoiGridService,
		PropertyService,
		PropertyGridService,
		WorkItemService,
		PropertyDetailService,
		GlobalServiceService,
		RolesGuardService,
		ShapeService,
		TeamService,
		KeyCloakService,
		CentralServerService,
		SyslogService,
	],
})
export class MerchantModule {}
