import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import _ = require("lodash");
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Between, In, Repository } from "typeorm";
import { ApiKeyUserApiUsageHistory, ApiKeyUserCreditsSpentQuery } from "./api-key-user-api-usage.entity";
import * as moment from "moment";

@Injectable()
export class ApiKeyUserApiUsageService {
	constructor(
		@InjectRepository(ApiKeyUser) private apiKeyUsersRepository: Repository<ApiKeyUser>,
		@InjectRepository(ApiKeyUserApiUsageHistory)
		private apiKeyUserApiUsageRepository: Repository<ApiKeyUserApiUsageHistory>,
		@InjectRepository(ApiKeyOrganisation) private apiKeyOrganisationRepository: Repository<ApiKeyOrganisation>,
	) {}

	async creditSpent(query: ApiKeyUserCreditsSpentQuery, userId: number, roles: string[]) {
		const { startTime, endTime, organistaionIds, groupBy } = query;
		let { userIds } = query;
		if (!moment(startTime).isValid() || !moment(endTime).isValid || moment(startTime).isAfter(moment(endTime))) {
			throw new HttpException(
				"StartTime and EndTime Not Specified / Invalid or Incorrect",
				HttpStatus.BAD_REQUEST,
			);
		}
		if (!groupBy.length) {
			throw new HttpException("GroupBy must be mentioned", HttpStatus.BAD_REQUEST);
		}
		if (userIds && !_.isArray(userIds)) throw new HttpException("UserIds must be an array", HttpStatus.BAD_REQUEST);
		if (organistaionIds && !_.isArray(organistaionIds))
			throw new HttpException("OrganisationIds must be an array", HttpStatus.BAD_REQUEST);
		if (true) {
			const orgUsers = organistaionIds?.length
				? await this.apiKeyUsersRepository.find({
						where: {
							organisationId: In(organistaionIds),
						},
						select: ["id"],
				  })
				: [];
			if (!orgUsers.length && !userIds?.length) userIds = null;
			else if (orgUsers.length && !userIds?.length) userIds = orgUsers.map((u) => u.id);
			else if (!orgUsers.length && userIds?.length) userIds = userIds;
			else if (orgUsers.length && userIds?.length)
				userIds = _.intersection(
					orgUsers.map((u) => u.id),
					userIds,
				);
		} else {
			const myUser = await this.apiKeyUsersRepository.findOne({
				where: {
					id: userId,
				},
				select: ["id"],
			});
			const myOrg = await this.apiKeyOrganisationRepository.findOne({
				where: {
					id: myUser.organisationId,
				},
				select: ["id"],
			});
			const myUsers = await this.apiKeyUsersRepository.find({
				where: {
					organisationId: myOrg.id,
				},
				select: ["id"],
			});
			userIds = [
				...(userIds?.length
					? _.intersection(
							userIds,
							myUsers.map((u) => u.id),
					  )
					: []),
				...myUsers.map((u) => u.id),
			];
		}
		const usages = await this.apiKeyUserApiUsageRepository.find({
			where: {
				createdAt: Between(startTime, endTime),
				userId: userIds?.length ? In(userIds) : undefined,
			},
			select: [
				"id",
				"userId",
				"createdAt",
				"State",
				"City",
				"Pincode",
				"Taluka",
				"District",
				"Country",
				"layer",
				"layerType",
				"createdAt",
				"creditsUsed",
			],
		});

		const response = [];
		if (query["groupBy"] == "user") {
			try {
				const usagesKeyedByUserId = _.groupBy(usages, "userId");
				const userIds = Object.keys(usagesKeyedByUserId);
				const users = await this.apiKeyUsersRepository.find({
					where: {
						id: In(userIds),
					},
					select: ["id", "email"],
				});
				for (const userID of userIds) {
					const theUser = users.find((u) => u.id === Number(userID));
					const noOfRequest = usagesKeyedByUserId[userID].length;
					const creditsUsed = usagesKeyedByUserId[userID].reduce((acc, curr) => acc + curr.creditsUsed, 0);
					const [userId, email] = [userID, theUser.email];
					response.push({
						userId: Number(userId),
						creditsUsed,
						noOfRequest,
						email,
					});
				}
				return response;
			} catch (error) {
				console.error(error);
			}
		}
		if (query["groupBy"] == "location") {
			try {
				const level = query["groupByLocation"] ?? "Pincode";
				const usagesKeyedByLocation = _.groupBy(usages, level);
				const locationNames = Object.keys(usagesKeyedByLocation);
				for (const locationName of locationNames) {
					const noOfRequest = usagesKeyedByLocation[locationName].length;
					const creditsUsed = usagesKeyedByLocation[locationName].reduce(
						(acc, curr) => acc + curr.creditsUsed,
						0,
					);
					const [geography, geographyName] = [level, locationName];
					response.push({
						geography,
						geographyName,
						creditsUsed,
						noOfRequest,
					});
				}
				return response;
			} catch (error) {
				console.error(error);
			}
		}
		if (query["groupBy"] == "layerType") {
			const selectedLayer = query["layer"] ?? "poi";
			const usagesKeyedByLayers = _.groupBy(usages, selectedLayer);
			const layers = Object.keys(usagesKeyedByLayers);
			for (const theLayer of layers) {
				const noOfRequest = usagesKeyedByLayers[theLayer].length;
				const creditsUsed = usagesKeyedByLayers[theLayer].reduce((acc, curr) => acc + curr.creditsUsed, 0);
				response.push({
					layer: theLayer,
					creditsUsed,
					noOfRequest,
				});
			}
		}
		if (query["groupBy"] == "time") {
			try {
				let totalCredits = 0;
				totalCredits = usages.map((u) => u.creditsUsed).reduce((a, b) => a + b, 0);
				let dates: { startTime: Date; endTime: Date }[];
				const brackets = Number(query["timeBracket"]) ?? undefined;
				if (!isNaN(brackets)) {
					dates = this.getBracketsTimeRanges(
						new Date(startTime),
						new Date(endTime),
						Number(query["timeBracket"]),
					);
				} else {
					dates = this.getISTTimeRanges(new Date(startTime), new Date(endTime));
				}
				let times: {
					startTime: Date;
					endTime: Date;
					startTimeIST: string;
					endTimeIST: string;
					creditsUsed: number;
					noOfRequest: number;
				}[] = [];
				times = dates.map((t) => {
					const filteredUsages = usages.filter((u) => u.createdAt > t.startTime && u.createdAt < t.endTime);
					return {
						startTime: t.startTime,
						endTime: t.endTime,
						startTimeIST: this.ISOtoIST(t.startTime),
						endTimeIST: this.ISOtoIST(t.endTime),
						creditsUsed: filteredUsages.reduce((a, b) => a + b.creditsUsed, 0),
						noOfRequest: filteredUsages.length,
					};
				});
				const responseObj = {
					totalCreditsSpent: totalCredits,
					times,
				};
				return responseObj;
			} catch (error) {
				console.error(error);
			}
		}
	}

	getISTTimeRanges(startTime: Date, endTime: Date): { startTime: Date; endTime: Date }[] {
		const dateArray: { startTime: Date; endTime: Date }[] = [];
		let currentTime: Date = new Date(
			Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate(), 18, 29, 59, 999),
		);
		dateArray.push({ startTime: startTime, endTime: currentTime });
		while (currentTime < new Date(endTime)) {
			const oldTime = new Date(
				Date.UTC(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate(), 18, 30, 0, 0),
			);
			const newTime = new Date(
				Date.UTC(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate() + 1, 18, 29, 59, 999),
			);
			if (newTime < endTime) {
				dateArray.push({ startTime: oldTime, endTime: newTime });
			} else {
				dateArray.push({ startTime: oldTime, endTime: endTime });
			}
			currentTime = newTime;
		}
		return dateArray;
	}

	getBracketsTimeRanges(startTime: Date, endTime: Date, brackets: number): { startTime: Date; endTime: Date }[] {
		const span = endTime.valueOf() - startTime.valueOf();
		const increment = span / brackets;
		const dateArray: { startTime: Date; endTime: Date }[] = [];
		let currentTime = startTime;
		while (currentTime < endTime) {
			dateArray.push({ startTime: currentTime, endTime: new Date(currentTime.valueOf() + increment) });
			currentTime = new Date(currentTime.valueOf() + increment);
		}
		return dateArray;
	}

	ISOtoIST(time: Date): string {
		return time.toLocaleString(undefined, { timeZone: "Asia/Kolkata" });
	}

	async includes(superSet: any[], subSet: any[]): Promise<boolean> {
		subSet.forEach((element) => {
			if (_.includes(superSet, element) == false) {
				return false;
			}
		});
		return true;
	}

	addDay(dateStr, days) {
		const myDate = new Date(dateStr.toISOString());
		myDate.setDate(myDate.getDay() + parseInt(days));
		return myDate;
	}
}
