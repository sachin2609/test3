import { Controller, Get, Body, Post } from "@nestjs/common";
import { Question } from "./question.entity";
import { QuestionService } from "./question.service";
import { ApiTags, ApiBody, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
@ApiTags("question")
@Controller("question")
export class QuestionController {
	constructor(private _questionService: QuestionService) {}

	//query against current questions
	@Roles("basic")
	@Get()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Query Against Current Questions" })
	async list(): Promise<Question[]> {
		return await this._questionService.list();
	}

	// create questions
	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Create Questions" })
	@ApiBody({ type: Question })
	async create(@Body() questions: Question[]): Promise<Question[]> {
		return await this._questionService.create(questions);
	}
}
