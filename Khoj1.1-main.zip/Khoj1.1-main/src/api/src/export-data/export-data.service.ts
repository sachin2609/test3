import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { RolesGuardService } from 'src/helpers/roles-guard/roles-guard.service';
import { ExportDataBody } from 'src/interfaces/export-data';
import { Repository } from 'typeorm';
import { ExportData } from './export-data.entity';

@Injectable()
export class ExportDataService {
    constructor(
        @InjectRepository(ExportData) private exportDataRepository: Repository<ExportData>,
        private _jwtService: JwtService,
        private rolesGuardService: RolesGuardService
    ) {}

    async addExportData(query: ExportDataBody, header) {
        if(header["apikey"] || header["api-key"] || header["apiKey"]) {
            query.userType = "apikey";
            const user = this._jwtService.decode(header["apikey"] || header["api-key"] || header["apiKey"]);
            query.userId = user["id"];
        } else {
            query.userType = "token";
            const user = this._jwtService.decode(header["token"]);
            query.userId = user["id"];
        }
        if(this.rolesGuardService.deductCredits(header,Number(query.count))) {
            try {
                await this.exportDataRepository.save(query);
                return { response: "success!" };
            } catch(err) {
                console.log(err);
                return { response : "failure!"};
            }
        } else {
            return {response: "failure!"};
        }
    }
}
