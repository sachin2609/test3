import { Injectable } from "@nestjs/common";
import { Repository } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { PropertyGrid } from "./property-grid.entity";
import { Grid } from "../../grid/grids.entity";
@Injectable()
export class PropertyGridService {
	constructor(
		@InjectRepository(PropertyGrid) private propertyGridRepository: Repository<PropertyGrid>,
		@InjectRepository(Grid) private gridsRepository: Repository<Grid>
	) {}

	async create(datas: PropertyGrid[]): Promise<PropertyGrid[]> {
		return await this.propertyGridRepository.save(datas);
	}

	async listGrids(propertyId: number): Promise<Grid[]> {
		const propertyGrids = await this.propertyGridRepository.find({ where: { propertyId: propertyId }});
		console.log("propertyGrids", propertyGrids);
		return await Promise.all(
			propertyGrids.map(async eachRelation => {
				return await this.gridsRepository.findOne({
					where:{
						id: eachRelation.gridId
					},
					relations: ["indexmaster"]
				});
			})
		);
	}
}
