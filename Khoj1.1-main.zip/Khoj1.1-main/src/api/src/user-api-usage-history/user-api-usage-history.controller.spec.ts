import { Test, TestingModule } from '@nestjs/testing';
import { UserApiUsageHistoryController } from './user-api-usage-history.controller';

describe('UserApiUsageHistoryController', () => {
  let controller: UserApiUsageHistoryController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UserApiUsageHistoryController],
    }).compile();

    controller = module.get<UserApiUsageHistoryController>(UserApiUsageHistoryController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
