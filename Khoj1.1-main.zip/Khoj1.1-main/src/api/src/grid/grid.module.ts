import { Module } from "@nestjs/common";
import { CacheModule } from "@nestjs/cache-manager";
import { HttpModule } from "@nestjs/axios";
import { GridService } from "./grid.service";
import { GridController } from "./grid.controller";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Grid } from "./grids.entity";
import { Indexmaster } from "../index-master/index-master.entity";
import { PropertyGrid } from "../relations/property-grid/property-grid.entity";
import { GlobalServiceService } from "src/helpers/global-service/global-service.service";
import { JwtModule } from "@nestjs/jwt";
import { User } from "src/users/users.entity";
import { MongooseModule } from "@nestjs/mongoose";
import { DemoShapesDBSchema } from "src/shape/shape.schema";
import { Shape } from "src/shape/shape.entity";
import * as redisStore from "cache-manager-redis-store";
import { RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { UserCredits } from "src/user-history/user-credits.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { ApiKeyOrganisation } from "src/api-key-organisations/api-key-organisations.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { ApiKeyUserCredits } from "src/api-key-users/api-key-users-credits.entity";
import { ApiKeyUserApiUsageHistory } from "src/api-key-user-api-usage/api-key-user-api-usage.entity";
import { Organisation } from "src/organisations/organisations.entity";
import { ApiKeyIp } from "src/auth/apiKey-ip.entity";
import { UserIdIp } from "src/auth/userId-ip.entity";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { ShapeService } from "src/shape/shape.service";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
import { AnalysisController } from "./analysis.controller";
import { Team } from "src/team/team.entity";

@Module({
	imports: [
		TypeOrmModule.forFeature([
			Grid,
			Indexmaster,
			PropertyGrid,
			User,
			Team,
			Shape,
			UserCredits,
			UserApiUsageHistory,
			ApiKeyUser,
			ApiKeyOrganisation,
			ApiKeyUserCredits,
			ApiKeyUserApiUsageHistory,
			ApiKeyUserCredits,
			Organisation,
			ApiKeyIp,
			UserIdIp,
			Shapeindex,
			ShapeDetail,
		]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		MongooseModule.forFeature([{ name: "DemoShapesDB", schema: DemoShapesDBSchema }]),
		CacheModule.register({
			store: redisStore,
			url: String(process.env.REDIS_URL),
			max: 500,
		}),
		HttpModule.register({
			timeout: 100000,
			maxRedirects: 100,
		}),
		MongoDatabaseModule,
	],
	providers: [GridService, GlobalServiceService, RolesGuardService, ShapeService],
	controllers: [GridController, AnalysisController],
})
export class GridModule {}
