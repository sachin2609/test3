import { ApiProperty } from "@nestjs/swagger";
import { Layer } from "src/layers/layers.entity";
import { Poi, PoiStatus } from "src/poi/poi.entity";

export class LatLng {
	@ApiProperty()
	latitude: number;

	@ApiProperty()
	longitude: number;

	@ApiProperty()
	category: string;

	@ApiProperty()
	radius: number;

	@ApiProperty()
	types: string[];
}
export class Catchment {
	@ApiProperty({ type: Array, description: "topLeft" })
	topLeft: {
		coordinates: number[];
	};

	@ApiProperty()
	bottomRight: {
		coordinates: number[];
	};

	@ApiProperty()
	bottomLeft: {
		coordinates: number[];
	};

	@ApiProperty()
	topRight: {
		coordinates: number[];
	};
}

export class PoiPaginationDto {
	@ApiProperty()
	page: number;

	@ApiProperty()
	limit: number;

	@ApiProperty()
	totalPages: number;

	@ApiProperty()
	data: Poi[] | Layer[];
}

export class PoiQuery {
	@ApiProperty()
	limit: number;

	@ApiProperty()
	page: number;

	@ApiProperty()
	status: PoiStatus;
}

export class PoiStatusUpdate {
	@ApiProperty()
	poiId: number;

	@ApiProperty()
	status: PoiStatus;
}

export class LatLong {
	@ApiProperty()
	lat: number;

	@ApiProperty()
	lng: number;
}
