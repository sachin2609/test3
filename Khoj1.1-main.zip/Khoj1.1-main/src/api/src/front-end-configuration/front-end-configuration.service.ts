import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FrontEndConfigurationId, PostFrontEndConfigurationBody, UpdateFrontEndConfigurationBody } from 'src/interfaces/front-end-configuration';
import { Repository } from 'typeorm';
import { FrontEndConfiguration } from './front-end-configuration.entity';

@Injectable()
export class FrontEndConfigurationService {
    constructor(
        @InjectRepository(FrontEndConfiguration) private frontEndConfigurationRepository: Repository<FrontEndConfiguration>
    ) {}

    async findAll() {
        return await this.frontEndConfigurationRepository.find();
    }

    async findById(query: FrontEndConfigurationId) {
        return await this.frontEndConfigurationRepository.find({ where: { id: Number(query.id) }});
    }

    async post(query: PostFrontEndConfigurationBody) {
        return await this.frontEndConfigurationRepository.save(query);
    }

    async update(query: UpdateFrontEndConfigurationBody) {
        if(query.id == undefined) {
            throw new HttpException("id not found!",HttpStatus.BAD_REQUEST);
        }
        try {
            await this.frontEndConfigurationRepository.update({id: query.id},query);
            return { response: "Success!" };
        } catch(err) {
            console.log(err);
            return { response: "Failure!" };
        }
    }

    async delete(query: FrontEndConfigurationId) {
        try {
            await this.frontEndConfigurationRepository.delete({ id: Number(query.id) });
            return { response: "Success!" };
        } catch(err) {
            console.error(err);
            return { response: "Failure!" };
        }
    }
}
