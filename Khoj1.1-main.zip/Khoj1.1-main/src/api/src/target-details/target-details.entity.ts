import { ApiProperty } from "@nestjs/swagger";
import { Poi } from "src/poi/poi.entity";
import { Entity, Column, ManyToOne, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, Index } from "typeorm";

@Entity()
export class TargetDetail {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	key: string;

	@ApiProperty()
	@Column()
	value: string;

	@ApiProperty()
	@Column({ default:"string" })
	dataType: string;

	@ApiProperty()
	@Column('decimal', {nullable:true})
	unit: number;

	@ApiProperty()
	@Column({nullable: true})
	metrics: string;
	
	@ApiProperty()
	@Index()
	@Column({
		type:"varchar",
		array: true
	})
	ownerIds: number[];

	@ApiProperty()
	@Column()
	poiType: string;

	@ApiProperty()
	@CreateDateColumn()
	createdAt: Date;

	@ApiProperty()
	@UpdateDateColumn()
	updatedAt: Date;

	@ApiProperty()
	@Column()
	createdBy: number;

	@ApiProperty()
	@Column()
	updatedBy: number;

	@ApiProperty()
	@Index()
	@ManyToOne(
		() => Poi,
		poi => poi.targetDetail
	)
	poi: Poi;
}
