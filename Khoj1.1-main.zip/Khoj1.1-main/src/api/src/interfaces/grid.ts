import { ApiProperty } from "@nestjs/swagger";
import { Grid } from "src/grid/grids.entity";

export class Indexquery {
	@ApiProperty({ type: Array, description: "ids" })
	ids: number[];

	@ApiProperty({ type: String, description: "type" })
	type: string;
}

export class GridWithIndexRanges {
	@ApiProperty()
	indexRanges: unknown;

	@ApiProperty()
	indexLockRanges: unknown;

	@ApiProperty()
	grids: Grid[];
}

export class GridWithIndexRangesNew {
	@ApiProperty()
	indexRanges: unknown;

	@ApiProperty()
	grids: Grid[];
}
