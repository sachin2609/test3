import { ApiProperty } from "@nestjs/swagger";
import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class Team {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	name: string;

	@ApiProperty()
	@Column({ nullable: true })
	description: string;

	@ApiProperty()
	@Column({
		default: 0,
	})
	credits: number;

	@ApiProperty()
	@Column({
		type: "boolean",
		default: false,
	})
	isAuthorized: boolean;

	@ApiProperty()
	@Column({ nullable: true })
	ownerId: number;

	@ApiProperty()
	@Column({ nullable: true, array: true, type: "integer" })
	coOwnerIds?: number[];

	@ApiProperty()
	@Column({ nullable: true })
	onboardedCount: number;

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt: Date;

	@ApiProperty()
	@UpdateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)", onUpdate: "CURRENT_TIMESTAMP(6)" })
	updatedAt: Date;

	@ApiProperty()
	@Column({ nullable: true })
	createdBy: number;

	@ApiProperty()
	@Column({ nullable: true })
	updatedBy: number;
}

export class TeamDTO extends Team {
	teamSize: number;
	owner: {
		id: number;
		firstName: string;
		lastName: string;
	};
}
