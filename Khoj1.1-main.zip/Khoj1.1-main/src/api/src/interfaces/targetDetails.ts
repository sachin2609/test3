import { ApiProperty } from "@nestjs/swagger";

export class TargetDetailsClass {
	@ApiProperty()
	key: string;

	@ApiProperty()
	value: string;

	@ApiProperty()
	ownerIds: number[];

	@ApiProperty()
	dataType: string;

	@ApiProperty()
	unit: number;

	@ApiProperty()
	poiId: number;
}
