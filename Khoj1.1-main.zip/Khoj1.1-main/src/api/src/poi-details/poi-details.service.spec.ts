import { Test, TestingModule } from "@nestjs/testing";
import { PoiDetailsService } from "./poi-details.service";

describe("PoiDetailsService", () => {
	let service: PoiDetailsService;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			providers: [PoiDetailsService]
		}).compile();

		service = module.get<PoiDetailsService>(PoiDetailsService);
	});

	it("should be defined", () => {
		expect(service).toBeDefined();
	});
});
