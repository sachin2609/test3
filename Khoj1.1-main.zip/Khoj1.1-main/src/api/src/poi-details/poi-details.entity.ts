import { Entity, PrimaryColumn, Column, Index } from "typeorm";

@Entity()
export class PoiDetail {
	@PrimaryColumn()
	@Index()
	poiId: number;

	@PrimaryColumn()
	key: string;

	@Column()
	value: string;

	@Column({ default: "string" })
	dataType: string;

	@Column("decimal", { nullable: true })
	unit: number;

	@Column({ nullable: true })
	metrics: string;

	@Column({ nullable: true })
	description: string;
}
