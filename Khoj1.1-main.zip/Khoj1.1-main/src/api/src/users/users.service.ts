import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { In, Repository } from "typeorm";
import { User } from "./users.entity";
import { UsersQuery } from "../interfaces/users";
import { UserCredits } from "src/user-history/user-credits.entity";
import { UserApiUsageHistory } from "src/user-api-usage-history/user-api-usage-history.entity";
import { keyBy } from "lodash";

@Injectable()
export class UsersService {
	constructor(
		@InjectRepository(User)
		private UserRepository: Repository<User>,
		@InjectRepository(UserCredits)
		private userCreditsRepository: Repository<UserCredits>,
		@InjectRepository(UserApiUsageHistory)
		private userApiUsageHistoryRepository: Repository<UserApiUsageHistory>,
	) {}

	async saveAll(data: User[]): Promise<User[]> {
		data.forEach((eachData: User) => {
			this.UserRepository.save(eachData);
		});
		return data;
	}

	async findUsers(query: { emails?: string[]; phoneNumbers?: string[] }) {
		if (!query?.emails && !query?.phoneNumbers)
			throw new HttpException(`emails or phoneNumbers missing!`, HttpStatus.BAD_REQUEST);
		return (async () => {
			try {
				let users: User[] = [];
				if (query?.emails && query?.phoneNumbers) {
					users = [
						...(await this.UserRepository.find({ where: { email: In(query?.emails) } })),
						...(await this.UserRepository.find({ where: { phoneNumber: In(query?.phoneNumbers) } })),
					];
				} else if (query?.emails) {
					users = [...(await this.UserRepository.find({ where: { email: In(query?.emails) } }))];
				} else if (query?.phoneNumbers) {
					users = [...(await this.UserRepository.find({ where: { phoneNumber: In(query?.phoneNumbers) } }))];
				}
				return users.map((u) => {
					return {
						id: u.id,
						firstName: u.firstName,
						lastName: u.lastName,
						email: u?.email,
						phoneNumber: u?.phoneNumber,
						teamId: u?.teamId,
						isAuthorized: u?.isAuthorized,
						designation: u?.designation,
						roles: u?.roles,
					};
				});
			} catch (error) {
				console.error(error);
				return [];
			}
		})();
	}

	async queryUsers(query: UsersQuery): Promise<User[]> {
		let queryString = "";
		Object.keys(query).forEach((eachkey, index) => {
			if (index === 0) {
				queryString += "user." + eachkey + " = :" + eachkey;
			} else {
				queryString += "AND user." + eachkey + " = :" + eachkey;
			}
		});
		return await this.UserRepository.createQueryBuilder("user").where(queryString, query).getMany();
	}

	async findOrCreateUser(userObject: UsersQuery): Promise<User> {
		const user = await this.UserRepository.findOne({ where: { email: userObject.email } });
		if (user) {
			if (userObject.roles) {
				user.roles = userObject.roles;
			}
			user.googleAccessToken = userObject.googleAccessToken;
			return await this.UserRepository.save(user);
		} else {
			console.log("user object is", userObject);
			const user = new User();
			user.firstName = userObject.firstName;
			user.lastName = userObject.lastName;
			user.email = userObject.email;
			user.roles = ["basic", "merchant_acquisition", "merchant_scorecard", "ip_risk_assessment"];
			user.googleAccessToken = userObject.googleAccessToken;
			return await this.UserRepository.save(user);
		}
	}

	async findUser(query): Promise<User> {
		if (query["email"] == undefined) {
			throw new HttpException("Please enter email", HttpStatus.BAD_REQUEST);
		} else {
			const user = await this.UserRepository.findOne({ where: { email: query["email"] } });
			if (user == undefined) {
				throw new HttpException("Please enter valid email", HttpStatus.BAD_REQUEST);
			} else {
				return user;
			}
		}
	}

	async addUserCreditsAndApiUsage(users: User[]): Promise<void> {
		const userIds = users.map((u) => u.id);
		// const userCredits = await (async () => {
		// 	try {
		// 		return await this.userCreditsRepository.find({ where: { userId: In(userIds) } });
		// 	} catch (error) {
		// 		console.error(error);
		// 	}
		// })();
		// const userCreditsDict = keyBy(userCredits, "userId");
		const userAPIUsage = await (async () => {
			try {
				return await this.userApiUsageHistoryRepository
					.createQueryBuilder("userApiUsageHistory")
					.where("userApiUsageHistory.userId IN (:...userIds)", { userIds })
					.groupBy("userApiUsageHistory.userId")
					.select("userApiUsageHistory.userId", "userId")
					.addSelect("COUNT(userApiUsageHistory.userId)", "noOfRequest")
					.addSelect("SUM(userApiUsageHistory.creditsUsed)", "creditsUsed")
					.getRawMany();
			} catch (error) {
				console.error(error);
			}
		})();
		const userAPIUsageDict = keyBy(userAPIUsage, "userId");

		users.forEach((eachUser) => {
			eachUser["creditsUsed"] = Number(userAPIUsageDict?.[eachUser.id]?.creditsUsed ?? "0");
			eachUser["noOfRequest"] = Number(userAPIUsageDict?.[eachUser.id]?.noOfRequest ?? "0");
		});
	}
}
