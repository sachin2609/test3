import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { TargetDetailsClass } from 'src/interfaces/targetDetails';
import { Poi } from 'src/poi/poi.entity';
import { Repository } from 'typeorm';
import { TargetDetail } from './target-details.entity';
import * as _ from 'lodash';
@Injectable()
export class TargetDetailsService {
	constructor(
		@InjectRepository(TargetDetail) private targetDetailsRepository: Repository<TargetDetail>,
		@InjectRepository(Poi) private poisRepository: Repository<Poi>
	) {}

	async getTargetDetails(): Promise<TargetDetail[]> {
		return await this.targetDetailsRepository.find();
	}

	async addTargetDetails(body: TargetDetailsClass[],userId): Promise<TargetDetail[]> {
		let targetDetails = [];
		targetDetails = body;
		targetDetails.forEach(async targetDetail => {
			const poi = await this.poisRepository.findOne({ where: {id:targetDetail.poiId}});
			targetDetail["createdBy"] = userId;
			targetDetail["updatedBy"] = userId;
			delete targetDetail.poiId;
			targetDetail["poi"] = poi;
			await this.targetDetailsRepository.save(targetDetail);
		});
		return targetDetails;
	}
	async populateUnit(): Promise<void> {
		let allTargetDetails = await this.targetDetailsRepository.find({ where: { dataType: 'number'}});
		let targetDetailsArr = _.chunk(allTargetDetails, 20);
		for await (let eachTargetDetailsArr of targetDetailsArr) {
			eachTargetDetailsArr.forEach(eachTargetDetail => {
				eachTargetDetail.unit = Number(eachTargetDetail.value);
			});
			try {
				let resp = await this.targetDetailsRepository.save(eachTargetDetailsArr);
			} catch(error) {console.log(error)}
		}
	}
/*
	async updateTargetDetails(body: TargetDetail, userId):Promise<unknown> {
		const targetDetail = await this.targetDetailsRepository.findOne({ where: {id:body.id}});
		targetDetail.key = body.key;
		targetDetail.ownerIds = body.ownerIds;
		targetDetail.value = body.value;
		targetDetail.updatedBy = userId;
		return await this.targetDetailsRepository.save(targetDetail);
	}*/
}
