import { Injectable } from "@nestjs/common";
import { UserGrid, Role } from "./user-grid.entity";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { Grid } from "src/grid/grids.entity";
import { ZoneUser, UserGridRequest } from "src/interfaces/user-grid";

@Injectable()
export class UserGridService {
	constructor(
		@InjectRepository(UserGrid) private userGridRepository: Repository<UserGrid>,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>
	) {}

	async create(userGridRequests: UserGridRequest[]): Promise<UserGridRequest[]> {
		await Promise.all(
			userGridRequests.map(async userGridRequest => {
				const zone = userGridRequest.zone;
				const userId = userGridRequest.userId;
				const role = userGridRequest.role;
				const grids = await this.gridRepository.find({ where: { Locality: zone }});
				console.log("grids", grids);
				for await (const grid of grids) {
					const userGrid = {
						userId: userId,
						gridId: grid.id,
						zone: zone,
						role: role
					};
					await this.userGridRepository.save(userGrid);
				}
			})
		);
		return userGridRequests;
	}

	async list(): Promise<ZoneUser[]> {
		const uniqueZones = new Set();
		const grids = await this.gridRepository.find();
		grids.forEach(grid => {
			uniqueZones.add(grid.Locality);
		});
		const zoneUsers = [];
		const zones = Array.from(uniqueZones);
		await Promise.all(
			zones.map(async zone => {
				const analyzer = await this.userGridRepository.findOne({
					where: {
						zone: zone.toString(),
						role: Role.analyzer
					}
				});
				const verifier = await this.userGridRepository.findOne({
					where: {
						zone: zone.toString(),
						role: Role.verifier
					}
				});
				const approver = await this.userGridRepository.findOne({
					where: {
						zone: zone.toString(),
						role: Role.approver
					}
				});
				const zoneUser = {
					zone: zone,
					analyzer: analyzer ? analyzer.userId : null,
					verifier: verifier ? verifier.userId : null,
					approver: approver ? approver.userId : null
				};
				zoneUsers.push(zoneUser);
			})
		);
		return zoneUsers;
	}
}
