import { Controller, Get, Headers, Post, Body } from "@nestjs/common";
import { ApiHeader, ApiResponse, ApiTags } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { UserHistoryService } from "./user-history.service";
import { TeamService } from "src/team/team.service";

@ApiTags("user-history")
@Controller("user-history")
export class UserHistoryController {
	constructor(private _userHistoryService: UserHistoryService, private teamService: TeamService) {}

	// @Roles("basic")
	// @Get("weeklyReportNew")
	// @ApiHeader({ name: "Token" })
	// @ApiResponse({ description: "get weekly reports" })
	// async getWeeklyReportNew(): Promise<string> {
	// 	return await this._userHistoryService.getWeeklyReportNew();
	// }

	// @Roles("basic")
	// @Get("weeklyReportOrgs")
	// @ApiHeader({ name: "Token" })
	// @ApiResponse({ description: "get weekly reports" })
	// async getWeeklyReportOrg(): Promise<unknown> {
	// 	return await this._userHistoryService.weeklyReportForOrgs();
	// }

	// @Roles("basic")
	// @Post("weeklyReportOrgWise")
	// @ApiHeader({ name: "Token" })
	// @ApiResponse({ description: "get weekly reports" })
	// async getWeeklyReport(@Body() body) {
	// 	return await this._userHistoryService.getWeeklyReportOrgWise(body);
	// }

	// @Roles("basic")
	// @Post("weeklyReportOrgWise-v2")
	// @ApiHeader({ name: "Token" })
	// @ApiResponse({ description: "get weekly reports" })
	// async getWeeklyReportOrgWise(@Body() body) {
	// 	try {
	// 		return await this._userHistoryService.getWeeklyReportOrgWiseNew(body);
	// 	} catch (err) {
	// 		throw err;
	// 	}
	// }

	@Roles("basic")
	@Post("login-time")
	async loginTime(@Body() body, @Headers() headers) {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		return await this._userHistoryService.loginTime(body, user.id, user.roles);
	}
}
