import { Test, TestingModule } from '@nestjs/testing';
import { LayerDetailsService } from './layer-details.service';

describe('LayerDetailsService', () => {
  let service: LayerDetailsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [LayerDetailsService],
    }).compile();

    service = module.get<LayerDetailsService>(LayerDetailsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
