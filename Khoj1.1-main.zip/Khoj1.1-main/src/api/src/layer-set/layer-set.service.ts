import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { LayerSet } from './layer-set.entity';

@Injectable()
export class LayerSetService {
	constructor(
		@InjectRepository(LayerSet) private layerSetRepository: Repository<LayerSet>
	) {}

	async create(body,userId) {
		const layerObj = {
			"layerSet": body["layerSet"],
			"name": body["name"],
			"value": body["value"],
			"userId": userId
		};
		return await this.layerSetRepository.save(layerObj);
	}

	async get(userId) {
		return await this.layerSetRepository.find({ where: [{userId: userId}, {default: true}]});
	}

	async delete(layerSetId,userId) {
		return await this.layerSetRepository.delete({id:layerSetId["id"] ,userId: userId});
	}
}
