import { Test, TestingModule } from '@nestjs/testing';
import { DeepDiveConfigService } from './deep-dive-config.service';

describe('DeepDiveConfigService', () => {
  let service: DeepDiveConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [DeepDiveConfigService],
    }).compile();

    service = module.get<DeepDiveConfigService>(DeepDiveConfigService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
