import { Module } from "@nestjs/common";
import { AnswerService } from "./answer.service";
import { AnswerController } from "./answer.controller";
import { Answer } from "./answer.entity";
import { TypeOrmModule } from "@nestjs/typeorm";
import { WorkItem } from "src/work-item/work-item.entity";
import { Property } from "src/property/property.entity";
import { JwtModule } from "@nestjs/jwt";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { User } from "src/users/users.entity";
@Module({
	imports: [
		TypeOrmModule.forFeature([Answer, WorkItem, Property, User, ApiKeyUser]),
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		})
	],
	providers: [AnswerService],
	controllers: [AnswerController]
})
export class AnswerModule {}
