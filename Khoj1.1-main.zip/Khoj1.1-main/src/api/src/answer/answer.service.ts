import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { Repository, In } from "typeorm";
import { Answer } from "./answer.entity";
import { InjectRepository } from "@nestjs/typeorm";
import { AnswerSearch, AnswerBody } from "../interfaces/answer";
import { WorkItem, WorkItemStatus } from "src/work-item/work-item.entity";
import { Property, PropertyReviewStatus } from "src/property/property.entity";
import { JwtService } from "@nestjs/jwt";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import _ = require("lodash");
@Injectable()
export class AnswerService {
	constructor(
		@InjectRepository(Answer) private answerRespository: Repository<Answer>,
		@InjectRepository(WorkItem) private workItemRepository: Repository<WorkItem>,
		@InjectRepository(Property) private propertyRepository: Repository<Property>,
		@InjectRepository(User) private userRepository: Repository<User>,
		@InjectRepository(ApiKeyUser) private apiKeyRespository: Repository<ApiKeyUser>,
		private jwtService: JwtService
	) {}

	async list(): Promise<Answer[]> {
		return await this.answerRespository.find();
	}

	async create(answers: Answer[],headers): Promise<Answer[]> {
		let user;
		let userType = "";
        if(headers?.["token"]) {
            user = await this.jwtService.decode(headers["token"]) as JSON;
			userType = "token user";
        } else {
            let apiKey;
			if(headers["apikey"]) {
				apiKey = headers["apikey"];
			}
			if(headers["api-key"]) {
				apiKey = headers["api-key"];
			}
			if(headers["apiKey"]) {
				apiKey = headers["apiKey"];
			}
            user = await this.jwtService.decode(apiKey) as JSON;
			userType = "apiKey user";
        }
		answers.forEach((answer: Answer) => {
			answer["userId"]?(answer.faId = String(answer["userId"])):false;
			answer["userId"]?(delete answer["userId"]):false;
			if(userType == "token user") {
				answer.tokenUserId = Number(user["id"]);
			} else {
				answer.apiKeyUserId = Number(user["id"]);
			}
		});
		return await this.answerRespository.save(answers);
	}

	async search(query: AnswerSearch,headers): Promise<Answer[]> {
		const thisUser = this.jwtService.decode( headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"]);
		const formatAnswer = async (answers: Answer[]) => {
			const userDict: _.Dictionary<{firsName : string, lastName: string, email?: string, phoneNumber?: string }> = {};
			const apiKeyDict: _.Dictionary<{firsName : string, lastName: string, email?: string }> = {};
			if(query.userDetails == undefined || query.userDetails == true) {
				const userIds = [];
				const apiKeyIds = [];
				answers.forEach((ans: Answer) => {
					if(ans.tokenUserId != undefined || ans.tokenUserId != null) {
						userIds.push(ans.tokenUserId);
					}
					if(ans.apiKeyUserId != undefined || ans.apiKeyUserId != null) {
						apiKeyIds.push(ans.apiKeyUserId);
					}
				});
				const users = await this.userRepository.find({ where: {id: In(userIds)}});
				const apiKeyUsers = await this.apiKeyRespository.find({ where: {id: In(apiKeyIds)}});
				users.forEach((user) => {
					userDict[user.id] = { firsName: user.firstName, 
						lastName: user.lastName, 
						email: (user.email != undefined && user.email != null) ? user.email : undefined ,
						phoneNumber: (user.phoneNumber != undefined && user.phoneNumber != null) ? user.phoneNumber : undefined
					};
				});
				apiKeyUsers.forEach((user) => {
					apiKeyDict[user.id] = { 
						firsName: user.firstName, 
						lastName: user.lastName, 
						email: (user.email != undefined && user.email != null) ? user.email : undefined
					};
				});
			}
			return answers.map(ans => {
				const a = ans;
				a["userId"] = a.faId;
				if(a?.tokenUserId != undefined && a?.tokenUserId != null) {
					a["user"] = (userDict[ans.tokenUserId] != undefined) ? userDict[ans.tokenUserId] : undefined 
				}
				if(a?.apiKeyUserId != undefined && a?.apiKeyUserId != null) {
					a["user"] = (apiKeyDict[ans.apiKeyUserId] != undefined) ? apiKeyDict[ans.apiKeyUserId] : undefined 
				}
				return a;
			});
		}
		if(query.uniqueId && query.userId) {
			if(query.userId == "all") {
				const answers = await this.answerRespository.find({
					where: {
						uniqueId: Number(query.uniqueId),
						questionId: In(query.questionIds)
					}
				});
				return formatAnswer(answers);
			} else {
				const answers = await this.answerRespository.find({
					where: {
						uniqueId: Number(query.uniqueId),
						faId: String(query.userId),
						questionId: In(query.questionIds)
					}
				});
				return formatAnswer(answers);
			}
		}		
		if(query.userId) {
			if(query.userId == "all") {
				const answers = await this.answerRespository.find({
					where: {
						questionId: In(query.questionIds)
					}
				});
				return formatAnswer(answers);
			} else {
				const answers = await this.answerRespository.find({ 
					where: {
						faId: String(query.userId),
						questionId: In(query.questionIds)
					}
				});
				return formatAnswer(answers);
			}
		}
		if(query.uniqueId) {
			if(thisUser["type"] == "token") {
				const answers = await this.answerRespository.find({
					where: {
						uniqueId: Number(query.uniqueId),
						questionId: In(query.questionIds),
						tokenUserId: Number(thisUser["id"])
					}
				});
				return formatAnswer(answers);
			} else {
				const answers = await this.answerRespository.find({
					where: {
						uniqueId: Number(query.uniqueId),
						questionId: In(query.questionIds),
						apiKeyUserId: Number(thisUser["id"])
					}
				});
				return formatAnswer(answers);
			}
			
		}
		if(thisUser["type"] == "token") {
			const answers = await this.answerRespository.find({
				where: {
					questionId: In(query.questionIds),
					tokenUserId: Number(thisUser["id"])
				}
			});
			return await formatAnswer(answers);
		} else {
			const answers = await this.answerRespository.find({
				where: {
					questionId: In(query.questionIds),
					apiKeyUserId: Number(thisUser["id"])
				}
			});
			return await formatAnswer(answers);
		}
		
	}

	async submitAnswers(answers: AnswerBody[]): Promise<Answer[]> {
		const answerss = await this.answerRespository.save(answers);
		const lastAnswer = answerss[1];
		const workItem = await this.workItemRepository.findOne({ where: { id: lastAnswer.workItemId } });
		workItem.status = WorkItemStatus.close;
		await this.workItemRepository.save(workItem);
		const property = await this.propertyRepository.findOne({ where: { id: lastAnswer.propertyId } });
		property.reviewStatus = PropertyReviewStatus.reviewed;
		await this.propertyRepository.save(property);
		return answerss;
	}

	async searchNew(query: AnswerSearch,headers) {
		//throw err if questionIds is missing
		if(query.questionIds == undefined) {
			throw new HttpException(`questionIds missing!`,HttpStatus.BAD_REQUEST);
		}
		//Find current user
		const thisUser = this.jwtService.decode( headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"]);
		//Create query string and obj
		let queryString = ``;
		let queryObject = {};
		if(query?.uniqueId) {
			queryString = `"uniqueId" = :uniqueId`;
			queryObject["uniqueId"] = Number(query.uniqueId);
		}
		if(query?.answers) {
			if(queryString.length == 0) {
				queryString = `answer IN (:...answers)`;
				queryObject["answers"] = query.answers as string[];
			} else {
				queryString = queryString + ` AND answer IN (:...answer)`;
				queryObject["answers"] = query.answers as string[];
			}
		}
		if(query.userId) {
			if(queryString.length == 0) {
				if(query.userId == "all") {

				} else {
					queryString = `"faId" = :userId`;
					queryObject["userId"] = String(query.userId);
				}
			} else {
				if(query.userId == "all") {

				} else {
					queryString = queryString + ` AND "faId" = :userId`;
					queryObject["userId"] = String(query.userId);
				}
			}
		} else {
			if(queryString.length == 0) {
				if(thisUser["type"] == "token") {
					queryString = `"tokenUserId" = :userId`;
					queryObject["userId"] = Number(thisUser["id"]);
				} else {
					queryString = `"apiKeyUserId" = :userId`;
					queryObject["userId"] = Number(thisUser["id"]);
				}
			} else {
				if(thisUser["type"] == "token") {
					queryString = queryString + ` AND "tokenUserId" = :userId`;
					queryObject["userId"] = Number(thisUser["id"]);
				} else {
					queryString = queryString + ` AND "apiKeyUserId" = :userId`;
					queryObject["userId"] = Number(thisUser["id"]);
				}
			}
		}
		//Find answers
		let answers: Answer[];
		if(queryString.length > 0) {
			answers = await this.answerRespository
				.createQueryBuilder("answer")
				.where(`"questionId" IN (:...questionIds)`,{ questionIds: query.questionIds })
				.andWhere(queryString,queryObject)
				.orderBy(`"createdAt"`)
				.getMany();
		} else {
			answers = await this.answerRespository
				.createQueryBuilder("answer")
				.where(`"questionId" IN (:...questionIds)`,{ questionIds: query.questionIds })
				.orderBy(`"createdAt"`)
				.getMany();
		}
		//Get last status
		if(query?.status) {
			const uniqueIds = answers.map(a => { return a.uniqueId });
			const lastAnswers = await this.answerRespository
				.createQueryBuilder("answer")
				.distinctOn([`"uniqueId"`])
				.where(`"uniqueId" IN (:...uniqueIds)`,{ uniqueIds: uniqueIds })
				.orderBy(`"uniqueId","createdAt"`,"DESC")
				.getMany();
			//console.log(lastAnswers);
			const remainingUniqueIds: number[] = [];
			const statusDict: _.Dictionary<{status: string, createdAt: number}> = {};
			lastAnswers.forEach(ans => {
				if(query.status.includes(ans.answer[0])) {
					remainingUniqueIds.push(Number(ans.uniqueId));
					statusDict[ans.uniqueId] = { status: ans.answer[0] , createdAt: ans.createdAt.getTime() };
				}
			});
			answers = answers.filter(ans => { 
				if(( remainingUniqueIds.includes(Number(ans.uniqueId))) && (ans.answer[0] == statusDict[ans.uniqueId].status) && (ans.createdAt.getTime() == statusDict[ans.uniqueId].createdAt)) {
					return true
				} else {
					return false;
				}
			});
		}
		//Get user details
		const userDict: _.Dictionary<{firsName : string, lastName: string, email?: string, phoneNumber?: string }> = {};
		const apiKeyDict: _.Dictionary<{firsName : string, lastName: string, email?: string }> = {};
		if(query.userDetails == undefined || query.userDetails == true) {
			const userIds = [];
			const apiKeyIds = [];
			answers.forEach((ans: Answer) => {
				if(ans.tokenUserId != undefined || ans.tokenUserId != null) {
					userIds.push(ans.tokenUserId);
				}
				if(ans.apiKeyUserId != undefined || ans.apiKeyUserId != null) {
					apiKeyIds.push(ans.apiKeyUserId);
				}
			});
			const users = await this.userRepository.find({ where: {id: In(userIds)}});
			const apiKeyUsers = await this.apiKeyRespository.find({ where: {id: In(apiKeyIds)}});
			users.forEach((user) => {
				userDict[user.id] = { firsName: user.firstName, 
					lastName: user.lastName, 
					email: (user.email != undefined && user.email != null) ? user.email : undefined ,
					phoneNumber: (user.phoneNumber != undefined && user.phoneNumber != null) ? user.phoneNumber : undefined
				};
			});
			apiKeyUsers.forEach((user) => {
				apiKeyDict[user.id] = { 
					firsName: user.firstName, 
					lastName: user.lastName, 
					email: (user.email != undefined && user.email != null) ? user.email : undefined
				};
			});
		}
		//format answers without changing order
		answers.forEach(a => {
			a["userId"] = a.faId;
			if(a?.tokenUserId != undefined && a?.tokenUserId != null) {
				a["user"] = (userDict[a.tokenUserId] != undefined) ? userDict[a.tokenUserId] : undefined 
			}
			if(a?.apiKeyUserId != undefined && a?.apiKeyUserId != null) {
				a["user"] = (apiKeyDict[a.apiKeyUserId] != undefined) ? apiKeyDict[a.apiKeyUserId] : undefined 
			}
		});
		//return response
		return answers;
	}
}
