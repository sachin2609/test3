export function getOTPMailTemplate(firstName: string, lastName: string, otp: number) {
	const htmlForUser = `
		<!DOCTYPE html>
		<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">
		<head>
		  <meta charset="UTF-8">
		  <meta name="viewport" content="width=device-width,initial-scale=1">
		  <meta name="x-apple-disable-message-reformatting">
		  <meta http-equiv="Content-Type" content="text/html charset=UTF-8" />
		  <title></title>
		  <style>
			table, td, div, h1, p {font-family: Arial, sans-serif;}
		  </style>
		</head>
		<body style="margin:0;padding:0;">
		  <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;background:rgb(237, 237, 237);">
			<tr>
			  <td align="center" style="padding:0;">
				<table role="presentation" style="width:602px;border-collapse:collapse;border-spacing:0;text-align:left;">
				  <tr>
					<td align="center" style="padding:40px 0 30px 0;">
					  <a href="https://datasutram.com" target="blank" style="box-sizing: border-box;color: #0d6efd;text-decoration: underline;">
						<img src="https://datasutram.com/assets/images/common/ds_logo_b.png" style="max-width: 100%;width: 300px;vertical-align: middle;margin-top: 1.5rem!important;margin-bottom: 1.5rem!important;" alt="">
					  </a>
					</td>
				  </tr>
				</table>
			  </td>
			</tr>
		  </table>
		  <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;background:rgb(237, 237, 237);">
			<tr>
			  <td align="center" style="padding-bottom:50px;">
				<table role="presentation" style="width:602px;border-collapse:collapse;border:1px solid #cccccc;border-spacing:0;text-align:left;background: #ffffff;">
				  <tr>
					<td style="padding:36px 30px 42px 30px;">
					  <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;">
						<tr>
						  <td align="center">
							<h1 style="font-size:24px;margin:0 0 20px 0;font-family:Arial,sans-serif;">Account Verification</h1>
						  </td>
						</tr>
						<tr>
						  <td style="padding:0 0 36px 0;color:#153643;">
							<p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Hello ${firstName} ${lastName}</p>
							<p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Your OTP for Data Sutram Account Verification is ${otp} - Use this to verify your account.</p>
							<p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">You should be able to login post verification. Thanks for your patience.</p>
							<p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Should you need any assistance or have a question, please write to us at <a href="https://mail.google.com/mail/u/0/?fs=1&to=hello@datasutram.com&su=Data%20Sutram&body=Your%20Comments%20on%20Datasutram%20Console%20here&tf=cm" target="blank">hello@datasutram.com</a></p>

							<p style="margin:20px 0 0 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Warm Regards,</p>
							<p style="margin:0 0 12px 0;font-size:16px;line-height:24px;font-family:Arial,sans-serif;">Team Datasutram</p>
						  </td>
						</tr>
					  </table>
					</td>
				  </tr>
				  <tr>
					<td style="padding:0 30px 30px 30px;">
					  <table role="presentation" style="width:100%;border-collapse:collapse;border:0;border-spacing:0;font-size:9px;font-family:Arial,sans-serif;">
						<tr>
						  <td style="padding:0;width:25%;" align="center">
							<table role="presentation" style="border-collapse:collapse;border:0;border-spacing:0;">
							  <tr>
								<td style="padding:0 0 0 10px;width:38px;">
								  <a href="https://www.linkedin.com/company/data-sutram" target="blank" class="icon linkedin" title="Linkedin" style="width: 38px;">
									<img src="https://cdn.exclaimer.com/Handbook%20Images/linkedin-icon_32x32.png?_ga=2.1038641.1612459600.1629015905-2070996887.1629015905" alt="">
								  </a>
								</td>
							  </tr>
							</table>
						  </td>
						  <td style="padding:0;width:25%;" align="center">
							<table role="presentation" style="border-collapse:collapse;border:0;border-spacing:0;">
							  <tr>
								<td style="padding:0 0 0 10px;width:38px;">
								  <a href="https://twitter.com/dsutram?lang=en" target="blank" class="icon twitter" title="Twitter" style="width: 38px;">
									<img src="https://cdn.exclaimer.com/Handbook%20Images/twitter-icon_32x32.png?_ga=2.39811107.1612459600.1629015905-2070996887.1629015905" alt="">
								  </a>
								</td>
							  </tr>
							</table>
						  </td>
						  <td style="padding:0;width:25%;" align="center">
							<table role="presentation" style="border-collapse:collapse;border:0;border-spacing:0;">
							  <tr>
								<td style="padding:0 0 0 10px;width:38px;">
								  <a href="https://www.facebook.com/datasutram/" target="blank" class="icon facebook" title="Facebook" style="width: 38px;">
									<img src="https://cdn.exclaimer.com/Handbook%20Images/facebook-icon_32x32.png?_ga=2.105871363.1612459600.1629015905-2070996887.1629015905" alt="">
								  </a>
								</td>
							  </tr>
							</table>
						  </td>
						  <td style="padding:0;width:25%;" align="center">
							<table role="presentation" style="border-collapse:collapse;border:0;border-spacing:0;">
							  <tr>
								<td style="padding:0 0 0 10px;width:38px;">
								  <a href="https://datasutram.medium.com/" target="blank" class="icon medium" title="Twitter" style="width: 38px;">
									<img src="https://cdn.exclaimer.com/Handbook%20Images/Medium_32.png?_ga=2.98997534.1612459600.1629015905-2070996887.1629015905" alt="">
								  </a>
								</td>
							  </tr>
							</table>
						  </td>
						</tr>
					  </table>
					</td>
				  </tr>
				  <tr>
					<td style="padding: 20px; text-align: center;">
					  <p style="margin:0 0 12px 0;font-size:10px;font-family:Arial,sans-serif;font-style: italic;">The information contained in this electronic message and any attachments to this message are intended for the exclusive use of the addressee(s) and may contain proprietary, confidential or privileged information. If you are not the intended recipient, you should not disseminate, distribute or copy this e-mail. Please notify the sender immediately and destroy all copies of this message and any attachments contained in it.</p>
					</td>
				  </tr>
				</table>
			  </td>
			</tr>
		  </table>
		</body>
		</html>
		`;
	return htmlForUser;
}
