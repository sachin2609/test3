import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { User } from "src/users/users.entity";
import { Between, In, Repository } from "typeorm";
import { UserApiUsageHistory, CreditsSpentQuery } from "./user-api-usage-history.entity";
import * as _ from "lodash";
import * as moment from "moment";
import { Team } from "src/team/team.entity";

@Injectable()
export class UserApiUsageHistoryService {
	constructor(
		@InjectRepository(Team) private teamRepository: Repository<Team>,
		@InjectRepository(User) private usersRepository: Repository<User>,
		@InjectRepository(UserApiUsageHistory) private userApiUsageRepository: Repository<UserApiUsageHistory>,
	) {}

	async creditSpent(query: CreditsSpentQuery, userId: number, roles: string[]) {
		const { startTime, endTime, teamIds, groupBy } = query;
		let { userIds } = query;
		if (!moment(startTime).isValid() || !moment(endTime).isValid || moment(startTime).isAfter(moment(endTime))) {
			throw new HttpException(
				"StartTime and EndTime Not Specified / Invalid or Incorrect",
				HttpStatus.BAD_REQUEST,
			);
		}
		if (!groupBy.length) {
			throw new HttpException("GroupBy must be mentioned", HttpStatus.BAD_REQUEST);
		}
		if (userIds && !_.isArray(userIds)) throw new HttpException("UserIds must be an array", HttpStatus.BAD_REQUEST);
		if (teamIds && !_.isArray(teamIds)) throw new HttpException("TeamIds must be an array", HttpStatus.BAD_REQUEST);
		if (roles.includes("admin")) {
			const teamUsers = teamIds?.length
				? await this.usersRepository.find({
						where: {
							teamId: In(teamIds),
						},
						select: ["id"],
				  })
				: [];
			if (!teamUsers.length && !userIds?.length) userIds = null;
			else if (teamUsers.length && !userIds?.length) userIds = teamUsers.map((u) => u.id);
			else if (!teamUsers.length && userIds?.length) userIds = userIds;
			else if (teamUsers.length && userIds?.length)
				userIds = _.intersection(
					teamUsers.map((u) => u.id),
					userIds,
				);
		} else {
			const myUser = await this.usersRepository.findOne({
				where: {
					id: userId,
				},
				select: ["id"],
			});
			const myTeam = await this.teamRepository.findOne({
				where: {
					id: myUser.teamId,
				},
				select: ["id"],
			});
			const myUsers = await this.usersRepository.find({
				where: {
					teamId: myTeam.id,
				},
				select: ["id"],
			});
			userIds = [
				...(userIds?.length
					? _.intersection(
							userIds,
							myUsers.map((u) => u.id),
					  )
					: []),
				...myUsers.map((u) => u.id),
			];
		}
		if (!userIds?.length) return [];
		const usages = await this.userApiUsageRepository.find({
			where: {
				createdAt: Between(startTime, endTime),
				userId: userIds?.length ? In(userIds) : undefined,
			},
			select: [
				"id",
				"userId",
				"createdAt",
				"State",
				"City",
				"Pincode",
				"Taluka",
				"District",
				"Country",
				"layer",
				"layerType",
				"createdAt",
				"creditsUsed",
			],
		});

		const response = [];
		if (query["groupBy"] == "user") {
			try {
				const usagesKeyedByUserId = _.groupBy(usages, "userId");
				const userIds = Object.keys(usagesKeyedByUserId);
				const users = await this.usersRepository.find({
					where: {
						id: In(userIds),
					},
					select: ["id", "email", "phoneNumber"],
				});
				for (const userID of userIds) {
					const theUser = users.find((u) => u.id === Number(userID));
					const noOfRequest = usagesKeyedByUserId[userID].length;
					const creditsUsed = _.sumBy(usagesKeyedByUserId[userID], "creditsUsed");
					const [userId, email, phoneNumber] = [userID, theUser?.email ?? "", theUser?.phoneNumber ?? ""];
					response.push({
						userId: Number(userId),
						creditsUsed,
						noOfRequest,
						email,
						phoneNumber,
					});
				}
				return response;
			} catch (error) {
				console.error(error);
			}
		}
		if (query["groupBy"] == "location") {
			try {
				const level = query["groupByLocation"] ?? "Pincode";
				const usagesKeyedByLocation = _.groupBy(usages, level);
				const locationNames = Object.keys(usagesKeyedByLocation);
				for (const locationName of locationNames) {
					const noOfRequest = usagesKeyedByLocation[locationName].length;
					const creditsUsed = usagesKeyedByLocation[locationName].reduce(
						(acc, curr) => acc + curr.creditsUsed,
						0,
					);
					const [geography, geographyName] = [level, locationName];
					response.push({
						geography,
						geographyName,
						creditsUsed,
						noOfRequest,
					});
				}
				return response;
			} catch (error) {
				console.error(error);
			}
		}
		if (query["groupBy"] == "layerType") {
			const selectedLayer = query["layer"] ?? "poi";
			const usagesKeyedByLayers = _.groupBy(usages, selectedLayer);
			const layers = Object.keys(usagesKeyedByLayers);
			for (const theLayer of layers) {
				const noOfRequest = usagesKeyedByLayers[theLayer].length;
				const creditsUsed = usagesKeyedByLayers[theLayer].reduce((acc, curr) => acc + curr.creditsUsed, 0);
				response.push({
					layer: theLayer,
					creditsUsed,
					noOfRequest,
				});
			}
		}
		if (query["groupBy"] == "time") {
			try {
				let totalCredits = 0;
				totalCredits = usages.map((u) => u.creditsUsed).reduce((a, b) => a + b, 0);
				let dates: { startTime: Date; endTime: Date }[];
				const brackets = Number(query["timeBracket"]) ?? undefined;
				if (!isNaN(brackets)) {
					dates = this.getBracketsTimeRanges(
						new Date(startTime),
						new Date(endTime),
						Number(query["timeBracket"]),
					);
				} else {
					dates = this.getISTTimeRanges(new Date(startTime), new Date(endTime));
				}
				let times: {
					startTime: Date;
					endTime: Date;
					startTimeIST: string;
					endTimeIST: string;
					creditsUsed: number;
					noOfRequest: number;
				}[] = [];
				times = dates.map((t) => {
					const filteredUsages = usages.filter((u) => u.createdAt > t.startTime && u.createdAt < t.endTime);
					return {
						startTime: t.startTime,
						endTime: t.endTime,
						startTimeIST: this.ISOtoIST(t.startTime),
						endTimeIST: this.ISOtoIST(t.endTime),
						creditsUsed: filteredUsages.reduce((a, b) => a + b.creditsUsed, 0),
						noOfRequest: filteredUsages.length,
					};
				});
				const responseObj = {
					totalCreditsSpent: totalCredits,
					times,
				};
				return responseObj;
			} catch (error) {
				console.error(error);
			}
		}
	}

	getISTTimeRanges(startTime: Date, endTime: Date): { startTime: Date; endTime: Date }[] {
		const dateArray: { startTime: Date; endTime: Date }[] = [];
		let currentTime: Date = new Date(
			Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate(), 18, 29, 59, 999),
		);
		dateArray.push({ startTime: startTime, endTime: currentTime });
		while (currentTime < new Date(endTime)) {
			const oldTime = new Date(
				Date.UTC(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate(), 18, 30, 0, 0),
			);
			const newTime = new Date(
				Date.UTC(currentTime.getFullYear(), currentTime.getMonth(), currentTime.getDate() + 1, 18, 29, 59, 999),
			);
			if (newTime < endTime) {
				dateArray.push({ startTime: oldTime, endTime: newTime });
			} else {
				dateArray.push({ startTime: oldTime, endTime: endTime });
			}
			currentTime = newTime;
		}
		return dateArray;
	}

	getBracketsTimeRanges(startTime: Date, endTime: Date, brackets: number): { startTime: Date; endTime: Date }[] {
		const span = endTime.valueOf() - startTime.valueOf();
		const increment = span / brackets;
		const dateArray: { startTime: Date; endTime: Date }[] = [];
		let currentTime = startTime;
		while (currentTime < endTime) {
			dateArray.push({ startTime: currentTime, endTime: new Date(currentTime.valueOf() + increment) });
			currentTime = new Date(currentTime.valueOf() + increment);
		}
		return dateArray;
	}

	ISOtoIST(time: Date): string {
		return time.toLocaleString(undefined, { timeZone: "Asia/Kolkata" });
	}

	async includes(superSet: any[], subSet: any[]): Promise<boolean> {
		subSet.forEach((element) => {
			if (_.includes(superSet, element) == false) {
				return false;
			}
		});
		return true;
	}

	addDay(dateStr, days) {
		const myDate = new Date(dateStr.toISOString());
		myDate.setDate(myDate.getDay() + parseInt(days));
		return myDate;
	}
}
