import { Module } from "@nestjs/common";
import { FormService } from "./form.service";
import { FormController } from "./form.controller";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Form } from "./form.entity";
import { Question } from "../question/question.entity";
import { QuestionService } from "../question/question.service";
@Module({
	imports: [TypeOrmModule.forFeature([Form, Question])],
	providers: [FormService, QuestionService],
	controllers: [FormController]
})
export class FormModule {}
