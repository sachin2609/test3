import { Entity, Column, PrimaryColumn, UpdateDateColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class UserOtp {
	@ApiProperty()
	@PrimaryColumn()
	userId: number;

	@ApiProperty()
	@Column()
	otp: number;

	@ApiProperty()
	@UpdateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)", onUpdate: "CURRENT_TIMESTAMP(6)" })
	updatedAt: Date;
}
