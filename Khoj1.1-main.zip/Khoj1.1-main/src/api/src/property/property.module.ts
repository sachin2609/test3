import { Module } from "@nestjs/common";
import { HttpModule } from "@nestjs/axios";
import { PropertyController } from "./property.controller";
import { PropertyService } from "./property.service";
import { Property } from "./property.entity";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Grid } from "src/grid/grids.entity";
import { PropertyGridService } from "src/relations/property-grid/property-grid.service";
import { PropertyGrid } from "src/relations/property-grid/property-grid.entity";
import { GridService } from "src/grid/grid.service";
import { UserGrid } from "src/relations/user-grid/user-grid.entity";
import { WorkItem } from "src/work-item/work-item.entity";
import { WorkItemService } from "src/work-item/work-item.service";
import { PropertyDetail } from "src/property-detail/property-detail.entity";
import { PropertyDetailService } from "src/property-detail/property-detail.service";
import { User } from "../users/users.entity";
import { Indexmaster } from "../index-master/index-master.entity";
import { PropertyProcessor } from "./propertyConsumer";
import { BullModule } from "@nestjs/bull";
import * as dotenv from "dotenv";
import { JwtModule } from "@nestjs/jwt";
import { Answer } from "src/answer/answer.entity";
import { Question } from "src/question/question.entity";
import { MongooseModule } from "@nestjs/mongoose";
import { DemoShapesDBSchema } from "src/shape/shape.schema";
import { Shape } from "src/shape/shape.entity";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
import { ShapeService } from "src/shape/shape.service";
dotenv.config();
@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY }
		}),
		HttpModule,
		TypeOrmModule.forFeature([
			Property,
			Grid,
			PropertyGrid,
			UserGrid,
			WorkItem,
			PropertyDetail,
			User,
			Indexmaster,
			Answer,
			Question,
			Shape,
			Shapeindex,
			ShapeDetail
		]),
		//BullModule.registerQueue({
		//	name: "uploadproperty",
		//	redis: {
		//		host: process.env.REDIS_HOST,
		//		port: Number(process.env.REDIS_PORT)
		//	}
		//}),
		MongooseModule.forFeature([{ name: 'DemoShapesDB', schema: DemoShapesDBSchema }]),
		HttpModule.register({
			timeout: 100000,
      		maxRedirects: 100
		}),
		MongoDatabaseModule
	],
	controllers: [PropertyController],
	providers: [
		PropertyService,
		PropertyGridService,
		GridService,
		WorkItemService,
		PropertyDetailService,
		PropertyProcessor,
		ShapeService
	]
})
export class PropertyModule {}
