import { ApiProperty } from "@nestjs/swagger";
import { Column, CreateDateColumn, Entity, PrimaryColumn, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class PromptLog {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	tokenUserId?: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	apiKeyUserId?: number;

	@ApiProperty()
	@PrimaryColumn({ type: "integer" })
	poiId: number;

	@ApiProperty()
	@Column()
	node: string;

	@ApiProperty()
	@Column({ nullable: true })
	question?: string;

	@ApiProperty()
	@Column({ nullable: true })
	answer?: string;

	@ApiProperty()
	@Column({ nullable: true })
	comment?: string;

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt?: Date;
}
