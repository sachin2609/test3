import { Entity, Column, PrimaryColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class ApiKeyIp {
	@ApiProperty()
	@PrimaryColumn()
	apiKey: string;

	@ApiProperty()
	@Column()
	ip: string;
}
