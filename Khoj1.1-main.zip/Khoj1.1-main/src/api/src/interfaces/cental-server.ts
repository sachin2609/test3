export class CentralServerFetchUsersRes {
	count: number;
	data: CentralServerAppUserDto[];
}

export class CentralServerAppUserDto {
	id: number;
	phoneNumber: string;
	ssoProvider: string;
	code: string;
	clientId: number;
	isAuthorized: boolean;
}
