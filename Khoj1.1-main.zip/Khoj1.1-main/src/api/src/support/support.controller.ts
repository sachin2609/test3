import { Controller, Post, Headers, Body, UseInterceptors, UploadedFiles } from "@nestjs/common";
import { SupportService } from "./support.service";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { TeamService } from "src/team/team.service";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { Issue } from "src/interfaces/support";
import { FilesInterceptor } from "@nestjs/platform-express";
import { diskStorage } from "multer";

@Controller("support")
export class SupportController {
	constructor(private readonly _supportService: SupportService, private teamService: TeamService) {}

	async getUser(headers: any): Promise<{ tokenUser: Partial<User>; apiKeyUser: Partial<ApiKeyUser> }> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		const tokenUser = user["type"] === "token" ? (user as User) : undefined;
		const apiKeyUser = user["type"] === "apikey" ? (user as ApiKeyUser) : undefined;
		if (!tokenUser && !apiKeyUser) {
			throw new Error("Invalid token");
		}
		return { tokenUser, apiKeyUser };
	}

	@Roles(Role.BASIC)
	@Post()
	@UseInterceptors(
		FilesInterceptor("file", 5, {
			storage: diskStorage({
				destination: String(process.env.PATH_TO_SAVE_FILES),
				filename: (req, file, callback) => {
					const date = new Date();
					return callback(
						null,
						`d-${String(date.getDate())}-${String(date.getMonth())}-${String(
							date.getFullYear(),
						)}-h-${String(date.getHours())}-m-${String(date.getMinutes())}-s-${String(
							date.getSeconds(),
						)}-ms-${String(date.getMilliseconds())}-f-${file.originalname}`,
					);
				},
			}),
			limits: {
				fileSize: 1024 * 1024 * Number(process.env.MAX_FILE_SIZE),
			},
		}),
	)
	async addIssue(@Headers() headers, @Body() body: Partial<Issue>, @UploadedFiles() files: { filename: string }[]) {
		const { tokenUser } = await this.getUser(headers);
		return await this._supportService.addIssue(body, files, tokenUser);
	}
}
