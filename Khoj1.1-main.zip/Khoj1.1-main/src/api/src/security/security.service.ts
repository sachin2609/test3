import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { HttpService } from "@nestjs/axios";
import { firstValueFrom } from "rxjs";
import * as CryptoJS from "crypto-js";
import { IPRiskBody, EncryptedBody } from "./security.entity";

@Injectable()
export class SecurityService {
	constructor(private httpService: HttpService) {}

	KEY = String(process.env.PAYLOAD_ENCRYPTION_KEY);
	IV = String(process.env.PAYLOAD_ENCRYPTION_IV);
	isPayloadEncryptionEnabled = process.env?.PAYLOAD_ENCRYPTION == "true";
	isResponseEncryptionEnabled = process.env?.RESPONSE_ENCRYPTION == "true";

	encrypt(body) {
		const key = CryptoJS.enc.Utf8.parse(this.KEY);
		const iv = CryptoJS.enc.Utf8.parse(this.IV);
		const encrypted = CryptoJS.AES.encrypt(body, key, { iv: iv, mode: CryptoJS.mode.CBC });
		return encrypted.toString();
	}

	decrypt<T>(payload: string): T {
		if (!payload?.length) {
			throw new HttpException(`'data' is required!`, HttpStatus.BAD_REQUEST);
		}
		const stringifiedPayload = (() => {
			try {
				const key = CryptoJS.enc.Utf8.parse(this.KEY);
				const iv = CryptoJS.enc.Utf8.parse(this.IV);
				const decrypted = CryptoJS.AES.decrypt(payload.trim(), key, { iv: iv, mode: CryptoJS.mode.CBC });
				return decrypted.toString(CryptoJS.enc.Utf8);
			} catch (err) {
				throw new HttpException(`Cannot decrypt payload - ${err}`, HttpStatus.SERVICE_UNAVAILABLE);
			}
		})();
		const parsedPayload = (() => {
			try {
				return JSON.parse(stringifiedPayload);
			} catch (err) {
				throw new HttpException("Invalid JSON in Payload!", HttpStatus.BAD_REQUEST);
			}
		})();
		return parsedPayload;
	}

	async IPRiskAssessment(query: EncryptedBody | IPRiskBody) {
		let ip: string;
		if (this.isPayloadEncryptionEnabled) {
			const decryptedBody = this.decrypt<{ ip: string }>((query as EncryptedBody).body);
			console.log("Decrypted Body: ", decryptedBody);
			ip = decryptedBody?.ip;
		} else {
			ip = (query as IPRiskBody)?.ip;
		}
		if (!ip) {
			throw new HttpException("IP is required!", HttpStatus.BAD_REQUEST);
		}
		const url = `${String(process.env.SCAMALYTICS_API_URL)}/?key=${String(
			process.env.SCAMALYTICS_API_KEY,
		)}&ip=${ip}`;
		const resp = await (async () => {
			try {
				return (await firstValueFrom(this.httpService.get(url)))?.data;
			} catch (err) {
				console.error(err);
			}
		})();
		const IPRiskScorecard = {
			ip: ip,
			score: parseInt(resp?.score) ?? null,
			status: resp?.status ?? "n/a",
			risk: resp?.risk ?? "n/a",
			Hostname: "n/a",
			ASN: "n/a",
			"ISP Name": resp?.["ISP Name"] ?? "n/a",
			"Organization Name": "n/a",
			"Connection type": resp?.["connection_type"] ?? "n/a",
			"Country Name": resp?.["ip_country_name"] ?? "n/a",
			"Country Code": resp?.["ip_country_code"] ?? "n/a",
			Region: resp?.["ip_state_name"] ?? "n/a",
			City: resp?.["ip_city"] ?? "n/a",
			Latitude: resp?.["ip_geolocation"]?.split(",")[1] ?? "n/a",
			Longitude: resp?.["ip_geolocation"]?.split(",")[0] ?? "n/a",
			"Anonymizing VPN": resp?.["proxy_type"] === "VPN" ? "Yes" : "No" ?? "n/a",
			"Tor Exit Node": resp?.["proxy_type"] === "TOR" ? "Yes" : "No" ?? "n/a",
			Server: resp?.["proxy_type"] === "DCH" ? "Yes" : "No" ?? "n/a",
			"Public Proxy": resp?.["proxy_type"] === "PUB" ? "Yes" : "No" ?? "n/a",
			"Web Proxy": resp?.["proxy_type"] === "WEB" ? "Yes" : "No" ?? "n/a",
			"Search Engine Robot": resp?.["proxy_type"] === "SES" ? "Yes" : "No" ?? "n/a",
			"Domain Name": resp?.["domain_name"] ?? "n/",
		};
		if (this.isResponseEncryptionEnabled)
			return {
				data: this.encrypt(JSON.stringify(IPRiskScorecard)),
			};
		else return IPRiskScorecard;
	}
}
