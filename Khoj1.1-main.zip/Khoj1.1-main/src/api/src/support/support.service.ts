import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import { Issue } from "src/interfaces/support";
import { User } from "src/users/users.entity";
import { InjectRepository } from "@nestjs/typeorm";
import { Team } from "src/team/team.entity";
import { Repository } from "typeorm";
import * as AWS from "aws-sdk";
import { GoogleSpreadsheet } from "google-spreadsheet";
import { JWT } from "google-auth-library";
import * as _ from "lodash";

//Google Sheets
const sheetId = String(process.env.GOOGLE_SHEET_ID);
const sheetIndex = _.isNaN(Number(process.env.GOOGLE_SHEET_INDEX)) ? 0 : Number(process.env.GOOGLE_SHEET_INDEX);
const serviceAccountAuth = new JWT({
	email: String(process.env.GOOGLE_SERVICE_EMAIL),
	key: String(process.env.GOOGLE_SERVICE_ACC_KEY),
	scopes: ["https://www.googleapis.com/auth/spreadsheets"],
});
//AWS
const s3 = new AWS.S3();
AWS.config.update({
	accessKeyId: process.env.AWS_ACCESS_KEY_ID,
	secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});

@Injectable()
export class SupportService {
	constructor(@InjectRepository(Team) private teamRepository: Repository<Team>) {}

	async addIssue(query: Partial<Issue>, files: { filename: string }[], user: Partial<User>) {
		if (!query?.issue || !query?.description)
			throw new HttpException(`'issue' AND 'description' are required!`, HttpStatus.BAD_REQUEST);
		const team = await (async () => {
			try {
				return await this.teamRepository.findOne({ where: { id: user.teamId } });
			} catch (error) {
				console.error(error);
				throw new HttpException(`Oops seems user doesnt have a team!`, HttpStatus.UNAUTHORIZED);
			}
		})();
		const attachments = files.map((file) => {
			return String(process.env.BASE_URL) + "/static/" + file.filename;
		});
		const issue: Issue = {
			issue: query.issue,
			description: query.description,
			userId: Number(user.id),
			username: `${user.firstName} ${user.lastName}`,
			phoneNumber: user?.phoneNumber,
			email: user?.email,
			client: String(process.env.FRONTEND_LOGIN_URL),
			team: team.name,
			attachments: attachments.join("\n"),
			createdAt: new Date(),
		};
		return await this.addDataToSheet(sheetId, issue);
	}

	async uploadFileToS3(fileBuffer: Buffer, fileName: string): Promise<{ Location: string }> {
		let location;
		try {
			const params = {
				Bucket: String(process.env.AWS_S3_BUCKET_NAME),
				Key: `${String(process.env.AWS_FILE_PATH).length ? String(process.env.AWS_FILE_PATH) : ""}/` + fileName,
				Body: fileBuffer,
			};
			location = await s3.upload(params).promise();
		} catch (error) {
			console.error(error);
		} finally {
			return location;
		}
	}

	async addDataToSheet(spreadsheetId: string, data) {
		try {
			const doc = new GoogleSpreadsheet(spreadsheetId, serviceAccountAuth);
			await doc.loadInfo(); // loads document properties and worksheets
			const sheet = doc.sheetsByIndex[sheetIndex];
			await sheet.addRow(data);
		} catch (error) {
			console.error("Error adding data from Google Sheets:", error);
			return { response: "Failure!" };
		} finally {
			return { response: "Success!" };
		}
	}
}
