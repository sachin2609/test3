import { CACHE_MANAGER, Controller, Get, Inject, UseInterceptors , CacheInterceptor} from "@nestjs/common";
import { Cache } from "cache-manager";
import { AppService } from "./app.service";
import { GridService } from "./grid/grid.service";
import { Roles } from "./helpers/roles-guard/roles-guard.service";

@Controller()
export class AppController {
	constructor(
		private readonly appService: AppService,
		private gridService: GridService,
		@Inject(CACHE_MANAGER) private cacheManager: Cache
	) {}
	
	@Get()
	async hello() {
		return "Welcome to DS-Api";
	}

}
