import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { ApiBody, ApiHeader, ApiParam, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { PoiPaginationDto } from 'src/interfaces/poi';
import { PoisQuery } from 'src/interfaces/pois';
import { PropertyQuery } from 'src/interfaces/property';
import { FilterQuery, FilterQueryRequest } from "../../interfaces/requests";
import { Poi } from 'src/poi/poi.entity';
import { PoiService } from 'src/poi/poi.service';
import { Roles } from 'src/helpers/roles-guard/roles-guard.service';
import { In } from 'typeorm/find-options/operator/In';

@ApiTags("Pois")
@Controller('pois')
export class PoiRoutesController {
	constructor(
		private _poiService : PoiService
	) {}

	//pois/Locality/colaba/?types=society&types=doctor&page=1&limit=20   --This is the ep
	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "GET POIS" })
	//@ApiParam({name: "Params", type: PoisQuery})
	@Get('/:level/:levelName')
	async getpois(@Param() query: PoisQuery,@Query() body): Promise<unknown> {
		console.log(query);
		console.log(body);
		let tempDict = {};
		//const types = query["poiType"];

		//tempDict = {query["level"] : query["levelName"]};
		tempDict[query.level] = query.levelName;
		//newQuery.location = tempDict;
		let newQuery : PropertyQuery = {
			location : tempDict,
			types: [],
			city: null,
			landmark: null,
			pincode: null,
			limit: null,
			page: null,
			poiStatus: null
		};
		if(body["types"]) {
			newQuery.types = body["types"];
		} else {
			delete newQuery.types;
		}
		if(body["page"] && body["limit"]) {
			newQuery.page = Number(body["page"]);
			newQuery.limit = Number(body["limit"]);
		} else {
			delete newQuery.page;
			delete newQuery.limit;
		}
		//newQuery["types"].push(query["poiType"]);
		console.log(newQuery);
		//newQuery["location"] = { query["level"] : query["levelName"] };
		return await this._poiService.filter(newQuery);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/filter")
	@ApiBody({ type: FilterQueryRequest , description: "Body for Pois/filter" })
	async filter(@Body() body: FilterQuery): Promise<Poi[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			return await this._poiService.filter(body);
		} catch(error) {
			console.log(error);
			return [];
		}
	}	
}
