import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class ExportData {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	userId: number;

	@ApiProperty()
    @Column()
    userType: string;

    @ApiProperty()
    @Column()
    layerName: string;

    @ApiProperty()
    @Column()
    layerProp: string;

    @ApiProperty()
    @Column()
    layerUrl: string;

    @ApiProperty()
    @Column()
    location: string;

    @ApiProperty()
    @Column()
    count: number;

    @ApiProperty()
    @CreateDateColumn()
    createdAt: Date;
}
