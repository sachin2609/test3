import { Body, Controller, Headers, Post } from '@nestjs/common';
import { Roles } from 'src/helpers/roles-guard/roles-guard.service';
import { ExportDataBody } from 'src/interfaces/export-data';
import { ExportDataService } from './export-data.service';

@Controller('export-data')
export class ExportDataController {
    constructor(
        private exportDataService: ExportDataService
    ) {}

    @Roles("basic")
    @Post()
    async addExportData(@Body() body: ExportDataBody, @Headers() header) {
        return this.exportDataService.addExportData(body as ExportDataBody,header);
    }
}
