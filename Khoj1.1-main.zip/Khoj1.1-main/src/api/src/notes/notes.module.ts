import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Poi } from "src/poi/poi.entity";
import { Note } from "./notes.entity";
import { NoteController } from "./notes.controller";
import { NoteService } from "./notes.service";
import { User } from "src/users/users.entity";
import { JwtModule } from "@nestjs/jwt";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { TeamService } from "src/team/team.service";
import { KeyCloakService } from "src/auth/keycloak.service";
import { CentralServerService } from "src/auth/central-server.service";
import { Team } from "src/team/team.entity";
import { UserCredits } from "src/user-history/user-credits.entity";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";

@Module({
	imports: [
		JwtModule.register({
			secret: process.env.JWT_SECURITY_KEY,
			signOptions: { expiresIn: process.env.JWT_EXPIRY },
		}),
		TypeOrmModule.forFeature([Note, Poi, User, ApiKeyUser, Team, UserCredits]),
	],
	controllers: [NoteController],
	providers: [NoteService, TeamService, KeyCloakService, CentralServerService, SyslogService],
})
export class NotesModule {}
