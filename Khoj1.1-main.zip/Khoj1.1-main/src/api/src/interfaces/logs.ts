import { HttpStatus } from "@nestjs/common";
import { Request as ERequest } from "express";

export interface LoggerParams {
	level?: "info" | "warn" | "err";
	statusCode?: HttpStatus;
	message: string;
	label?: "DS_Find";
	timestamp?: string;
	payload?: string;
	ip: string;
	route: string;
	userType: "token" | "apikey";
	creditsUsed: number;
}
export interface LoggerPayload {
	req: ERequest;
	ip: string;
	level?: "info" | "warn" | "err";
	message?: string;
	statusCode?: HttpStatus;
	response?: object;
	creditsUsed: number;
}
