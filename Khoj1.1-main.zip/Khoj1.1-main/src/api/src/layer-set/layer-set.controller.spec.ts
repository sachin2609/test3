import { Test, TestingModule } from '@nestjs/testing';
import { LayerSetController } from './layer-set.controller';

describe('LayerSetController', () => {
  let controller: LayerSetController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [LayerSetController],
    }).compile();

    controller = module.get<LayerSetController>(LayerSetController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
