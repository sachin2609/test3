import { Controller, Post, Body, Headers, Query, Get, UseInterceptors, HttpException, HttpStatus } from "@nestjs/common";
import { Grid } from "../grid/grids.entity";
import { LatLng, Catchment, PoiQuery, PoiPaginationDto, PoiStatusUpdate } from "../interfaces/poi";
import { JwtService } from "@nestjs/jwt";
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Header } from "../interfaces/header";
import { ApiTags, ApiBody, ApiHeader, ApiQuery, ApiResponse } from "@nestjs/swagger";
import { Roles, RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { LayersService } from './layers.service';
import { Layer } from './layers.entity';
import { LayerQuery } from '../interfaces/layerQuery';
import _ = require("lodash");
import { CacheInterceptorInterceptor } from "src/helpers/cache/cache-interceptor.interceptor";
import { CacheKey } from "src/helpers/cache/cache-key.decorator";
import { RealIP } from 'nestjs-real-ip';
import { CachePopulateInterceptor } from "src/helpers/cache/cache-populate.interceptor";

@Controller('layers')
export class LayersController {
	constructor(
		private _layerService: LayersService,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		private _jwtService: JwtService,
		private _rolesGuardService: RolesGuardService
	) {}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "filter" })
	@Post("/filter")
	@ApiBody({ type: Layer })
	async filter(@Body() body: LayerQuery, @Headers() header, @RealIP() ip: string): Promise<Layer[] | PoiPaginationDto | any> {
		console.log(body);
		try {
			if(body["without"]) {
				body["within"] = body["without"];
				let within = null;
				let page = null;
				let limit = null;
				if(body["page"] && body["limit"]) {
					page = body["page"] -1;
					limit = body["limit"];
					delete body["page"];
					delete body["limit"];
					console.log("Deleted 'page' and 'limit' from body");
				}
				const withinPoisRes = await this._layerService.filter(body);
				const withinPois = withinPoisRes["data"] as Layer[];
				if(body["within"]) {
					within = body["within"];
					delete body["within"];
					console.log("Deleted 'within' from body");
				}
				const allPoisRes = await this._layerService.filter(body);
				const allPois = allPoisRes["data"] as Layer[];
				console.log("Length of All pois : ",allPois.length);
				console.log("Length of Pois to be deleted :",withinPois.length);
				//const response = allPois.filter( poi => !withinPois.includes( poi ) );
				/*const response = allPois.filter(function(x) { 
					return withinPois.indexOf(x) < 0;
				});*/
				const response = allPois.filter(ar => !withinPois.find(rm => (rm.name === ar.name && ar.id === rm.id) ));
				console.log("Length of Response Pois :",response.length);
				if(limit) {
					const splitedArray = _.chunk(response,limit);
					const totalPages = splitedArray.length;
					const responsePaginate : PoiPaginationDto = {
						page: page+1,
						limit: limit,
						totalPages: totalPages,
						data: splitedArray[page]
					}
					return responsePaginate;
				} else {
					//New Response------------
					let resp = {};
					resp["count"] = response.length;
					resp["data"] = response;
					resp["typeCount"] = {};
					await Promise.all(response.map(poi => {
						const subTypes = Object.keys(resp["typeCount"]);
						if(subTypes.includes(poi.type)) {
							//console.log("Type encounterd :",poi.type);
							resp["typeCount"][poi.type] = resp["typeCount"][poi.type] +1;
						} else {
							resp["typeCount"][poi.type] = 1;
						}
					}));
					console.log("here u go :",resp["typeCount"]);
					console.log("deducting ", resp['count'])
					let credsResp;
					if(header.token) {
						credsResp = await this._rolesGuardService.updateCreds(header.token, resp['count'],"/layers/filter",ip,JSON.stringify(body));
					} else {
						credsResp = await this._rolesGuardService.apiKeyUpdateCreds(header["apikey"], resp['count'],"/layers/filter",ip,JSON.stringify(body));
					}
					console.log("response from creds deduction", credsResp);
					if (credsResp) {
						return resp;
					} else {
						throw new HttpException({
							status: HttpStatus.FORBIDDEN,
							error: "Insufficient Credits Left"
						}, HttpStatus.FORBIDDEN)
					}
					//return response;
				}	
			} else {
				const resp = await this._layerService.filter(body);
				console.log("deducting ", resp['count'])
				let credsResp;
				if(header.token) {
					credsResp = await this._rolesGuardService.updateCreds(header.token, resp['count'],"/layers/filter",ip,JSON.stringify(body));
				} else {
					credsResp = await this._rolesGuardService.apiKeyUpdateCreds(header["apikey"], resp['count'],"/layers/filter",ip,JSON.stringify(body));
				}
				console.log("response from creds deduction", credsResp);
				if (credsResp) {
					return resp;
				} else {
					throw new HttpException({
						status: HttpStatus.FORBIDDEN,
						error: "Insufficient Credits Left"
					}, HttpStatus.FORBIDDEN)
				}
			}
		} catch(error) {
			console.log(error);
			return [];
		}
	}
	@Roles("basic")
	@Post("internal-filter")
	@CacheKey("layer-internal-filter")
	@UseInterceptors(CacheInterceptorInterceptor)
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "filter" })
	@ApiBody({ type: Object })
	async filterPoiDetails(@Body() body): Promise<any> {
		try {
			return await this._layerService.filterLayerDetails(body);
		} catch(error) {
			return [];
			console.log(error);
		}
	}

	@Roles("admin")
	@Post("populate-internal-filter")
	@CacheKey("layer-internal-filter")
	@UseInterceptors(CachePopulateInterceptor)
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "filter" })
	@ApiBody({ type: Object })
	async populatefilterPoiDetails(@Body() body): Promise<any> {
		try {
			return await this._layerService.filterLayerDetails(body);
		} catch(error) {
			return [];
			console.log(error);
		}
	}


	@Roles("basic")
	@Get("alllayertypes")
	@CacheKey("layer-alllayertypes")
	@UseInterceptors(CacheInterceptorInterceptor)
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "allLayerNames" })
	@ApiBody({ type: Object })
	async getAllLayerTypes(@Query() query): Promise<any> {
		try {
			return await this._layerService.getAllLayerTypes(query);
		} catch(error) {
			console.log(error);
			return [];
		}
	}

	@Roles("admin")
	@Get("populate-alllayertypes")
	@CacheKey("layer-alllayertypes")
	@UseInterceptors(CachePopulateInterceptor)
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "allLayerNames" })
	@ApiBody({ type: Object })
	async populategetAllLayerTypes(@Query() query): Promise<any> {
		try {
			return await this._layerService.getAllLayerTypes(query);
		} catch(error) {
			console.log(error);
			return [];
		}
	}
	
}
