import { Test, TestingModule } from '@nestjs/testing';
import { TargetDetailsService } from './target-details.service';

describe('TargetDetailsService', () => {
  let service: TargetDetailsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [TargetDetailsService],
    }).compile();

    service = module.get<TargetDetailsService>(TargetDetailsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
