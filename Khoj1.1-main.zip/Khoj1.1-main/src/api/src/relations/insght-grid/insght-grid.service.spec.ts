import { Test, TestingModule } from "@nestjs/testing";
import { InsghtGridService } from "./insght-grid.service";

describe("InsghtGridService", () => {
	let service: InsghtGridService;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			providers: [InsghtGridService]
		}).compile();

		service = module.get<InsghtGridService>(InsghtGridService);
	});

	it("should be defined", () => {
		expect(service).toBeDefined();
	});
});
