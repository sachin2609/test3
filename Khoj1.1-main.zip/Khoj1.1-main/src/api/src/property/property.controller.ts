import {
	Controller,
	Post,
	Body,
	Get,
	Query,
	UseInterceptors,
	UploadedFiles,
	Headers
} from "@nestjs/common";
import { PropertyService } from "./property.service";
import { Property } from "./property.entity";
import {
	PropertyQuery,
	PropertyPaginationDto,
	PropertyLatLng,
	PropertyReviewBody,
	PropertyIdBody
} from "src/interfaces/property";
import { FilesInterceptor } from "@nestjs/platform-express";
import { diskStorage } from "multer";
import { Queue } from "bull";
import { InjectQueue } from "@nestjs/bull";
import { JwtService } from "@nestjs/jwt";
import { ApiTags, ApiQuery, ApiBody, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
import { WorkItem } from "src/work-item/work-item.entity";
import { WorkItemQuery, WorkItemPaginationDtoNew } from "src/interfaces/work-item";
import { User } from "src/users/users.entity";
import { Indexquery } from "src/interfaces/grid";
@ApiTags("property")
@Controller("property")
export class PropertyController {
	constructor(
		private _jwtService: JwtService,
		private _propertyService: PropertyService,
		//@InjectQueue("uploadproperty") private readonly propertyQueue: Queue
	) {}

	@Roles("basic")
	@Get()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "List" })
	@ApiQuery({ type: PropertyQuery, name: "query" })
	async list(@Query() query: PropertyQuery): Promise<Property[] | PropertyPaginationDto> {
		console.log(query);
		return await this._propertyService.list(query);
	}

	@Roles("basic")
	@Post("/search")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "search Property" })
	@ApiBody({ type: PropertyQuery })
	async search(@Body() body: PropertyQuery): Promise<Property[] | PropertyPaginationDto> {
		console.log(body);

		return await this._propertyService.search(body);
	}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "create properties" })
	@ApiBody({ type: Property })
	async create(@Body() properties: Property[]): Promise<Property[]> {
		return await this._propertyService.create(properties);
	}

	@Roles("basic")
	@Post("/upload")
	@ApiHeader({ name: "header" })
	@ApiResponse({ description: "Upload" })
	@UseInterceptors(
		FilesInterceptor("file", 20, {
			storage: diskStorage({
				destination: "./files"
			})
		})
	)
	//async upload(@UploadedFiles() files: File[], @Headers() header: JSON): Promise<void> {
	//	const fileNames = [];
	//	const user = this._jwtService.decode(header["token"]);
	//	console.log(files);
	//	files.forEach(file => {
	//		fileNames.push(file["filename"]);
	//	});
	//	// return await this._propertyService.parseCsv(fileNames);
	//	await this.propertyQueue.add("processCsv", {
	//		filenames: fileNames,
	//		userId: user["id"]
	//	});
	//}

	@Roles("basic")
	@Post("getagainstids")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Get against Ids" })
	@ApiBody({ type: Object })
	async getAgainstIds(@Body() body: JSON): Promise<Property[]> {
		return await this._propertyService.getAgainstIds(body["ids"]);
	}

	@Roles("basic")
	@Post("searchlatlng")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Get against LatLong" })
	@ApiBody({ type: Object })
	async searchLatLong(@Body() body: PropertyLatLng): Promise<Property[]> {
		return await this._propertyService.searchLatLong(body);
	}

	@Roles("basic")
	@Post("propertyreview")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Review Property" })
	@ApiBody({ type: PropertyReviewBody })
	async propertyReview(@Body() body: PropertyReviewBody, @Headers() header: JSON): Promise<void> {
		const user = this._jwtService.decode(header["token"]);
		const userId = user["id"];
		return await this._propertyService.propertyReview(body, userId);
	}

	@Roles("basic")
	@Get("propertyreview")
	@ApiHeader({ name: "Header" })
	@ApiQuery({ type: WorkItemQuery, name: "Query" })
	@ApiResponse({ description: "Get property Review" })
	async getPropertyReview(
		@Headers() header: JSON,
		@Query() query: WorkItemQuery
	): Promise<WorkItem[] | WorkItemPaginationDtoNew> {
		const user = this._jwtService.decode(header["token"]);
		const userId = user["id"];
		return await this._propertyService.getPropertyReview(userId, query);
	}

	@Roles("basic")
	@Post("userforproperty")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Review Property" })
	@ApiBody({ type: PropertyReviewBody })
	async getUserForProperty(@Body() body: PropertyIdBody): Promise<User[]> {
		return await this._propertyService.getUserForProperty(body);
	}

	@Roles("basic")
	@Post("changereviewstatus")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Change Status Review Property" })
	@ApiBody({ type: PropertyReviewBody })
	async changeReviewStatus(@Body() body: PropertyIdBody): Promise<Property> {
		return await this._propertyService.changeReviewStatus(body);
	}

	@Roles("basic")
	@Post("reviewsofproperty")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Review Property" })
	@ApiBody({ type: PropertyReviewBody })
	async propertyReviews(@Body() body: PropertyIdBody): Promise<unknown> {
		return await this._propertyService.propertyReviews(body);
	}

	@Roles("basic")
	@Post("pendingreviews")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Get no of PendingReviews of Property" })
	@ApiBody({ type: PropertyReviewBody })
	async pendingReviews(@Body() body: PropertyIdBody): Promise<number> {
		return await this._propertyService.pendingReviews(body);
	}
	@Roles("basic")
	@Post("deleteProperty")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Get no of PendingReviews of Property" })
	@ApiBody({ type: PropertyReviewBody })
	async deleteProperty(@Body() body: PropertyReviewBody): Promise<void> {
		return await this._propertyService.deleteProperty(body);
	}
	@Roles("basic")
	@Post("getindex")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "get Index" })
	@ApiBody({ type: Indexquery })
	async getIndexes(@Body() query: Indexquery): Promise<unknown> {
		return await this._propertyService.getIndex(query);
	}
}
