import { ApiProperty } from "@nestjs/swagger";
import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class Reminder {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id?: number;

	@ApiProperty()
	@Column({ type: "integer" })
	poiId: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	tokenUserId?: number;

	@ApiProperty()
	@Column({ type: "integer", nullable: true })
	apiKeyUserId?: number;

	@ApiProperty()
	@Column()
	message: string;

	@ApiProperty()
	@Column({ type: "timestamp", nullable: true })
	remindAt?: Date;

	@ApiProperty()
	@Column()
	isDeleted: boolean;

	@ApiProperty()
	@Column()
	isActive: boolean;

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt: Date;

	@ApiProperty()
	@UpdateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)", onUpdate: "CURRENT_TIMESTAMP(6)" })
	updatedAt: Date;
}

@Entity()
export class ReminderUpdate {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id?: number;

	@ApiProperty()
	@Column({})
	reminderId: number;

	@ApiProperty()
	@Column({ type: "varchar", array: true, nullable: true })
	updatedFields?: string[];

	@ApiProperty()
	@Column()
	message: string;

	@ApiProperty()
	@Column()
	isActive: boolean;

	@ApiProperty()
	@Column({ nullable: true })
	status?: string;

	@ApiProperty()
	@Column()
	remindAt: Date;

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt?: Date;

	@ApiProperty()
	@UpdateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)", onUpdate: "CURRENT_TIMESTAMP(6)" })
	updatedAt?: Date;
}
