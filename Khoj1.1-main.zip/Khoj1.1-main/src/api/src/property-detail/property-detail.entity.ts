import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class PropertyDetail {
	@PrimaryGeneratedColumn()
	id: number;

	@Column()
	propertyId: number;

	@Column()
	key: string;

	@Column()
	value: string;
}
