import { HttpException, HttpStatus, Injectable } from "@nestjs/common";
import * as csv from "csv-parser";
import { Repository, In } from "typeorm";
import { InjectRepository } from "@nestjs/typeorm";
import { Poi, PoiStatus } from "./poi.entity";
import { GridService } from "../grid/grid.service";
import { PoiGrid } from "../relations/poi-grid/poi-grid.entity";
import * as fs from "fs";
import * as tf from "@turf/turf";
import * as geohash from "ngeohash";
import { Grid } from "../grid/grids.entity";
import { LatLng, Catchment, PoiQuery, PoiPaginationDto, PoiStatusUpdate, LatLong } from "../interfaces/poi";
import * as excel from "exceljs";
import * as _ from "lodash";
import { POI } from "../interfaces/newPOI";
import { PoiDetail } from "../poi-details/poi-details.entity";
import { Poiexported } from "./poisExported.entity";
import { Indexmaster } from "src/index-master/index-master.entity";
import * as stats from "stats-lite";
import { FilterQuery } from "../interfaces/requests";
import * as dotenv from "dotenv";
dotenv.config();
import { Cron } from "@nestjs/schedule";
import * as elastic from "elasticsearch";
import { Client } from "pg";
import { InjectModel } from "@nestjs/mongoose";
import { DemoShapesDB } from "src/shape/shape.schema";
const pgClient = new Client({
	user: process.env.POSTGRES_USER,
	password: process.env.POSTGRES_PASSWORD,
	database: process.env.POSTGRES_DB,
	host: process.env.POSTGRES_HOST,
});
const client = new elastic.Client({
	host: process.env.ELASTIC_HOST,
});
import * as mongoose from "mongoose";
import { UserMerchant } from "src/merchant/user-merchant.entity";
import { Answer } from "src/answer/answer.entity";
import { ApiKeyUserMerchant } from "src/merchant/api-key-user-merchant.entity";
import { PoiDetailFilter } from "src/interfaces/merchant";
import { POIFilter, POIFilterUserTeam } from "src/poi-filter/poi-filter.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { User } from "src/users/users.entity";

@Injectable()
export class PoiService {
	constructor(
		@InjectModel("DemoShapesDB") private demoShapesDBModel: mongoose.Model<DemoShapesDB>,
		@InjectRepository(Poi) private poiRepository: Repository<Poi>,
		@InjectRepository(PoiGrid) private poiGridRepository: Repository<PoiGrid>,
		@InjectRepository(Grid) private gridRepository: Repository<Grid>,
		@InjectRepository(PoiDetail) private poiDetailRepository: Repository<PoiDetail>,
		@InjectRepository(Poiexported) private poiexportedRepository: Repository<Poiexported>,
		@InjectRepository(Indexmaster) private indexMasterRepository: Repository<Indexmaster>,
		@InjectRepository(UserMerchant) private usermerchantRepository: Repository<UserMerchant>,
		@InjectRepository(ApiKeyUserMerchant)
		private apiKeyUserMerchantRepository: Repository<ApiKeyUserMerchant>,
		@InjectRepository(Answer) private answerRepository: Repository<Answer>,
		@InjectRepository(POIFilter) private poiFilterRepository: Repository<POIFilter>,
		@InjectRepository(POIFilterUserTeam) private poiFilterUserTeamRepository: Repository<POIFilterUserTeam>,
		private _gridService: GridService,
	) {}

	//@Cron("0 0 * * *")
	//async handleCron() {
	//	await this.indexPoi();
	//}

	async create(pois: Poi[]): Promise<void> {
		await this.poiRepository.save(pois);
	}

	async search(latitude: number, longitude: number): Promise<Poi[]> {
		const distance = 0.5;
		const pi = Math.PI;
		const lat_increment = 1 / 110.574;
		const lng_increment = 1 / 111.32;
		const lat_max = Number(latitude) + distance * lat_increment;
		const lat_min = Number(latitude) - distance * lat_increment;
		const lng_max = Number(longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
		const lng_min = Number(longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
		const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
		try {
			const tempGrid = await this.gridRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.select("grid.id")
				.getMany();

			const tempGridIds = tempGrid.map((eachGrid) => {
				return eachGrid.id;
			});
			const poiGridsReltions = await this.poiGridRepository.find({
				where: {
					gridId: In(tempGridIds),
				},
			});
			const poiGridsReltionsIds = poiGridsReltions.map((eachRelation) => {
				return eachRelation.poiId;
			});
			return await this.poiRepository.find({
				where: {
					id: In(poiGridsReltionsIds),
				},
			});
		} catch (error) {
			return [];
		}
	}

	async dumpSociety(): Promise<void> {
		const results = [];
		fs.createReadStream("./src/files/societies.csv")
			.pipe(csv())
			.on("data", async (data) => {
				results.push(data);
			})
			.on("end", async () => {
				for await (const eachSociety of results) {
					const tempPoi = new Poi();
					tempPoi.address = eachSociety.address;
					tempPoi.name = eachSociety.name;
					tempPoi.type = eachSociety.type;
					tempPoi.category = "target";
					tempPoi.latitude = eachSociety.latitude;
					tempPoi.longitude = eachSociety.longitude;
					const savedPoi = await this.poiRepository.save(tempPoi);
					const grid = await this._gridService.nearestGrid(tempPoi.latitude, tempPoi.longitude);
					const tempPoiGrid = new PoiGrid();
					tempPoiGrid.gridId = grid["id"];
					tempPoiGrid.poiId = savedPoi.id;
					await this.poiGridRepository.save(tempPoiGrid);
				}
			});
	}
	async dumpCustomer(): Promise<void> {
		const results = [];
		fs.createReadStream("./src/files/customers.csv")
			.pipe(csv())
			.on("data", async (data) => {
				results.push(data);
			})
			.on("end", async () => {
				for await (const eachSociety of results) {
					try {
						const tempPoi = new Poi();
						tempPoi.address = eachSociety.address;
						tempPoi.name = eachSociety.name;
						tempPoi.type = "customer";
						tempPoi.category = "contact";
						tempPoi.latitude = eachSociety.latitude;
						tempPoi.longitude = eachSociety.longitude;
						const savedPoi = await this.poiRepository.save(tempPoi);
						const grid = await this._gridService.nearestGrid(tempPoi.latitude, tempPoi.longitude);
						const tempPoiGrid = new PoiGrid();
						tempPoiGrid.gridId = grid["id"];
						tempPoiGrid.poiId = savedPoi.id;
						await this.poiGridRepository.save(tempPoiGrid);
					} catch (error) {
						return [];
						console.log(error);
					}
				}
			});
	}
	async searchLatLong(latitude: number, longitude: number, types?: string[]): Promise<Poi[]> {
		//const point = tf.point([latitude, longitude]);
		const distance = 0.5;
		/*
		const topLeft = tf.destination(point, distance, angleA);
		const bottomRight = tf.destination(point, distance, angleB);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		*/
		const pi = Math.PI;
		const lat_increment = 1 / 110.574;
		const lng_increment = 1 / 111.32;
		const lat_max = Number(latitude) + distance * lat_increment;
		const lat_min = Number(latitude) - distance * lat_increment;
		const lng_max = Number(longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
		const lng_min = Number(longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
		const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
		try {
			const tempGrid = await this.gridRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.leftJoinAndSelect("grid.indexmaster", "indexmaster")
				.getMany();

			const tempGridIds = tempGrid.map((eachGrid) => {
				return eachGrid.id;
			});
			const gridIndexDict = {};
			tempGrid.forEach((eachGrid) => {
				const indexesDict = {};
				eachGrid.indexmaster.forEach((eachIndex) => {
					indexesDict[eachIndex.indexName] = eachIndex.indexValue;
				});
				gridIndexDict[eachGrid.id] = indexesDict;
			});
			const poiGridsReltions = await this.poiGridRepository.find({
				where: {
					gridId: In(tempGridIds),
				},
			});
			const poiGridsRelationDict = {};
			const poiGridsReltionsIds = poiGridsReltions.map((eachRelation) => {
				poiGridsRelationDict[eachRelation.poiId] = eachRelation.gridId;
				return eachRelation.poiId;
			});
			if (!types) {
				types = [];
			}
			if (!types.length) {
				const responsePois = await this.poiRepository.find({
					where: {
						id: In(poiGridsReltionsIds),
						status: PoiStatus.approved,
					},
				});
				responsePois.forEach((eachPoi) => {
					eachPoi["index"] = gridIndexDict[poiGridsRelationDict[eachPoi.id]];
				});
				return responsePois;
			} else {
				const responsePois = await this.poiRepository.find({
					where: {
						id: In(poiGridsReltionsIds),
						status: PoiStatus.approved,
						type: In(types),
					},
				});
				responsePois.forEach((eachPoi) => {
					eachPoi["index"] = gridIndexDict[poiGridsRelationDict[eachPoi.id]];
				});
				return responsePois;
			}
		} catch (error) {
			console.log("error is", error);
			return [];
		}
	}
	async searchLatLongDistanceCategory(query: LatLng): Promise<unknown> {
		const masterDict = {};
		let prevPoiCount = 0;
		for (let distance = 0.05; distance < 0.5; distance += 0.05) {
			/*
			const point = tf.point([query.latitude, query.longitude]);
			const topLeft = tf.destination(point, distance, angleA);
			const bottomRight = tf.destination(point, distance, angleB);
			const withinGrids = geohash.bboxes(
				topLeft["geometry"]["coordinates"][0],
				topLeft["geometry"]["coordinates"][1],
				bottomRight["geometry"]["coordinates"][0],
				bottomRight["geometry"]["coordinates"][1],
				7
			);
			*/
			const pi = Math.PI;
			const lat_increment = 1 / 110.574;
			const lng_increment = 1 / 111.32;
			const lat_max = Number(query.latitude) + distance * lat_increment;
			const lat_min = Number(query.latitude) - distance * lat_increment;
			const lng_max = Number(query.longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
			const lng_min = Number(query.longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
			const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
			const tempDist = Math.round(distance * 2 * 10) / 10;
			try {
				const tempGrid = await this.gridRepository
					.createQueryBuilder("grid")
					.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
					.select("grid.id")
					.getMany();

				const tempGridIds = tempGrid.map((eachGrid) => {
					return eachGrid.id;
				});
				const poiGridsReltions = await this.poiGridRepository.find({
					where: {
						gridId: In(tempGridIds),
					},
				});
				const poiGridsReltionsIds = poiGridsReltions.map((eachRelation) => {
					return eachRelation.poiId;
				});
				const poi = await this.poiRepository.find({
					where: {
						id: In(poiGridsReltionsIds),
						type: query.category,
						status: PoiStatus.approved,
					},
				});
				masterDict[Math.round((tempDist - 0.1) * 10) / 10 + " - " + tempDist] = poi.length - prevPoiCount;
				prevPoiCount = poi.length;
			} catch (error) {
				masterDict[Math.round((tempDist - 0.1) * 10) / 10 - 0.1 + " - " + tempDist] = 0;
			}
		}
		return masterDict;
	}
	async exportLatLong(latitude: number, longitude: number, userId: number, radius?: number): Promise<string> {
		const point = tf.point([latitude, longitude]);
		let distance = 0.5;
		if (radius) {
			console.log("Radius found in query :", radius);
			distance = radius;
		}
		/*
		const topLeft = tf.destination(point, distance, angleA);
		const bottomRight = tf.destination(point, distance, angleB);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		*/
		const pi = Math.PI;
		const lat_increment = 1 / 110.574;
		const lng_increment = 1 / 111.32;
		const lat_max = Number(latitude) + distance * lat_increment;
		const lat_min = Number(latitude) - distance * lat_increment;
		const lng_max = Number(longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
		const lng_min = Number(longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
		const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
		try {
			const tempGrid = await this.gridRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.leftJoinAndSelect("grid.indexmaster", "indexmaster")
				.getMany();
			const gridsDict = {};
			const tempGridIds = tempGrid.map((eachGrid) => {
				const tempIndexes = {};
				eachGrid.indexmaster.forEach((eachIndex) => {
					tempIndexes[eachIndex.indexName] = eachIndex.indexValue;
				});
				delete eachGrid.indexmaster;
				eachGrid["indexes"] = tempIndexes;
				gridsDict[eachGrid.id] = eachGrid;
				return eachGrid.id;
			});
			const poiGridRltnDict = {};
			const poiGridsReltions = await this.poiGridRepository.find({
				where: {
					gridId: In(tempGridIds),
				},
			});
			const poiGridsReltionsIds = poiGridsReltions.map((eachRelation) => {
				poiGridRltnDict[eachRelation.poiId] = gridsDict[eachRelation.gridId];
				return eachRelation.poiId;
			});
			const societyPois = await this.poiRepository.find({
				where: {
					id: In(poiGridsReltionsIds),
					type: "society",
				},
			});
			const societyObjects = await Promise.all(
				societyPois.map(async (eachSociety, index) => {
					const tempObject = {};
					let gridObj, societyDetails;
					const societyDetailsObj = {};
					try {
						gridObj = poiGridRltnDict[eachSociety.id];
						societyDetails = await this.poiDetailRepository.find({ where: { poiId: eachSociety.id } });
						if (societyDetails) {
							societyDetails.forEach((eachDetail) => {
								societyDetailsObj[eachDetail.key] = eachDetail.value;
							});
						}
					} catch (error) {
						return [];
						console.log(error);
					}
					tempObject["index"] = index + 1;
					tempObject["name"] = eachSociety.name;
					tempObject["City"] = gridObj.City;
					tempObject["address"] = eachSociety.address;
					tempObject["pincode"] = poiGridRltnDict[eachSociety.id]["Pincode"];
					tempObject["locality"] = gridObj.Locality;
					tempObject["distance_from_nearby_store"] = societyDetailsObj["distance_from_nearby_store"];
					tempObject["nearby_store"] = societyDetailsObj["nearby_store"];
					tempObject["latitude"] = eachSociety.latitude;
					tempObject["longitude"] = eachSociety.longitude;
					const incomeCat = gridObj["indexes"]["income"] as number;
					if (1 <= incomeCat && incomeCat <= 2) {
						tempObject["income"] = "LIG";
					} else if (4 <= incomeCat && incomeCat <= 5) {
						tempObject["income"] = "HIG";
					} else {
						tempObject["income"];
					}
					return tempObject;
				}),
			);
			const doctorsPois = await this.poiRepository.find({
				where: {
					id: In(poiGridsReltionsIds),
					type: "doctor",
				},
			});
			const doctorObjects = await Promise.all(
				doctorsPois.map(async (eachDoctor, index) => {
					const tempObject = {};
					let gridObj, doctorDetails;
					const doctorDetailsObj = {};
					try {
						gridObj = poiGridRltnDict[eachDoctor.id];
						doctorDetails = await this.poiDetailRepository.find({ where: { poiId: eachDoctor.id } });
						if (doctorDetails) {
							doctorDetails.forEach((eachDetail) => {
								doctorDetailsObj[eachDetail.key] = eachDetail.value;
							});
						}
					} catch (error) {
						return [];
						console.log(error);
					}
					tempObject["index"] = index + 1;
					tempObject["name"] = eachDoctor.name;
					tempObject["City"] = gridObj.City;
					tempObject["pincode"] = poiGridRltnDict[eachDoctor.id]["Pincode"];
					tempObject["locality"] = gridObj.Locality;
					tempObject["latitude"] = eachDoctor.latitude;
					tempObject["longitude"] = eachDoctor.longitude;
					tempObject["speciality"] = eachDoctor.subType;
					tempObject["address"] = eachDoctor.address;
					tempObject["distance_from_nearby_store"] = doctorDetailsObj["distance_from_nearby_store"];
					tempObject["nearby_store"] = doctorDetailsObj["nearby_store"];
					return tempObject;
				}),
			);
			const hospitalPois = await this.poiRepository.find({
				where: {
					id: In(poiGridsReltionsIds),
					type: "hospital_and_clinics",
				},
			});
			hospitalPois.forEach((eachHospital, index) => {
				eachHospital["index"] = index + 1;
			});
			const pharmacyPois = await this.poiRepository.find({
				where: {
					id: In(poiGridsReltionsIds),
					type: "pharmacy",
				},
			});
			const pharmacyObjects = await Promise.all(
				pharmacyPois.map(async (eachPharmacy, index) => {
					const tempObject = {};
					let gridObj, pharmacyDetails;
					const pharmacyDetailsObj = {};
					try {
						gridObj = poiGridRltnDict[eachPharmacy.id];
						pharmacyDetails = await this.poiDetailRepository.find({ where: { poiId: eachPharmacy.id } });
						if (pharmacyDetails) {
							pharmacyDetails.forEach((eachDetail) => {
								pharmacyDetailsObj[eachDetail.key] = eachDetail.value;
							});
						}
					} catch (error) {
						return [];
						console.log(error);
					}
					tempObject["index"] = index + 1;
					tempObject["name"] = eachPharmacy.name;
					tempObject["City"] = gridObj.City;
					tempObject["pincode"] = poiGridRltnDict[eachPharmacy.id]["Pincode"];
					tempObject["locality"] = gridObj.Locality;
					tempObject["latitude"] = eachPharmacy.latitude;
					tempObject["longitude"] = eachPharmacy.longitude;
					tempObject["address"] = eachPharmacy.address;
					tempObject["distance_from_nearby_store"] = pharmacyDetailsObj["distance_from_nearby_store"];
					tempObject["nearby_store"] = pharmacyDetailsObj["nearby_store"];
					return tempObject;
				}),
			);
			const workbook = new excel.Workbook();
			const societyWorksheet = workbook.addWorksheet("Societies");
			const doctorWorksheet = workbook.addWorksheet("Doctors");
			const hospitalsWorksheet = workbook.addWorksheet("Hospitals And Clinics");
			const pharmacyWorksheet = workbook.addWorksheet("Chemist");
			societyWorksheet.columns = [
				{ header: "Sr. No.", key: "index" },
				{ header: "Society Name(address 1)", key: "name" },
				{ header: "Address", key: "address" },
				{ header: "Wing (Address 1)", key: "wing" },
				{ header: "Name of sub Area (Road Name)(Address-2)", key: "locality" },
				{ header: "Landmark (Address-3)", key: "landmark" },
				{ header: "City", key: "City" },
				{ header: "Pin Code", key: "pincode" },
				{ header: "Area Name", key: "locality" },
				{ header: "Number of Households (Residentail Count-Total)", key: "houseHolds" },
				{ header: "Latitude", key: "latitude" },
				{ header: "Longitude", key: "longitude" },
				{ header: "People Count", key: "societyPopulation" },
				{ header: "Type of Residence (Flat, Banglow,row, house, Chael)", key: "residenceType" },
				{ header: "Community of People", key: "community" },
				{ header: "Nearest Store", key: "nearby_store" },
				{ header: "Distnace From Nearest Store", key: "distance_from_nearby_store" },
				{ header: "Income Group", key: "income" },
				{ header: "Occupancy in %", key: "occupancy" },
				{ header: "Vehicle Analysis ( 2 wheeler / 4 wheeler )", key: "vehicleAnalysis" },
				{ header: "Age Group (Youth 15-24 / Adult 25-64 / Senior 65 & above)", key: "ageGroup" },
			];
			societyWorksheet.columns.forEach((column) => {
				if (column.header === "Address") {
					column.width = 40;
				} else {
					column.width = column.header.length < 12 ? 12 : column.header.length;
				}
			});
			societyWorksheet.getRow(1).font = { bold: true, size: 12 };
			societyWorksheet.getRow(1).alignment = { horizontal: "justify", vertical: "justify" };
			societyWorksheet.getRow(1).height = 40;
			societyObjects.forEach((eachPoi, index) => {
				const rowIndex = index + 2;
				societyWorksheet.addRow({
					...eachPoi,
					amountRemaining: {
						formula: `=C${rowIndex}-D${rowIndex}`,
					},
					percentRemaining: {
						formula: `=E${rowIndex}/C${rowIndex}`,
					},
				});
			});
			const societySheetColumns = [
				"A",
				"B",
				"C",
				"D",
				"E",
				"F",
				"G",
				"H",
				"I",
				"J",
				"K",
				"L",
				"M",
				"N",
				"O",
				"P",
				"Q",
				"R",
				"S",
				"T",
				"U",
			];
			societyWorksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
				societySheetColumns.forEach((eachSheetCol) => {
					societyWorksheet.getCell(`${eachSheetCol}${rowNumber}`).border = {
						top: { style: "thin" },
						left: { style: "thin" },
						bottom: { style: "thin" },
						right: { style: "thin" },
					};
					societyWorksheet.getCell(`${eachSheetCol}${rowNumber}`).alignment = {
						horizontal: "center",
						vertical: "justify",
					};
					societyWorksheet.getCell(`${eachSheetCol}1`).fill = {
						type: "pattern",
						pattern: "darkVertical",
						fgColor: { argb: "FFdcbeff" },
					};
				});
			});
			doctorWorksheet.columns = [
				{ header: "Sr. No.", key: "index" },
				{ header: "Hospital/Clinic Name", key: "hospitalName" },
				{ header: "Type of Hospital/Clinic" },
				{ header: "Doctor Name", key: "name" },
				{ header: "Nearest Store", key: "nearby_store" },
				{ header: "Distance From Store", key: "distance_from_nearby_store" },
				{ header: "Qualification(Degree)", key: "qualification" },
				{ header: "Category(A/B/C)", key: "category" },
				{ header: "Speciality", key: "speciality" },
				{ header: "Contact No", key: "contact" },
				{ header: "Address", key: "address" },
				{ header: "Name of Sub Area(Bulding, Road Name)(Address-2)", key: "subArea" },
				{ header: "Landmark", key: "landmark" },
				{ header: "City", key: "City" },
				{ header: "Pin Code", key: "pincode" },
				{ header: "Website/Email", key: "mail" },
				{ header: "Area Name", key: "locality" },
				{ header: "Latitude", key: "latitude" },
				{ header: "Longitude", key: "longitude" },
				{ header: "Registration Number", key: "registrationNumber" },
				{ header: "Timings", key: "timings" },
			];
			doctorObjects.forEach((eachPoi, index) => {
				const rowIndex = index + 2;
				doctorWorksheet.addRow({
					...eachPoi,
					amountRemaining: {
						formula: `=C${rowIndex}-D${rowIndex}`,
					},
					percentRemaining: {
						formula: `=E${rowIndex}/C${rowIndex}`,
					},
				});
			});

			doctorWorksheet.columns.forEach((column) => {
				if (column.header === "Address") {
					column.width = 40;
				} else if (column.header === "Doctor Name") {
					column.width = 30;
				} else {
					column.width = column.header.length < 12 ? 12 : column.header.length;
				}
			});
			doctorWorksheet.getRow(1).font = { bold: true, size: 12 };
			doctorWorksheet.getRow(1).alignment = { horizontal: "justify", vertical: "justify" };
			doctorWorksheet.getRow(1).height = 40;
			const doctorSheetColumns = [
				"A",
				"B",
				"C",
				"D",
				"E",
				"F",
				"G",
				"H",
				"I",
				"J",
				"K",
				"L",
				"M",
				"N",
				"O",
				"P",
				"Q",
				"R",
				"S",
				"T",
				"U",
			];
			doctorWorksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
				doctorSheetColumns.forEach((eachSheetCol) => {
					doctorWorksheet.getCell(`${eachSheetCol}${rowNumber}`).border = {
						top: { style: "thin" },
						left: { style: "thin" },
						bottom: { style: "thin" },
						right: { style: "thin" },
					};
					doctorWorksheet.getCell(`${eachSheetCol}${rowNumber}`).alignment = {
						horizontal: "center",
						vertical: "justify",
					};
					doctorWorksheet.getCell(`${eachSheetCol}1`).fill = {
						type: "pattern",
						pattern: "darkVertical",
						fgColor: { argb: "FFff006e" },
					};
				});
			});

			hospitalsWorksheet.columns = [
				{ header: "Sr No.", key: "index" },
				{ header: "Hospital Name", key: "name" },
				{ header: "Votes", key: "votes" },
				{ header: "Address", key: "address" },
				{ header: "Latitude", key: "latitude" },
				{ header: "Longitude", key: "longitude" },
			];
			hospitalPois.forEach((eachPoi, index) => {
				const rowIndex = index + 2;
				hospitalsWorksheet.addRow({
					...eachPoi,
					amountRemaining: {
						formula: `=C${rowIndex}-D${rowIndex}`,
					},
					percentRemaining: {
						formula: `=E${rowIndex}/C${rowIndex}`,
					},
				});
			});

			hospitalsWorksheet.columns.forEach((column) => {
				if (column.header === "Address") {
					column.width = 40;
				} else {
					column.width = column.header.length < 12 ? 12 : column.header.length;
				}
			});
			hospitalsWorksheet.getRow(1).font = { bold: true, size: 12 };
			hospitalsWorksheet.getRow(1).alignment = { horizontal: "justify", vertical: "justify" };
			hospitalsWorksheet.getRow(1).height = 40;
			const hospitalsSheetColumns = ["A", "B", "C", "D", "E", "F"];
			hospitalsWorksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
				hospitalsSheetColumns.forEach((eachSheetCol) => {
					hospitalsWorksheet.getCell(`${eachSheetCol}${rowNumber}`).border = {
						top: { style: "thin" },
						left: { style: "thin" },
						bottom: { style: "thin" },
						right: { style: "thin" },
					};
					hospitalsWorksheet.getCell(`${eachSheetCol}${rowNumber}`).alignment = {
						horizontal: "center",
						vertical: "justify",
					};
					hospitalsWorksheet.getCell(`${eachSheetCol}1`).fill = {
						type: "pattern",
						pattern: "darkVertical",
						fgColor: { argb: "FF3cb44b" },
					};
				});
			});
			pharmacyWorksheet.columns = [
				{ header: "Sr No.", key: "index" },
				{ header: "Chemist Stores", key: "name" },
				{ header: "latitude", key: "latitude" },
				{ header: "longitude", key: "longitude" },
				{ header: "Monthly Sale (Lac)", key: "sale" },
				{ header: "Market Share", key: "Market Share" },
				{ header: "Sq. ft Area", key: "area" },
				{ header: "Category (Medical & General)", key: "pharmacyCategory" },
				{ header: "Number of years in business", key: "businessYears" },
				{ header: "Rent In Area", key: "rent" },
				{ header: "Nearby Store", key: "nearby_store" },
				{ header: "Distance from Wellness Store", key: "distance_from_nearby_store" },
				{ header: "GST No.", key: "gstNo" },
				{ header: "DL No.", key: "dlNo" },
				{ header: "Address", key: "address" },
				{ header: "Contact No", key: "contactNo" },
				{ header: "Opening Time", key: "openingTime" },
				{ header: "Closing Time", key: "closingTime" },
				{ header: "Discount %", key: "discount" },
				{ header: "Availability", key: "availability" },
				{ header: "Customer Service", key: "customerService" },
				{ header: "Ambience", key: "ambience" },
				{ header: "H. D Analysis", key: "HDAnalysis" },
				{ header: "Technology Analysis", key: "technologyAnalysis" },
				{ header: "Man Power", key: "manPower" },
				{ header: "Credit Sale", key: "creditSale" },
			];
			pharmacyObjects.forEach((eachPoi, index) => {
				const rowIndex = index + 2;
				pharmacyWorksheet.addRow({
					...eachPoi,
					amountRemaining: {
						formula: `=C${rowIndex}-D${rowIndex}`,
					},
					percentRemaining: {
						formula: `=E${rowIndex}/C${rowIndex}`,
					},
				});
			});
			pharmacyWorksheet.columns.forEach((column) => {
				if (column.header === "Address") {
					column.width = 40;
				} else if (column.header === "Chemist Stores") {
					column.width = 30;
				} else {
					column.width = column.header.length < 12 ? 12 : column.header.length;
				}
			});
			pharmacyWorksheet.getRow(1).font = { bold: true, size: 12 };
			pharmacyWorksheet.getRow(1).alignment = { horizontal: "justify", vertical: "justify" };
			pharmacyWorksheet.getRow(1).height = 40;
			const pharmacySheetColumns = [
				"A",
				"B",
				"C",
				"D",
				"E",
				"F",
				"G",
				"H",
				"I",
				"J",
				"K",
				"L",
				"M",
				"N",
				"O",
				"P",
				"Q",
				"R",
				"S",
				"T",
				"U",
				"V",
				"W",
				"X",
				"Y",
				"Z",
			];
			pharmacyWorksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
				pharmacySheetColumns.forEach((eachSheetCol) => {
					pharmacyWorksheet.getCell(`${eachSheetCol}${rowNumber}`).border = {
						top: { style: "thin" },
						left: { style: "thin" },
						bottom: { style: "thin" },
						right: { style: "thin" },
					};
					pharmacyWorksheet.getCell(`${eachSheetCol}${rowNumber}`).alignment = {
						horizontal: "center",
						vertical: "justify",
					};
					pharmacyWorksheet.getCell(`${eachSheetCol}1`).fill = {
						type: "pattern",
						pattern: "darkVertical",
						fgColor: { argb: "FFfa3cf0" },
					};
				});
			});
			const expDate = new Date();
			try {
				await workbook.xlsx.writeFile("./public/pois" + expDate + ".xlsx");
				const tempPoiExported = new Poiexported();
				tempPoiExported.latitude = latitude;
				tempPoiExported.longitude = longitude;
				tempPoiExported.userId = userId;
				tempPoiExported.filePath = "./public/pois" + expDate + ".xlsx";
				try {
					await this.poiexportedRepository.save(tempPoiExported);
				} catch (error) {}
				return String(process.env.FRONTEND_LOGIN_URL) + "/api/public/pois" + expDate + ".xlsx";
			} catch (error) {
				return "";
				console.log(error);
			}
		} catch (error) {
			console.log(error);
			return "";
		}
	}
	async catchment(latitude: number, longitude: number): Promise<Catchment> {
		const point = tf.point([latitude, longitude]);
		const distance = 0.65;
		const bottomLeft = tf.destination(point, distance, -160);
		const topRight = tf.destination(point, 0.7, 25);
		const topLeft = tf.destination(point, 0.7, 155);
		const bottomRight = tf.destination(point, distance, -20);
		const bboxDict = {};
		bboxDict["topLeft"] = {};
		bboxDict["bottomRight"] = {};
		bboxDict["topRight"] = {};
		bboxDict["bottomLeft"] = {};
		bboxDict["topLeft"]["coordinates"] = topLeft["geometry"]["coordinates"];
		bboxDict["bottomRight"]["coordinates"] = bottomRight["geometry"]["coordinates"];
		bboxDict["bottomLeft"]["coordinates"] = bottomLeft["geometry"]["coordinates"];
		bboxDict["topRight"]["coordinates"] = topRight["geometry"]["coordinates"];

		return bboxDict as Catchment;
	}

	async getAggrigation(responseIds: number[], query) {
		if (responseIds.length == 0) {
			return { count: 0 };
		}
		let Pois = [];
		if (responseIds.length > 30000) {
			const responseIdsArr = _.chunk(responseIds, 30000);
			await Promise.all(
				responseIdsArr.map(async (eachArr) => {
					const pois = await this.poiRepository
						.createQueryBuilder("poi")
						.select("id")
						.where("type IN(:...types) AND id IN(:...poiIds)", { types: query["types"], poiIds: eachArr })
						.distinct(true)
						.getRawMany();
					Pois.push(pois);
				}),
			);
			Pois = _.flattenDeep(Pois);
		} else {
			Pois = await this.poiRepository
				.createQueryBuilder("poi")
				.select("id")
				.where("type IN(:...types) AND id IN(:...poiIds)", { types: query["types"], poiIds: responseIds })
				.distinct(true)
				.getRawMany();
		}
		const ids = await Promise.all(
			Pois.map((obj) => {
				return obj["id"];
			}),
		);
		responseIds = ids;
		if (query["responseType"] == "count") {
			console.log("Here in Count Section in the Agg function");
			responseIds = [...new Set(responseIds)];
			const count = responseIds.length;
			const response = { count: {} };
			response["count"]["total"] = count;
			await Promise.all(
				query["types"].map(async (eachType) => {
					const typeCount = await this.poiRepository
						.createQueryBuilder("poi")
						.select("COUNT(id)", "count")
						.where("id IN(:...poiIds) AND type = :type", { poiIds: responseIds, type: eachType })
						.distinct(true)
						.getRawOne();
					//console.log("Type Count :",typeCount);
					response["count"][eachType] = Number(typeCount["count"]);
				}),
			);
			/*
			const count = await this.gridsRepository.count({
				where: { id: In(responseIds) }
			});*/
			if (query["requiredShapes"] == true) {
				response["shapes"] = [];
				const Level = Object.keys(query["location"])[0].toLowerCase();
				const LevelName = String(query["location"][Object.keys(query["location"])[0]]).toLowerCase();
				console.log("Level :" + Level + " LevelName :" + LevelName);
				/*
				const Query = 'shape."'+Level+'" = '+"'"+LevelName+"'";
				console.log(Query);
				let finalObjects: any[] = await this.shapesRepository.createQueryBuilder("shape")
					.where(Query)
					.distinct(true)
					.getMany();
				console.log("ObjectIds :",finalObjects);
				finalObjects = [{objectId: '"60544962c8fed19c2a72381d"'} , {objectId: '"60544962c8fed19c2a72381c"'}];
				let finalObjectIdsFromPostgres:mongoose.ObjectId[] = [];
				await Promise.all(finalObjects.map(eachObject => {
					let newObjectIdString = String(eachObject.objectId.slice(1,-1));
					newObjectIdString =String('"'+newObjectIdString+'"');
					console.log(newObjectIdString)
					//finalObjectIdsFromPostgres.push(new ObjectId(newObjectIdString));
					finalObjectIdsFromPostgres.push(new mongoose.Types.ObjectId(newObjectIdString));
				}));
				console.log("bdjkbc :",finalObjectIdsFromPostgres);*/
				const shapesFromMongoReturned = await this.demoShapesDBModel.find({
					where: {
						level: Level,
						name: String(LevelName),
					},
				});
				console.log("random query test", await this.demoShapesDBModel.findOne());
				console.log("Shapes :", shapesFromMongoReturned);
				response["shapes"] = shapesFromMongoReturned;
			}
			return response;
		} else if (query["responseType"] == "aggregation") {
			responseIds = [...new Set(responseIds)];
			const count = responseIds.length;
			const finalResponse = { count: {} };
			finalResponse["count"]["total"] = count;
			await Promise.all(
				query["types"].map(async (eachType) => {
					const typeCount = await this.poiRepository
						.createQueryBuilder("poi")
						.select("COUNT(id)", "count")
						.where("id IN(:...poiIds) AND type = :type", { poiIds: responseIds, type: eachType })
						.distinct(true)
						.getRawOne();
					//console.log("Type Count :",typeCount);
					finalResponse["count"][eachType] = Number(typeCount["count"]);
				}),
			);
			responseIds = [...new Set(responseIds)];
			console.log("Length of ResponseIds :", count);
			finalResponse["data"] = [];
			if (query["locationIndex"]) {
				let poiGrids = [];
				if (responseIds.length > 60000) {
					const poiIdsArray = _.chunk(responseIds, 60000);
					await Promise.all(
						poiIdsArray.map(async (eacharray) => {
							poiGrids = await this.poiGridRepository.find({ where: { poiId: In(eacharray) } });
						}),
					);
					poiGrids = _.flattenDeep(poiGrids);
				} else {
					poiGrids = await this.poiGridRepository.find({ where: { poiId: In(responseIds) } });
				}
				const gridIds = await Promise.all(
					poiGrids.map((eachpoiGrid) => {
						return eachpoiGrid.gridId;
					}),
				);
				await Promise.all(
					Object.keys(query["locationIndex"]).map(async (eachKey) => {
						const indexMaster = await this.indexMasterRepository
							.createQueryBuilder("indexmaster")
							.select('"indexValue"')
							.where('"indexName" = :indexName AND "gridId" IN(:...gridIds)', {
								indexName: eachKey,
								gridIds: gridIds,
							})
							.getRawMany();
						const indexValues = await Promise.all(
							indexMaster.map((eachIndexMaster) => {
								return Number(eachIndexMaster["indexValue"]);
							}),
						);
						if (query["locationIndex"][eachKey] == "mean") {
							const mean = stats.mean(indexValues);
							const resObj = {
								key: eachKey,
								value: mean,
								aggregationType: "mean",
								indexType: "locationIndex",
							};
							finalResponse["data"].push(resObj);
						}
						if (query["locationIndex"][eachKey] == "median") {
							const median = stats.median(indexValues);
							const resObj = {
								key: eachKey,
								value: median,
								aggregationType: "median",
								indexType: "locationIndex",
							};
							finalResponse["data"].push(resObj);
						}
						if (query["locationIndex"][eachKey] == "mode") {
							let mode;
							mode = stats.mode(indexValues);
							if (typeof mode != "number") {
								mode = Array.from(mode);
							}
							console.log(mode);
							const resObj = {
								key: eachKey,
								value: mode,
								aggregationType: "mode",
								indexType: "locationIndex",
							};
							finalResponse["data"].push(resObj);
						}
						if (query["locationIndex"][eachKey] == "sum") {
							const sum = stats.sum(indexValues);
							const resObj = {
								key: eachKey,
								value: sum,
								aggregationType: "sum",
								indexType: "locationIndex",
							};
							finalResponse["data"].push(resObj);
						}
					}),
				);
			}
			if (query["businessIndex"]) {
				await Promise.all(
					Object.keys(query["businessIndex"]).map(async (eachKey) => {
						let indexMaster = [];
						if (responseIds.length > 60000) {
							const poiIdsArray = _.chunk(responseIds, 60000);
							await Promise.all(
								poiIdsArray.map(async (eachPoiIdsArray) => {
									const indexMasters = await this.poiDetailRepository
										.createQueryBuilder("poi_detail")
										.select("unit")
										.where('key = :key AND "poiId" IN(:...poiIds)', {
											key: eachKey,
											poiIds: eachPoiIdsArray,
										})
										.getRawMany();
									indexMaster.push(indexMasters);
								}),
							);
							indexMaster = _.flattenDeep(indexMaster);
						} else {
							indexMaster = await this.poiDetailRepository
								.createQueryBuilder("poi_detail")
								.select("unit")
								.where('key = :key AND "poiId" IN(:...poiIds)', { key: eachKey, poiIds: responseIds })
								.getRawMany();
						}
						console.log("Length of BusinessIndex :" + eachKey + "is" + indexMaster.length);
						const indexValues = await Promise.all(
							indexMaster.map((eachIndexMaster) => {
								return Number(eachIndexMaster["unit"]);
							}),
						);
						if (query["businessIndex"][eachKey] == "mean") {
							const mean = stats.mean(indexValues);
							const resObj = {
								key: eachKey,
								value: mean,
								aggregationType: "mean",
								indexType: "businessIndex",
							};
							finalResponse["data"].push(resObj);
						}
						if (query["businessIndex"][eachKey] == "median") {
							const median = stats.median(indexValues);
							const resObj = {
								key: eachKey,
								value: median,
								aggregationType: "median",
								indexType: "businessIndex",
							};
							finalResponse["data"].push(resObj);
						}
						if (query["businessIndex"][eachKey] == "mode") {
							let mode;
							mode = stats.mode(indexValues);
							if (typeof mode != "number") {
								mode = Array.from(mode);
							}
							console.log(mode);
							const resObj = {
								key: eachKey,
								value: mode,
								aggregationType: "mode",
								indexType: "businessIndex",
							};
							finalResponse["data"].push(resObj);
						}
						if (query["businessIndex"][eachKey] == "sum") {
							const sum = stats.sum(indexValues);
							const resObj = {
								key: eachKey,
								value: sum,
								aggregationType: "sum",
								indexType: "businessIndex",
							};
							finalResponse["data"].push(resObj);
						}
					}),
				);
			}
			return finalResponse;
		}
	}

	gridFiltersCheck(grid: Grid, rangeKeys, selectKeys): boolean {
		for (const k of Object.keys(rangeKeys)) {
			const kval = grid.indexmaster?.filter((i) => i.indexName === k)?.[0]?.indexValue;
			if (kval < rangeKeys[k]["min"] || kval > rangeKeys[k]["max"]) return false;
		}
		for (const k of Object.keys(selectKeys)) {
			const kval = grid.indexmaster?.filter((i) => i.indexName === k)?.[0]?.categoricalValue;
			if (kval?.length) {
				if (!selectKeys[k].includes(kval)) return false;
			} else return false;
		}
		return true;
	}

	poiInterDetailsCheck(poi, rangeKeys, selectKeys, booleanKeys): boolean {
		if (poi && Object.keys(poi)?.length) {
			for (const k of selectKeys) {
				const kval = poi?.[k?.key];
				if (!k.values.includes(kval)) return false;
			}
			for (const k of rangeKeys) {
				const kval = poi?.[k?.key];
				if (kval < k?.values?.min || kval > k?.vales?.max) return false;
			}
			for (const k of booleanKeys) {
				const kval = poi?.[k?.key];
				if (kval !== k.values) return false;
			}
			return true;
		} else return false;
	}

	async optimized_filter(query: FilterQuery): Promise<Poi[] | PoiPaginationDto | any> {
		// Selecting all Grid IDs
		let radialGridsIds;
		let locationGridsIds;
		if (query["within"] || (query["location"] && query["without"])) {
			let latLongs: LatLong[] = [];
			latLongs = query?.["within"]?.["points"] ?? query?.["without"]?.["points"];
			let distance;
			if (query?.["within"]?.["radius"] || query?.["within"]?.["radius"]) {
				distance = query["within"]["radius"] ?? query["within"]["radius"];
			} else distance = 0.5;
			const pi = Math.PI;
			const lat_increment = 1 / 110.574;
			const lng_increment = 1 / 111.32;
			const gridBBoxes = latLongs.map((latLng) => {
				const lat_max = latLng.lat + distance * lat_increment;
				const lat_min = latLng.lat - distance * lat_increment;
				const lng_max = latLng.lng + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
				const lng_min = latLng.lng - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
				return geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
			});
			const radialGridsArr = await Promise.all(
				gridBBoxes.map(async (bbox) => {
					try {
						const tempGrids = await this.gridRepository
							.createQueryBuilder("grid")
							.where("grid.hash IN (:...hashes)", { hashes: bbox })
							.select("grid.id")
							.getMany();
						return tempGrids.map((g) => g.id);
					} catch (error) {
						return [];
					}
				}),
			);
			radialGridsIds = _.flatten(radialGridsArr);
			console.log("Radial Grids = ", radialGridsIds?.length);
		}
		if (!query["within"] && query["location"]) {
			const locationQueryObject = {};
			let locationQueryString = "";
			Object.keys(query["location"]).forEach((location, index) => {
				if (index === 0) {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += "grid." + location + " = :" + location;
				} else {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += " AND grid." + location + " = :" + location;
				}
			});
			if (Object.keys(locationQueryObject).length) {
				try {
					const locationGrids = await this.gridRepository
						.createQueryBuilder("grid")
						.select("grid.id")
						.where(locationQueryString, locationQueryObject)
						.getMany();
					locationGridsIds = locationGrids.map((g) => g.id);
					console.log("Grids in Location Search :", locationGridsIds.length);
				} catch (error) {
					console.log(error);
				}
			}
		}
		let radiallyFilteredGridIds;
		if (query["within"]) {
			radiallyFilteredGridIds = radialGridsIds;
		} else if (query["location"] && query["without"]) {
			radiallyFilteredGridIds = _.difference(locationGridsIds, radialGridsIds);
		} else if (query["location"] && !query["without"]) {
			radiallyFilteredGridIds = locationGridsIds;
		} else radiallyFilteredGridIds = [];
		console.log("Radially Filtered Grids = ", radiallyFilteredGridIds?.length);

		const response = {
			count: 0,
			data: [],
			typeCount: {},
		};
		if (radiallyFilteredGridIds?.length) {
			// Creating Grid Indices Dictionary
			const gridsChunkLength = 60000;
			const gridIndexDict = {};
			try {
				const gridIndexMasterArrs = await Promise.all(
					_.chunk(radiallyFilteredGridIds, gridsChunkLength).map(async (arr) => {
						return await this.gridRepository
							.createQueryBuilder("grid")
							.leftJoinAndSelect("grid.indexmaster", "indexmaster")
							.where("grid.id In (:...gridIds)", { gridIds: arr })
							.getMany();
					}),
				);
				const rangeKeys = query?.["grids"]?.["range"] ?? {};
				const selectKeys = query?.["grids"]?.["select"] ?? {};
				console.log(rangeKeys, selectKeys);
				if (Object.keys(rangeKeys).length || Object.keys(selectKeys).length) {
					_.flatten(gridIndexMasterArrs).forEach((g: Grid) => {
						if (this.gridFiltersCheck(g, rangeKeys, selectKeys)) {
							const indices = {};
							g.indexmaster.forEach(
								(i) =>
									(indices[i.indexName] =
										i.indexType === "string" ? i.categoricalValue : i.indexValue),
							);
							gridIndexDict[g.id] = {
								index: indices,
							};
						}
					});
				} else {
					_.flatten(gridIndexMasterArrs).forEach((g: Grid) => {
						const indices = {};
						g.indexmaster.forEach(
							(i) =>
								(indices[i.indexName] = i.indexType === "string" ? i.categoricalValue : i.indexValue),
						);
						gridIndexDict[g.id] = {
							index: indices,
						};
					});
				}
			} catch (error) {
				console.log(error);
			}
			const indexFilteredGridIds = Object.keys(gridIndexDict);
			console.log("The Index Filtered Grids", indexFilteredGridIds.length);

			// Creating Poi-GridID Dict
			const poiGridIDDict = {};
			let allPoiIDs;
			if (indexFilteredGridIds?.length) {
				try {
					const gridPOIArrs = await Promise.all(
						_.chunk(indexFilteredGridIds, gridsChunkLength).map(async (arr) => {
							return this.poiGridRepository
								.createQueryBuilder("poi_grid")
								.where("poi_grid.gridId IN (:...gridIds)", { gridIds: arr })
								.getMany();
						}),
					);
					_.flatten(gridPOIArrs).forEach((pg) => (poiGridIDDict[pg.poiId] = pg.gridId));
					allPoiIDs = Object.keys(poiGridIDDict);
				} catch (error) {
					console.log(error);
				}
				console.log("All POIs in Index Filtered Grids", allPoiIDs.length);
			}

			// Filtering POIs of queried types out of all types
			if (allPoiIDs?.length) {
				let poiDetails;
				let filteredPoiIDs;
				try {
					const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
					const poiDetailsArr = await Promise.all(
						allPoiIDsArr.map(async (arr) => {
							return await this.poiRepository
								.createQueryBuilder("poi")
								.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
									poiIds: arr,
									poiTypes: query.types,
								})
								.getMany();
						}),
					);
					poiDetails = _.flatten(poiDetailsArr);
					filteredPoiIDs = poiDetails.map((p) => p.id);
				} catch (error) {
					console.log(error);
				}
				console.log("The POI of Selected Types", filteredPoiIDs.length);

				if (filteredPoiIDs?.length) {
					// Creating POI InternalDetails Dictionary
					const poiInternalDetailsDict = {};
					try {
						const filteredPoiIdsArr = _.chunk(filteredPoiIDs, gridsChunkLength);
						const poiInternalDetailsArr = await Promise.all(
							filteredPoiIdsArr.map(async (arr) => {
								return await this.poiDetailRepository
									.createQueryBuilder("poi_detail")
									.where("poi_detail.poiId IN (:...poiIds)", { poiIds: arr })
									.getMany();
							}),
						);
						_.flatten(poiInternalDetailsArr).forEach((d) => {
							if (poiInternalDetailsDict[d.poiId]) poiInternalDetailsDict[d.poiId][d.key] = d.value;
							else {
								poiInternalDetailsDict[d.poiId] = { [d.key]: d.value };
							}
						});
					} catch (error) {
						console.log(error);
					}
					console.log("The POI Internal Detail Sets done");

					let POIs;
					if (query?.["poiDetails"]?.length) {
						const internalRangeKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "number");
						const internalSelectKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "string");
						const internalBooleanKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "boolean");
						POIs = poiDetails
							.map((poi) => {
								if (
									this.poiInterDetailsCheck(
										poiInternalDetailsDict?.[poi.id],
										internalRangeKeys,
										internalSelectKeys,
										internalBooleanKeys,
									)
								) {
									const coordinates: number[] = [];
									//coordinates.push(Number(poi.latitude));
									coordinates.push(Number(poi.longitude));
									coordinates.push(Number(poi.latitude));
									return {
										...poi,
										index: gridIndexDict?.[poiGridIDDict[poi.id]]?.index,
										geometry: { type: "Point", coordinates: coordinates },
										internalDetails: poiInternalDetailsDict?.[poi.id],
									};
								} else return false;
							})
							.filter((p) => p);
					} else {
						POIs = poiDetails.map((poi) => {
							const coordinates: number[] = [];
							//coordinates.push(Number(poi.latitude));
							coordinates.push(Number(poi.longitude));
							coordinates.push(Number(poi.latitude));
							return {
								...poi,
								index: gridIndexDict?.[poiGridIDDict[poi.id]]?.index,
								geometry: { type: "Point", coordinates: coordinates },
								internalDetails: poiInternalDetailsDict?.[poi.id],
							};
						});
					}

					console.log("All POIs processed", POIs.length);
					const allTypes = POIs.map((p) => p.type);
					const typeCount = {};
					_.uniq(allTypes).forEach(
						(t: string) => (typeCount[t] = allTypes.filter((type) => type === t).length),
					);
					response.count = POIs.length;
					response.data = POIs;
					response.typeCount = typeCount;
				}
			}
		}
		return response;
	}

	async fetch_fresh_merchant(query: FilterQuery): Promise<Poi[] | PoiPaginationDto | any> {
		// Selecting all Grid IDs
		let radialGridsIds;
		let locationGridsIds;
		if (query["within"] || (query["location"] && query["without"])) {
			let latLongs: LatLong[] = [];
			latLongs = query?.["within"]?.["points"] ?? query?.["without"]?.["points"];
			let distance;
			if (query?.["within"]?.["radius"] || query?.["within"]?.["radius"]) {
				distance = query["within"]["radius"] ?? query["within"]["radius"];
			} else distance = 0.5;
			const pi = Math.PI;
			const lat_increment = 1 / 110.574;
			const lng_increment = 1 / 111.32;
			const gridBBoxes = latLongs.map((latLng) => {
				const lat_max = latLng.lat + distance * lat_increment;
				const lat_min = latLng.lat - distance * lat_increment;
				const lng_max = latLng.lng + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
				const lng_min = latLng.lng - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
				return geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
			});
			const radialGridsArr = await Promise.all(
				gridBBoxes.map(async (bbox) => {
					try {
						const tempGrids = await this.gridRepository
							.createQueryBuilder("grid")
							.where("grid.hash IN (:...hashes)", { hashes: bbox })
							.select("grid.id")
							.getMany();
						return tempGrids.map((g) => g.id);
					} catch (error) {
						return [];
					}
				}),
			);
			radialGridsIds = _.flatten(radialGridsArr);
			console.log("Radial Grids = ", radialGridsIds?.length);
		}
		if (!query["within"] && query["location"]) {
			const locationQueryObject = {};
			let locationQueryString = "";
			Object.keys(query["location"]).forEach((location, index) => {
				if (index === 0) {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += "grid." + location + " = :" + location;
				} else {
					locationQueryObject[location] = query["location"][location];
					locationQueryString += " AND grid." + location + " = :" + location;
				}
			});
			if (Object.keys(locationQueryObject).length) {
				try {
					const locationGrids = await this.gridRepository
						.createQueryBuilder("grid")
						.select("grid.id")
						.where(locationQueryString, locationQueryObject)
						.getMany();
					locationGridsIds = locationGrids.map((g) => g.id);
					console.log("Grids in Location Search :", locationGridsIds.length);
				} catch (error) {
					console.log(error);
				}
			}
		}
		let radiallyFilteredGridIds;
		if (query["within"]) {
			radiallyFilteredGridIds = radialGridsIds;
		} else if (query["location"] && query["without"]) {
			radiallyFilteredGridIds = _.difference(locationGridsIds, radialGridsIds);
		} else if (query["location"] && !query["without"]) {
			radiallyFilteredGridIds = locationGridsIds;
		} else radiallyFilteredGridIds = [];
		console.log("Radially Filtered Grids = ", radiallyFilteredGridIds?.length);

		const response = {
			count: 0,
			data: [],
			typeCount: {},
		};
		if (radiallyFilteredGridIds?.length) {
			// Creating Grid Indices Dictionary
			const gridsChunkLength = 60000;
			const gridIndexDict = {};
			try {
				const gridIndexMasterArrs = await Promise.all(
					_.chunk(radiallyFilteredGridIds, gridsChunkLength).map(async (arr) => {
						return await this.gridRepository
							.createQueryBuilder("grid")
							.leftJoinAndSelect("grid.indexmaster", "indexmaster")
							.where("grid.id In (:...gridIds)", { gridIds: arr })
							.getMany();
					}),
				);
				const rangeKeys = query?.["grids"]?.["range"] ?? {};
				const selectKeys = query?.["grids"]?.["select"] ?? {};
				console.log(rangeKeys, selectKeys);
				if (Object.keys(rangeKeys).length || Object.keys(selectKeys).length) {
					_.flatten(gridIndexMasterArrs).forEach((g: Grid) => {
						if (this.gridFiltersCheck(g, rangeKeys, selectKeys)) {
							const indices = {};
							g.indexmaster.forEach(
								(i) =>
									(indices[i.indexName] =
										i.indexType === "string" ? i.categoricalValue : i.indexValue),
							);
							gridIndexDict[g.id] = {
								index: indices,
							};
						}
					});
				} else {
					_.flatten(gridIndexMasterArrs).forEach((g: Grid) => {
						const indices = {};
						g.indexmaster.forEach(
							(i) =>
								(indices[i.indexName] = i.indexType === "string" ? i.categoricalValue : i.indexValue),
						);
						gridIndexDict[g.id] = {
							index: indices,
						};
					});
				}
			} catch (error) {
				console.log(error);
			}
			const indexFilteredGridIds = Object.keys(gridIndexDict);
			console.log("The Index Filtered Grids", indexFilteredGridIds.length);

			// Creating Poi-GridID Dict
			const poiGridIDDict = {};
			let allPoiIDs;
			if (indexFilteredGridIds?.length) {
				try {
					const gridPOIArrs = await Promise.all(
						_.chunk(indexFilteredGridIds, gridsChunkLength).map(async (arr) => {
							return this.poiGridRepository
								.createQueryBuilder("poi_grid")
								.where("poi_grid.gridId IN (:...gridIds)", { gridIds: arr })
								.getMany();
						}),
					);
					_.flatten(gridPOIArrs).forEach((pg) => (poiGridIDDict[pg.poiId] = pg.gridId));
					allPoiIDs = Object.keys(poiGridIDDict);
				} catch (error) {
					console.log(error);
				}
				console.log("All POIs in Index Filtered Grids", allPoiIDs.length);
			}

			// Filtering POIs of queried types out of all types
			if (allPoiIDs?.length) {
				let poiDetails;
				let filteredPoiIDs;
				try {
					//
					let barredPoiIds = [];
					try {
						const barredPoiIdsFromUserMerchant = (await this.usermerchantRepository.find()).map(
							(o) => o.merchantId,
						);
						const barredPoiIdsFromApiKeyUserMerchant = (await this.apiKeyUserMerchantRepository.find()).map(
							(o) => o.merchantId,
						);
						const barredPoiIdsFromAnswers = (
							await this.answerRepository
								.createQueryBuilder("answer")
								.select(`"uniqueId"`)
								.where(`"questionId" IN (:...questionIds)`, { questionIds: [1, 2, 3, 4, 6] })
								.distinct(true)
								.getRawMany()
						).map((a) => a.uniqueId);
						console.log(barredPoiIdsFromAnswers);
						barredPoiIds = barredPoiIdsFromUserMerchant.concat(barredPoiIdsFromAnswers);
						barredPoiIds = barredPoiIds.concat(barredPoiIdsFromApiKeyUserMerchant);
					} catch (error) {
						console.error(error);
					}
					//
					if (query.count != undefined) {
						if (query.gst != undefined) {
							if (query.gst.includes("Gst") && query.gst.includes("Non Gst")) {
								if (barredPoiIds.length) {
									const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
									const poiDetailsArr = await Promise.all(
										allPoiIDsArr.map(async (arr) => {
											return await this.poiRepository
												.createQueryBuilder("poi")
												.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
													poiIds: arr,
													poiTypes: query.types,
												})
												.andWhere(`id NOT IN (:...barredPoiIds)`, {
													barredPoiIds: barredPoiIds,
												})
												.orderBy("poi.id")
												.limit(Number(query.count))
												.getMany();
										}),
									);
									poiDetails = _.flatten(poiDetailsArr);
									filteredPoiIDs = poiDetails.map((p) => p.id);
								} else {
									const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
									const poiDetailsArr = await Promise.all(
										allPoiIDsArr.map(async (arr) => {
											return await this.poiRepository
												.createQueryBuilder("poi")
												.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
													poiIds: arr,
													poiTypes: query.types,
												})
												.orderBy("poi.id")
												.limit(Number(query.count))
												.getMany();
										}),
									);
									poiDetails = _.flatten(poiDetailsArr);
									filteredPoiIDs = poiDetails.map((p) => p.id);
								}
								if (query.count == 0) {
									poiDetails = [];
									filteredPoiIDs = [];
								}
							} else if (query.gst.includes("Gst") && !query.gst.includes("Non Gst")) {
								if (barredPoiIds.length) {
									const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
									const poiDetailsArr = await Promise.all(
										allPoiIDsArr.map(async (arr) => {
											return await this.poiRepository
												.createQueryBuilder("poi")
												.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
													poiIds: arr,
													poiTypes: query.types,
												})
												.andWhere(`id NOT IN (:...barredPoiIds)`, {
													barredPoiIds: barredPoiIds,
												})
												.andWhere(
													`EXISTS (select * from poi_detail where key = 'gstin' and "poiId" = poi.id)`,
												)
												.orderBy("poi.id")
												.limit(Number(query.count))
												.getMany();
										}),
									);
									poiDetails = _.flatten(poiDetailsArr);
									filteredPoiIDs = poiDetails.map((p) => p.id);
								} else {
									const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
									const poiDetailsArr = await Promise.all(
										allPoiIDsArr.map(async (arr) => {
											return await this.poiRepository
												.createQueryBuilder("poi")
												.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
													poiIds: arr,
													poiTypes: query.types,
												})
												.andWhere(
													`EXISTS (select * from poi_detail where key = 'gstin' and "poiId" = poi.id)`,
												)
												.orderBy("poi.id")
												.limit(Number(query.count))
												.getMany();
										}),
									);
									poiDetails = _.flatten(poiDetailsArr);
									filteredPoiIDs = poiDetails.map((p) => p.id);
								}
								if (query.count == 0) {
									poiDetails = [];
									filteredPoiIDs = [];
								}
							} else if (!query.gst.includes("Gst") && query.gst.includes("Non Gst")) {
								if (barredPoiIds.length) {
									const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
									const poiDetailsArr = await Promise.all(
										allPoiIDsArr.map(async (arr) => {
											return await this.poiRepository
												.createQueryBuilder("poi")
												.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
													poiIds: arr,
													poiTypes: query.types,
												})
												.andWhere(`id NOT IN (:...barredPoiIds)`, {
													barredPoiIds: barredPoiIds,
												})
												.andWhere(
													`NOT EXISTS (select * from poi_detail where key = 'gstin' and "poiId" = poi.id)`,
												)
												.orderBy("poi.id")
												.limit(Number(query.count))
												.getMany();
										}),
									);
									poiDetails = _.flatten(poiDetailsArr);
									filteredPoiIDs = poiDetails.map((p) => p.id);
								} else {
									const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
									const poiDetailsArr = await Promise.all(
										allPoiIDsArr.map(async (arr) => {
											return await this.poiRepository
												.createQueryBuilder("poi")
												.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
													poiIds: arr,
													poiTypes: query.types,
												})
												.andWhere(
													`NOT EXISTS (select * from poi_detail where key = 'gstin' and "poiId" = poi.id)`,
												)
												.orderBy("poi.id")
												.limit(Number(query.count))
												.getMany();
										}),
									);
									poiDetails = _.flatten(poiDetailsArr);
									filteredPoiIDs = poiDetails.map((p) => p.id);
								}
								if (query.count == 0) {
									poiDetails = [];
									filteredPoiIDs = [];
								}
							}
						} else {
							if (barredPoiIds.length) {
								const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
								const poiDetailsArr = await Promise.all(
									allPoiIDsArr.map(async (arr) => {
										return await this.poiRepository
											.createQueryBuilder("poi")
											.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
												poiIds: arr,
												poiTypes: query.types,
											})
											.andWhere(`id NOT IN (:...barredPoiIds)`, { barredPoiIds: barredPoiIds })
											.orderBy("poi.id")
											.limit(Number(query.count))
											.getMany();
									}),
								);
								poiDetails = _.flatten(poiDetailsArr);
								filteredPoiIDs = poiDetails.map((p) => p.id);
							} else {
								const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
								const poiDetailsArr = await Promise.all(
									allPoiIDsArr.map(async (arr) => {
										return await this.poiRepository
											.createQueryBuilder("poi")
											.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
												poiIds: arr,
												poiTypes: query.types,
											})
											.orderBy("poi.id")
											.limit(Number(query.count))
											.getMany();
									}),
								);
								poiDetails = _.flatten(poiDetailsArr);
								filteredPoiIDs = poiDetails.map((p) => p.id);
							}
							if (query.count == 0) {
								poiDetails = [];
								filteredPoiIDs = [];
							}
						}
					} else {
						if (barredPoiIds.length) {
							const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
							const poiDetailsArr = await Promise.all(
								allPoiIDsArr.map(async (arr) => {
									return await this.poiRepository
										.createQueryBuilder("poi")
										.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
											poiIds: arr,
											poiTypes: query.types,
										})
										.andWhere(`id NOT IN (:...barredPoiIds)`, { barredPoiIds: barredPoiIds })
										.orderBy("poi.id")
										.getMany();
								}),
							);
							poiDetails = _.flatten(poiDetailsArr);
							filteredPoiIDs = poiDetails.map((p) => p.id);
						} else {
							const allPoiIDsArr = _.chunk(allPoiIDs, gridsChunkLength);
							const poiDetailsArr = await Promise.all(
								allPoiIDsArr.map(async (arr) => {
									return await this.poiRepository
										.createQueryBuilder("poi")
										.where("poi.id IN (:...poiIds) AND poi.type IN (:...poiTypes)", {
											poiIds: arr,
											poiTypes: query.types,
										})
										.orderBy("poi.id")
										.getMany();
								}),
							);
							poiDetails = _.flatten(poiDetailsArr);
							filteredPoiIDs = poiDetails.map((p) => p.id);
						}
					}
				} catch (error) {
					console.log(error);
				}
				console.log("The POI of Selected Types", filteredPoiIDs.length);

				if (filteredPoiIDs?.length) {
					// Creating POI InternalDetails Dictionary
					const poiInternalDetailsDict = {};
					try {
						const filteredPoiIdsArr = _.chunk(filteredPoiIDs, gridsChunkLength);
						const poiInternalDetailsArr = await Promise.all(
							filteredPoiIdsArr.map(async (arr) => {
								return await this.poiDetailRepository
									.createQueryBuilder("poi_detail")
									.where("poi_detail.poiId IN (:...poiIds)", { poiIds: arr })
									.getMany();
							}),
						);
						_.flatten(poiInternalDetailsArr).forEach((d) => {
							if (poiInternalDetailsDict[d.poiId]) poiInternalDetailsDict[d.poiId][d.key] = d.value;
							else {
								poiInternalDetailsDict[d.poiId] = { [d.key]: d.value };
							}
						});
					} catch (error) {
						console.log(error);
					}
					console.log("The POI Internal Detail Sets done");

					let POIs;
					if (query?.["poiDetails"]?.length) {
						const internalRangeKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "number");
						const internalSelectKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "string");
						const internalBooleanKeys = query?.["poiDetails"]?.filter((f) => f.dataType === "boolean");
						POIs = poiDetails
							.map((poi) => {
								if (
									this.poiInterDetailsCheck(
										poiInternalDetailsDict?.[poi.id],
										internalRangeKeys,
										internalSelectKeys,
										internalBooleanKeys,
									)
								) {
									const coordinates: number[] = [];
									//coordinates.push(Number(poi.latitude));
									coordinates.push(Number(poi.longitude));
									coordinates.push(Number(poi.latitude));
									const { latitude, longitude, ...POI } = poi;
									return {
										...POI,
										index: gridIndexDict?.[poiGridIDDict[poi.id]]?.index,
										geometry: { type: "Point", coordinates: coordinates },
										internalDetails: poiInternalDetailsDict?.[poi.id],
									};
								} else return false;
							})
							.filter((p) => p);
					} else {
						POIs = poiDetails.map((poi) => {
							const { latitude, longitude, ...POI } = poi;
							const coordinates: number[] = [];
							//coordinates.push(Number(poi.latitude));
							coordinates.push(Number(poi.longitude));
							coordinates.push(Number(poi.latitude));
							return {
								...POI,
								index: gridIndexDict?.[poiGridIDDict[poi.id]]?.index,
								geometry: { type: "Point", coordinates: coordinates },
								internalDetails: poiInternalDetailsDict?.[poi.id],
							};
						});
					}

					console.log("All POIs processed", POIs.length);
					const allTypes = POIs.map((p) => p.type);
					const typeCount = {};
					_.uniq(allTypes).forEach(
						(t: string) => (typeCount[t] = allTypes.filter((type) => type === t).length),
					);
					response.count = POIs.length;
					response.data = POIs;
					response.typeCount = typeCount;
				}
			}
		}
		return response;
	}

	async filter(query: FilterQuery): Promise<Poi[] | PoiPaginationDto | any> {
		if (query["within"]) {
			if (query["within"]["points"].length == 0) {
				delete query["within"];
			}
		}
		let gridIds; /*
		if(! query["location"]) {
			throw new HttpException({
				status: HttpStatus.BAD_REQUEST,
				error: "Request body must contain 'location'"
			},HttpStatus.BAD_REQUEST);
		}*/
		//For WFSL
		if (!query.types) {
			query.types = ["society"];
		}
		let poiStatus = PoiStatus.approved;
		if (query.poiStatus) {
			poiStatus = query.poiStatus;
		}
		const gridsSearchedArr = [];
		let poiIdsFromPoiDetails = [];
		let poiGridIds;
		let poiIds;
		if (query["grids"] || query["location"] || query["within"] || query["poiDetails"] || query["ids"]) {
			if (query["ids"]) {
				const gridIds = [];
				const poiIds = query["ids"] as any[];
				if (poiIds.length > 60000) {
					const poiIdsArr = _.chunk(poiIds, 60000);
					await Promise.all(
						poiIdsArr.map(async (eachPoiIds) => {
							const poiGrids = await this.poiGridRepository.find({
								where: {
									poiId: In(eachPoiIds),
								},
							});
							await Promise.all(
								poiGrids.map((eachPoiGrid) => {
									gridIds.push(eachPoiGrid.gridId);
								}),
							);
						}),
					);
				} else {
					const poiGrids = await this.poiGridRepository.find({
						where: {
							poiId: In(poiIds),
						},
					});
					await Promise.all(
						poiGrids.map((eachPoiGrid) => {
							gridIds.push(eachPoiGrid.gridId);
						}),
					);
				}
				_.flattenDeep(gridIds);
				gridsSearchedArr.push(gridIds);
				delete query["grids"];
				delete query["location"];
				delete query["within"];
				//delete query["types"];
				delete query["poiDetails"];
			}
			if (query["poiDetails"]) {
				const poiDetails: any[] = query["poiDetails"];
				if (poiDetails.length == 0) {
					delete query["poiDetails"];
				}
			}
			if (query["grids"]) {
				if (query["grids"]["range"]) {
					if (Object.keys(query["grids"]["range"]).length) {
						await Promise.all(
							Object.keys(query["grids"]["range"]).map(async (eachKey) => {
								console.log("eachRanged key");
								let gridsQueryString = "";
								const gridsQueryObject = {};
								gridsQueryString +=
									'indexmaster."indexName" = :' +
									eachKey +
									'name AND indexmaster."indexValue" BETWEEN :' +
									eachKey +
									"min AND :" +
									eachKey +
									"max";
								gridsQueryObject[eachKey + "min"] = query["grids"]["range"][eachKey]["min"];
								gridsQueryObject[eachKey + "max"] = query["grids"]["range"][eachKey]["max"];
								gridsQueryObject[eachKey + "name"] = eachKey;
								try {
									const response = await this.gridRepository
										.createQueryBuilder("grid")
										.leftJoinAndSelect("grid.indexmaster", "indexmaster")
										.where(gridsQueryString, gridsQueryObject)
										.select("grid.id")
										.getMany();
									const gridIds = response.map((eachResp) => {
										return eachResp.id;
									});
									gridsSearchedArr.push(gridIds);
									return gridIds;
								} catch (error) {
									console.error(error);
									return [];
								}
							}),
						);
					}
				}
				if (query["grids"]["select"]) {
					if (Object.keys(query["grids"]["select"]).length) {
						await Promise.all(
							Object.keys(query["grids"]["select"]).map(async (eachKey) => {
								console.log("eachSelect key", eachKey);
								try {
									const someIndexes = await this.indexMasterRepository
										.createQueryBuilder("indexmaster")
										.select('indexmaster."gridId"')
										.where('indexmaster."indexName" = :indexName', { indexName: eachKey })
										.andWhere('indexmaster."categoricalValue" IN (:...categoricalValues)', {
											categoricalValues: query["grids"]["select"][eachKey],
										})
										.getRawMany();
									const gridIds = someIndexes.map((eachIndex) => {
										return eachIndex["gridId"];
									});
									gridsSearchedArr.push(_.flattenDeep(gridIds));
									return gridIds;
								} catch (error) {
									console.log(error);
									return [];
								}
							}),
						);
						console.log("gridsSelectResponse", gridsSearchedArr);
					}
				}
			}
			if (query["location"]) {
				const locationQueryObject = {};
				let locationQueryString = "";
				Object.keys(query["location"]).forEach((location, index) => {
					if (index === 0) {
						locationQueryObject[location] = query["location"][location];
						locationQueryString += "grid." + location + " = :" + location;
					} else {
						locationQueryObject[location] = query["location"][location];
						locationQueryString += " AND grid." + location + " = :" + location;
					}
				});
				if (Object.keys(locationQueryObject).length) {
					try {
						const locationGrids = await this.gridRepository
							.createQueryBuilder("grid")
							.select("grid.id")
							.where(locationQueryString, locationQueryObject)
							.getMany();
						const locationGridIds = await locationGrids.map((g) => g.id);
						console.log("Length of gridIds in Location Search :", locationGridIds.length);
						gridsSearchedArr.push(locationGridIds);
					} catch (error) {
						console.log(error);
					}
				}
			}
			if (query["within"]) {
				let distance = query["within"]["radius"];
				distance = distance;
				const withinGridsArr: number[][] = await Promise.all(
					query["within"]["points"].map(async (eachLatLong) => {
						//new try
						const pi = Math.PI;
						const lat_increment = 1 / 110.574;
						const lng_increment = 1 / 111.32;
						const lat_max = eachLatLong.lat + distance * lat_increment;
						const lat_min = eachLatLong.lat - distance * lat_increment;
						const lng_max = eachLatLong.lng + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
						const lng_min = eachLatLong.lng - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
						const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
						try {
							const tempGrid = await this.gridRepository
								.createQueryBuilder("grid")
								.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
								.select("grid.id")
								.getMany();

							const tempGridIds = tempGrid.map((eachGrid) => {
								return eachGrid.id;
							});
							return tempGridIds;
						} catch (error) {
							return null;
						}
					}),
				);
				const tempGrids = _.flattenDeep(withinGridsArr);
				console.log("Length of GridIds from Within search :", tempGrids.length);
				gridsSearchedArr.push(tempGrids);
			}
			if (query["poiDetails"]) {
				const poiDetails: any[] = query["poiDetails"];
				if (poiDetails.length == 0) {
					poiIdsFromPoiDetails = [];
				} else {
					await Promise.all(
						poiDetails.map(async (eachPoiDetail) => {
							if (eachPoiDetail.dataType == "string") {
								const tempPoiIdsFromString = [];
								const tempPoiIds = await this.poiDetailRepository
									.createQueryBuilder("poi_detail")
									.where("key = :key AND value IN(:...values)", {
										key: eachPoiDetail.key,
										values: eachPoiDetail.values,
									})
									.select('"poiId"')
									.distinct(true)
									.getRawMany();
								await Promise.all(
									tempPoiIds.map((eachPoiId) => {
										tempPoiIdsFromString.push(eachPoiId.poiId);
									}),
								);
								poiIdsFromPoiDetails.push(tempPoiIdsFromString);
							}
							if (eachPoiDetail.dataType == "number") {
								console.log("inside numbers query");
								const tempPoiIdsArray = [];
								console.log(eachPoiDetail);
								const tempPoiDetails = await this.poiDetailRepository
									.createQueryBuilder("poi_detail")
									.where("key = :key", { key: eachPoiDetail.key })
									.andWhere("unit BETWEEN :min and :max", {
										min: eachPoiDetail["values"]["min"],
										max: eachPoiDetail["values"]["max"],
									})
									.select('"poiId"')
									.distinct(true)
									.getRawMany();

								console.log("temp poi details", tempPoiDetails);
								await Promise.all(
									tempPoiDetails.map((eachPoiDetailHere) => {
										tempPoiIdsArray.push(eachPoiDetailHere.poiId);
									}),
								);
								poiIdsFromPoiDetails.push(tempPoiIdsArray);
							}
						}),
					);
				}
			}
			let responseIds = [];
			gridsSearchedArr.forEach((eachArr, index) => {
				if (index === 0) {
					responseIds = eachArr;
				} else {
					responseIds = _.intersection(responseIds, eachArr);
				}
			});
			console.log("Length of gridIds :", responseIds.length);
			if (!responseIds) {
				responseIds = [];
			}
			if (responseIds.length > 0) {
				gridIds = responseIds;
				try {
					let poiGrids;
					if (responseIds.length > 50000) {
						const responseIdsArr = _.chunk(responseIds, 50000);
						poiGrids = await Promise.all(
							responseIdsArr.map(async (eachResponseIdsArr) => {
								return await this.poiGridRepository
									.createQueryBuilder("poi_grid")
									.where("poi_grid.gridId IN (:...gridIds)", { gridIds: eachResponseIdsArr })
									.getMany();
							}),
						);
					} else {
						poiGrids = await this.poiGridRepository
							.createQueryBuilder("poi_grid")
							.where("poi_grid.gridId IN (:...gridIds)", { gridIds: responseIds })
							.getMany();
					}
					poiGrids = _.flattenDeep(poiGrids);
					poiGridIds = poiGrids.map((g) => g.poiId);
					poiIds = poiGridIds;
				} catch (error) {
					console.log(error);
				}
			} else {
				return [];
			}
		}
		if (!poiIds) {
			poiIds = [];
		}
		if (poiIds.length == 0) {
			poiIds = [0];
		}
		if (query["poiDetails"]) {
			console.log("poi ids array", poiIdsFromPoiDetails);
			let poiIdsFromPoiDetailsIntersected = [];
			const poiDetails: unknown[] = query["poiDetails"];
			poiIdsFromPoiDetails.forEach((eachArr, index) => {
				if (index === 0) {
					poiIdsFromPoiDetailsIntersected = eachArr;
				} else {
					poiIdsFromPoiDetailsIntersected = _.intersection(poiIdsFromPoiDetailsIntersected, eachArr);
				}
			});
			if (poiDetails.length > 0) {
				poiIds = _.intersection(poiIds, poiIdsFromPoiDetailsIntersected);
			}
		}
		if (query["ids"]) {
			poiIds = query["ids"] as unknown[];
		}
		let poiIdsArr;
		let indexMasterGrids = [];
		if (gridIds.length > 50000) {
			console.log("Chunking...");
			const gridIdsArr = _.chunk(gridIds, 50000);
			await Promise.all(
				gridIdsArr.map(async (eachGridIds) => {
					const tempIndexMasterGrids = await this.gridRepository
						.createQueryBuilder("grid")
						.leftJoinAndSelect("grid.indexmaster", "indexmaster")
						.where("grid.id In (:...gridIds)", { gridIds: eachGridIds })
						.getMany();
					indexMasterGrids.push(tempIndexMasterGrids);
				}),
			);
			indexMasterGrids = _.flattenDeep(indexMasterGrids);
		} else {
			indexMasterGrids = await this.gridRepository
				.createQueryBuilder("grid")
				.leftJoinAndSelect("grid.indexmaster", "indexmaster")
				.where("grid.id In (:...gridIds)", { gridIds: gridIds })
				.getMany();
		}
		const indexMasterGridsDict = {};
		indexMasterGrids.forEach((eachGrid) => {
			const tempDict = {};
			eachGrid.indexmaster.forEach((eachIndexMaster) => {
				if (eachIndexMaster.indexType === "string") {
					tempDict[eachIndexMaster.indexName] = eachIndexMaster.categoricalValue;
				} else {
					const tempObj = {};
					tempObj["unit"] = eachIndexMaster.metrices;
					tempObj["value"] = eachIndexMaster.indexValue;
					//tempObj["unit"] = eachIndexMaster.unit;
					//tempObj["description"] = eachIndexMaster.description;
					tempDict[eachIndexMaster.indexName] = eachIndexMaster.indexValue;
				}
			});
			indexMasterGridsDict[eachGrid.id] = tempDict;
		});
		if (poiIds.length > 10000 && query.limit && query.page) {
			poiIds.sort();
			const limit: number = query.limit as number;
			const page: number = query.page as number;
			poiIdsArr = _.chunk(poiIds, 10000);
			const POIs = await Promise.all(
				poiIdsArr.map(async (eachPoiIdsArr) => {
					return await this.poiRepository.find({
						where: { id: In(eachPoiIdsArr), status: poiStatus, type: In(query.types) },
						order: { id: "ASC" },
					});
				}),
			);
			const pois = _.flattenDeep(POIs) as Poi[];
			await Promise.all(
				pois.map(async (eachPoi) => {
					const poiDetails = await this.poiDetailRepository.find({
						where: {
							poiId: eachPoi.id,
						},
					});
					const internalDetailsObj = {};
					await Promise.all(
						poiDetails.map(async (eachPoiDetail) => {
							internalDetailsObj[eachPoiDetail.key] = eachPoiDetail.value;
						}),
					);
					eachPoi["internalDetails"] = internalDetailsObj;
				}),
			);
			const totalPages =
				pois.length % limit ? Math.floor(pois.length / limit) + 1 : Math.floor(pois.length / limit);
			const startIndex = (page - 1) * limit;
			let stopIndex = page * limit;
			if (stopIndex >= pois.length) {
				stopIndex = pois.length;
			}
			const responsePOIs = pois.slice(startIndex, stopIndex) as Poi[];
			const responsePois: PoiPaginationDto = {
				limit: limit,
				page: page,
				totalPages: totalPages,
				data: responsePOIs,
			};
			return responsePois;
		} else if (query["responseType"] == "count") {
			console.log("Length of PoiIds Found :", poiIds.length);
			return await this.getAggrigation(poiIds, query);
		} else if (query["responseType"] == "aggregation") {
			console.log("Length of PoiIds Found :", poiIds.length);
			return await this.getAggrigation(poiIds, query);
		} else if (poiIds.length > 60000) {
			poiIdsArr = _.chunk(poiIds, 60000);
			const pois = await Promise.all(
				poiIdsArr.map(async (eachPoiIdsArr) => {
					const poiGridRelationships = await this.poiGridRepository.find({
						where: {
							poiId: In(eachPoiIdsArr as number[]),
						},
					});
					const poiGridsRelationDict = {};
					try {
						poiGridRelationships.forEach((eachRelation) => {
							poiGridsRelationDict[eachRelation.poiId] = eachRelation.gridId;
						});
						const poiObjects = await this.poiRepository.find({
							where: { id: In(eachPoiIdsArr), status: poiStatus, type: In(query.types) },
						});
						poiObjects.forEach((eachPoiObject) => {
							const eachGridRelation = poiGridsRelationDict[eachPoiObject.id];
							eachPoiObject["index"] = indexMasterGridsDict[eachGridRelation];
						});
						return poiObjects;
					} catch (error) {
						console.log("error is", error);
					}
				}),
			);
			const POIs = _.flattenDeep(pois) as Poi[];
			console.log("Length of pois", POIs.length);
			await Promise.all(
				POIs.map(async (eachPoi) => {
					const poiDetails = await this.poiDetailRepository.find({
						where: {
							poiId: eachPoi.id,
						},
					});
					const internalDetailsObj = {};
					await Promise.all(
						poiDetails.map(async (eachPoiDetail) => {
							const tempObj = {};
							tempObj["unit"] = eachPoiDetail.metrics;
							tempObj["value"] = eachPoiDetail.value;
							//tempObj["description"] = eachPoiDetail.description;
							//tempObj["unit"] = eachPoiDetail.unit;
							internalDetailsObj[eachPoiDetail.key] = eachPoiDetail.value;
						}),
					);
					eachPoi["internalDetails"] = internalDetailsObj;
				}),
			);
			//New Response------------
			const finalResponse = {};
			finalResponse["count"] = POIs.length;
			finalResponse["data"] = POIs;
			finalResponse["typeCount"] = {};
			await Promise.all(
				POIs.map((poi) => {
					const subTypes = Object.keys(finalResponse["typeCount"]);
					if (subTypes.includes(poi.type)) {
						//console.log("Type encounterd :",poi.type);
						finalResponse["typeCount"][poi.type] = finalResponse["typeCount"][poi.type] + 1;
					} else {
						finalResponse["typeCount"][poi.type] = 1;
					}
					//changing lat long to geomerty
					poi["geometry"] = {};
					poi["geometry"]["type"] = "Point";
					const coordinates: number[] = [];
					coordinates.push(Number(poi.longitude));
					coordinates.push(Number(poi.latitude));
					poi["geometry"]["coordinates"] = coordinates;
					delete poi.latitude;
					delete poi.longitude;
				}),
			);
			console.log("here u go :", finalResponse["typeCount"]);
			return finalResponse;
			//return POIs;
		} else if (query.limit && query.page) {
			try {
				const limit: number = query.limit as number;
				const page: number = query.page as number;
				const offset: number = (page - 1) * limit;
				const pois = await this.poiRepository.find({
					where: {
						id: In(poiIds),
						status: poiStatus,
						type: In(query.types),
					},
					order: { id: "ASC" },
					take: limit,
					skip: offset,
				});
				await Promise.all(
					pois.map(async (eachPoi) => {
						const poiDetails = await this.poiDetailRepository.find({
							where: {
								poiId: eachPoi.id,
							},
						});
						const internalDetailsObj = {};
						await Promise.all(
							poiDetails.map(async (eachPoiDetail) => {
								internalDetailsObj[eachPoiDetail.key] = eachPoiDetail.value;
							}),
						);
						eachPoi["internalDetails"] = internalDetailsObj;
					}),
				);
				const totalPages = await this.poiRepository.count({
					where: { id: In(poiIds), status: poiStatus, type: In(query.types) },
				});
				const responsePois: PoiPaginationDto = {
					limit: limit,
					page: page,
					totalPages:
						totalPages % limit ? Math.floor(totalPages / limit) + 1 : Math.floor(totalPages / limit),
					data: pois,
				};
				return responsePois;
			} catch (error) {
				console.log(error);
			}
		} else {
			try {
				console.log("PoiIds", poiIds);
				if (poiIds.length == 0) {
					poiIds = [0];
				}
				const poiGridRelationships = await this.poiGridRepository.find({
					where: {
						poiId: In(poiIds as number[]),
					},
				});
				const poiObjects = await this.poiRepository.find({
					where: {
						id: In(poiIds),
						status: poiStatus,
						type: In(query.types),
					},
				});
				console.log("poiObjects length : ", poiObjects.length);
				const poiGridsRelationDict = {};
				poiGridRelationships.forEach((eachRelation) => {
					poiGridsRelationDict[eachRelation.poiId] = eachRelation.gridId;
				});
				poiObjects.forEach((eachPoiObject) => {
					const eachGridRelation = poiGridsRelationDict[eachPoiObject.id];
					eachPoiObject["index"] = indexMasterGridsDict[eachGridRelation];
				});
				await Promise.all(
					poiObjects.map(async (eachPoi) => {
						const poiDetails = await this.poiDetailRepository.find({
							where: {
								poiId: eachPoi.id,
							},
						});
						const internalDetailsObj = {};
						await Promise.all(
							poiDetails.map(async (eachPoiDetail) => {
								const tempObj = {};
								tempObj["unit"] = eachPoiDetail.metrics;
								tempObj["value"] = eachPoiDetail.value;
								//tempObj["description"] = eachPoiDetail.description;
								//tempObj["unit"] = eachPoiDetail.unit;
								internalDetailsObj[eachPoiDetail.key] = eachPoiDetail.value;
							}),
						);
						eachPoi["internalDetails"] = internalDetailsObj;
					}),
				);
				console.log("length of Pois :", poiObjects.length);
				//New Response ----------------
				const finalResponse = {};
				finalResponse["count"] = poiObjects.length;
				finalResponse["data"] = poiObjects;
				finalResponse["typeCount"] = {};
				await Promise.all(
					poiObjects.map((poi) => {
						const subTypes = Object.keys(finalResponse["typeCount"]);
						if (subTypes.includes(poi.type)) {
							//console.log("Type encounterd :",poi.type);
							finalResponse["typeCount"][poi.type] = finalResponse["typeCount"][poi.type] + 1;
						} else {
							finalResponse["typeCount"][poi.type] = 1;
						}
						//changing lat long to geomerty
						poi["geometry"] = {};
						poi["geometry"]["type"] = "Point";
						const coordinates: number[] = [];
						coordinates.push(Number(poi.longitude));
						coordinates.push(Number(poi.latitude));
						poi["geometry"]["coordinates"] = coordinates;
						delete poi.latitude;
						delete poi.longitude;
					}),
				);
				console.log("here u go :", finalResponse["typeCount"]);
				return finalResponse;
				//return poiObjects;
			} catch (error) {
				return [];
				console.log(error);
			}
		}
	}

	async createnew(userId: number, body: POI): Promise<void> {
		const tempPOI: POI = {
			address: body.address,
			name: body.name,
			type: body.type,
			latitude: body.latitude,
			longitude: body.longitude,
			createdBy: userId,
			category: null,
			subType: null,
			votes: null,
			rating: null,
			dataType: "organization",
			status: PoiStatus.pending,
		};
		if (body.type == "bank" || body.type == "atm") {
			tempPOI.category = "financial";
		}
		if (body.type == "hardware-shop" || body.type == "grocery" || body.type == "supermarket") {
			tempPOI.category = "commercial";
		}
		if (body.type == "mall" || body.type == "beauty-salon" || body.type == "gym") {
			tempPOI.category = "entertainment";
		}
		if (body.type == "doctor" || body.type == "pharmacy" || body.type == "hospital") {
			tempPOI.category = "medical";
		}
		if (body.type == "school") {
			tempPOI.category = "educational";
		}
		const savedPoi = await this.poiRepository.save(tempPOI);
		const grid = await this._gridService.nearestGrid(tempPOI.latitude, tempPOI.longitude);
		const tempPoiGrid = new PoiGrid();
		tempPoiGrid.gridId = grid["id"];
		tempPoiGrid.poiId = savedPoi.id;
		await this.poiGridRepository.save(tempPoiGrid);
	}

	async getSubTypes(query: POI): Promise<string[]> {
		try {
			if (query.category) {
				const subTypes = await this.poiRepository
					.createQueryBuilder("poi")
					.where("poi.category = :category", { category: query.category })
					.select('"subType"')
					.distinct(true)
					.getRawMany();
				const subTypesArr = subTypes.map((eachSubType) => {
					return eachSubType.subType;
				});
				return subTypesArr;
			} else if (query.type) {
				const subTypes = await this.poiRepository
					.createQueryBuilder("poi")
					.where("poi.type = :type", { type: query.type })
					.select('"subType"')
					.distinct(true)
					.getRawMany();
				const subTypesArr = subTypes.map((eachSubType) => {
					return eachSubType.subType;
				});
				return subTypesArr;
			}
		} catch (error) {
			console.log(error);
		}
	}

	async getNewlyAddedPois(query: PoiQuery): Promise<Poi[] | PoiPaginationDto> {
		const limit: number = query.limit as number;
		const page: number = query.page as number;
		const offset: number = (page - 1) * limit;
		const filterQuery = {};
		if (query.status) {
			filterQuery["status"] = query.status;
		}
		delete query.limit;
		delete query.page;
		const NewlyAddedPois = await this.poiRepository.find({
			where: filterQuery,
			skip: offset,
			take: limit,
			order: { id: "ASC" },
		});
		const totalPages = await this.poiRepository.count({ where: filterQuery });
		const responsePois: PoiPaginationDto = {
			limit: limit,
			page: page,
			totalPages: totalPages % limit ? Math.floor(totalPages / limit) + 1 : Math.floor(totalPages / limit),
			data: NewlyAddedPois,
		};
		return responsePois;
	}

	async updatePoiStatus(body: PoiStatusUpdate[]): Promise<void> {
		const poiStatusUpdates = body;
		poiStatusUpdates.forEach(async (poiStatusUpdate) => {
			const poi = await this.poiRepository.findOne({ where: { id: poiStatusUpdate.poiId } });
			poi.status = poiStatusUpdate.status;
			await this.poiRepository.save(poi);
		});
	}

	async createnewstore(userId: number, body: POI): Promise<void> {
		const tempPOI: POI = {
			address: body.address,
			name: body.name,
			type: "own-store",
			latitude: body.latitude,
			longitude: body.longitude,
			createdBy: userId,
			category: "commercial",
			subType: null,
			votes: null,
			rating: null,
			dataType: "organization",
			status: PoiStatus.approved,
		};
		const savedPoi = await this.poiRepository.save(tempPOI);
		const grid = await this._gridService.nearestGrid(tempPOI.latitude, tempPOI.longitude);
		const tempPoiGrid = new PoiGrid();
		tempPoiGrid.gridId = grid["id"];
		tempPoiGrid.poiId = savedPoi.id;
		await this.poiGridRepository.save(tempPoiGrid);
	}

	async filterPoiDetails(query) {
		if (!query["types"]) {
			throw new HttpException(
				{
					status: HttpStatus.BAD_REQUEST,
					error: "Request body must contain 'types'",
				},
				HttpStatus.BAD_REQUEST,
			);
		}
		const types: unknown[] = query["types"];
		let requestedKeys = [];
		if (query?.["keys"]?.length) {
			requestedKeys = query["keys"] as string[];
		}

		let reqPoiDetail = [];
		if (query?.["keys"]?.length) {
			reqPoiDetail = await this.poiDetailRepository
				.createQueryBuilder("poi_detail")
				.select(["key", '"dataType"'])
				.distinct(true)
				.where(`"poiId" IN (SELECT id FROM poi WHERE type IN(:...types))`, { types: types })
				.andWhere(`key IN(:...keys)`, { keys: requestedKeys })
				.getRawMany();
		} else {
			reqPoiDetail = await this.poiDetailRepository
				.createQueryBuilder("poi_detail")
				.select(["key", '"dataType"'])
				.distinct(true)
				.where(`"poiId" IN (SELECT id FROM poi WHERE type IN(:...types))`, { types: types })
				.getRawMany();
		}
		console.log("KEYS :", reqPoiDetail);

		const reqKeys = [];
		await Promise.all(
			reqPoiDetail.map((eachpoiDetail) => {
				const tempObj = {};
				tempObj["key"] = eachpoiDetail.key;
				tempObj["dataType"] = eachpoiDetail.dataType;
				reqKeys.push(tempObj);
			}),
		);

		await Promise.all(
			reqKeys.map(async (eachKey) => {
				if (eachKey.dataType == "number") {
					console.log("Number type found");
				} else {
					const values = await this.poiDetailRepository
						.createQueryBuilder("poi_detail")
						.select(["value", "unit"])
						.where('key = :key AND "poiId" IN (SELECT id FROM poi WHERE type IN(:...types))', {
							key: eachKey["key"],
							types: types,
						})
						.distinct(true)
						.getRawMany();
					const sortedValues = _.sortBy(values, "unit");
					if (sortedValues.length > Number(process.env.MINIMUM_LIMIT_FOR_FILTER)) {
						eachKey["values"] = "Not Filterable";
					} else {
						eachKey["values"] = sortedValues.map((eachValue) => {
							return eachValue.value;
						});
					}
				}
			}),
		);

		return reqKeys;
	}
	async filterQuery(poiIds: number[], key) {
		return await this.poiDetailRepository
			.createQueryBuilder("poi_detail")
			.where('key = :key AND "poiId" IN (:...poiIds)', { key: key, poiIds: poiIds })
			.select("unit")
			.distinct(true)
			.getRawMany();
	}

	async getUserDefaultPOIFilter(user: Partial<User>) {
		let defaultFilter = null;
		try {
			if (user?.["type"] == "apikey") return undefined;
			const userMapping: POIFilterUserTeam[] = await this.poiFilterUserTeamRepository.find({
				where: { UserId: Number(user.id) },
			});
			const teamMapping: POIFilterUserTeam[] = await this.poiFilterUserTeamRepository.find({
				where: { TeamId: user.teamId },
			});
			const poiFilterIDs = _.uniq([...userMapping, ...teamMapping].map((el) => el.POIFilterId));
			if (poiFilterIDs?.length) {
				const poiFilters: POIFilter[] = await this.poiFilterRepository.find({
					where: { id: In(poiFilterIDs), isActivated: true },
				});
				const orderedPoiFilters = poiFilterIDs
					.map((id) => poiFilters.find((el) => el.id == id))
					.filter((el) => el);
				defaultFilter = JSON.parse(orderedPoiFilters?.[0]?.value);
			}
		} catch (error) {
			console.error(error);
		} finally {
			return defaultFilter;
		}
	}

	async getMyPoiTypes(query, user: Partial<User | ApiKeyUser>) {
		if (!query?.["userId"]) {
			throw new HttpException(`"userId" missing!`, HttpStatus.BAD_REQUEST);
		}
		let response = [];
		try {
			const poiFilter: { types: string[] } = await this.getUserDefaultPOIFilter(user);
			console.log("POI Filter :", poiFilter);
			const queryBuilder = this.poiRepository.createQueryBuilder("poi").select("type").distinct(true);
			if (query["category"]) {
				queryBuilder.where("poi.category = :category", { category: query["category"] });
			}
			if (poiFilter?.types) {
				queryBuilder.andWhere(`poi.type IN (:...types)`, { types: poiFilter.types });
			}
			const poiNames = await queryBuilder.getRawMany();
			console.log("Total Number of Poi Types in DB :", poiNames.length);
			response = poiNames.map((p) => p.type);
		} catch (error) {
			console.error(error);
		} finally {
			return response;
		}
	}

	async getAllPoiTypes(query) {
		if (query["category"]) {
			const poiNames = await this.poiRepository
				.createQueryBuilder("poi")
				.select("type")
				.where("poi.category = :category", { category: query["category"] })
				.distinct(true)
				.getRawMany();
			console.log("Total Number of Poi Types in DB :", poiNames.length);
			const response = [];
			await Promise.all(
				poiNames.map((eachPoiName) => {
					response.push(eachPoiName["type"]);
				}),
			);
			return response;
		} else {
			const poiNames = await this.poiRepository
				.createQueryBuilder("poi")
				.select("type")
				.distinct(true)
				.getRawMany();
			console.log("Total Number of Poi Types in DB :", poiNames.length);
			const response = [];
			await Promise.all(
				poiNames.map((eachPoiName) => {
					response.push(eachPoiName["type"]);
				}),
			);
			return response;
		}
	}

	async indexPoi() {
		console.log("Starting Poi Indexing...");
		await this.query();
		console.log("Poi Indexing Completed");
	}

	async query() {
		await pgClient.connect();
		const res = await pgClient.query('SELECT * FROM poi WHERE "indexStatus"=false');
		console.log(res.rows);
		for await (const eachRow of res.rows) {
			try {
				const queryString = 'SELECT * FROM poi_grid WHERE "poiId" = ' + eachRow["id"];
				const res2 = await pgClient.query(queryString);
				const queryString2 = "SELECT * from grid where id=" + res2.rows[0]["gridId"];
				const res3 = await pgClient.query(queryString2);
				const grid = res3.rows[0];
				eachRow["state"] = grid["State"];
				eachRow["city"] = grid["City"];
				eachRow["locality"] = grid["Locality"];
				eachRow["pincode"] = grid["Pincode"];
				eachRow["indexStatus"] = true;
				console.log("grid is", eachRow);
				const poi = await this.poiRepository.findOne({
					where: {
						id: eachRow["id"],
					},
				});
				poi["indexStatus"] = true;
				await this.poiRepository.save(poi);
				console.log("Poi with ID =" + poi["id"] + "is updated and saved");
			} catch (error) {
				console.log("error", error);
			}
		}
		pgClient.end();
	}

	async index(data) {
		return await client.index({
			index: process.env.ELASTIC_INDEX,
			type: process.env.ELASTIC_TYPE,
			body: data,
		});
	}

	async searchLatLongNew(latitude: number, longitude: number, radius: number, typeSubTypeObj: unknown[]) {
		console.log("here");
		let distance = 0.5;
		if (radius) {
			distance = radius;
			console.log("distance found :", distance);
		}
		const pi = Math.PI;
		const lat_increment = 1 / 110.574;
		const lng_increment = 1 / 111.32;
		const lat_max = Number(latitude) + distance * lat_increment;
		const lat_min = Number(latitude) - distance * lat_increment;
		const lng_max = Number(longitude) + distance * (lng_increment / Math.cos((pi / 180) * lat_max));
		const lng_min = Number(longitude) - distance * (lng_increment / Math.cos((pi / 180) * lat_min));
		const withinGrids = geohash.bboxes(lat_min, lng_min, lat_max, lng_max, 7);
		const tempGrid = await this.gridRepository
			.createQueryBuilder("grid")
			.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
			.leftJoinAndSelect("grid.indexmaster", "indexmaster")
			.getMany();
		const tempGridIds = tempGrid.map((eachGrid) => {
			return eachGrid.id;
		});
		const gridIndexDict = {};
		tempGrid.forEach((eachGrid) => {
			const indexesDict = {};
			eachGrid.indexmaster.forEach((eachIndex) => {
				indexesDict[eachIndex.indexName] = eachIndex.indexValue;
			});
			gridIndexDict[eachGrid.id] = indexesDict;
		});
		const poiGridsReltions = await this.poiGridRepository.find({
			where: {
				gridId: In(tempGridIds),
			},
		});
		const poiGridsRelationDict = {};
		let poiGridsReltionsIds = poiGridsReltions.map((eachRelation) => {
			poiGridsRelationDict[eachRelation.poiId] = eachRelation.gridId;
			return eachRelation.poiId;
		});
		//const poiIds = poiGridsReltionsIds;//Found all those poiIds within the required catchment
		const poiIdsFromTypeSearch: number[] = [];
		await Promise.all(
			typeSubTypeObj.map(async (eachObj) => {
				let tempPoiIdsArray = [];
				if (Object.keys(eachObj)[0] == "null") {
					const pois = await this.poiRepository
						.createQueryBuilder("poi")
						.select("id")
						.where('"subType" IN (:...subtypes)', { subtypes: eachObj[Object.keys(eachObj)[0]] })
						.getRawMany();
					//console.log(pois);
					tempPoiIdsArray.push(pois);
				}
				if (eachObj[Object.keys(eachObj)[0]] == "null") {
					const pois = await this.poiRepository
						.createQueryBuilder("poi")
						.select("id")
						.where("type = :type", { type: Object.keys(eachObj)[0] })
						.getRawMany();
					//console.log(pois);
					tempPoiIdsArray.push(pois);
				}
				if (Object.keys(eachObj)[0] != "null" && eachObj[Object.keys(eachObj)[0]] != "null") {
					//console.log("hahaha")
					const pois = await this.poiRepository
						.createQueryBuilder("poi")
						.select("id")
						.where('type = :type AND "subType" IN (:...subtypes)', {
							type: Object.keys(eachObj)[0],
							subtypes: eachObj[Object.keys(eachObj)[0]],
						})
						//.andWhere('"subType" IN (:...subtypes)',{subtypes: eachObj[Object.keys(eachObj)[0]]})
						.getRawMany();
					//console.log("HEREREREREER",pois);
					tempPoiIdsArray.push(pois);
				}
				tempPoiIdsArray = _.flattenDeep(tempPoiIdsArray);
				console.log(tempPoiIdsArray.length);
				tempPoiIdsArray = _.uniqBy(tempPoiIdsArray, function (e) {
					return e.id;
				});
				console.log(tempPoiIdsArray.length);
				await Promise.all(
					tempPoiIdsArray.map((eachObj) => {
						poiIdsFromTypeSearch.push(eachObj["id"]);
					}),
				);
			}),
		);
		console.log("Length of type searched poiIds :", poiIdsFromTypeSearch.length);
		console.log(poiIdsFromTypeSearch);
		poiGridsReltionsIds = _.intersection(poiIdsFromTypeSearch, poiGridsReltionsIds); //intersection b/w catchment search and type search
		if (poiGridsReltionsIds.length == 0) {
			return [];
		}
		const responsePois = await this.poiRepository.find({
			where: {
				id: In(poiGridsReltionsIds),
				status: PoiStatus.approved,
			},
		});
		responsePois.forEach((eachPoi) => {
			eachPoi["index"] = gridIndexDict[poiGridsRelationDict[eachPoi.id]];
		});
		return responsePois;
	}

	async findByIds(query) {
		if (query["poiIds"] == undefined) {
			throw new HttpException(`poi ids must be defined`, HttpStatus.BAD_REQUEST);
		}
		if (!_.isArray(query["poiIds"])) {
			throw new HttpException(`poi ids must be an array of numbers`, HttpStatus.BAD_REQUEST);
		}
		const poiIds: number[] = query["poiIds"];
		if (poiIds.length == 0) {
			return [];
		}
		const pois = await this.poiRepository.find({ where: { id: In(poiIds) } });
		if (pois.length == 0) {
			throw new HttpException(`Pois with id(s): ${poiIds.join(",")} not found!`, HttpStatus.BAD_REQUEST);
		}
		const poiGrids = await this.poiGridRepository.find({ where: { poiId: In(poiIds) } });
		const gridIds = await Promise.all(
			poiGrids.map((eachPoiGrids) => {
				return eachPoiGrids.gridId;
			}),
		);
		/*
		const indexmasters = await this.indexMasterRepository.createQueryBuilder("indexmaster")
			.where(`"gridId" IN (:...gridIds)`,{gridIds: gridIds})
			.getMany();
		//console.log(indexmasters);
		*/
		const indexMasterGrids = await this.gridRepository
			.createQueryBuilder("grid")
			.leftJoinAndSelect("grid.indexmaster", "indexmaster")
			.where("grid.id In (:...gridIds)", { gridIds: gridIds })
			.getMany();
		const indexMasterGridsDict = {};
		indexMasterGrids.forEach((eachGrid) => {
			const tempDict = {};
			eachGrid.indexmaster.forEach((eachIndexMaster) => {
				if (eachIndexMaster.indexType === "string") {
					tempDict[eachIndexMaster.indexName] = eachIndexMaster.categoricalValue;
				} else {
					const tempObj = {};
					tempObj["unit"] = eachIndexMaster.metrics;
					tempObj["value"] = eachIndexMaster.indexValue;
					//tempObj["unit"] = eachIndexMaster.unit;
					//tempObj["description"] = eachIndexMaster.description;
					tempDict[eachIndexMaster.indexName] = eachIndexMaster.indexValue;
				}
			});
			indexMasterGridsDict[eachGrid.id] = tempDict;
		});
		//Internal Details...
		const poiDetailDict = {};
		let poiDetails = [];
		console.log("PoiIds :", poiIds);
		if (poiIds.length > 40000) {
			const poiIdsArr = _.chunk(poiIds, 40000);
			poiDetails = await Promise.all(
				poiIdsArr.map(async (eachPoiIds) => {
					return await this.poiDetailRepository.find({ where: { poiId: In(eachPoiIds) } });
				}),
			);
			poiDetails = _.flattenDeep(poiDetails);
		} else {
			poiDetails = await this.poiDetailRepository.find({ where: { poiId: In(poiIds) } });
		}
		console.log("PoiDetails Length :", poiDetails.length);
		await Promise.all(
			poiDetails.map((eachObj) => {
				if (poiDetailDict[eachObj.poiId] != undefined) {
					poiDetailDict[eachObj.poiId][eachObj.key] = eachObj.value;
				} else {
					const tempObj = {};
					tempObj[eachObj.key] = eachObj.value;
					poiDetailDict[eachObj.poiId] = tempObj;
				}
			}),
		);
		//InternalDetails Done...
		console.log("poiObjects length : ", pois.length);
		const poiGridsRelationDict = {};
		poiGrids.forEach((eachRelation) => {
			poiGridsRelationDict[eachRelation.poiId] = eachRelation.gridId;
		});
		pois.forEach((eachPoiObject) => {
			const eachGridRelation = poiGridsRelationDict[eachPoiObject.id];
			eachPoiObject["index"] = indexMasterGridsDict[eachGridRelation];
			eachPoiObject["internalDetails"] = poiDetailDict[eachPoiObject.id];
			eachPoiObject["geometry"] = {};
			eachPoiObject["geometry"]["type"] = "Point";
			const coordinates: number[] = [];
			coordinates.push(Number(eachPoiObject.longitude));
			coordinates.push(Number(eachPoiObject.latitude));
			eachPoiObject["geometry"]["coordinates"] = coordinates;
			delete eachPoiObject.latitude;
			delete eachPoiObject.longitude;
		});
		return pois;
	}
}
