import { Entity, Column, PrimaryGeneratedColumn, Index } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class Layer {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	name: string;

	@ApiProperty()
	@Column("decimal", { default: -1 })
	clusterId: number;

	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	code: string;

	@ApiProperty()
	@Column()
	@Index()
	type: string;
	
	@ApiProperty()
	@Column()
	address: string;
	
	@ApiProperty()
	@Column({ nullable: true })
	pincode: string;
	
	@ApiProperty()
	@Column("decimal")
	latitude: number;

	@ApiProperty()
	@Column("decimal")
	longitude: number;

	@Column()
	@Index()
	gridHash: string;
	
	@Column({ nullable: true})
	firstDayOfVisit: Date;
	
	@Column({ nullable: true})
	lastDayOfVisit: Date;
}

