import { ApiProperty } from "@nestjs/swagger";
import { Team } from "src/team/team.entity";
import { User } from "src/users/users.entity";
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class POIFilter {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	name: string;

	@ApiProperty()
	@Column()
	description: string;

	@ApiProperty()
	@Column()
	value: string;

	@ApiProperty()
	@Column()
	isActivated: boolean;

	@ApiProperty()
	@CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
	createdAt: Date;

	@ApiProperty()
	@UpdateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)", onUpdate: "CURRENT_TIMESTAMP(6)" })
	updatedAt: Date;

	@ApiProperty()
	@Column({ nullable: true })
	createdBy: number;

	@ApiProperty()
	@Column({ nullable: true })
	updatedBy: number;
}

@Entity()
export class POIFilterUserTeam {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	POIFilterId: number;

	@ApiProperty()
	@Column({ nullable: true })
	UserId?: number;

	@ApiProperty()
	@Column({ nullable: true })
	TeamId?: number;
}

export class POIFilterDTO {
	id: number;
	name: string;
	description: string;
	value: string;
	isActivated: boolean;
	createdBy: Partial<User>;
	assignedUsers: Partial<User>[];
	assignedTeams: Partial<Team>[];
}

export class POIFilterPayload {
	id: number;
	name: string;
	description: string;
	value: string;
	isActivated: boolean;
	userIds: number[];
	teamIds: number[];
}
