import { Body, Controller, Delete, Get, Param, Patch, Post, Headers, Req, HttpStatus } from "@nestjs/common";
import { Role, Roles } from "src/helpers/roles-guard/roles-guard.service";
import { AppConfigsService } from "./app-configs.service";
import { AppConfigs } from "./app-configs.entity";
import { TeamService } from "src/team/team.service";
import { User } from "src/users/users.entity";
import { ApiKeyUser } from "src/api-key-users/api-key-users.entity";
import { UpdatePromptChainBody } from "src/interfaces/prompt-log";
import { SyslogService } from "src/helpers/log-interceptor/syslog.service";
import { Request } from "express";
import { RealIP } from "nestjs-real-ip";

@Controller("app-config")
export class AppConfigsController {
	constructor(
		private readonly _appConfigsService: AppConfigsService,
		private readonly teamService: TeamService,
		private _syslogService: SyslogService,
	) {}

	async getUser(headers: any): Promise<{ tokenUser: Partial<User>; apiKeyUser: Partial<ApiKeyUser> }> {
		const tokenAPIKey = headers["token"] || headers["apikey"] || headers["api-key"] || headers["apiKey"];
		const user = await this.teamService.decodeUserJWT(tokenAPIKey);
		const tokenUser = user["type"] === "token" ? (user as User) : undefined;
		const apiKeyUser = user["type"] === "apikey" ? (user as ApiKeyUser) : undefined;
		if (!tokenUser && !apiKeyUser) {
			throw new Error("Invalid token");
		}
		return { tokenUser, apiKeyUser };
	}

	@Roles(Role.ADMIN, Role.TEAM_ADMIN, Role.MAPS_USER, Role.BASIC)
	@Get()
	async getAllConfigs(@Headers() headers, @Req() req: Request, @RealIP() ip) {
		try {
			const { tokenUser } = await this.getUser(headers);
			const { id, config } = (await this._appConfigsService.getAppConfigs(tokenUser?.id)) as unknown as {
				id: number;
				config: JSON;
			};
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return { id, ...config };
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.ADMIN)
	@Post("create")
	async addAppConfig(@Body() body: Partial<AppConfigs>, @Req() req: Request, @RealIP() ip) {
		try {
			await this._appConfigsService.addAppConfigs(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return { message: "App Config added successfully!" };
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.ADMIN)
	@Patch("update")
	async updateAppConfig(@Body() body: AppConfigs, @Req() req: Request, @RealIP() ip) {
		try {
			await this._appConfigsService.updateAppConfig(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return { message: "App Config updated successfully!" };
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.ADMIN)
	@Delete("/:id")
	async deleteAppConfig(@Param() param: { id: number }, @Req() req: Request, @RealIP() ip) {
		try {
			await this._appConfigsService.deleteAppConfig(param.id);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return { message: "App Config deleted successfully!" };
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}

	@Roles(Role.ADMIN)
	@Post("update-prompt-chain")
	async updatePromptChain(@Body() body: UpdatePromptChainBody, @Req() req: Request, @RealIP() ip) {
		try {
			const res = await this._appConfigsService.updatePromptChain(body);
			await this._syslogService.log({
				ip: ip,
				req: req,
				level: "info",
				message: "Success",
				statusCode: HttpStatus.OK,
				creditsUsed: 0,
			});
			return res;
		} catch (error) {
			console.error(error);
			await this._syslogService.error({
				ip: ip,
				req: req,
				level: "err",
				message: (error as Error).message,
				statusCode: error.status,
				creditsUsed: 0,
			});
			throw error;
		}
	}
}
