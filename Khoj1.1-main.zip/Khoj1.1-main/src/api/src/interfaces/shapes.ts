export class MultilevelShapesQuery {
	location: {
		State: string;
		City: string;
		Locality: string;
		Cluster: string;
		Pincode: string;
		Taluka: string;
		District: string;
		Country: string;
	};
	childLevel: string;
	types: string[];
}

export class ElasticShapeIndex {
	id: any;
	name: string;
	indexname: string;
	level: string;
	objectid: any;
}
