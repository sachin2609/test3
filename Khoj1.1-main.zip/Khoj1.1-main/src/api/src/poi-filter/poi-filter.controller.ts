import { Controller, Headers, Param, Body, Get, Post, Patch, Delete } from "@nestjs/common";
import { Role, Roles, RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { PoiFilterService } from "./poi-filter.service";
import { TeamService } from "src/team/team.service";
import { POIFilterPayload } from "./poi-filter.entity";
import { RealIP } from "nestjs-real-ip";
import { Header } from "src/interfaces/header";

@Controller("poi-filter")
export class PoiFilterController {
	constructor(
		private poiFilterService: PoiFilterService,
		private teamService: TeamService,
		private rolesGuardService: RolesGuardService,
	) {}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN, Role.TEAM_ADMIN)
	@Get()
	async getPOIFilters(@Headers() headers: { token: string }) {
		const user = await this.teamService.decodeUserJWT(headers.token);
		const poiFilters = await this.poiFilterService.getPOIFilters(null, [user.id]);
		const poiFilterDTOs = await this.poiFilterService.POIFilterToPOIFilterDTO(poiFilters);
		return {
			count: poiFilterDTOs.length,
			data: poiFilterDTOs,
		};
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN)
	@Get("all")
	async getAllPOIFilters(@Headers() header: Header, @RealIP() ip: string) {
		const poiFilters = await this.poiFilterService.getPOIFilters();
		const poiFilterDTOs = await this.poiFilterService.POIFilterToPOIFilterDTO(poiFilters);
		this.rolesGuardService.updateCreds(header.token, 0, "/poi-filter/all", ip, "");
		return {
			count: poiFilterDTOs.length,
			data: poiFilterDTOs,
		};
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN, Role.TEAM_ADMIN)
	@Post("create")
	async createPOIFilter(@Headers() headers: { token: string }, @Body() body: Partial<POIFilterPayload>) {
		const user = await this.teamService.decodeUserJWT(headers.token);
		await this.poiFilterService.createPOIFilter(body, user);
		return {
			message: "POI Filter Created Successfully!",
		};
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN, Role.TEAM_ADMIN)
	@Patch("update")
	async updatePOIFilter(@Headers() headers: { token: string }, @Body() body: Partial<POIFilterPayload>) {
		const user = await this.teamService.decodeUserJWT(headers.token);
		await this.poiFilterService.updatePOIFilter(body, user);
		return {
			message: "POI Filter Updated Successfully!",
		};
	}

	@Roles(Role.ADMIN, Role.CLIENT_ADMIN, Role.TEAM_ADMIN)
	@Delete("delete/:id")
	async deletePOIFilter(@Param("id") id: number) {
		await this.poiFilterService.deletePOIFilter(id);
		return {
			message: "POI Filter Deleted Successfully!",
		};
	}
}
