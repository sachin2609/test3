import { Module } from "@nestjs/common";
import { HttpModule } from "@nestjs/axios";
import { TypeOrmModule } from "@nestjs/typeorm";
import { GridService } from "src/grid/grid.service";
import { Grid } from "src/grid/grids.entity";
import { IndexMasterController } from "./index-master.controller";
import { Indexmaster } from "./index-master.entity";
import { IndexMasterService } from "./index-master.service";
import { PropertyGrid } from "../relations/property-grid/property-grid.entity";
import { MongooseModule } from "@nestjs/mongoose";
import { DemoShapesDBSchema } from "src/shape/shape.schema";
import { Shape } from "src/shape/shape.entity";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { ShapeService } from "src/shape/shape.service";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
@Module({
	imports: [
		TypeOrmModule.forFeature([Indexmaster, Grid, PropertyGrid , Shape, Shapeindex, ShapeDetail]),
		MongooseModule.forFeature([{ name: 'DemoShapesDB', schema: DemoShapesDBSchema }]),
		HttpModule.register({
			timeout: 100000,
      		maxRedirects: 100
		}),
		MongoDatabaseModule
	],
	controllers: [IndexMasterController],
	providers: [IndexMasterService, GridService,ShapeService]
})
export class IndexMasterModule {}
