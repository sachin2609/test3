import { Entity, Column, PrimaryGeneratedColumn, JoinColumn, OneToMany, Unique, Index } from "typeorm";
import { Indexmaster } from "../index-master/index-master.entity";
import { ApiProperty } from "@nestjs/swagger";
@Entity()
export class Grid {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Index()
	@Column({ unique: true })
	hash: string;

	@ApiProperty()
	@OneToMany(
		() => Indexmaster,
		indexmaster => indexmaster.grid,
		{ cascade: true }
	)
	@JoinColumn()
	indexmaster: Indexmaster[];

	@ApiProperty()
	@Column("decimal", { nullable: true })
	latitude: number;

	@ApiProperty()
	@Column("decimal", { nullable: true })
	longitude: number;

	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	State: string;

	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	District: string;
	
	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	City: string;

	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	Locality: string;

	@ApiProperty()
	@Column({ nullable: true })
	Taluka: string;

	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	Pincode: string;

	@ApiProperty()
	@Index()
	@Column({ nullable: true })
	Cluster: string;
}
