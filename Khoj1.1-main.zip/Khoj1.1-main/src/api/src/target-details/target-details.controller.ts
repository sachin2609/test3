import { Body, Controller, Get, Headers, Post } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ApiBody, ApiHeader, ApiResponse } from '@nestjs/swagger';
import { TargetDetailsClass } from 'src/interfaces/targetDetails';
import { Roles } from 'src/helpers/roles-guard/roles-guard.service';
import { TargetDetail } from './target-details.entity';
import { TargetDetailsService } from './target-details.service';

@Controller('target-details')
export class TargetDetailsController {
	constructor(
		private _targetDetailsService : TargetDetailsService, 
		private _jwtService: JwtService
	) {}


	@Roles("basic")
	@Get()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "List" })
	async getOrgs(): Promise<TargetDetail[]> {
		return await this._targetDetailsService.getTargetDetails();
	}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Header" })
	@ApiBody({type: TargetDetailsClass})
	@ApiResponse({ description: "Add Target-Details" })
	async addTargetDetails(@Body() body: TargetDetailsClass[], @Headers() header): Promise<TargetDetail[]> {
		const user = this._jwtService.decode(header["token"]);
		return await this._targetDetailsService.addTargetDetails(body,user["id"]);
	}
	/*
	@Roles("basic")
	@Post("update")
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description:"Update" })
	async updateTargetDetails(@Body() body: TargetDetail, @Headers() header): Promise<unknown> {
		const user = this._jwtService.decode(header["token"]);
		return await this._targetDetailsService.updateTargetDetails(body,user["id"]);
	}*/
       @Get('populateunit')
       async populateUnit(): Promise<void> {
	       await this._targetDetailsService.populateUnit();
       }
}
