import { Controller, Post, Body, Get, Param , Query, Headers, HttpException, HttpStatus, UseInterceptors, Request, Req } from "@nestjs/common";
import { GridService } from "./grid.service";
import { Grid } from "./grids.entity";
import { GridWithIndexRanges, GridWithIndexRangesNew, Indexquery } from "../interfaces/grid";
import { ApiTags, ApiBody, ApiParam, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { LatLng } from "../interfaces/poi";
import { Roles, RolesGuardService } from "src/helpers/roles-guard/roles-guard.service";
import { query, request } from "express";
import { GlobalServiceService } from "src/helpers/global-service/global-service.service";
import { JwtService } from "@nestjs/jwt";
import { CacheKey } from "src/helpers/cache/cache-key.decorator";
import { CacheInterceptorInterceptor } from "src/helpers/cache/cache-interceptor.interceptor";
import { RealIP } from 'nestjs-real-ip';
import { CachePopulateInterceptor } from "src/helpers/cache/cache-populate.interceptor";

//import { Query } from "mongoose";
@ApiTags("grid")
@Controller("grid")
export class GridController {
	constructor(
		private _gridService: GridService, 
		private _globalService : GlobalServiceService, 
		private _jwtService: JwtService,
		private _rolesGuardService: RolesGuardService
	) {}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create Grids" })
	@ApiBody({ type: Grid })
	async create(@Body() data: Grid[]): Promise<Grid[]> {
		console.log(data);
		return await this._gridService.create();
	}

	@Roles("basic")
	@Post("filters")
	@CacheKey("grid-filters")
	@UseInterceptors(CacheInterceptorInterceptor)
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "get filters" })
	async filters(@Body() body) {
		console.log(body);
		return await this._gridService.getFilters(body);
	}

	@Roles("admin")
	@Post("populate-filters")
	@CacheKey("grid-filters")
	@UseInterceptors(CachePopulateInterceptor)
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "get filters" })
	async populateFilters(@Body() body) {
		console.log(body);
		return await this._gridService.getFilters(body);
	}

	@Roles("basic")
	@Get(":id")
	@ApiParam({ type: Number, name: "id" })
	async find(@Param() params: JSON): Promise<Grid> {
		return await this._gridService.getById(params["id"]);
	}

	@Roles("basic")
	@Post("populate")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Populate Grids" })
	async populate(): Promise<void> {
		await this._gridService.populateGrids();
	}

	@Roles("basic")
	@Post("latlng")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "genetare LatLong" })
	async generateLatLong(): Promise<void> {
		await this._gridService.generateLatLong();
	}

	@Roles("basic")
	@Post("search")
	@UseInterceptors(CacheInterceptorInterceptor)
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Search Grids" })
	@ApiBody({ type: Object })
	async search(@Body() body: JSON, @Headers() header, @RealIP() ip: string, @Request() req): Promise<Grid[] | GridWithIndexRanges | any> {
		console.log("RealIp Output",ip);
		console.log(req.ip +'  '+req.connection.remoteAddress+' '+ req.clientIp);
		try{
			const resp = await this._gridService.optimized_search(body);
			console.log("deducting ", resp['count'])
			let credsResp;
			if(header.token) {
				credsResp = await this._rolesGuardService.updateCreds(header.token, resp['count'],"/grid/search",ip,JSON.stringify(body));
			} else {
				credsResp = await this._rolesGuardService.apiKeyUpdateCreds(header["apikey"], resp['count'],"/grid/search",ip,JSON.stringify(body));
			}
			console.log("response from creds deduction", credsResp);
			if (credsResp) {
				return resp;
			} else {
				throw new HttpException({
					status: HttpStatus.FORBIDDEN,
					error: "Insufficient Credits Left"
				}, HttpStatus.FORBIDDEN)
			}
		} catch (err) {
			console.log(err);
			return {
				count: 0,
				data: []
			}
		}
	}


	@Roles("basic")
	@Post("getindex")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "get Index" })
	@ApiBody({ type: Indexquery })
	async getIndexes(@Body() query: Indexquery): Promise<unknown> {
		return await this._gridService.getIndex(query);
	}

	@Roles("basic")
	@Post("writegrids")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Write Grids to File" })
	async writeGrids(): Promise<void> {
		return await this._gridService.writeGridsToFile();
	}

	@Roles("basic")
	@Post("searchlatlng")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "search Latlong" })
	@ApiBody({ type: LatLng })
	async searchLatLng(@Body() latLong: LatLng): Promise<Grid[] | GridWithIndexRangesNew> {
		return await this._gridService.gridsLatLong(
			latLong.latitude,
			latLong.longitude,
			latLong.radius
		);
	}

	@Roles("basic")
	@Post("update")
	async update(@Body() grids: Grid[]): Promise<Grid[]> {
		return await this._gridService.update(grids);
	}

	@Roles("basic")
	@Post("index-ranges")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "search Latlong" })
	@ApiBody({ type: LatLng })
	async indexRanges(@Body() body): Promise<unknown> {
		return await this._gridService.indexRanges(
			body
		);
	}

	@Roles("basic")
	@Post("export-filter")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Search Grids" })
	@ApiBody({ type: Object })
	async exportFilter(@Body() body: JSON, @Headers() header): Promise<Grid[] | GridWithIndexRanges | any> {
		try {
			const user = await this._jwtService.decode(header.token);
			const userId = user["id"];
			if (body["without"]) {
				body["within"] = body["without"];
				let within = null;
				let page = null;
				let limit = null;
				if(body["page"] && body["limit"]) {
					page = body["page"] -1;
					limit = body["limit"];
					delete body["page"];
					delete body["limit"];
					console.log("Deleted 'page' and 'limit' from body");
				}
				const withinGridsRes = await this._gridService.search(body);
				const withinGrids = withinGridsRes["data"] as Grid[];
				if(body["within"]) {
					within = body["within"];
					delete body["within"];
					console.log("Deleted 'within' from body");
				}
				const allGridsRes = await this._gridService.search(body);
				const allGrids = allGridsRes["data"] as Grid[];
				console.log("Length of All grids : ",allGrids.length);
				console.log("Length of grids to be deleted :",withinGrids.length);
				//const response = allPois.filter( poi => !withinPois.includes( poi ) );
				/*const response = allPois.filter(function(x) { 
					return withinPois.indexOf(x) < 0;
				});*/
				const response = allGrids.filter(ar => !withinGrids.find(rm => (rm.hash === ar.hash && ar.id === rm.id) ));
				console.log("Length of Response Grids :",response.length);/*
				if(limit) {
					const splitedArray = _.chunk(response,limit);
					const totalPages = splitedArray.length;
					const responsePaginate : PoiPaginationDto = {
						page: page+1,
						limit: limit,
						totalPages: totalPages,
						data: splitedArray[page]
					}
					return responsePaginate;
				} else {
					return response;
				}*/
				if(body["responseType"]) {
					let responseIds : number[] = []
					await Promise.all(response.map(eachGrid => {
						responseIds.push(eachGrid.id);
					}));
					let res = await this._gridService.getAggrigation(responseIds,body);
					if(res["shapes"]) {
						delete res["shapes"];
					}
					if(res["data"] == undefined) {
						res["data"] = [{"count": res["count"]}];
					}
					return await this._globalService.exportCsv(res["data"],userId,"grid");
				} else {
					console.log("Length of Data sent to GlobalService :",response.length);
					await Promise.all(response.map(async eachData => {
						eachData["latitude"] = eachData["geometry"]["coordinates"][1];
						eachData["longitude"] = eachData["geometry"]["coordinates"][0];
						delete eachData["geometry"];
						await Promise.all(Object.keys(eachData["index"]).map(indexKey => {
							eachData[indexKey] = eachData["index"][indexKey];
						}));
						delete eachData["index"];
					}));
					return await this._globalService.exportCsv(response , userId , "grid");
				}
				//return response;
			} else {
				if(body["responseType"]) {
					let res = await this._gridService.search(body);
					if(res["shapes"]) {
						delete res["shapes"];
					}
					if(res["data"] == undefined) {
						res["data"] = [{"count": res["count"]}];
					}
					return await this._globalService.exportCsv(res["data"],userId,"grid");
				} else {
					const res = await this._gridService.search(body);
					console.log("Length of Data sent to GlobalService :",res["data"].length);
					await Promise.all(res["data"].map(async eachData => {
						eachData["latitude"] = eachData["geometry"]["coordinates"][0];
						eachData["longitude"] = eachData["geometry"]["coordinates"][1];
						delete eachData["geometry"];
						await Promise.all(Object.keys(eachData["index"]).map(indexKey => {
							eachData[indexKey] = eachData["index"][indexKey];
						}));
						delete eachData["index"];
					}));
					return await this._globalService.exportCsv(res["data"] , userId , "grid");
				}
			}
		} catch(error) {
			console.log(error);
			throw new HttpException('Bad Request', HttpStatus.BAD_REQUEST);
		}
	}

	@Roles("basic")
	@Post("get-info")
	async getInfo(@Body() body,@Headers() header) {
		return await this._gridService.getInfo(body,header["token"]);
	}

}
