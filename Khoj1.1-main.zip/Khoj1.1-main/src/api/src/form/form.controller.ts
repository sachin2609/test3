import { Controller, Get, Post, Body, Query } from "@nestjs/common";
import { Form } from "./form.entity";
import { FormService } from "./form.service";
import { Question } from "../question/question.entity";
import { ApiTags, ApiQuery, ApiBody, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
@ApiTags("form")
@Controller("form")
export class FormController {
	constructor(private _formService: FormService) {}

	@Roles("basic")
	@Get()
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create Questions" })
	@ApiQuery({ type: Form, name: "Form" })
	async create(@Query() query: Form): Promise<Question[]> {
		return await this._formService.list(query);
	}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create forms" })
	@ApiBody({ type: Form })
	async list(@Body() forms: Form[]): Promise<Form[]> {
		console.log(forms);
		return await this._formService.create();
	}
}
