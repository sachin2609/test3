import { ApiProperty } from "@nestjs/swagger";

export class RedirectObject {
	@ApiProperty()
	url: string;
}
