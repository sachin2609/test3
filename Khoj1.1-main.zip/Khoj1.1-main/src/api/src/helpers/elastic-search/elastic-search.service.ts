import { Injectable, HttpStatus, HttpException } from '@nestjs/common';
import { ElasticsearchService } from '@nestjs/elasticsearch';
import { InjectRepository } from '@nestjs/typeorm';
import { Grid } from 'src/grid/grids.entity';
import { ElasticShapeIndex } from 'src/interfaces/shapes';
import { Poi } from 'src/poi/poi.entity';
import { Repository } from 'typeorm';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import * as mongo from "mongodb";
import { DemoShapesDB } from 'src/shape/shape.schema';
import * as _ from "lodash";
import { Shape } from 'src/shape/shape.entity';
const mongoClient = mongo.MongoClient;
require('dotenv').config();

@Injectable()
export class ElasticSearchService {
    constructor(
        private _elasticSearchService: ElasticsearchService,
        @InjectRepository(Grid) private gridRepository: Repository<Grid>,
        @InjectRepository(Poi) private poiRepository: Repository<Poi>,
        @InjectRepository(Shape) private shapeRepository: Repository<Shape>,
        @InjectModel('DemoShapesDB') private demoShapesDBModel: Model<DemoShapesDB>,
    ) {}
    
    async searchPois(query): Promise<Poi[]> {
        console.log('query body', query);
        let response = [];
        await Promise.all(query["search"].map(async eachQuery => {
            const filterQueryArr = [];
            Object.keys(eachQuery).forEach((eachKey) => {
                const tempDict = {};
                let searchStrings = String(eachQuery[eachKey]);
                if(searchStrings.length == 1) {
                    searchStrings = " " + searchStrings+ " ";
                }
                if(searchStrings.length == 2) {
                    searchStrings = " " + searchStrings;
                }
                tempDict['match'] = {};
                tempDict['match'][eachKey] = searchStrings;
                filterQueryArr.push(tempDict);
            });
            try {
                const searchResp:any = await this._elasticSearchService.search({
                  index: 'poi',
                  body: {
                    query: {
                      bool: {
                        must: filterQueryArr,
                      },
                    },
                  },
                });
                const responsePois = searchResp.body.hits.hits.map((eachSource) => {
                  return eachSource._source;
                });
                console.log('final search response is', responsePois.length);
                response.push(responsePois);
            } catch (error) {
                console.log(error);
                throw new HttpException('Bad Request', HttpStatus.BAD_REQUEST);
            }
        }));
        return _.flattenDeep(response);
    }

    async searchShapes(query): Promise<ElasticShapeIndex[]> {
        console.log('query body', query);
        let useDb = false;
        Object.keys(query).forEach((eachKey) => {
            if(String(query[eachKey]).length < 3) {
                useDb = true;
            }
        });
        if(useDb) {
            const url = String(process.env.MONGO_URL);
            Object.keys(query).forEach((eachKey) => {
                if(String(query[eachKey]).length < 3) {
                    try {
                        query[eachKey] = RegExp(String(query[eachKey]));
                    } catch(err) {
                        console.log(err);
                        const str: string = "[" + String(query[eachKey]) + "]";
                        query[eachKey] = RegExp(str);
                    }
                }
            });
            return (await mongoClient.connect(url,{ useUnifiedTopology: true }))
                .db(String(process.env.MONGO_DB))
                .collection("ElasticIndexDB")
                .find(query)
                .limit(10).toArray();

        } else {
            const filterQueryArr = [];
            Object.keys(query).forEach((eachKey) => {
                const tempDict = {};
                const searchStrings = query[eachKey];
                tempDict['match'] = {};
                tempDict['match'][eachKey] = searchStrings;
                filterQueryArr.push(tempDict);
            });
            try {
                const searchResp:any = await this._elasticSearchService.search({
                  index: String(process.env.ELASTIC_INDEX),
                  body: {
                    query: {
                      bool: {
                        must: filterQueryArr,
                      },
                    },
                  },
                });
                const sources = searchResp?.body?.hits?.hits || searchResp?.hits?.hits;
                const responseShapes = sources.map(src => src._source);
                console.log('final search response is', responseShapes);
                return responseShapes;
            } catch (error) {
                console.log(error);
                throw new HttpException('Bad Request', HttpStatus.BAD_REQUEST);
            }
        }
    }

    async getResponse(query) {
        const url = String(process.env.MONGO_URL);
        console.log("req.body ", query);
	    if(query.id) {
            /*
            mongoClient.connect(url,{ useUnifiedTopology: true }).then(async mgClient => {
                const db = mgClient.db(String(process.env.MONGO_DB));
	    		const col = db.collection("ShapesDB");
                return await col.findOne({ where: { _id : new mongo.ObjectId(query.id) }});
            }).catch(err => {
                console.log(err);
            });
            */
            return await this.demoShapesDBModel.findOne({ _id: new mongoose.Types.ObjectId(query.id) });
            // return (await mongoClient.connect(url,{ useUnifiedTopology: true }))
            //     .db(String(process.env.MONGO_DB))
            //     .collection("ShapesDB")
            //     .findOne({ where: { _id: new mongo.ObjectId(query.id) }});
	    }
    }

}
