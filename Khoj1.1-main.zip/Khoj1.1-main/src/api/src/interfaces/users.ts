import { ApiProperty } from "@nestjs/swagger";

//interface to be used by Users module
export class UsersQuery {
	@ApiProperty()
	id: number;

	@ApiProperty()
	firstName: string;

	@ApiProperty()
	lastName: string;

	@ApiProperty()
	email: string;

	@ApiProperty()
	roles: string[];

	@ApiProperty()
	googleAccessToken: string;
}
