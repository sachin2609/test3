import {
	PrimaryGeneratedColumn,
	Column,
	Entity,
	CreateDateColumn,
	UpdateDateColumn
} from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

export enum WorkItemStage {
	analyzer = "Analyzer",
	verifier = "Verifier",
	approver = "Approver"
}

export enum WorkItemStatus {
	open = "open",
	close = "close"
}

@Entity()
export class WorkItem {
	@ApiProperty()
	@PrimaryGeneratedColumn()
	id: number;

	@ApiProperty()
	@Column()
	propertyId: number; //is like target

	@ApiProperty()
	@Column()
	userId: number;

	@ApiProperty()
	@Column()
	stage: WorkItemStage;

	@ApiProperty()
	@Column({ default: WorkItemStatus.open })
	status: WorkItemStatus;

	@ApiProperty()
	@Column({ nullable: true })
	assignedBy: number;

	@ApiProperty()
	@CreateDateColumn()
	createdAt: Date;

	@ApiProperty()
	@UpdateDateColumn()
	updatedAt: Date;
}
