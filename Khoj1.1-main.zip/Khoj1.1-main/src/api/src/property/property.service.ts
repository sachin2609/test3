import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { Repository, In } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Grid } from '../grid/grids.entity';
import { Property, PropertyReviewStatus } from './property.entity';
import {
  PropertyQuery,
  PropertyPaginationDto,
  PropertyLatLng,
  PropertyReviewBody,
  PropertyIdBody,
} from '../interfaces/property';
import * as fs from 'fs';
import * as tf from '@turf/turf';
import * as geohash from 'ngeohash';
import * as _ from 'lodash';
import * as csvParser from 'csv-parser';
import { PropertyGrid } from 'src/relations/property-grid/property-grid.entity';
import { PropertyGridService } from 'src/relations/property-grid/property-grid.service';
import { GridService } from 'src/grid/grid.service';
import { UserGrid, Role } from 'src/relations/user-grid/user-grid.entity';
import { WorkItemService } from 'src/work-item/work-item.service';
import { WorkItemStage, WorkItem, WorkItemStatus } from 'src/work-item/work-item.entity';
import { Indexmaster } from 'src/index-master/index-master.entity';
import { User } from 'src/users/users.entity';
import { WorkItemQuery, WorkItemPaginationDtoNew } from 'src/interfaces/work-item';
import { Answer } from 'src/answer/answer.entity';
import { Question } from 'src/question/question.entity';
import { Indexquery } from 'src/interfaces/grid';
@Injectable()
export class PropertyService {
  constructor(
    @InjectRepository(Property) private propertyRepository: Repository<Property>,
    @InjectRepository(Grid) private gridsRepository: Repository<Grid>,
    @InjectRepository(PropertyGrid) private propertyGridRepository: Repository<PropertyGrid>,
    @InjectRepository(UserGrid) private userGridRepository: Repository<UserGrid>,
    @InjectRepository(Indexmaster) private indexmasterRepository: Repository<Indexmaster>,
    @InjectRepository(User) private userRepository: Repository<User>,
    @InjectRepository(WorkItem) private workItemRepository: Repository<WorkItem>,
    @InjectRepository(Answer) private answerRepository: Repository<Answer>,
    @InjectRepository(Question) private questionRepository: Repository<Question>,
    private _gridService: GridService,
    private _propertyGridService: PropertyGridService,
    private _workItemService: WorkItemService,
    private _httpService: HttpService
  ) {}

	async create(properties: Property[], userId = 0): Promise<Property[]> {
		const propertyFields = [
			"name",
			"building",
			"street",
			"town",
			"city",
			"landmark",
			"latitude",
			"longitude",
			"pinCode"
		];
		//const workItemRequests = [];
		let propertyGrids = await Promise.all(
			properties.map(async property => {
				const propertyDetails = [];
				Object.keys(property).map(key => {
					if (!propertyFields.includes(key)) {
						const propertyDetail = {
							propertyId: property.id,
							key: key,
							value: property[key]
						};
						propertyDetails.push(propertyDetail);
					}
				});
				const preExistingProperty = await this.propertyRepository.find({ where: {
					name: property.name
			}});
				console.log("preexisting propert is", preExistingProperty);
				if (preExistingProperty.length < 1) {
					properties = await this.propertyRepository.save(properties);
					if (property.latitude && property.longitude) {
						const nearestGrid = await this._gridService.nearestGrid(
							property.latitude,
							property.longitude
						);
						console.log("nearest grid is", nearestGrid);
						const propertyGrid: PropertyGrid = {
							propertyId: property.id,
							gridId: nearestGrid["id"]
						};
						console.log("property grid obj", propertyGrid);
						const userGrid = await this.userGridRepository.findOne({
							where: {
								gridId: propertyGrid.gridId,
								role: Role.analyzer
							}
						});
						console.log(userGrid);
						/*
						if (userGrid) {
							const workItemRequest = {
								propertyId: property.id,
								userId: userGrid.userId,
								stage: WorkItemStage.analyzer
							};
							workItemRequests.push(workItemRequest);
						}*/
						return propertyGrid;
					}
				} else {
					const requestBody = {};
					requestBody["type"] = "property exists";
					requestBody["message"] = property.name + " already exists";
					requestBody["status"] = "error";
					requestBody["from"] = 0;
					requestBody["to"] = userId;
					requestBody["channel"] = 2;
					try {
						this._httpService.post(process.env.NOTIFICATION_URL, requestBody).subscribe(
							data => {
								console.log("response is", data);
							},
							err => {
								console.log(err);
							}
						);
					} catch (error) {
						console.log(error);
					}
					return null;
				}
			})
		);
		propertyGrids = propertyGrids.filter(property => {
			return property;
		});
		console.log("saving ", propertyGrids);
		try {
			//await this._workItemService.create(workItemRequests);
			await this._propertyGridService.create(propertyGrids);
			return properties;
		} catch (error) {
			console.log(error);
		}
	}

  async search(query: PropertyQuery): Promise<Property[] | PropertyPaginationDto> {
    let gridsSearchedArr = [];
    let propertyGridIds;
    let propertyIds;
    if (query['grids'] || query['location'] || query['within']) {
      if (query['grids']) {
        gridsSearchedArr = await Promise.all(
          Object.keys(query['grids']).map(async (eachKey) => {
            let gridsQueryString = '';
            const gridsQueryObject = {};
            gridsQueryString +=
              'indexmaster."indexName" = :' +
              eachKey +
              'name AND indexmaster."indexValue" BETWEEN :' +
              eachKey +
              'min AND :' +
              eachKey +
              'max';
            gridsQueryObject[eachKey + 'min'] = query['grids'][eachKey]['min'];
            gridsQueryObject[eachKey + 'max'] = query['grids'][eachKey]['max'];
            gridsQueryObject[eachKey + 'name'] = eachKey;
            const response = await this.gridsRepository
              .createQueryBuilder('grid')
              .leftJoinAndSelect('grid.indexmaster', 'indexmaster')
              .where(gridsQueryString, gridsQueryObject)
              .select('grid.id')
              .getMany();
            return response.map((eachResp) => {
              return eachResp.id;
            });
          })
        );
      }
      if (query['location']) {
        const locationQueryObject = {};
        let locationQueryString = '';
        Object.keys(query['location']).forEach((location, index) => {
          console.log('value', query['location'][location]);
          if (index === 0) {
            locationQueryObject[location] = query['location'][location];
            locationQueryString += 'grid.' + location + ' = :' + location;
          } else {
            locationQueryObject[location] = query['location'][location];
            locationQueryString += ' AND grid.' + location + ' = :' + location;
          }
        });
        if (Object.keys(locationQueryObject).length) {
          const locationGrids = await this.gridsRepository
            .createQueryBuilder('grid')
            .select('grid.id')
            .where(locationQueryString, locationQueryObject)
            .getMany();
          const locationGridIds = await locationGrids.map((eachGrid) => {
            return eachGrid.id;
          });
          gridsSearchedArr.push(locationGridIds);
        }
      }
      if (query['within']) {
        let distance = query['within']['radius'];
        const withinGridsArr: number[][] = await Promise.all(
          query['within']['ids'].map(async (eachId) => {
            const eachTarget = await this.propertyRepository.findOne({
              where: {
                id: eachId,
              },
            });
            const point = tf.point([eachTarget.latitude, eachTarget.longitude]);
            distance = distance / 2;
            const topLeft = tf.destination(point, distance, -135);
            const bottomRight = tf.destination(point, distance, 45);
            const withinGrids = geohash.bboxes(
              topLeft['geometry']['coordinates'][0],
              topLeft['geometry']['coordinates'][1],
              bottomRight['geometry']['coordinates'][0],
              bottomRight['geometry']['coordinates'][1],
              7
            );
            try {
              const tempGrid = await this.gridsRepository
                .createQueryBuilder('grid')
                .where('grid.hash IN (:...hashes)', { hashes: withinGrids })
                .select('grid.id')
                .getMany();

              const tempGridIds = tempGrid.map((eachGrid) => {
                return eachGrid.id;
              });
              return tempGridIds;
            } catch (error) {
              return null;
            }
          })
        );
        const tempGrids = _.flattenDeep(withinGridsArr);
        gridsSearchedArr.push(tempGrids);
      }
      let responseIds = [];
      gridsSearchedArr.forEach((eachArr) => {
        if (responseIds.length) {
          responseIds = _.intersection(responseIds, eachArr);
        } else {
          responseIds = eachArr;
        }
      });
      console.log('response ids', responseIds);
      if (responseIds.length) {
        let propertyGrids = await this.propertyGridRepository
          .createQueryBuilder('property_grid')
          .where('property_grid.gridId IN (:...gridIds)', { gridIds: responseIds })
          .getMany();

				propertyGrids = _.flattenDeep(propertyGrids);
				console.log("PropertyGrids :", propertyGrids.length);
				propertyGridIds = propertyGrids.map(eachGrid => {
					return eachGrid["propertyId"];
				});
				propertyIds = propertyGridIds;
			}
		}
		if (!propertyIds) {
			propertyIds = [0];
		}
		if (propertyIds.length == 0) {
			propertyIds = [0];
		}
		const limit: number = query.limit as number;
		const page: number = query.page as number;
		const offset: number = (page - 1) * limit;
		delete query.limit;
		delete query.page;
		const properties = await this.propertyRepository.find({
			where: { id: In(propertyIds) },
			skip: offset,
			take: limit
		});
		console.log("Length :", properties.length);
		const totalPages = await this.propertyRepository.count({where: { id: In(propertyIds) } });
		const propertyPaginationDto: PropertyPaginationDto = {
			limit: limit,
			page: page,
			totalPages:
				totalPages % limit ? Math.floor(totalPages / limit) + 1 : Math.floor(totalPages / limit),
			data: properties
		};
		return propertyPaginationDto;
		// } else {
		// 	return await this.propertyRepository.find(query);
		// }
	}

	async list(query: PropertyQuery): Promise<Property[] | PropertyPaginationDto> {
		if (query.limit) {
			const limit: number = query.limit as number;
			const page: number = query.page as number;
			const offset: number = (page - 1) * limit;
			delete query.limit;
			delete query.page;
			const properties = await this.propertyRepository.find({
				where: query,
				skip: offset,
				take: limit,
				order: {
					id: "ASC"
				}
			});
			const totalPages = await this.propertyRepository.count({where: query});
			const propertyPaginationDto: PropertyPaginationDto = {
				limit: limit,
				page: page,
				totalPages:
					totalPages % limit ? Math.floor(totalPages / limit) + 1 : Math.floor(totalPages / limit),
				data: properties
			};
			return propertyPaginationDto;
		} else {
			return await this.propertyRepository.find({where: query});
		}
	}

	async parseCsv(fileNames: string[], userId: number): Promise<Property[]> {
		let finalResult: Property[];
		await Promise.all(
			fileNames.map(async fileName => {
				const results = [];
				console.log(fileName);
				fs.createReadStream(`./files/${fileName}`)
					.pipe(csvParser())
					.on("data", data => results.push(data))
					.on("end", async () => {
						finalResult = await this.create(results, userId);
					});
			})
		);
		return finalResult;
	}
	async getAgainstIds(ids: number[]): Promise<Property[]> {
		return await this.propertyRepository.find({ where: { id: In(ids) } });
	}
	async searchLatLong(body: PropertyLatLng): Promise<Property[]> {
		const latitude = body.latitude;
		const longitude = body.longitude;
		let distance = 0.5;
		if (body.distance) {
			distance = body.distance;
		}
		const point = tf.point([latitude, longitude]);
		console.log("point is", point);
		const topLeft = tf.destination(point, distance, -160);
		console.log("distance is", distance);
		const bottomRight = tf.destination(point, distance, 30);
		console.log("topleft", topLeft);
		const withinGrids = geohash.bboxes(
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1],
			7
		);
		console.log(
			"latlongs are",
			topLeft["geometry"]["coordinates"][0],
			topLeft["geometry"]["coordinates"][1],
			bottomRight["geometry"]["coordinates"][0],
			bottomRight["geometry"]["coordinates"][1]
		);
		try {
			const tempGrid = await this.gridsRepository
				.createQueryBuilder("grid")
				.where("grid.hash IN (:...hashes)", { hashes: withinGrids })
				.select("grid.id")
				.getMany();

			const tempGridIds = tempGrid.map(eachGrid => {
				return eachGrid.id;
			});
			const propertyGrids = await this.propertyGridRepository.find({
				where: {
					gridId: In(tempGridIds)
				}
			});
			const propertyIds = propertyGrids.map(propertyGrid => {
				return propertyGrid.propertyId;
			});
			const properties = await this.propertyRepository.find({ where: { id: In(propertyIds) } });
			await Promise.all(
				properties.map(async property => {
					const propertyGrid = await this.propertyGridRepository.findOne({ where: {
						propertyId: property.id
				}});
					const grid = await this.gridsRepository.findOne({where: {id: propertyGrid.gridId}});
					const indexes = await this.indexmasterRepository.find({ where: { grid: grid }});
					grid["index"] = {};
					indexes.forEach(index => {
						grid["index"][index.indexName] = index.indexValue;
					});
					property["grid"] = grid;
				})
			);
			console.log(properties);
			return properties;
		} catch (error) {
			return [];
		}
	}
	async propertyReview(body: PropertyReviewBody, userId: number): Promise<void> {
		body.propertyIds.forEach(async propertyId => {
			console.log("Property Id :");
			console.log(propertyId);
			const workItemRequests = [];
			const propertyGrid = await this.propertyGridRepository.findOne({ where: { propertyId: propertyId }});
			console.log("Property Grid :");
			console.log(propertyGrid);
			const userGrid = await this.userGridRepository.findOne({
				where: {
					gridId: propertyGrid.gridId,
					role: Role.analyzer
				}
			});
			console.log("User Grid :");
			console.log(userGrid);
			if (userGrid) {
				const workItemRequest = {
					propertyId: propertyId,
					userId: userGrid.userId,
					stage: WorkItemStage.analyzer,
					assignedBy: userId
				};
				workItemRequests.push(workItemRequest);
			}
			console.log("Creating WorkItem");
			console.log(workItemRequests);
			await this._workItemService.create(workItemRequests);
		});
	}
	async getPropertyReview(
		userId: number,
		query: WorkItemQuery
	): Promise<WorkItem[] | WorkItemPaginationDtoNew> {
		const user = await this.userRepository.findOne({ where: { id: userId }});
		if (user.roles.includes("admin") || user.roles.includes("monitor")) {
			console.log("Roles found :", user.roles);
			const limit: number = query.limit as number;
			const page: number = query.page as number;
			const offset: number = (page - 1) * limit;
			const filterQuery = {};
			if (query.status) {
				filterQuery["status"] = query.status;
			}
			delete query.limit;
			delete query.page;
			const workItems = await this.workItemRepository.find({
				where: filterQuery,
				skip: offset,
				take: limit,
				order: { createdAt: "DESC" }
			});
			console.log(workItems);
			await Promise.all(
				workItems.map(async workItem => {
					const property = await this.propertyRepository.findOne({where: {id: workItem.propertyId }});
					workItem["property"] = property;
					const propertyGrid = await this.propertyGridRepository.findOne({ where: {
						propertyId: property.id
				}});
					workItem["gridId"] = propertyGrid.gridId;
					const user = await this.userRepository.findOne({ where: { id: workItem.assignedBy }});
					delete workItem["assignedBy"];
					workItem["createdBy"] = user;
				})
			);
			const totalPages = await this.workItemRepository.count({ where: filterQuery });
			const workItemPaginationDto: WorkItemPaginationDtoNew = {
				limit: limit,
				page: page,
				totalPages:
					totalPages % limit ? Math.floor(totalPages / limit) + 1 : Math.floor(totalPages / limit),
				data: workItems
			};
			return workItemPaginationDto;
		} else {
			console.log("Roles found :", user.roles);
			const limit: number = query.limit as number;
			const page: number = query.page as number;
			const offset: number = (page - 1) * limit;
			const filterQuery = {};
			if (query.status) {
				filterQuery["status"] = query.status;
			}
			filterQuery["userId"] = userId;
			delete query.limit;
			delete query.page;
			const workItems = await this.workItemRepository.find({
				where: filterQuery,
				skip: offset,
				take: limit,
				order: { createdAt: "DESC" }
			});
			await Promise.all(
				workItems.map(async workItem => {
					const property = await this.propertyRepository.findOne({where: {id: workItem.propertyId }});
					workItem["property"] = property;
					const user = await this.userRepository.findOne({ where: { id: workItem.assignedBy }});
					delete workItem["assignedBy"];
					workItem["createdBy"] = user;
				})
			);
			const totalPages = await this.workItemRepository.count({ where: filterQuery });
			const workItemPaginationDto: WorkItemPaginationDtoNew = {
				limit: limit,
				page: page,
				totalPages:
					totalPages % limit ? Math.floor(totalPages / limit) + 1 : Math.floor(totalPages / limit),
				data: workItems
			};
			return workItemPaginationDto;
		}
	}
	async getUserForProperty(body: PropertyIdBody): Promise<User[]> {
		const users: User[] = [];
		const propertyGrid = await this.propertyGridRepository.findOne({ where: { propertyId: body.propertyId }});
		console.log(propertyGrid);
		const userGrids = await this.userGridRepository.find({ where: { gridId: propertyGrid.gridId }});
		console.log(userGrids);
		await Promise.all(
			userGrids.map(async userGrid => {
				const user = await this.userRepository.findOne({ where: { id: userGrid.userId }});
				user["stage"] = userGrid.role;
				console.log(user);
				users.push(user);
			})
		);
		console.log(users);
		return users;
	}

	async changeReviewStatus(body: PropertyIdBody): Promise<Property> {
		const property = await this.propertyRepository.findOne({ where: { id: body.propertyId }});
		property.reviewStatus = PropertyReviewStatus.notReviewed;
		console.log(property);
		return await this.propertyRepository.save(property);
	}

	async propertyReviews(body: PropertyIdBody): Promise<unknown> {
		const workItems = await this.workItemRepository.find({
			where: {
				propertyId: body.propertyId,
				status: WorkItemStatus.close
			},
			order: { createdAt: "DESC" }
		});
		await Promise.all(
			workItems.map(async workItem => {
				const user = await this.userRepository.findOne({ where: { id: workItem.userId }});
				const answers = await this.answerRepository.find({
					where: {
						workItemId: workItem.id,
						// propertyId: Number(workItem.propertyId)
					}
				});
				console.log(answers);
				await Promise.all(
					answers.map(async answer => {
						const question = await this.questionRepository.findOne({ where: { id: answer.questionId }});
						answer["question"] = question;
					})
				);
				workItem["reviews"] = answers;
				workItem["user"] = user;
				delete workItem["stage"];
			})
		);
		return workItems;
	}

	async pendingReviews(body: PropertyIdBody): Promise<number> {
		return await this.workItemRepository.count({ where: {
			propertyId: body.propertyId,
			status: WorkItemStatus.open
	}});
	}
	async deleteProperty(body: PropertyReviewBody): Promise<void> {
		const propertyIds = body.propertyIds;
		await this.propertyRepository.delete({ id: In(propertyIds) });
		await this.propertyGridRepository.delete({ propertyId: In(propertyIds) });
		console.log("Properties deleted with Ids:", propertyIds);
	}


  async getIndex(query: Indexquery): Promise<unknown> {
    if (query.type === 'property') {
      try {
        const gridRltn = await this.propertyGridRepository.find({
          where: {
            propertyId: In(query.ids),
          },
        });
        const responseArr = [];
        await Promise.all(
          gridRltn.map(async (eachRltn) => {
            const tempGrid = await this.gridsRepository.findOne({
              where: {
                id: eachRltn.gridId,
              },
            });
            const indexes = await this.indexmasterRepository.find({
              where: {
                grid: tempGrid,
              },
            });
            const tempObject = {};
            tempObject['propertyId'] = eachRltn.propertyId;
            indexes.forEach((eachIndex) => {
              tempObject[eachIndex.indexName] = eachIndex.indexValue;
            });
            responseArr.push(tempObject);
          })
        );
        return responseArr;
      } catch (error) {
        console.log(error);
        return null;
      }
    }
  }
}
