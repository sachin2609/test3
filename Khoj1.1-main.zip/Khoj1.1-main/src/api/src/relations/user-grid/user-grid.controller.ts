import { Controller, Post, Body, Get } from "@nestjs/common";
import { UserGridService } from "./user-grid.service";
import { ZoneUser, UserGridRequest } from "src/interfaces/user-grid";
import { ApiTags, ApiBody, ApiHeader, ApiResponse } from "@nestjs/swagger";
import { Roles } from "src/helpers/roles-guard/roles-guard.service";
@ApiTags("user-grid")
@Controller("user-grid")
export class UserGridController {
	constructor(private _userGridService: UserGridService) {}

	@Roles("basic")
	@Get()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "get User-Grid" })
	async list(): Promise<ZoneUser[]> {
		return this._userGridService.list();
	}

	@Roles("basic")
	@Post()
	@ApiHeader({ name: "Header" })
	@ApiResponse({ description: "Create User-Grids" })
	@ApiBody({ type: UserGridRequest })
	async create(@Body() userGridRequests: UserGridRequest[]): Promise<UserGridRequest[]> {
		return this._userGridService.create(userGridRequests);
	}
}
