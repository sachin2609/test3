import { Test, TestingModule } from "@nestjs/testing";
import { PoiGridController } from "./poi-grid.controller";

describe("PoiGridController", () => {
	let controller: PoiGridController;

	beforeEach(async () => {
		const module: TestingModule = await Test.createTestingModule({
			controllers: [PoiGridController]
		}).compile();

		controller = module.get<PoiGridController>(PoiGridController);
	});

	it("should be defined", () => {
		expect(controller).toBeDefined();
	});
});
