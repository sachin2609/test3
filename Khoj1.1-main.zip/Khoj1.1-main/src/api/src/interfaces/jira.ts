export class Issue{
    project: {
        id: string;
    };
    summary: string;
    description: string;
    issuetype: {
        id: string;
    }
    issueType?: string; 
}

export class FilterIssue {
    startDate?: Date;
    endDate?: Date;
    userIds?: number[];
    orderBy?: string;
}