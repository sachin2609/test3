import { Module } from "@nestjs/common";
import { HttpModule } from "@nestjs/axios";
import { InsghtGridController } from "./insght-grid.controller";
import { InsghtGridService } from "./insght-grid.service";
import { InsightGrid } from "./insight-grid.entity";
import { Insight } from "../../insight/insight.entity";
import { Grid } from "../../grid/grids.entity";
import { GridService } from "../../grid/grid.service";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Property } from "../../property/property.entity";
import { PoiGrid } from "../poi-grid/poi-grid.entity";
import { Poi } from "../../poi/poi.entity";
import { Indexmaster } from "../../index-master/index-master.entity";
import { PropertyGrid } from "../property-grid/property-grid.entity";
import { MongooseModule } from "@nestjs/mongoose";
import { DemoShapesDBSchema } from "src/shape/shape.schema";
import { Shape } from "src/shape/shape.entity";
import { Shapeindex } from "src/shape/shapeIndex.entity";
import { MongoDatabaseModule } from "src/helpers/mongo-database/mongo-database.module";
import { ShapeDetail } from "src/shape-details/shape-details.entity";
import { ShapeService } from "src/shape/shape.service";
@Module({
	imports: [
		TypeOrmModule.forFeature([
			Insight,
			InsightGrid,
			Grid,
			Property,
			Poi,
			PoiGrid,
			Indexmaster,
			PropertyGrid,
			Shape,
			Shapeindex,
			ShapeDetail
		]),
		MongooseModule.forFeature([{ name: 'DemoShapesDB', schema: DemoShapesDBSchema }]),
		HttpModule.register({
			timeout: 100000,
      		maxRedirects: 100
		}),
		MongoDatabaseModule
	],
	controllers: [InsghtGridController],
	providers: [InsghtGridService, GridService,ShapeService]
})
export class InsghtGridModule {}
