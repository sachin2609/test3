import { Entity, PrimaryColumn } from "typeorm";
import { ApiProperty } from "@nestjs/swagger";

@Entity()
export class PropertyGrid {
	@ApiProperty()
	@PrimaryColumn()
	propertyId: number;

	@ApiProperty()
	@PrimaryColumn()
	gridId: number;
}
