import { Controller, Get, Post, Query, Body, Response } from '@nestjs/common';
import { response } from 'express';
import { Grid } from 'src/grid/grids.entity';
import { ElasticShapeIndex } from 'src/interfaces/shapes';
import { Poi } from 'src/poi/poi.entity';
import { ElasticSearchService } from './elastic-search.service';

@Controller('elastic-search')
export class ElasticSearchController {
    constructor(
        private _elasticSearchService: ElasticSearchService,
    ) {}
    
    @Post('pois')
    async searchPois(@Body() query): Promise<Poi[]> {
        return await this._elasticSearchService.searchPois(query);
    }

    @Get('shapes')
    async searchShapes(@Query() query: Partial<ElasticShapeIndex>): Promise<ElasticShapeIndex[]> {
        return await this._elasticSearchService.searchShapes(query);
    }

    @Post("get-response")
    async getResponse(@Body() body) {
        return await this._elasticSearchService.getResponse(body);
    }

}
