import { Body, Controller, Delete, Get, Headers, Post } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ApiBody, ApiHeader, ApiResponse, ApiTags } from '@nestjs/swagger';
import { InjectRepository } from '@nestjs/typeorm';
import { Roles } from 'src/helpers/roles-guard/roles-guard.service';
import { Repository } from 'typeorm';
import { LayerSet } from './layer-set.entity';
import { LayerSetService } from './layer-set.service';

@ApiTags("layer-set")
@Controller('layer-set')
export class LayerSetController {
	constructor(
		private _layerSetService: LayerSetService,
		private _jwtService: JwtService,
		@InjectRepository(LayerSet) private layerSetRepository: Repository<LayerSet> 
	) {}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create POI" })
	@Post()
	async create(@Body() body,@Headers() header):Promise<unknown> {
		const user = await this._jwtService.decode(header.token);
		return await this._layerSetService.create(body,user["id"]);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create POI" })
	@Get()
	async get(@Headers() header):Promise<unknown> {
		const user = await this._jwtService.decode(header.token);
		return await this._layerSetService.get(user["id"]);
	}

	@Roles("basic")
	@ApiHeader({ name: "Token" })
	@ApiResponse({ description: "Create POI" })
	@Delete()
	async delete(@Body() body:number,@Headers() header):Promise<unknown> {
		const user = await this._jwtService.decode(header.token);
		return await this._layerSetService.delete(body,user["id"]);
	}
}
